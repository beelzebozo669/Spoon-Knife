  select *
    from v$lock;

  select *
    from v$lock
   where block = 1;

ADDR             KADDR                   SID TY        ID1        ID2      LMODE    REQUEST      CTIME      BLOCK     CON_ID
---------------- ---------------- ---------- -- ---------- ---------- ---------- ---------- ---------- ---------- ----------
07000100A79F46C0 07000100A79F4740       4602 TX    1703966    1543487          6          0       9473          1          0
   
  select l1.sid, ' IS BLOCKING ', l2.sid
    from v$lock l1, v$lock l2
   where l1.block = 1
     and l2.request > 0
     and l1.id1 = l2.id1
     and l1.id2 = l2.id2;
  
       SID 'ISBLOCKING'         SID
---------- ------------- ----------
      4602  IS BLOCKING        3364


  select s1.username || '@' || s1.machine||
         ' ( SID=' || s1.sid || ' )  is blocking '||
		 s2.username || '@' || s2.machine ||
		 ' ( SID=' || s2.sid || ' ) ' AS blocking_status
   from v$lock    l1,
        v$session s1,
        v$lock    l2,
        v$session s2
  where s1.sid = l1.sid
    and s2.sid = l2.sid
    and l1.BLOCK = 1
    and l2.request > 0
    and l1.id1 = l2.id1
    and l2.id2 = l2.id2 ;

BLOCKING_STATUS
--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
CLASS@SLC_NT\CZC6517JTQ ( SID=4602 )  is blocking CLASS@SLC_NT\CZC6517JTQ ( SID=3364 )


  select object_name
    from dba_objects
   where object_id = 1703966;


  select object_name
    from dba_objects
   where object_id = 1543487;


  select row_wait_obj#, row_wait_file#, row_wait_block#, row_wait_row#
    from v$session
   where sid = 4602 ;
  
ROW_WAIT_OBJ# ROW_WAIT_FILE# ROW_WAIT_BLOCK# ROW_WAIT_ROW#
------------- -------------- --------------- -------------
        57138             85           62392             0


  select do.object_name,
         row_wait_obj#, row_wait_file#, row_wait_block#, row_wait_row#,
         dbms_rowid.rowid_create ( 1, ROW_WAIT_OBJ#, ROW_WAIT_FILE#, ROW_WAIT_BLOCK#, ROW_WAIT_ROW# )
    from v$session s, dba_objects do
   where sid = 4602
     and s.ROW_WAIT_OBJ# = do.OBJECT_ID ;


OBJECT_NAME                    ROW_WAIT_OBJ# ROW_WAIT_FILE# ROW_WAIT_BLOCK# ROW_WAIT_ROW# DBMS_ROWID.ROWID_C
------------------------------ ------------- -------------- --------------- ------------- ------------------
LAC_PK                                 57138             85           62392             0 AAAN8yABVAAAPO4AAA



OR


column "wait event" format a50 word_wrap
column "session" format a25
column "minutes" format 9999D9
column CHAIN_ID noprint
column N noprint
column l noprint

with w as (
select
 chain_id,rownum n,level l
 ,lpad(' ',level,' ')||(select instance_name from gv$instance where inst_id=w.instance)||' '''||w.sid||','||w.sess_serial#||'@'||w.instance||'''' "session"
 ,lpad(' ',level,' ')||w.wait_event_text ||
   case
   when w.wait_event_text like 'enq: TM%' then
    ' mode '||decode(w.p1 ,1414332418,'Row-S' ,1414332419,'Row-X' ,1414332420,'Share' ,1414332421,'Share RX' ,1414332422,'eXclusive')
     ||( select ' on '||object_type||' "'||owner||'"."'||object_name||'" ' from all_objects where object_id=w.p2 )
   when w.wait_event_text like 'enq: TX%' then
    (
     select ' on '||object_type||' "'||owner||'"."'||object_name||'" on rowid '
     ||dbms_rowid.rowid_create(1,data_object_id,relative_fno,w.row_wait_block#,w.row_wait_row#)
     from all_objects ,dba_data_files where object_id=w.row_wait_obj# and w.row_wait_file#=file_id
    )
   end "wait event"
 , w.in_wait_secs/60 "minutes"
 , s.username , s.program
 from v$wait_chains w join gv$session s on (s.sid=w.sid and s.serial#=w.sess_serial# and s.inst_id=w.instance)
 connect by prior w.sid=w.blocker_sid and prior w.sess_serial#=w.blocker_sess_serial# and prior w.instance = w.blocker_instance
 start with w.blocker_sid is null
)
select * from w where chain_id in (select chain_id from w group by chain_id having max("minutes") >= 1 and max(l)>1 )
order by n;


==================================================

  SELECT sid,serial#,audsid,paddr,user#,username,command,lockwait,status,server,schema#,schemaname,osuser,process,machine,port,terminal,program,type,sql_address,sql_hash_value,sql_id             
    FROM v$session
   WHERE sid = 1259;

==================================================
SET LINES 300 
SET PAGES 999

COL SID FOR 99999
COL SERIAL# FOR 99999
COL EVENT FOR A30

  SELECT SID, SERIAL#, SQL_ID, EVENT, SECONDS_IN_WAIT, BLOCKING_SESSION
    FROM V$SESSION
   WHERE BLOCKING_SESSION IS NOT NULL;

==================================================
==================================================
==================================================
==================================================
==================================================
ALTER SYSTEM KILL SESSION '3364,57696@1' IMMEDIATE;

==================================================
DBA_BLOCKERS
DBA_DDL_LOCKS
DBA_DML_LOCKS
DBA_HIST_CR_BLOCK_SERVER
DBA_HIST_CURRENT_BLOCK_SERVER
DBA_KGLLOCK
DBA_LOCK
DBA_LOCK_INTERNAL
DBA_RECOVERABLE_SCRIPT_BLOCKS
DBA_LOCKS
==================================================