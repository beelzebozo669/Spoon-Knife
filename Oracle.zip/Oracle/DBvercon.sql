SET LINESIZE 100
SET PAGESIZE 60
SET VERIFY OFF

TTITLE CENTER "Database Version" SKIP 2

  SELECT version
    FROM v$instance;

TTITLE CENTER "Database Tablespace Summary" SKIP 2

  SELECT tablespace_name, tablespace_size, ROUND(used_percent,2) percent
    FROM dba_tablespace_usage_metrics
ORDER BY tablespace_name;

TTITLE CENTER "Database Containers" SKIP 2

  SELECT con_id, name, open_mode
    FROM V$CONTAINERS
ORDER BY con_id;

TTITLE CENTER "Database ConnectID Tablespace Summary" SKIP 2

  SELECT con_id, tablespace_name, tablespace_size, ROUND(used_percent,2) percent
    FROM cdb_tablespace_usage_metrics
ORDER BY con_id, tablespace_name;

TTITLE CENTER "Database View Prefix" SKIP 2

COLUMN view_prefix NEW_VALUE view_prefix

  SELECT DECODE(SUBSTR(version,1,INSTR(version,'.')-1),'12','CDB','DBA') view_prefix
    FROM v$instance;

SET VERIFY ON

PROMPT &view_prefix

PROMPT &view_prefix._TABLESPACE_USAGE_METRICS

SET VERIFY OFF

TTITLE CENTER "Database Container Tablespace Summary" SKIP 2

  SELECT tablespace_name, tablespace_size, ROUND(used_percent,2) percent
   FROM &view_prefix._tablespace_usage_metrics
ORDER BY tablespace_name;

TTITLE CENTER "Database Version" SKIP 2

COLUMN view_prefix NEW_VALUE view_prefix NOPRINT
  SELECT DECODE(SUBSTR(version,1,INSTR(version,'.')-1),'12','CDB','DBA') view_prefix
    FROM v$instance;

TTITLE CENTER "Database Version" SKIP 2

COLUMN con_id_col NEW_VALUE con_id_col NOPRINT
  SELECT DECODE(SUBSTR(version,1,INSTR(version,'.')-1),'12','con_id,','') con_id_col
    FROM v$instance;

TTITLE CENTER "Database Version" SKIP 2

  SELECT &con_id_col MIN(extended_timestamp), MAX(extended_timestamp)
    FROM &view_prefix._audit_trail
GROUP BY &con_id_col 1
ORDER BY &con_id_col 1;

CLEAR COLUMNS

TTITLE OFF

UNDEFINE con_id_col
UNDEFINE view_prefix





  