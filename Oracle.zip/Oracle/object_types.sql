SET LINESIZE 60
SET PAGESIZE 60

COLUMN object_type FORMAT A30 HEADING "Object Types"

TTITLE CENTER "Objects In Database" SKIP 2

  SELECT DISTINCT object_type
    FROM dba_objects
ORDER BY object_type;

CLEAR COLUMNS

SET LINESIZE 80
SET PAGESIZE 20
