SET ECHO OFF
SET VERIFY OFF
SET LOGSOURCE "Dummy"
STORE SET temp.tmp REPLACE

CLEAR BREAKS
CLEAR COLUMNS
CLEAR COMPUTES

SET PAGESIZE 24 LINESIZE 150

PROMPT
PROMPT Please enter Synonym Owner and/or Destination-Object Owner, wildcards allowed
PROMPT
PROMPT eg.: SCOTT, S% , % or PUBLIC
PROMPT
ACCEPT s_owner      CHAR PROMPT "Synonym Owner <PUBLIC>    : " DEFAULT "PUBLIC"
ACCEPT s_dest_owner CHAR PROMPT "Destination Owner <%>     : " DEFAULT "%"

@@foenvtit "Synonyms Report"

COLUMN owner        FORMAT A30 HEADING "Synonym Owner"
COLUMN synonym_name FORMAT A30 HEADING "Synonym Name"
COLUMN object_owner FORMAT A30 HEADING "Dest-Obj Owner"
COLUMN object_name  FORMAT A30 HEADING "Dest-Obj Name"
COLUMN object_type  FORMAT A30 HEADING "Type"

  SELECT owner,
             synonym_name,
                 object_owner,
                 object_name,
                 object_type
    FROM jc_synonyms
   WHERE owner LIKE UPPER('&v_owner')
     AND object_owner LIKE UPPER('&v_dest_owner')
ORDER BY owner, synonym_name, object_owner, object_name;

TTITLE OFF

PROMPT  Type "n/a": the synonym points to nowhere, and probably could be dropped
PROMPT

UNDEFINE s_owner
UNDEFINE s_dest_owner

@temp.tmp
