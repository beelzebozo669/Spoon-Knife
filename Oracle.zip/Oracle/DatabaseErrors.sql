DROP TRIGGER jc_errors_trig;

DROP TABLE   jc_errors_tab;
 
CREATE TABLE jc_errors_tab
(
error      VARCHAR2(30),
timestamp  DATE,
user#      NUMBER,
username   VARCHAR2(30),
osuser     VARCHAR2(30),
sid        NUMBER,
serial#    NUMBER,
command    NUMBER,
ownerid    NUMBER,
taddr      VARCHAR2(16),
lockwait   VARCHAR2(16),
status     VARCHAR2(8),
server     VARCHAR2(9),
schemaname VARCHAR2(30),
process    VARCHAR2(34),
machine    VARCHAR2(64),
port       NUMBER,
terminal   VARCHAR2(30),
program    VARCHAR2(48),
type       VARCHAR2(10),
wait_class VARCHAR2(64)
);
 
CREATE OR REPLACE TRIGGER jc_errors_trig 
     after servererror ON database
DECLARE
	var_user#      NUMBER;
	var_username   VARCHAR2(30);
	var_osuser     VARCHAR2(30);
	var_sid        NUMBER;
	var_serial#    NUMBER;
	var_command    NUMBER;
	var_ownerid    NUMBER;
	var_taddr      VARCHAR2(16);
	var_lockwait   VARCHAR2(16);
	var_status     VARCHAR2(8);
	var_server     VARCHAR2(9);
	var_schemaname VARCHAR2(30);
	var_process    VARCHAR2(34);
	var_machine    VARCHAR2(64);
	var_port       NUMBER;
	var_terminal   VARCHAR2(30);
	var_program    VARCHAR2(48);
	var_type       VARCHAR2(10);
	var_wait_class VARCHAR2(64);
BEGIN
     SELECT user#, username, osuser, sid, serial#, command, ownerid, taddr, lockwait, status, server, schemaname, process, machine, port, terminal, program, type, wait_class
     INTO   var_user#, var_username, var_osuser, var_sid, var_serial#, var_command, var_ownerid, var_taddr, var_lockwait, var_status, var_server, var_schemaname, var_process, var_machine, var_port, var_terminal, var_program, var_type, var_wait_class
     FROM   sys.v_$session
     WHERE  audsid = USERENV('sessionid');
 
     INSERT INTO jc_errors_tab
       VALUES(dbms_standard.server_error(1),
              SYSDATE,
              var_user#,
			  var_username,
			  var_osuser,
			  var_sid,
			  var_serial#,
			  var_command,
			  var_ownerid,
			  var_taddr,
			  var_lockwait,
			  var_status,
			  var_server,
			  var_schemaname,
			  var_process,
			  var_machine,
			  var_port,
			  var_terminal,
			  var_program,
			  var_type,
			  var_wait_class);
END;
/

SET LINESIZE 500
SET PAGESIZE 30

COLUMN error      FORMAT A15          HEADING "Error#"
COLUMN timestamp  FORMAT A20          HEADING "Date"
COLUMN user#      FORMAT 999999       HEADING "User#"
COLUMN username   FORMAT A20          HEADING "User Name"
COLUMN osuser     FORMAT A30          HEADING "OS User"
COLUMN sid        FORMAT 999999999    HEADING "Sid"
COLUMN serial#    FORMAT 999999999    HEADING "Serial#"
COLUMN sidserial  FORMAT A12          HEADING "Sid and Serial#"
COLUMN command    FORMAT 99999999     HEADING "Command"
COLUMN ownerid    FORMAT 999999999999 HEADING "Owner Id"
COLUMN taddr      FORMAT A16          HEADING "Taddr"
COLUMN lockwait   FORMAT A16          HEADING "Lock Wait"
COLUMN status     FORMAT A8           HEADING "Status"
COLUMN server     FORMAT A9           HEADING "Server"
COLUMN schemaname FORMAT A20          HEADING "Schema Name"
COLUMN process    FORMAT A17          HEADING "Process"
COLUMN machine    FORMAT A32          HEADING "Machine"
COLUMN port       FORMAT 999999999    HEADING "Port#"
COLUMN terminal   FORMAT A15          HEADING "Terminal"
COLUMN program    FORMAT A24          HEADING "Program"
COLUMN type       FORMAT A10          HEADING "Type"
COLUMN wait_class FORMAT A20          HEADING "Wait Class"

  SELECT *
    FROM jc_errors_tab
ORDER BY timestamp;

  SELECT error,
         TO_CHAR(timestamp,'DD/MM/YYYY HH24:MI:SS'),
         --user#,
         username,
         osuser,
         sid || ', ' || serial# AS sidserial,
         --command,
         --ownerid,
         --taddr,
         --lockwait,
         status,
         --server,
         --schemaname,
         --process,
         machine,
         --port,
         terminal,
         program,
         type,
         wait_class
    FROM jc_errors_tab
ORDER BY sid, serial#, timestamp;

