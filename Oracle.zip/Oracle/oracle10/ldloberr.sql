rem -------------------------------------------------------------------------
rem        Trivadis AG, Baden/Basel/Bern/Lausanne/Z�rich
rem                     Frankfurt/Freiburg i.Br./M�nchen/Stuttgart
rem                     Switzerland/Germany Internet: http://www.trivadis.com
rem -------------------------------------------------------------------------
rem   $Header$
rem   **********************************************************************
rem
rem   Group/Privileges.: DBA
rem   Script-Name......: ldloberr.sql
rem   Developer........: Andri Kisseleff (ank) andri.kisseleff@trivadis.com
rem   Date.............: Sept.2000
rem   Version..........: Oracle10g (Written originally with 8.1.6)
rem   Usage............: Shows LOBs which are not able to allocate further 
rem                      extents
REM                      All cases: do not show if TS is READ ONLY
rem                      Case 1: LOBs in tables
rem                      - Case 1a: LOB Segments where next extent is > then max freespace in TS
rem                      - Case 1b: LOB Segments where TS is 100% full
rem                      - Case 1c: 1a+1b only if NOT a datafile (DF) of the TS has AUTOEXTENT ON
rem                      - Case 1d: LOB Segments where nbr. extents reached max_extents
rem                      Case 2: LOBs in range part. tables + hash part. tables the same case
rem                      Case 3: LOBs in composite part. tables
rem                      Case 4: LOBs in tables in locally managed TS
rem                      Case 5: LOBs in range part. tables + hash part. tables in locally mgmt. TS
rem                      Case 6: LOBs in composite part. tables in locally mgmt. TS
rem                      
rem   Input parameters.:
rem   Output.......... : ldloberr.lis
rem   Called by........:
rem   Remarks..........: LOBs in IOTs (Index Organized Tables) are also supported by this script
rem                      Actually (8.1.6) Oracle does not support LOBs in partitioned IOTs
rem                      If once this will be supported this will have to be tested/added
rem			 10g 10.1 Tested LOBs in part. IOTs. OK AnK
rem
rem
rem			Segments in locally managed tablespaces AUTOALLOCATE have
rem			NEXT_EXTENT = NULL in the DD. We assume, that if 64K
rem			would be available, the segment could allocate a next extent
rem			(tested with 10.1. AnK). A large Lob in an AUTOALLOCATE TS
rem                     needing to allocate an additional extent and only 64K are
rem			available in DBA_FREE_SPACE and no file AUTOEXTEND --> works.
rem			The LOB takes the 64K.
rem
rem -----------------------------------------------------------------------
rem
rem $Log$
rem Revision 1.2  2004/04/25 18:30:05  mnb
rem Name of objects in recycle bin is 'BIN$%' (instead of 'RB$%' in 10g beta)
rem
rem Revision 1.1  2003/09/16 08:38:19  ank
rem - OK for 10.1
rem (now also supporting locally managed AUTOALLOCATE (NEXT_EXTENT is NULL in the DD)
rem - Support for LOBs in partitioned IOTs
rem - Excluded LOBs of tables in the recycle bin
rem
rem Revision 1.3  2002/09/09 16:56:24  far
rem 9.2 f�hig checked by ThJ
rem
rem Revision 1.2  2001/07/22 12:59:28  ank
rem - Load initial release Oracle9i 9.0.x
rem
rem
rem
rem Changes:
rem DD.MM.YYYY Consultant Change
rem 04.09.2002 ThJ        OK for Oracle9i R2
rem
rem
rem -----------------------------------------------------------------------
rem
rem 
	rem
    ACCEPT user_namen CHAR PROMPT     'Username or Wildcard <%>: ' DEFAULT '%'
    ACCEPT tabellen_namen CHAR PROMPT 'Tablename or Wildcard <%> : ' DEFAULT '%'
    ACCEPT partitionen_namen CHAR PROMPT 'Partitionname or Wildcard <%>: ' DEFAULT '%'
    ACCEPT subpartitionen_namen CHAR PROMPT 'Subpartitionname or Wildcard <%>: ' DEFAULT '%'

	SET ECHO OFF TERMOUT ON


	SET PAGES 48 LINES 130 VERIFY OFF
	COLUMN datum		NEW_VALUE	datum	NOPRINT
	COLUMN extents		FORMAT		999	HEADING EXT
	COLUMN used_blocks	FORMAT		9999999 HEADING USED_BLCK
	COLUMN allo_blocks	FORMAT		9999999 HEADING ALLO_BLCK
	COLUMN space_for_recs	FORMAT 	9999999
	COLUMN next_extent	FORMAT		99999999	HEADING NEXT_EXT
    
	rem
	SET ECHO OFF TERMOUT OFF
    @@foenvtit "LOBs unable to allocate a next extent"
	SPOOL ldloberr.lis
        

	SET ECHO OFF TERMOUT ON

    SELECT  TO_CHAR(SYSDATE,'DD.MM.YY') datum,   /* Case 1: Lob Segments in Tables */
	       RPAD(L.owner,10,'.') OWNER,
               RPAD(L.table_name,10,'.') TABLE_NAME,
	       RPAD(L.column_name,20,'.') COLUMN_NAME,
   	       RPAD('.',20,'.') PARTITION_NAME,
	       RPAD(S.tablespace_name,10,'.') TABLESPACE_NAME,
	       extents,
	       S.blocks ALLO_BLOCKS,
	       nvl(S.next_extent,65536) NEXT_EXTENT
	FROM   sys.dba_lobs L, sys.dba_segments S, sys.dba_tablespaces TS
	WHERE  L.owner = S.owner
	AND    L.segment_name = S.segment_name
	AND    TS.tablespace_name = S.tablespace_name
        AND    TS.STATUS != 'READ ONLY'
        AND    TS.EXTENT_MANAGEMENT = 'DICTIONARY'
	AND    L.owner LIKE UPPER('&user_namen')
	AND    L.table_name LIKE UPPER('&tabellen_namen')
        AND    L.table_name NOT LIKE 'BIN$%'
        AND    S.SEGMENT_TYPE = 'LOBSEGMENT'
	AND    ((( nvl(S.next_extent,65536) > ( SELECT   MAX(F.bytes)    /* +Case 1a: not enough free space */
		   	           FROM   sys.dba_free_space F
				   WHERE  F.tablespace_name = S.tablespace_name)
              OR          NOT EXISTS (SELECT  ''            /* +Case 1b: no free space at all */
                               FROM   sys.dba_free_space F
                               WHERE  F.tablespace_name = TS.tablespace_name))
           AND    NOT EXISTS (SELECT '' /* - Case 1c: do not show if DF of TS has AUTOEXTEND ON */
                       FROM   sys.dba_data_files F
                       WHERE  F.tablespace_name = TS.tablespace_name
                       AND    F.autoextensible = 'YES'))
         OR     S.EXTENTS >= S.MAX_EXTENTS) /* +Case 1d: LOB has reached MAXEXTENTS */
 UNION /* LOB Segments in Range Part. Tables + Hash Part. Tables */
    SELECT  TO_CHAR(SYSDATE,'DD.MM.YY') datum,   /* Case 2: Lob Segments in range + hash part. Tables */
	       RPAD(L.table_owner,10,'.') OWNER,
               RPAD(L.table_name,10,'.') TABLE_NAME,
	       RPAD(L.column_name,20,'.') COLUMN_NAME,
   	       RPAD(L.partition_name||' '||L.lob_partition_name,30,'.') PARTITION_NAME,
	       RPAD(S.tablespace_name,10,'.') TABLESPACE_NAME,
	       extents,
	       S.blocks ALLO_BLOCKS,
	       nvl(S.next_extent,65536) NEXT_EXTENT
	FROM   sys.dba_lob_partitions L, sys.dba_segments S, sys.dba_tablespaces TS
	WHERE  L.table_owner = S.owner
	AND    L.lob_name = S.segment_name
        AND    L.lob_partition_name = S.partition_name
	AND    TS.tablespace_name = S.tablespace_name
        AND    TS.STATUS != 'READ ONLY'
        AND    TS.EXTENT_MANAGEMENT = 'DICTIONARY'
	AND    L.table_owner LIKE UPPER('&user_namen')
	AND    L.table_name LIKE UPPER('&tabellen_namen')
        AND    L.table_name NOT LIKE 'BIN$%'
        AND    L.lob_partition_name like UPPER('&partitionen_namen')
        AND    S.SEGMENT_TYPE = 'LOB PARTITION'
	AND    ((( nvl(S.next_extent,65536) > ( SELECT   MAX(F.bytes)    /* +Case 2a: not enough free space */
		   	           FROM   sys.dba_free_space F
				   WHERE  F.tablespace_name = S.tablespace_name)
              OR          NOT EXISTS (SELECT  ''            /* +Case 2b: no free space at all */
                               FROM   sys.dba_free_space F
                               WHERE  F.tablespace_name = TS.tablespace_name))
           AND    NOT EXISTS (SELECT '' /* - Case 2c: do not show if DF of TS has AUTOEXTEND ON */
                       FROM   sys.dba_data_files F
                       WHERE  F.tablespace_name = TS.tablespace_name
                       AND    F.autoextensible = 'YES'))
         OR     S.EXTENTS >= S.MAX_EXTENTS) /* +Case 2d: LOB has reached MAXEXTENTS */
UNION /* LOB Segments Composite part. tables */
    SELECT  TO_CHAR(SYSDATE,'DD.MM.YY') datum,   /* Case 3: Lob Segments in Comp. part. Tables */
	       RPAD(L.table_owner,10,'.') OWNER,
               RPAD(L.table_name,10,'.') TABLE_NAME,
	       RPAD(L.column_name,20,'.') COLUMN_NAME,
   	       RPAD(L.lob_partition_name||' '||L.subpartition_name,30,'.') PARTITION_NAME,
	       RPAD(S.tablespace_name,10,'.') TABLESPACE_NAME,
	       extents,
	       S.blocks ALLO_BLOCKS,
	       nvl(S.next_extent,65536) NEXT_EXTENT
	FROM   sys.dba_lob_subpartitions L, sys.dba_segments S, sys.dba_tablespaces TS
	WHERE  L.table_owner = S.owner
	AND    L.lob_name = S.segment_name
        AND    L.lob_subpartition_name = S.partition_name
	AND    TS.tablespace_name = S.tablespace_name
        AND    TS.STATUS != 'READ ONLY'
        AND    TS.EXTENT_MANAGEMENT = 'DICTIONARY'
	AND    L.table_owner LIKE UPPER('&user_namen')
	AND    L.table_name LIKE UPPER('&tabellen_namen')
        AND    L.table_name NOT LIKE 'BIN$%'
        AND    L.lob_subpartition_name like UPPER('&subpartitionen_namen')
        AND    S.SEGMENT_TYPE = 'LOB SUBPARTITION'
	AND    ((( nvl(S.next_extent,65536) > ( SELECT   MAX(F.bytes)    /* +Case 3a: not enough free space */
		   	           FROM   sys.dba_free_space F
				   WHERE  F.tablespace_name = S.tablespace_name)
              OR          NOT EXISTS (SELECT  ''            /* +Case 3b: no free space at all */
                               FROM   sys.dba_free_space F
                               WHERE  F.tablespace_name = TS.tablespace_name))
           AND    NOT EXISTS (SELECT '' /* - Case 3c: do not show if DF of TS has AUTOEXTEND ON */
                       FROM   sys.dba_data_files F
                       WHERE  F.tablespace_name = TS.tablespace_name
                       AND    F.autoextensible = 'YES'))
         OR     S.EXTENTS >= S.MAX_EXTENTS) /* +Case 3d: LOB has reached MAXEXTENTS */
UNION /* Lob Segments in tables in locally managed TS */
     SELECT  TO_CHAR(SYSDATE,'DD.MM.YY') datum,   /* Case 4: Lob Segments in Tables in locally mgmt. TS */
	       RPAD(L.owner,10,'.') OWNER,
               RPAD(L.table_name,10,'.') TABLE_NAME,
	       RPAD(L.column_name,20,'.') COLUMN_NAME,
   	       RPAD('.',20,'.') PARTITION_NAME,
	       RPAD(S.tablespace_name,10,'.') TABLESPACE_NAME,
	       extents,
	       S.blocks ALLO_BLOCKS,
	       nvl(S.next_extent,65536) NEXT_EXTENT
	FROM   sys.dba_lobs L, sys.dba_segments S, sys.dba_tablespaces TS
	WHERE  L.owner = S.owner
	AND    L.segment_name = S.segment_name
	AND    TS.tablespace_name = S.tablespace_name
        AND    TS.STATUS != 'READ ONLY'
        AND    TS.EXTENT_MANAGEMENT = 'LOCAL'
	AND    L.owner LIKE UPPER('&user_namen')
	AND    L.table_name LIKE UPPER('&tabellen_namen')
        AND    L.table_name NOT LIKE 'BIN$%'
        AND    S.SEGMENT_TYPE = 'LOBSEGMENT'
	AND    ((( nvl(S.next_extent,65536) > ( SELECT   MAX(F.bytes)    /* +Case 4a: not enough free space */
		   	           FROM   sys.dba_free_space F
				   WHERE  F.tablespace_name = S.tablespace_name)
              OR          NOT EXISTS (SELECT  ''            /* +Case 4b: no free space at all */
                               FROM   sys.dba_free_space F
                               WHERE  F.tablespace_name = TS.tablespace_name))
           AND    NOT EXISTS (SELECT '' /* - Case 4c: do not show if DF of TS has AUTOEXTEND ON */
                       FROM   sys.dba_data_files F
                       WHERE  F.tablespace_name = TS.tablespace_name
                       AND    F.autoextensible = 'YES'))
         OR     S.EXTENTS >= S.MAX_EXTENTS) /* +Case 4d: LOB has reached MAXEXTENTS */
UNION /* LOB in Range/Hash part. Table in locally managed TS */
   SELECT  TO_CHAR(SYSDATE,'DD.MM.YY') datum,   /* Case 5: Lob Segments in range + hash part. Tables */
	       RPAD(L.table_owner,10,'.') OWNER,
               RPAD(L.table_name,10,'.') TABLE_NAME,
	       RPAD(L.column_name,20,'.') COLUMN_NAME,
   	       RPAD(L.partition_name||' '||L.lob_partition_name,30,'.') PARTITION_NAME,
	       RPAD(S.tablespace_name,10,'.') TABLESPACE_NAME,
	       extents,
	       S.blocks ALLO_BLOCKS,
	       nvl(S.next_extent,65536) NEXT_EXTENT
	FROM   sys.dba_lob_partitions L, sys.dba_segments S, sys.dba_tablespaces TS
	WHERE  L.table_owner = S.owner
	AND    L.lob_name = S.segment_name
        AND    L.lob_partition_name = S.partition_name
	AND    TS.tablespace_name = S.tablespace_name
        AND    TS.STATUS != 'READ ONLY'
        AND    TS.EXTENT_MANAGEMENT = 'LOCAL'
	AND    L.table_owner LIKE UPPER('&user_namen')
	AND    L.table_name LIKE UPPER('&tabellen_namen')
        AND    L.table_name NOT LIKE 'BIN$%'
        AND    L.lob_partition_name like UPPER('&partitionen_namen')
        AND    S.SEGMENT_TYPE = 'LOB PARTITION'
	AND    ((( nvl(S.next_extent,65536) > ( SELECT   MAX(F.bytes)    /* +Case 5a: not enough free space */
		   	           FROM   sys.dba_free_space F
				   WHERE  F.tablespace_name = S.tablespace_name)
              OR          NOT EXISTS (SELECT  ''            /* +Case 5b: no free space at all */
                               FROM   sys.dba_free_space F
                               WHERE  F.tablespace_name = TS.tablespace_name))
           AND    NOT EXISTS (SELECT '' /* - Case 5c: do not show if DF of TS has AUTOEXTEND ON */
                       FROM   sys.dba_data_files F
                       WHERE  F.tablespace_name = TS.tablespace_name
                       AND    F.autoextensible = 'YES'))
         OR     S.EXTENTS >= S.MAX_EXTENTS) /* +Case 5d: LOB has reached MAXEXTENTS */
UNION /* LOB in comp. part Table in locally managed TS */
    SELECT  TO_CHAR(SYSDATE,'DD.MM.YY') datum,   /* Case 6: Lob Segments in Comp. part. Tables */
	       RPAD(L.table_owner,10,'.') OWNER,
               RPAD(L.table_name,10,'.') TABLE_NAME,
	       RPAD(L.column_name,20,'.') COLUMN_NAME,
   	       RPAD(L.lob_partition_name||' '||L.subpartition_name,30,'.') PARTITION_NAME,
	       RPAD(S.tablespace_name,10,'.') TABLESPACE_NAME,
	       extents,
	       S.blocks ALLO_BLOCKS,
	       nvl(S.next_extent,65536) NEXT_EXTENT
	FROM   sys.dba_lob_subpartitions L, sys.dba_segments S, sys.dba_tablespaces TS
	WHERE  L.table_owner = S.owner
	AND    L.lob_name = S.segment_name
        AND    L.lob_subpartition_name = S.partition_name
	AND    TS.tablespace_name = S.tablespace_name
        AND    TS.STATUS != 'READ ONLY'
        AND    TS.EXTENT_MANAGEMENT = 'LOCAL'
	AND    L.table_owner LIKE UPPER('&user_namen')
	AND    L.table_name LIKE UPPER('&tabellen_namen')
        AND    L.table_name NOT LIKE 'BIN$%'
        AND    L.lob_subpartition_name like UPPER('&subpartitionen_namen')
        AND    S.SEGMENT_TYPE = 'LOB SUBPARTITION'
	AND    ((( nvl(S.next_extent,65536) > ( SELECT   MAX(F.bytes)    /* +Case 6a: not enough free space */
		   	           FROM   sys.dba_free_space F
				   WHERE  F.tablespace_name = S.tablespace_name)
              OR          NOT EXISTS (SELECT  ''            /* +Case 6b: no free space at all */
                               FROM   sys.dba_free_space F
                               WHERE  F.tablespace_name = TS.tablespace_name))
           AND    NOT EXISTS (SELECT '' /* - Case 6c: do not show if DF of TS has AUTOEXTEND ON */
                       FROM   sys.dba_data_files F
                       WHERE  F.tablespace_name = TS.tablespace_name
                       AND    F.autoextensible = 'YES'))
         OR     S.EXTENTS >= S.MAX_EXTENTS) /* +Case 6d: LOB has reached MAXEXTENTS */
order by 1,2,3,4,5
/
	SPOOL OFF
	SET VERIFY ON TERMOUT ON PAGES 24 LINES 80
	TTITLE OFF
	CLEAR COMPUTES BREAKS
	COLUMN datum		clear
	COLUMN extents		clear
	COLUMN used_blocks	clear
	COLUMN allo_blocks	clear
	COLUMN space_for_recs	clear
	COLUMN next_extent	clear

	PROMPT
	PROMPT ldloberr.lis has been spooled (A4 landscape)
	PROMPT
SET TERMOUT ON
