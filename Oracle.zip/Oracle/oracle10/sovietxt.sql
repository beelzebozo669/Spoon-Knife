rem -------------------------------------------------------------------------
rem        Trivadis AG, Baden/Basel/Bern/Lausanne/Z�rich
rem                     Frankfurt/Freiburg i.Br./M�nchen/Stuttgart
rem                     Switzerland/Germany Internet: http://www.trivadis.com
rem -------------------------------------------------------------------------
rem   $Header$
rem   **********************************************************************
rem   Group/Privileges.: Owner (Utilities)
rem   Script-Name......: sovietxt.sql
rem   Developer........: Urs Meier (urm) urs.meier@trivadis.com
rem   Date.............: 1994
rem   Version..........: Oracle10g
rem   Usage............: Show the text for a views. The script automatically
rem                      adjusts the necessary settings for long.
rem   Input parameters.:
rem   Output.......... : 
rem   Called by........:
rem   Remarks..........:
rem -----------------------------------------------------------------------
rem
rem $Log$
rem Revision 1.2  2003/09/15 09:02:06  ank
rem - added store set as to reset the SQL*Plus settings
rem
rem Revision 1.1  2003/09/15 09:00:36  ank
rem - OK for 10.1
rem
rem Revision 1.3  2002/09/09 16:56:24  far
rem 9.2 f�hig checked by ThJ
rem
rem Revision 1.2  2001/07/22 12:59:28  ank
rem - Load initial release Oracle9i 9.0.x
rem
rem
rem Changes:
rem DD.MM.YYYY Consultant Change
rem -----------------------------------------------------------------------
rem 05.04.1997 urs.meier  rename
rem 02.08.1997 AnK        Oracle8
rem 21.04.1999 AnK        OK for Oracle8i
rem 03.09.2002 ThJ        OK for Oracle9i R2
rem -----------------------------------------------------------------------
rem
rem
store set temp.tmp replace
ACCEPT vname CHAR PROMPT "Text for View(s) [%]: " Default "%"

SET PAUSE OFF -
    ECHO OFF -
    TERMOUT OFF
CLEAR COLUMNS -
      BREAKS -
      COMPUTES
COLUMN maxlong  NOPRINT NEW_VALUE maxlong
COLUMN viewname NOPRINT NEW_VALUE viewname

SELECT MAX(text_length) maxlong
 FROM user_views
WHERE view_name LIKE UPPER('&&vname');

SET LONG &maxlong

SET TERMOUT ON -
    FEEDBACK ON -
    VERIFY OFF 
   
@@fopauon

BREAK ON viewname SKIP PAGE

TTITLE CENTER "View description for "viewname

SELECT view_name viewname, text
 FROM user_views
WHERE view_name LIKE UPPER('&&vname')
ORDER BY view_name;

set LONG 80
TTITLE OFF
col maxlong clear
col viewname clear
@@fopauoff
set echo off
@temp.tmp

