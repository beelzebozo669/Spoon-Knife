rem -------------------------------------------------------------------------
rem        Trivadis AG, Baden/Basel/Bern/Lausanne/Z�rich
rem                     Frankfurt/Freiburg i.Br./M�nchen/Stuttgart
rem                     Switzerland/Germany Internet: http://www.trivadis.com
rem -------------------------------------------------------------------------
rem   $Header$
rem   **********************************************************************
rem   Privilegien......: SYS
rem   Name.............: sssavsta.sql
rem   Entwickler.......: Sven Vetter (ssv) Sven.Vetter@trivadis.com
rem   Datum............: 22.08.1999
rem   Version..........: Oracle10g
rem   Zweck............: Programm zum Abspeichern und Vergleichen von Statistiken
rem                      aus v$sysstat und v$waitstat
rem   Input parameters.:
rem   Output.......... : 
rem   Called by........:
rem   Remarks..........: To be run while connected as SYS
rem -----------------------------------------------------------------------
rem
rem $Log$
rem Revision 1.1  2003/09/10 08:24:32  ank
rem - OK for 10.1
rem
rem Revision 1.3  2002/09/09 16:56:24  far
rem 9.2 f�hig checked by ThJ
rem
rem Revision 1.2  2001/07/22 12:59:28  ank
rem - Load initial release Oracle9i 9.0.x
rem
rem
rem
rem Changes:
rem DD.MM.YYYY Consultant Ver Change
rem 21.04.1999 ssv        1.1 Bessere Formatierung der Ausgabe
rem 22.08.1999 ssv        2.0 ReDesign der Datenspeicherung (2 Tabellen)
rem 04.09.2002 thj        2.1 OK for Oracle9i R2

rem Description
rem -----------
rem siehe cssavsta.sql

set line 120
spool sssavsta.lis
select substr(p.bezeichnung||decode(a.art,'1',' - Count','2',' - Time',''),1,35) Parameter,
a.wert1 "Wert 1",b.wert1 "Wert 2",c.wert1 "Wert 3",d.wert1 "Wert 4"
from Sys.css_save_stats a,Sys.css_save_stats b,Sys.css_save_stats c,Sys.css_save_stats d,Sys.css_save_stats_params p
where a.key=p.key and a.counter=1
and   b.key(+)=a.key and b.counter(+)=2 and a.art=b.art(+)
and   c.key(+)=a.key and c.counter(+)=3 and a.art=c.art(+)
and   d.key(+)=a.key and d.counter(+)=4 and a.art=d.art(+)
order by p.key;
spool off
