rem -------------------------------------------------------------------------
rem        Trivadis AG, Baden/Basel/Bern/Lausanne/Z�rich
rem                     Frankfurt/Freiburg i.Br./M�nchen/Stuttgart
rem                     Switzerland/Germany Internet: http://www.trivadis.com
rem -------------------------------------------------------------------------
rem   $Header$
rem   **********************************************************************
rem   Group/Privileges.: DBA
rem   Script-Name......: udcmpsta.sql
rem   Developer........: Andri Kisseleff (ank) andri.kisseleff@trivadis.com
rem   Date.............: January 1996
rem   Version..........: Oracle10g
rem   Usage............: Sample script to submit a ANALYZE for all objects
rem                      of one user into DBMS_JOB Job-Queue (This example
rem                      schedules the job every night at 22:00, starting
rem                      this night)
rem   Input parameters.:
rem   Output.......... : 
rem   Called by........:
rem   Remarks..........: JOB_QUEUE_??? - INIT.ORA-Parameters must have been
rem                      specified
rem                      --> Have a look at OEM (GUI interface in "distributed" available) 
rem                      Much easier to specify jobs!
rem -----------------------------------------------------------------------
rem
rem $Log$
rem Revision 1.1  2003/09/15 09:26:48  ank
rem - OK for 10.1
rem
rem Revision 1.3  2002/09/09 16:56:24  far
rem 9.2 f�hig checked by ThJ
rem
rem Revision 1.2  2001/07/22 12:59:28  ank
rem - Load initial release Oracle9i 9.0.x
rem
rem
rem
rem Changes:
rem DD.MM.YYYY Consultant Change
rem -----------------------------------------------------------------------
rem 02.08.1997 ank        Oracle8
rem 21.04.1999 AnK        OK for Oracle8i
rem 30.06.2001 AnK        OK f�r 9i with DBMS_STATS
rem 04.09.2002 ThJ        OK f�r Oracle9i R2
rem -----------------------------------------------------------------------
rem
rem
variable jobno number
begin
 dbms_job.submit(:jobno,
         'dbms_stats.gather_schema_stats(ownname=>''SYSTEM'',
         estimate_percent => 50, cascade => true);',
         to_date(to_char(sysdate,'dd-mon-yy')||' 22:00','DD-MON-YY HH24:MI'),
         'trunc(sysdate+1)+1/24*22');
commit;
end;
/
print jobno
