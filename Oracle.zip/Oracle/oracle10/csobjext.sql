rem -------------------------------------------------------------------------
rem        Trivadis AG, Baden/Basel/Bern/Lausanne/Z�rich
rem                     Frankfurt/Freiburg i.Br./M�nchen/Stuttgart
rem                     Switzerland/Germany Internet: http://www.trivadis.com
rem -------------------------------------------------------------------------
rem   $Header$
rem   **********************************************************************
rem   Group/Privileges.: SYS
rem   Script-Name......: csobjext.sql
rem   Developer........: Andri Kisseleff (ank) andri.kisseleff@trivadis.com
rem   Date.............: February 1998 (Oracle8)
rem   Version..........: Oracle10g
rem   Usage............: Creates View extent_owner_object_map. (which block
rem                      in which file belongs to which segment)
rem   Input parameters.:
rem   Output.......... : 
rem   Called by........:
rem   Remarks..........: used for example by ssobjext.sql (analyze the blocks
rem                      actually in the buffer cache)
rem                      Important: does only work for dictionary managed tabplespaces
rem -----------------------------------------------------------------------
rem
rem $Log$
rem Revision 1.1  2003/09/15 09:23:15  ank
rem - OK for 10.1
rem (still only for dictionary managed tablespaces)
rem
rem Revision 1.3  2002/10/06 14:44:18  far
rem Tested for 9.2 by ThJ
rem
rem Revision 1.2  2001/07/22 12:59:28  ank
rem - Load initial release Oracle9i 9.0.x
rem
rem
rem
rem Changes:
rem DD.MM.YYYY Consultant Change
rem -----------------------------------------------------------------------
rem 20.04.1999 AnK        OK for Oracle8i (Hash-Partitions, Comp-Partitions)
rem 18.09.2002 ThJ        OK for Oracle9i R2 (Works only for dictionary
rem                       managed Tablespaces) 
rem -----------------------------------------------------------------------
rem
rem
drop view extent_owner_object_map;
create view extent_owner_object_map as
  select file$.file# file# 
       , uet$.block# lowb
       , uet$.block# + uet$.length - 1 highb
       , username owner
       , obj$.name name 
       , NULL partition_name
       , 'TABLE' kind
  from tab$, uet$, obj$, file$, dba_users
  where bitand(tab$.property, 1024) = 0          /* exclude clustered tables */
    and tab$.file# = uet$.segfile#
    and tab$.block# = uet$.segblock#
    and tab$.ts# = uet$.ts#
    and tab$.obj# = obj$.obj#
    and file$.ts# = uet$.ts#
    and file$.relfile# = uet$.file#
    and obj$.owner# = dba_users.user_id
union all
  select file$.file# file# 
       , uet$.block# lowb
       , uet$.block# + uet$.length - 1 highb
       , username owner
       , obj$.name name 
       , obj$.subname partition_name
       , 'TABLE PARTITION' kind
  from tabpart$, uet$, obj$, file$, dba_users
  where tabpart$.file# = uet$.segfile#
    and tabpart$.block# = uet$.segblock#
    and tabpart$.ts# = uet$.ts#
    and tabpart$.obj# = obj$.obj#
    and file$.ts# = uet$.ts#
    and file$.relfile# = uet$.file#
    and obj$.owner# = dba_users.user_id
union all
  select distinct
         file$.file# file# 
       , uet$.block# lowb
       , uet$.block# + uet$.length - 1 highb
       , username owner
       , obj$.name name 
       , NULL partition_name
       , 'CLUSTER' kind
  from tab$, uet$, obj$, file$, dba_users
  where bitand(tab$.property, 1024) <> 0
    and tab$.file# = uet$.segfile#
    and tab$.block# = uet$.segblock#
    and tab$.ts# = uet$.ts#
    and tab$.bobj# = obj$.obj#
    and file$.ts# = uet$.ts#
    and file$.relfile# = uet$.file#
    and obj$.owner# = dba_users.user_id
union all
  select file$.file# file# 
       , uet$.block# lowb
       , uet$.block# + uet$.length - 1 highb 
       , username owner
       , obj$.name name 
       , NULL partition_name
       , 'INDEX' kind
  from ind$, uet$, obj$, file$, dba_users
  where ind$.file# = uet$.segfile#
    and ind$.block# = uet$.segblock#
    and ind$.ts# = uet$.ts#
    and ind$.obj# = obj$.obj#
    and file$.ts# = uet$.ts#
    and file$.relfile# = uet$.file#
    and obj$.owner# = dba_users.user_id
union all
  select file$.file# file# 
       , uet$.block# lowb
       , uet$.block# + uet$.length - 1 highb
       , username owner 
       , obj$.name name 
       , obj$.subname partition_name
       , 'INDEX PARTITION' kind
  from indpart$, uet$, obj$, file$, dba_users
  where indpart$.file# = uet$.segfile#
    and indpart$.block# = uet$.segblock#
    and indpart$.ts# = uet$.ts#
    and indpart$.obj# = obj$.obj#
    and file$.ts# = uet$.ts#
    and file$.relfile# = uet$.file#
    and obj$.owner# = dba_users.user_id
union all
  select file$.file# file#
       , uet$.block# lowb
       , uet$.block# + uet$.length - 1 highb
       , username owner
       , undo$.name name
       , NULL partition_name
       , 'ROLLBACK SEGMENT' kind
  from undo$, uet$, file$, dba_users
  where undo$.file# = uet$.segfile#
    and undo$.block# = uet$.segblock#
    and undo$.ts# = uet$.ts#
    and file$.ts# = uet$.ts#
    and file$.relfile# = uet$.file#
    and undo$.user# = dba_users.user_id
union all
  select file$.file# file#
       , uet$.block# lowb
       , uet$.block# + uet$.length - 1 highb
       , username owner
       , 'TEMP SEGMENT' name
       , NULL partition_name
       , 'TEMP SEGMENT' kind
  from uet$, seg$, file$, dba_users
  where seg$.file# = uet$.segfile#
   and  seg$.block# = uet$.block#
   and  seg$.ts# = uet$.ts#
   and  seg$.type# = 3
   and file$.ts# = uet$.ts#
   and file$.relfile# = uet$.file#
   and seg$.user# = dba_users.user_id
union all
  select file$.file#
       , fet$.block#
       , fet$.length + fet$.block# - 1
       , null owner
       , 'FREE EXTENT' name
       , NULL partition_name
       , 'FREE EXTENT' kind
  from fet$, file$
  where file$.ts# = fet$.ts#
    and file$.relfile# = fet$.file#
  ;
grant select on extent_owner_object_map to select_catalog_role;