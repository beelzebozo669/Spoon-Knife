rem ---------------------------------------------------------------------------
rem  Trivadis AG, Baden-D�ttwil/Basel/Bern/Lausanne/Z�rich
rem               D�sseldorf/Frankfurt/Freiburg i.Br./Hamburg/M�nchen/Stuttgart
rem               Wien
rem               Switzerland/Germany/Austria Internet: http://www.trivadis.com
rem ---------------------------------------------------------------------------
rem $Id: sslongop.sql 199 2008-12-01 02:06:35Z cha $
rem ---------------------------------------------------------------------------
rem  Group/Privileges.: SYSDBA
rem  Script Name......: sslongop.sql
rem  Developer........: Urs Meier (UrM)
rem  Date.............: 19.07.1997
rem  Version..........: Oracle Database 10g
rem  Description......: Show long operations
rem  Usage............: 
rem  Input parameters.: 
rem  Output...........: 
rem  Called by........:
rem  Requirements.....: 
rem  Remarks..........: 
rem
rem ---------------------------------------------------------------------------
rem Changes:
rem DD.MM.YYYY Developer Change
rem ---------------------------------------------------------------------------
rem 21.09.1997 ank       Added COL CLEAR
rem                      Copy of UrM sdlongop.sql
rem                      but only shows working sessions
rem 21.04.1999 AnK       OK for Oracle8i. v$session_lonops completely 
rem                      changed between 8.0 and 8.1. OBJ# not any longer
rem                      available --> Join to v$sqlarea as to see the
rem                      SQL-Command.
rem 04.09.2002 ThJ       OK for Oracle9i R2
rem 15.09.2003 AnK       OK for 10.1
rem 01.12.2008 ChA       Fixed header
rem ---------------------------------------------------------------------------

set logsource "dummy"
store set temp.tmp replace
column username 		noprint new_value username
column schemaname		noprint new_value schemaname
column logon_time		noprint new_value logon_time
column name			format a20
column units                    format a60
set pages 80
break on username duplicate skip page

Ttitle center username " as " schemaname " logged in since " logon_time skip 2


SELECT NVL(s.username,'SNP (inactive)') username, 
       s.schemaname, TO_CHAR(s.logon_time,'DD.MM.YYYY HH24:MI.SS') logon_time,
       message, /* sofar, totalwork, units, */ elapsed_seconds, time_remaining,
       q.sql_text
  FROM sys.v$session s,
       sys.v$session_longops l,
       sys.v$sqlarea q
 WHERE s.sid = l.sid
   AND s.serial# = l.serial#
   AND l.sofar < l.totalwork
   AND q.address(+) = l.sql_address
   AND q.hash_value(+) = l.sql_hash_value
 ORDER BY s.username, s.schemaname, logon_time;



column username 		clear
column schemaname		clear
column logon_time		clear
column units                    clear
clear breaks
@temp.tmp
ttitle off
