rem -------------------------------------------------------------------------
rem        Trivadis AG, Baden/Basel/Bern/Lausanne/Z�rich
rem                     Frankfurt/Freiburg i.Br./Muenchen/Stuttgart
rem                     Switzerland/Germany Internet: http://www.trivadis.com
rem -------------------------------------------------------------------------
rem   $Header$
rem   **********************************************************************
rem   GROUP/Privileges.: SYS
rem   Script-Name......: LSSEGKCH.SQL
rem   Developer........: Sven Vetter Sven.Vetter@Trivadis.com
rem   Date.............: 09.04.2000
rem   Version..........: Oracle10g
rem   Usage............: Zeigt eine Uebersicht der Segmente im KEEP-Buffer-Pool
rem                      incl. allocate SPACE und Used SPACE (Highwater-Mark)
rem                      und wieviel Prozent dieser Segmente IN den KEEP-Buffer
rem                      passen wuerden
rem   Input parameters.: 
rem   Output.......... : 
rem   Called by........:
rem   Remarks..........: Das Privileg 'ANALYZE ANY' ist notwenig, um die 
rem                      Highwatermark anzeigen zu koennen.
rem
rem -----------------------------------------------------------------------
rem
rem $LOG: lssegkch.sql,v $
rem Revision 1.2  2001/07/22 12:59:28  ank
rem - Load INITIAL RELEASE Oracle9i 9.0.x
rem
rem
rem
rem Changes:
rem DD.MM.YYYY Consultant Change
rem -----------------------------------------------------------------------
rem 07.12.2001 SvV        Message bei LOB-(SUB)PARTITIONEN
rem 16.07.2001 SvV        Korrektur der Anzeige, wenn Keep-Cache nicht 
rem                       definiert
rem 28.08.2002 MaW        Ok for Oracle9i R2
rem -----------------------------------------------------------------------
rem
rem
rem

SET linesize 90 feedback off echo off verify off;
SET serveroutput ON size 1000000;

prompt
prompt Anzeige der Segmente im KEEP-Buffer-Pool (Allocated SPACE und Used SPACE)
prompt

CREATE OR REPLACE 
FUNCTION TVD$Temp$Get_High_WaterMark
  ( pOwner   varchar2,
    pSegment varchar2,
    pType    varchar2 DEFAULT 'table',
    pPartit  varchar2 DEFAULT NULL
  ) RETURN number IS
 vTBlk  number;
 vTByte number;
 vUBlk  number;
 vUByte number;
 vLuFID number;
 vLuBID number;
 vLuBlk number;
BEGIN
 dbms_space.unused_space(
   pOwner,pSegment,
   segment_type=>pType,
   total_blocks=>vTBlk,
   total_bytes=>vTByte,
   unused_blocks=>vUBlk,
   unused_bytes=>vUByte,
   last_used_extent_file_id=>vLuFID,
   last_used_extent_block_id=>vLuBID,
   last_used_block=>vLuBlk,
   partition_name=>pPartit
 );
 RETURN vTBlk-vUBlk;
EXCEPTION
  WHEN others THEN
    RETURN NULL;
END; 
/

DECLARE

   CURSOR cDaten IS
    SELECT owner,segment_type,SUM(bytes) sum_bytes, SUM(blocks) sum_blocks, SUM(hwm) sum_hwm, COUNT(*) Anzahl
     FROM
      (SELECT owner,segment_type,bytes,blocks,
       TVD$Temp$Get_High_WaterMark(owner,segment_name,segment_type,partition_name) hwm
       FROM dba_segments
       WHERE buffer_pool='KEEP'
      )
     GROUP BY owner,segment_type
     ORDER BY owner,segment_type;

   vAnz        pls_integer :=0;
   vSumBlock   pls_integer :=0;
   vSumHWM     pls_integer :=0;
   vSumAnz     pls_integer :=0;
   vBufferSize number      :=0;
   vAnalyze    boolean     :=TRUE;
   vPlatz      varchar2(10);
   vLobP       boolean     :=FALSE;
BEGIN
  dbms_output.put_line('User-                         | Segmenttyp          | Anzahl |  Blocks  |  Blocks');
  dbms_output.put_line('name                          |                     |        |  alloc.  |  used');
  dbms_output.put_line('------------------------------|---------------------|--------|----------|---------');
  FOR rDaten IN cDaten LOOP
    dbms_output.put_line(
      RPAD(rDaten.owner,30)                   ||'| ' ||
      RPAD(rDaten.Segment_Type,20)            ||'|'  ||
      TO_CHAR(rDaten.Anzahl,    '999999')     ||' |' ||
      TO_CHAR(rDaten.Sum_Blocks,'9999g999')   ||' |' ||
      TO_CHAR(rDaten.Sum_HWM,   '9999g999'));
    vSumBlock:=vSumBlock+rDaten.Sum_Blocks;
    vSumAnz  :=vSumAnz  +rDaten.Anzahl;
    IF rDaten.Sum_HWM IS NULL THEN
      vAnalyze:=FALSE;
      IF rDaten.Segment_Type IN ('LOB PARTITION','LOB SUBPARTITION') THEN
        vLobP:=TRUE;
      END IF;
    ELSE
      vSumHWM  :=vSumHWM  +rDaten.Sum_HWM;
    END IF;

  END LOOP;
  dbms_output.put_line('----------------------------------------------------|--------|----------|---------');
  dbms_output.put_line('Total:                                              |'||
    TO_CHAR(vSumAnz,  '999999')      ||' |' ||
    TO_CHAR(vSumBlock,'9999g999')   ||' |' ||
    TO_CHAR(vSumHWM,  '9999g999'));
  dbms_output.put_line('_');

  SELECT NVL(SUM(buffers),0) INTO vBufferSize FROM v$buffer_pool WHERE name='KEEP';
  dbms_output.put('Die Groesse des KEEP-caches betraegt '||TO_CHAR(vBufferSize)||' Bloecke');

  IF vSumHWM=0 THEN
    vSumHWM:=vSumBlock;
  END IF;
  IF vSumHWM>vBufferSize THEN
    vPlatz:=LTRIM(TO_CHAR(vBufferSize/vSumHWM*100,'990D00'));
    dbms_output.put_line(', d.h. '||vPlatz||'% der Segmente passen in das cache');
  ELSE
    dbms_output.put_line(' und alle Segmente passen in das cache');
  END IF;
  IF NOT vAnalyze THEN
   dbms_output.put_line('_');
   dbms_output.put_line('Die Highwater-Mark wurde nicht bei allen Segmenten angezeigt.');
   dbms_output.put_line('Eventuell ist das Privileg ''ANALYZE ANY'' nicht erteilt worden.');
   dbms_output.put_line('Syntax dafuer: ''GRANT ANALYZE ANY TO '||USER||';''');
  END IF;
  IF vLobP THEN
   dbms_output.put_line('Fuer LOB-(SUB)PARTITION wird die Highwater-Mark nie angezeigt.');
  END IF;  
END;
/
DROP FUNCTION TVD$Temp$Get_High_WaterMark;
SET feedback ON;
