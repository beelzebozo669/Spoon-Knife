rem ---------------------------------------------------------------------------
rem  Trivadis AG, Baden-D�ttwil/Basel/Bern/Lausanne/Z�rich
rem               D�sseldorf/Frankfurt/Freiburg i.Br./Hamburg/M�nchen/Stuttgart
rem               Wien
rem               Switzerland/Germany/Austria Internet: http://www.trivadis.com
rem ---------------------------------------------------------------------------
rem $Id: sdsegts.sql 196 2008-12-01 01:31:20Z cha $
rem ---------------------------------------------------------------------------
rem  Group/Privileges.: DBA
rem  Script Name......: sdsegts.sql
rem  Developer........: Ingo Frost (InF)
rem  Date.............: 01.08.2001
rem  Version..........: Oracle Database 10g
rem  Description......: Show information about segments per user or tablespace
rem  Usage............: 
rem  Input parameters.: 
rem  Output...........: 
rem  Called by........:
rem  Requirements.....: 
rem  Remarks..........: 
rem
rem ---------------------------------------------------------------------------
rem Changes:
rem DD.MM.YYYY Developer Change
rem ---------------------------------------------------------------------------
rem 03.09.2002 ThJ       OK for Oracle9i R2
rem 09.09.2003 AnK       OK for 10.1
rem 01.12.2008 ChA       Fixed header + Formatting
rem ---------------------------------------------------------------------------

set logsource "Dummy"
store set temp.tmp replace
clear   columns -
        breaks -
        computes
set echo off verify off pagesize 50 linesize 130 feedback off

PROMPT
PROMPT Please enter Username and/or Tablespace , wildcards allowed
PROMPT
PROMPT eg.: SCOTT, S% or %
PROMPT eg.: IDX, DATA% or %
PROMPT
accept user_name char prompt "Username   <%>: " default "%"
accept ts_name char prompt "Tablespace <%>: " default "%"
PROMPT
accept v_type char prompt "Output per Tablespace or per User (T/<U>): " default "U"

col v_sel_col noprint new_value v_sel_col
col v_text noprint new_value v_text

set termout off
select  decode('&v_type','U','owner','u','owner','tablespace_name') v_sel_col,
        decode('&v_type','U','user','u','user', 'tablespace') v_text
from dual;
set termout on

@@foenvtit "Segment statistics per &v_text"

col owner format a20
col tablespace_name  format a20
col TC_COUNT heading "Tab/Clu|Count" format 999G999
col TC_SUM heading "Tab/Clu|Alloc" format 9G999G990
col I_COUNT heading "Index|Count" format 999G999
col I_SUM heading "Index|Alloc" format 9G999G990
col PT_COUNT heading "Part-Tab|Count" format 999G999
col PT_SUM heading "Part-Tab|Alloc" format 9G999G990
col PI_COUNT heading "Part-Idx|Count" format 999G999
col PI_SUM heading "Part-Idx|Alloc" format 9G999G990
col L_COUNT heading "Lob|Count" format 999G999
col L_SUM heading "Lob|Alloc" format 9G999G990

break on report
compute sum label "Total:" of L_Sum on report 
compute sum label "Total:" of I_Sum on report 
compute sum label "Total:" of TC_Sum on report 
compute sum label "Total:" of PT_Sum on report 
compute sum label "Total:" of PI_Sum on report 
compute sum label "Total:" of L_count on report 
compute sum label "Total:" of I_count on report 
compute sum label "Total:" of TC_count on report 
compute sum label "Total:" of PT_count on report 
compute sum label "Total:" of PI_count on report 

select 	&v_sel_col , 
	count(decode(segment_type, 'TABLE','x','CLUSTER','x', null) ) TC_Count,
	round(sum(decode(segment_type, 'TABLE',bytes,'CLUSTER',bytes, 0) )/1024/1024,0) TC_Sum,
	count(decode(segment_type, 'INDEX','x', null) ) I_Count,
	round(sum(decode(segment_type, 'INDEX',bytes, 0) )/1024/1024,1) I_Sum,
        count(decode(segment_type, 'TABLE PARTITION','x','TABLE SUBPARTITION','x', null) ) PT_Count,
        round(sum(decode(segment_type, 'TABLE PARTITION',bytes,'TABLE SUBPARTITION',bytes, 0) )/1024/1024,0) PT_Sum,
        count(decode(segment_type, 'INDEX PARTITION','x','INDEX SUBPARTITION','x', null) ) PI_Count,
        round(sum(decode(segment_type, 'INDEX PARTITION',bytes,'INDEX SUBPARTITION',bytes, 0) )/1024/1024,0) PI_Sum,
	count(decode(segment_type, 'LOBSEGMENT','x','LOBINDEX','x', null) ) L_Count,
	round(sum(decode(segment_type, 'LOBSEGMENT',bytes,'LOBINDEX',bytes, 0) )/1024/1024,0) L_Sum
from dba_segments
where SEGMENT_TYPE in ('TABLE','CLUSTER','INDEX','LOGSEGMENT','LOBINDEX', 'TABLE SUBPARTITION', 'TABLE PARTITION', 'INDEX PARTITION' , 'INDEX SUBPARTITION')
and owner like upper('&&user_Name')
and tablespace_name like upper('&&ts_name')
group by &v_sel_col
order by &v_sel_col;

col owner clear
col tablespace_name clear
col TC_COUNT clear
col TC_SUM clear
col PT_COUNT clear
col PT_SUM clear
col I_COUNT clear
col I_SUM clear
col PI_COUNT clear
col PI_SUM clear
col L_COUNT clear
col L_SUM clear

ttitle off
prompt
prompt Only users and tablespaces with segments are listed 
prompt Report parameter: username = &&user_name , tablespace = &&ts_name
prompt
prompt  Tab/Clu  : Tables and Clusters
prompt  LOB      : Lob-Segments and Lob-Indexes
prompt  Part-Tab : Partitioned Tables , Sub Partitioned Tables
prompt  Part-Idx : Partitioned Indexes , Sub Partitioned Indexes
prompt  Count    : Number of Segments in the Tablespace
prompt  Alloc    : Space allocated by these segments in MB
prompt
undefine user_name
undefine ts_name
undefine v_type
@temp.tmp
