rem ---------------------------------------------------------------------------
rem  Trivadis AG, Baden-D�ttwil/Basel/Bern/Lausanne/Z�rich
rem               D�sseldorf/Frankfurt/Freiburg i.Br./Hamburg/M�nchen/Stuttgart
rem               Wien
rem               Switzerland/Germany/Austria Internet: http://www.trivadis.com
rem ---------------------------------------------------------------------------
rem $Id: sdindprt.sql 160 2008-11-30 10:25:41Z cha $
rem ---------------------------------------------------------------------------
rem  Group/Privileges.: DBA
rem  Script Name......: sdindprt.sql
rem  Developer........: Marc Bosshard (MBo)
rem  Date.............: 01.2001
rem  Version..........: Oracle Database 10g
rem  Description......: Shows tablespace and status of all
rem                     partitions/subpartitions of a partitioned index
rem  Usage............: 
rem  Input parameters.: 
rem  Output...........: 
rem  Called by........:
rem  Requirements.....: 
rem  Remarks..........: 
rem
rem ---------------------------------------------------------------------------
rem Changes:
rem DD.MM.YYYY Developer Change
rem ---------------------------------------------------------------------------
rem 18.09.2002 ThJ       Tested for Oracle9i R2 (incl. Composite Range-
rem                      List Partitioning)
rem 15.09.2003 AnK       OK for 10.1
rem 25.04.2004 MnB       Name of objects in recycle bin is 'BIN$%' (instead of
rem                      'RB$%' in 10g beta)
rem 30.11.2008 ChA       Fixed header
rem ---------------------------------------------------------------------------

set serveroutput on size 1000000;
set linesize 240 feedback off echo off verify off;
set pagesize 200

prompt
accept pIndex_Owner CHAR PROMPT 'INDEX OWNER: '
prompt
select rpad(index_name,30,'.') || ' ('||table_name||')' as "LIST OF PARTITIONED INDEX:" 
from dba_part_indexes
where owner= UPPER('&pIndex_Owner')
and   index_name not like 'BIN$%'
order by 1;
prompt
ACCEPT pIndex_Name CHAR PROMPT 'INDEX NAME: '
prompt

DECLARE
	CURSOR c_Partition IS 
		      SELECT part.index_owner owner,
                      	     part.index_name index_name,
                             part.partition_name partition_name,
                             part.tablespace_name tbs_partition,
                             decode(part.composite,'YES',subpart.subpartition_name,'NO') subpartition_name,
                             decode(part.composite,'YES',subpart.tablespace_name,'NO') tbs_subpartition,
                             decode(part.composite,'YES',subpart.status,part.status) status 
                        FROM dba_ind_partitions part,
                             dba_ind_subpartitions subpart,
                             dba_indexes ind
                        WHERE ind.index_name=part.index_name
                              AND subpart.index_name(+)=part.index_name
                              AND subpart.partition_name(+)=part.partition_name
                              AND ind.owner=part.index_owner
			      AND ind.owner=UPPER('&pIndex_Owner')
                              AND subpart.index_owner(+)=part.index_owner
	                      AND (ind.index_name = UPPER('&pIndex_Name') OR
			           ind.index_name = ('&pIndex_Name'))
			      AND ind.index_name NOT LIKE 'BIN$%';

 	v_Partition       c_Partition%ROWTYPE;
	v_CursorID        INTEGER	:=0;

BEGIN
-- H E A D E R 
	DBMS_OUTPUT.PUT_LINE('-------------------- ----------------------------- ----------------------------- ----------------------------- ----------------------------- ----------');
	DBMS_OUTPUT.PUT_LINE('INDEX                PARTITION                     TABLESPACE PARTITION          SUBPARTITION                  TABLESPACE SUBPARTITION       STATUS'); 
	DBMS_OUTPUT.PUT_LINE('-------------------- ----------------------------- ----------------------------- ----------------------------- ----------------------------- ----------');
	OPEN c_Partition();
	LOOP
-- K I N D   O F    P A R T I T I O N I N G
		FETCH c_Partition INTO v_Partition;
		IF (c_Partition%NOTFOUND) AND (c_Partition%ROWCOUNT = 0) THEN   -- Exit if no partitioned index
			DBMS_OUTPUT.PUT_LINE('NOT PARTITIONED');
			EXIT;
		END IF;
    		EXIT WHEN c_Partition%NOTFOUND; -- Exit at the end of select output
-- O U T P U T
		DBMS_OUTPUT.PUT_LINE(rpad(v_Partition.index_name,20,'.')||' '||
				     rpad(v_Partition.partition_name,29,'.')||' '||
				     rpad(NVL(v_Partition.tbs_partition,'.'),29,'.')||' '||
  				     rpad(v_Partition.subpartition_name,29,'.')||' '||
				     rpad(v_Partition.tbs_subpartition,29,'.')||' '||
				     rpad(v_Partition.status,10,'.'));
	END LOOP;
-- F O O T E R
	DBMS_OUTPUT.PUT_LINE('-------------------- ----------------------------- ----------------------------- ----------------------------- ----------------------------- ----------');
	CLOSE c_Partition;
END;
/
prompt
set feedback on;
set timing off;
set serveroutput off;
