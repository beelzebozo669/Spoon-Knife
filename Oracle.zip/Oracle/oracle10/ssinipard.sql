rem ---------------------------------------------------------------------------
rem  Trivadis AG, Baden-D�ttwil/Basel/Bern/Lausanne/Z�rich
rem               D�sseldorf/Frankfurt/Freiburg i.Br./Hamburg/M�nchen/Stuttgart
rem               Wien
rem               Switzerland/Germany/Austria Internet: http://www.trivadis.com
rem ---------------------------------------------------------------------------
rem $Id: ssinipard.sql 206 2009-01-29 13:15:30Z cha $
rem ---------------------------------------------------------------------------
rem  Group/Privileges.: SYSDBA
rem  Script Name......: ssinipard.sql
rem  Developer........: Christian Antognini
rem  Date.............: November 2008
rem  Version..........: 
rem  Description......: Show description of initialization parameters
rem  Usage............: 
rem  Input parameters.: 
rem  Output...........: 
rem  Called by........:
rem  Requirements.....: 
rem  Remarks..........: 
rem
rem ---------------------------------------------------------------------------
rem Changes:
rem DD.MM.YYYY Developer Change
rem ---------------------------------------------------------------------------
rem 19.11.2008 ChA       Created
rem 29.01.2009 ChA       Changed wrap for column "Description"
rem ---------------------------------------------------------------------------

set logsource "dummy"
store set temp.tmp replace
set pages 100 lines 100 verify off recsep off
col "Parameter" format a46 wrap
col "Description" format a53 word_wrap
@@foenvtit "INIT.ORA Parameter"
select  a.ksppinm  "Parameter", a.ksppdesc "Description"
from x$ksppi a
where upper(a.ksppinm) like upper('%&Parameter%')
order by a.ksppinm
/
ttitle off
col "Parameter" clear
undefine parameter
@temp.tmp

