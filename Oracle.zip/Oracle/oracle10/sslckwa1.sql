rem ---------------------------------------------------------------------------
rem  Trivadis AG, Baden-D�ttwil/Basel/Bern/Lausanne/Z�rich
rem               D�sseldorf/Frankfurt/Freiburg i.Br./Hamburg/M�nchen/Stuttgart
rem               Wien
rem               Switzerland/Germany/Austria Internet: http://www.trivadis.com
rem ---------------------------------------------------------------------------
rem $Id: sslckwa1.sql 201 2008-12-01 02:23:36Z cha $
rem ---------------------------------------------------------------------------
rem  Group/Privileges.: SYSDBA
rem  Script Name......: sslckwa1.sql
rem  Developer........: Andri Kisseleff (AnK)
rem  Date.............: August 1995
rem  Version..........: Oracle Database 10g
rem  Description......: Show users waiting for a lock, the locker and the
rem                     SQL statement they are waiting for a lock
rem                     osuser, schema and PIDs are shown
rem  Usage............: 
rem  Input parameters.: 
rem  Output...........: 
rem  Called by........:
rem  Requirements.....: 
rem  Remarks..........: 
rem
rem ---------------------------------------------------------------------------
rem Changes:
rem DD.MM.YYYY Developer Change
rem ---------------------------------------------------------------------------
rem 21.09.1997 ank       Oracle8. 
rem                          Removed join to v$sqlarea (from v$open_cursor)
rem                          in pure TX-Locks, as SQL-Command now
rem                          can be found in v$open_cursor
rem 21.04.1999 AnK       OK for Oracle8i
rem 03.09.2002 ThJ       OK for Oracle9i R2
rem 10.12.2002 AnK       Additional Join between L_Waiter + v$open_cursor as to 
rem                      show only the real SQL-Command waiting, and not other
rem                      SQL-Commands (Security Policies, etc.)
rem 09.09.2003 AnK       OK for 10.1
rem 01.12.2008 ChA       Fixed header
rem ---------------------------------------------------------------------------

set logsource "dummy"
store set temp.tmp replace
	SET PAGES 24 LINES 100 FEED ON ECHO OFF TERMOUT ON HEAD ON
	COLUMN OS_LOCKER FORMAT A15 TRUNC
	COLUMN OS_WAITER FORMAT A15 TRUNC
	COLUMN LOCKER_SCHEMA FORMAT A15 TRUNC
	COLUMN WAITER_SCHEMA FORMAT A15 TRUNC
 	COLUMN WAITER_PID FORMAT A10
	COLUMN LOCKER_PID FORMAT A10
	COLUMN SQL_TEXT_WAITER FORMAT A100 WRAP
	COLUMN DATABASE NOPRINT NEW_VALUE DATABASE
	COLUMN DATUM_ZEIT NOPRINT NEW_VALUE DATUM_ZEIT
	SET TERMOUT OFF ECHO OFF FEED OFF
	select
		NAME DATABASE,
		TO_CHAR(SYSDATE,'DD.MM.YYYY HH24:MI') DATUM_ZEIT
		FROM V$DATABASE;
	SET TERMOUT ON
	TTITLE CENTER 'Current Lock-Waits - DB: 'database' ('datum_zeit) SKIP 2
REM
	select	/*+ ordered 
		    no_merge(L_WAITER) 
		    no_merge(L_LOCKER) use_hash(L_LOCKER)
		    no_merge(S_WAITER) use_hash(S_WAITER)
		    no_merge(S_LOCKER) use_hash(S_LOCKER)
		    use_nl(O)
		    use_nl(U)
		*/
        	/* first the table-level locks (TM) and mixed TM/TX TX/TM */
		S_LOCKER.OSUSER OS_LOCKER,
		S_LOCKER.USERNAME LOCKER_SCHEMA,
		S_LOCKER.PROCESS LOCKER_PID,
		S_WAITER.OSUSER OS_WAITER,
		S_WAITER.USERNAME WAITER_SCHEMA,
		S_WAITER.PROCESS WAITER_PID,
		'Table lock (TM): '||U.NAME||'.'||O.NAME||
		     ' - Mode held: '||
                	 decode(L_LOCKER.LMODE,
                		0, 'None',           /* same as Monitor */
                		1, 'Null',           /* N */
                		2, 'Row-S (SS)',     /* L */
                		3, 'Row-X (SX)',     /* R */
                		4, 'Share',          /* S */
                		5, 'S/Row-X (SSX)',  /* C */
                		6, 'Exclusive',      /* X */
                		'???: '||to_char(L_LOCKER.LMODE))||
                     ' / Mode requested: '||      
                	 decode(L_WAITER.REQUEST,
                		0, 'None',           /* same as Monitor */
                		1, 'Null',           /* N */
                		2, 'Row-S (SS)',     /* L */
                		3, 'Row-X (SX)',     /* R */
                		4, 'Share',          /* S */
                		5, 'S/Row-X (SSX)',  /* C */
                		6, 'Exclusive',      /* X */
                		'???: '||to_char(L_WAITER.REQUEST))
				                            SQL_TEXT_WAITER
	from	
		V$LOCK L_WAITER,
		V$LOCK L_LOCKER,
		V$SESSION S_WAITER,
		V$SESSION S_LOCKER,
		OBJ$ O,
		USER$ U
        where   S_WAITER.SID = L_WAITER.SID
        and     L_WAITER.TYPE IN ('TM')
        and     S_LOCKER.sid = L_LOCKER.sid
        and     L_LOCKER.ID1 = L_WAITER.ID1
        and     L_WAITER.REQUEST > 0
        and     L_LOCKER.LMODE > 0
        and     L_WAITER.ADDR != L_LOCKER.ADDR
	and     L_WAITER.ID1 = O.OBJ#
	and     U.USER# = O.OWNER#
	union
	select  /*+ ordered
		    no_merge(L_WAITER) 
		    no_merge(L_LOCKER) use_hash(L_LOCKER)
		    no_merge(S_WAITER) use_hash(S_WAITER)
		    no_merge(S_LOCKER) use_hash(S_LOCKER)
		    no_merge(L1_WAITER) use_hash(L1_WAITER)
		    no_merge(O) use_hash(O)
	        */
	        /* now the (usual) row-locks TX */ 
		S_LOCKER.OSUSER OS_LOCKER,
		S_LOCKER.USERNAME LOCKER_SCHEMA,
		S_LOCKER.PROCESS LOCK_PID,
		S_WAITER.OSUSER OS_WAITER,
		S_WAITER.USERNAME WAITER_SCHEMA,
		S_WAITER.PROCESS WAITER_PID,
		'TX: '||O.SQL_TEXT SQL_TEXT_WAITER
	from    	
                V$LOCK L_WAITER,
                V$LOCK L_LOCKER,
                V$SESSION S_WAITER,
                V$SESSION S_LOCKER,
                V$_LOCK1 L1_WAITER,
                V$OPEN_CURSOR O
	where   S_WAITER.SID = L_WAITER.SID
	and     L_WAITER.TYPE IN ('TX')
        and     S_LOCKER.sid = L_LOCKER.sid
        and     L_LOCKER.ID1 = L_WAITER.ID1
        and     L_WAITER.REQUEST > 0
        and     L_LOCKER.LMODE > 0
        and     L_WAITER.ADDR != L_LOCKER.ADDR
        and     L1_WAITER.LADDR = L_WAITER.ADDR
        and     L1_WAITER.KADDR = L_WAITER.KADDR
        and     L1_WAITER.SADDR = O.SADDR
        and     O.HASH_VALUE = S_WAITER.SQL_HASH_VALUE
/
TTITLE OFF
	COLUMN OS_LOCKER CLEAR
	COLUMN OS_WAITER CLEAR
	COLUMN LOCKER_SCHEMA CLEAR
	COLUMN WAITER_SCHEMA CLEAR
 	COLUMN WAITER_PID CLEAR
	COLUMN LOCKER_PID CLEAR
	COLUMN SQL_TEXT_WAITER CLEAR
	COLUMN DATABASE CLEAR
	COLUMN DATUM_ZEIT CLEAR
@temp.tmp
