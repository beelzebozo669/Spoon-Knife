rem -------------------------------------------------------------------------
rem        Trivadis AG, Baden/Basel/Bern/Lausanne/Z�rich
rem                     Frankfurt/Freiburg i.Br./M�nchen/Stuttgart
rem                     Switzerland/Germany Internet: http://www.trivadis.com
rem -------------------------------------------------------------------------
rem   $Header$
rem   **********************************************************************
rem   Group/Privileges.: SYS
rem   Script-Name......: ssobjext.sql
rem   Developer........: Andri Kisseleff (ank) andri.kisseleff@trivadis.com
rem   Date.............: February 1998 (Oracle8)
rem   Version..........: Oracle10g
rem   Usage............: Shows objects (nbr of blocks) actually in the 
rem                      DB-Buffer-Cache (SGA)
rem   Input parameters.:
rem   Output.......... : 
rem   Called by........:
rem   Remarks..........: must create view extent_owner_object_map using
rem                      csobjext.sql
rem -----------------------------------------------------------------------
rem
rem $Log$
rem Revision 1.1  2003/09/15 09:23:27  ank
rem - OK for 10.1
rem (still only for dictionary managed tablespaces)
rem
rem Revision 1.2  2001/07/22 12:59:28  ank
rem - Load initial release Oracle9i 9.0.x
rem
rem
rem
rem Changes:
rem DD.MM.YYYY Consultant Change
rem -----------------------------------------------------------------------
rem 20.04.1999 AnK        OK for Oracle8i (Hash-Partitions, Comp-Partitions)
rem -----------------------------------------------------------------------
rem
rem
rem
set echo off termout on 
col owner format a10 trunc
col name format a20 wrap
col partition_name format a20 wrap
@foenvtit "DB-Buffer Cache"
spool ssobjext.lis
select owner, name, partition_name, kind, count(*) nbr_blocks
from   extent_owner_object_map e, x$bh b
where  e.file# = b.file#
and    b.dbablk between e.lowb and e.highb
group by owner, name, partition_name, kind
order by 5 desc,1,2,3,4;
spool off
prompt
prompt ssobjext.lis has been spooled...
prompt
ttitle off
col owner clear
col name clear
col partition_name clear
