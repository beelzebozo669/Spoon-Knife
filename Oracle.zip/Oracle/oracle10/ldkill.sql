rem ---------------------------------------------------------------------------
rem  Trivadis AG, Baden-D�ttwil/Basel/Bern/Lausanne/Z�rich
rem               D�sseldorf/Frankfurt/Freiburg i.Br./Hamburg/M�nchen/Stuttgart
rem               Wien
rem               Switzerland/Germany/Austria Internet: http://www.trivadis.com
rem ---------------------------------------------------------------------------
rem $Id: ldkill.sql 153 2008-11-28 17:32:38Z cha $
rem ---------------------------------------------------------------------------
rem  Group/Privileges.: DBA
rem  Script Name......: ldkill.sql
rem  Developer........: Andri Kisseleff (AnK)
rem  Date.............: July 1993
rem  Version..........: Oracle Database 10g
rem  Description......: Generate SQL and KSH scripts to kill all user sessions
rem  Usage............: 
rem  Input parameters.: 
rem  Output...........: 
rem  Called by........:
rem  Requirements.....: 
rem  Remarks..........: 
rem
rem ---------------------------------------------------------------------------
rem Changes:
rem DD.MM.YYYY Developer Change
rem ---------------------------------------------------------------------------
rem 02.08.1997 ank       Oracle8
rem 20.04.1999 AnK       OK for Oracle8i
rem 04.09.2002 ThJ       OK for Oracle9i R2
rem 10.09.2003 AnK       OK for 10.1 (changed OpenVMS-Syntax to Unix kill -9,
rem                      removed REPLY.COM)
rem 28.11.2008 ChA       Fixed header + Fixed problem with generation of kill.ksh
rem ---------------------------------------------------------------------------

SET ECHO OFF FEED OFF HEAD OFF NEWPAGE 1 PAGES 0 TERMOUT OFF

SPOOL kill.sql

PROMPT REM kill.sql
PROMPT REM

SELECT 'REM '||TO_CHAR(SYSDATE,'DD.MM.YY HH24:MI')
FROM DUAL;
PROMPT SET ECHO ON
PROMPT REM

SELECT 	'ALTER SYSTEM KILL SESSION '||
	CHR(39)||sid||','||serial#||CHR(39)||';'
FROM  V$SESSION
WHERE TYPE NOT IN ('BACKGROUND')
AND   USERNAME NOT IN ('SYS','SYSTEM');

PROMPT SET ECHO OFF
SPOOL OFF
SPOOL kill.ksh

PROMPT # kill.ksh
PROMPT #

SELECT '# '||TO_CHAR(SYSDATE,'DD.MM.YY HH24:MI')
FROM DUAL;

PROMPT #

SELECT 'kill -9 '||P.SPID
FROM  V$SESSION S, V$PROCESS P
WHERE S.PADDR = P.ADDR
AND   S.TYPE NOT IN ('BACKGROUND')
AND   S.USERNAME NOT IN ('SYS','SYSTEM');

SPOOL OFF

SET TERMOUT ON
PROMPT
PROMPT kill.sql and kill.ksh have been created 
PROMPT Please check and/or run them ...
PROMPT i.E.: ksh kill.ksh
SET TERMOUT ON ECHO OFF FEED ON PAUSE OFF HEAD ON PAGES 24
