rem -------------------------------------------------------------------------
rem        Trivadis AG, Baden/Basel/Bern/Lausanne/Z�rich
rem                     Frankfurt/Freiburg i.Br./M�nchen/Stuttgart
rem                     Switzerland/Germany Internet: http://www.trivadis.com
rem -------------------------------------------------------------------------
rem   $Header$
rem   **********************************************************************
rem   Group/Privileges.: DBA
rem   Script-Name......: sdsrtsta.sql
rem   Developer........: Andri Kisseleff (ank) andri.kisseleff@trivadis.com
rem   Date.............: 07.1993
rem   Version..........: Oracle10g
rem   Usage............: shows sort statistics since instance startup
rem   Input parameters.:
rem   Output.......... : 
rem   Called by........:
rem   Remarks..........:
rem -----------------------------------------------------------------------
rem
rem $Log$
rem Revision 1.1  2003/09/10 13:45:57  ank
rem - OK for 10.1
rem
rem Revision 1.3  2002/09/09 16:56:24  far
rem 9.2 f�hig checked by ThJ
rem
rem Revision 1.2  2001/07/22 12:59:28  ank
rem - Load initial release Oracle9i 9.0.x
rem
rem
rem
rem Changes:
rem DD.MM.YYYY Consultant Change
rem 18.06.1996 ank	  title and new header
rem -----------------------------------------------------------------------
rem 02.08.1997 ank        Oracle8
rem 21.04.1999 AnK        OK for Oracle8i
rem 03.09.2002 ThJ        OK for Oracle9i R2
rem -----------------------------------------------------------------------
rem
rem
@@foenvtit "sort statistics"
	SET ECHO OFF TERMOUT ON
	SPOOL sdsrtsta.lis
	SELECT  name, value
	FROM	v$sysstat
	WHERE	name IN ('sorts (memory)',
		 	 'sorts (disk)',
			 'sorts (rows)')
	ORDER BY statistic#
/
ttitle off
REM
REM
	SELECT	'Avg. nbr. of sorted records per sort operation: '||
		TO_CHAR(ROUND(recs.value/(memory.value+disk.value))) AVG_NBR
	FROM 	v$sysstat recs, v$sysstat memory, v$sysstat disk
	WHERE	recs.name = 'sorts (rows)'
	AND	memory.name = 'sorts (memory)'
	AND	disk.name = 'sorts (disk)'
/
	SPOOL off


