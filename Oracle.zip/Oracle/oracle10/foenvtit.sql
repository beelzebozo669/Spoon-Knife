rem -------------------------------------------------------------------------
rem        Trivadis AG, Baden/Basel/Bern/Lausanne/Z�rich
rem                     Frankfurt/Freiburg i.Br./M�nchen/Stuttgart
rem                     Switzerland/Germany Internet: http://www.trivadis.com
rem -------------------------------------------------------------------------
rem   $Header$
rem   **********************************************************************
rem   Group/Privileges.: Utilities
rem   Script-Name......: foenvtit.sql
rem   Developer........: Andri Kisseleff andri.kisseleff@trivadis.com
rem   Date.............: 27.03.1996
rem   Version..........: Oracle10g
rem   Usage............: Display open time and current time of instance and a title
rem			 DBA required (or grant on v$tread, global_name)
rem   Input parameters.: P1 = Title
rem   Output.......... : 
rem   Called by........:
rem   Remarks..........: Grant = grant select on v_$thread to public;
rem -----------------------------------------------------------------------
rem
rem $Log$
rem Revision 1.1  2003/09/09 07:21:20  ank
rem - OK for 10.1
rem
rem Revision 1.3  2002/08/30 13:16:09  far
rem getestet/angepasst f�r 9.2
rem
rem Revision 1.2  2001/07/22 12:59:28  ank
rem - Load initial release Oracle9i 9.0.x
rem
rem
rem
rem Changes:
rem DD.MM.YYYY Consultant Change
rem -----------------------------------------------------------------------
rem 02.08.1997 ank        Oracle8
rem 20.04.1999 AnK        OK for Oracle8i
rem 27.08.2002 MaW        OK for Oracle9i R2
rem -----------------------------------------------------------------------
rem
rem
	COLUMN	TIME_RUNNING	NEW_VALUE TIME_RUNNING
	COLUMN 	GLOBAL_NAME 	NEW_VALUE GLOBAL_NAME
	SET ECHO OFF TERMOUT OFF PAUSE OFF
	SELECT 	TO_CHAR(open_time,'DD.MM.YYYY HH24:MI')||' - '|| 
		TO_CHAR(SYSDATE,'DD.MM.YYYY HH24:MI')||
                ' ('||TO_CHAR(ROUND((SYSDATE-OPEN_TIME)*24,1))||' h)'
                TIME_RUNNING
	FROM 	v$thread;
	SELECT 	global_name
	FROM 	global_name;
REM
	SET TERMOUT ON
	TTITLE  CENTER '&1' SKIP 1 -
		CENTER ''GLOBAL_NAME'' SKIP 1 -
		CENTER ''TIME_RUNNING''  SKIP 2 
	COLUMN GLOBAL_NAME CLEAR
	COLUMN TIME_RUNNING CLEAR
	UNDEFINE 1
