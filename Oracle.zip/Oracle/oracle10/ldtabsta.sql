rem -------------------------------------------------------------------------
rem        Trivadis AG, Baden/Basel/Bern/Lausanne/Z�rich
rem                     Frankfurt/Freiburg i.Br./M�nchen/Stuttgart
rem                     Switzerland/Germany Internet: http://www.trivadis.com
rem -------------------------------------------------------------------------
rem   $Header$
rem   **********************************************************************
rem   Group/Privileges.: DBA
rem   Script-Name......: ldtabsta.sql
rem   Developer........: Andri Kisseleff (ank) andri.kisseleff@trivadis.com
rem   Date.............: July 1993
rem   Version..........: Oracle10g
rem   Usage............: Shows how much tables are already filled up
rem                      and how many records (approx.) could be inserted
rem   additionally without allocating a new extent
rem   Input parameters.:
rem   Output.......... : ldtabsta.lis
rem   Called by........:
rem   Remarks..........: To be run as a DBA
rem                      --> Optimizer statistics must be available
rem			 --> EMPTY_BLOCKS is not always reliable
rem
rem -----------------------------------------------------------------------
rem
rem  $Log$
rem  Revision 1.2  2004/04/25 18:46:13  mnb
rem  Name of objects in recycle bin is 'BIN$%' (instead of 'RB$%' in 10g beta)
rem
rem  Revision 1.1  2003/09/15 08:06:03  ank
rem  - OK for 10.1
rem  ( removed tables/part/subpart in recycle bin). NEXT_EXTENT = 64 K if TS = locally managed AUTOALLOCATE)
rem  ( changed display)
rem
rem  EMPTY_BLOCKS in the optimizer statistics is not as reliable as it was once.
rem  (Difference between blocks in dba_segments and blocks (used) in the optimizer statistics
rem  does not give empty_blocks in many cases...)
rem
rem  Revision 1.3  2002/08/30 13:16:09  far
rem  getestet/angepasst f�r 9.2
rem
rem  Revision 1.2  2001/07/22 12:59:28  ank
rem  - Load initial release Oracle9i 9.0.x
rem
rem
rem
rem Changes:
rem DD.MM.YYYY Consultant Change
rem -----------------------------------------------------------------------
rem 18.06.1996 ank	  title and new header
rem 02.08.1997 ank        Oracle8 Header explanations in ldtaberr.sql
rem 20.04.1999 AnK        OK for Oracle8i incl. hash & comp. Partitions
rem 27.08.2002 MaW        Ok for Oracle9i R2, incl. list and comp. list
rem -----------------------------------------------------------------------
rem
rem
SET LOGSOURCE "DUMMY" 
STORE SET temp.tmp REPLACE
	ACCEPT user_namen CHAR PROMPT 'Username or Wildcard <%> : ' DEFAULT '%'
	ACCEPT tabellen_namen CHAR PROMPT 'Tablename or Wildcard <%> : ' DEFAULT '%'
	SET ECHO OFF TERMOUT ON
@@foenvtit "Table statistics"
prompt
	rem
	SET PAGES 24 LINES 132  VERIFY OFF
	BREAK ON OWNER SKIP 2
	COLUMN extents		FORMAT		999	HEADING EXT
	COLUMN used_blocks	FORMAT		9999999 HEADING USED_BL
	COLUMN allo_blocks	FORMAT		9999999 HEADING ALLO_BL
	COLUMN next_extent	FORMAT		9999999	HEADING NEXT_EXT
	COLUMN space_for	FORMAT		9999999
        COLUMN table_name       FORMAT A40 WRAP HEADING "TABLE_NAME (PART) (SUBP)"
	rem
	SET ECHO OFF TERMOUT ON 
	SPOOL ldtabsta.lis
	SELECT 
	       RPAD(T.owner,10,'.') OWNER,
	       RPAD(T.table_name,40,'.') TABLE_NAME,
	       extents,
	       T.blocks USED_BLOCKS,
	       S.blocks ALLO_BLOCKS,
               CASE
               WHEN 
               0 >= (((( value-86-(ini_trans-1*24))*empty_blocks)*
			(1-pct_free/100))-4)/avg_row_len
                THEN 0
                ELSE
               (((( value-86-(ini_trans-1*24))*empty_blocks)*
			(1-pct_free/100))-4)/avg_row_len
               END AS SPACE_FOR,
	       NVL(S.next_extent,65536) NEXT_EXTENT
	FROM   sys.dba_tables T, sys.dba_segments S, v$parameter
	WHERE  T.owner = S.owner
	AND    T.table_name = S.segment_name
	AND    T.owner LIKE UPPER('&user_namen')
	AND    T.table_name LIKE UPPER('&tabellen_namen')
	AND    name = 'db_block_size'
	AND    avg_row_len > 0
	AND    num_rows > 0
	AND    T.cluster_name IS NULL
	AND    T.OWNER NOT IN ('SYS')
        AND    T.PARTITIONED = 'NO'
        AND    T.table_name NOT LIKE 'BIN$%' -- recycle bin
      UNION
     	SELECT
	       RPAD(T.table_owner,10,'.') OWNER,
	       RPAD(T.table_name||' ('||T.partition_name||')',40,'.') TABLE_NAME,
	       extents,
	       T.blocks USED_BLOCKS,
	       S.blocks ALLO_BLOCKS,
               CASE
                WHEN 
               0 >= (((( value-86-(ini_trans-1*24))*empty_blocks)*
			(1-pct_free/100))-4)/avg_row_len
                THEN 0
                ELSE
               (((( value-86-(ini_trans-1*24))*empty_blocks)*
			(1-pct_free/100))-4)/avg_row_len
               END AS SPACE_FOR,
	       NVL(S.next_extent,65536) NEXT_EXTENT
	FROM   sys.dba_tab_partitions T, sys.dba_segments S, v$parameter
	WHERE  T.table_owner = S.owner
	AND    T.table_name = S.segment_name
        AND    T.partition_name = S.partition_name
	AND    T.table_owner LIKE UPPER('&user_namen')
	AND    T.table_name LIKE UPPER('&tabellen_namen')
	AND    name = 'db_block_size'
	AND    avg_row_len > 0
	AND    num_rows > 0
	AND    T.table_owner NOT IN ('SYS')
	AND    T.table_name NOT LIKE 'BIN$%' -- recycle bin
     UNION
     	SELECT 
	       RPAD(T.table_owner,10,'.') OWNER,
	       RPAD(T.table_name||' ('||T.partition_name||')'
                                ||' ('||T.subpartition_name||')',40,'.') TABLE_NAME,
	       extents,
	       T.blocks USED_BLOCKS,
	       S.blocks ALLO_BLOCKS,
               CASE
                WHEN 
               0 >= (((( value-86-(ini_trans-1*24))*empty_blocks)*
			(1-pct_free/100))-4)/avg_row_len
                THEN 0
                ELSE
               (((( value-86-(ini_trans-1*24))*empty_blocks)*
			(1-pct_free/100))-4)/avg_row_len
               END AS SPACE_FOR,
	       NVL(S.next_extent,65536) NEXT_EXTENT
	FROM   sys.dba_tab_subpartitions T, sys.dba_segments S, v$parameter
	WHERE  T.table_owner = S.owner
	AND    T.table_name = S.segment_name
        AND    T.subpartition_name = S.partition_name
	AND    T.table_owner LIKE UPPER('&user_namen')
	AND    T.table_name LIKE UPPER('&tabellen_namen')
	AND    name = 'db_block_size'
	AND    avg_row_len > 0
	AND    num_rows > 0
	AND    T.table_owner NOT IN ('SYS')
	AND    T.table_name NOT LIKE 'BIN$%' -- recycle bin
	ORDER BY  2,3
/
	SPOOL OFF
	SET VERIFY ON TERMOUT ON PAUSE OFF
	TTITLE OFF
	CLEAR COMPUTES BREAKS
	COL extents CLEAR
	COL used_blocks CLEAR
	COL allo_blocks CLEAR
	COL next_extent CLEAR
	COL space_for CLEAR
        COL table_name CLEAR
	PROMPT
	prompt ldtabsta.lis (132 w) has been spooled...
	prompt

REM Reset "SETs"	                       	       
@temp.tmp
