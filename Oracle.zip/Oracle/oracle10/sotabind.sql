rem -------------------------------------------------------------------------
rem        Trivadis AG, Baden/Basel/Bern/Lausanne/Z�rich
rem                     Frankfurt/Freiburg i.Br./M�nchen/Stuttgart
rem                     Switzerland/Germany Internet: http://www.trivadis.com
rem -------------------------------------------------------------------------
rem   $Header$
rem   **********************************************************************
rem   Group/Privileges.: Owner
rem   Script-Name......: sotabind.sql
rem   Developer........: Urs Meier (urm) urs.meier@trivadis.com
rem   Date.............: 03.01.1990
rem   Version..........: Oracle10g
rem   Usage............: Shows the indexes for a given table (or many)
rem   Input parameters.:
rem   Output.......... : 
rem   Called by........:
rem   Remarks..........:
rem -----------------------------------------------------------------------
rem
rem $Log$
rem Revision 1.1  2003/09/09 08:47:27  ank
rem - OK for 10.1 (Bitmap idx. on IOTs, List part. IOT)
rem
rem Revision 1.3  2002/08/30 13:16:09  far
rem getestet/angepasst f�r 9.2
rem
rem Revision 1.2  2001/07/22 12:59:28  ank
rem - Load initial release Oracle9i 9.0.x
rem
rem
rem
rem Changes:
rem DD.MM.YYYY Consultant Change
rem -----------------------------------------------------------------------
rem 14.07.1994 AnK        Lauffaehig fuer ORACLE7
rem                       Anzeige DISTINCT KEYS	
rem 05.04.1997 urs.meier  rename
rem 21.09.1997 AnK       Oracle8, added Partitions, IOTs, etc.
rem 21.04.1999 AnK       OK for Oracle8i. Tested hash partitions.
rem                      Added support for composite partitions.
rem                      P=part.Index. SP=Sub.part.Index
rem                      Scipt runs much faster with ALL_ROWS Optimizer-Hint
rem 03.01.2001 ChA       Added some hints for better performances
rem 08.27.2002 ChA       OK for Oracle9i R2
rem -----------------------------------------------------------------------
rem
rem
rem
set echo off
set verify off
@@fopauon
column index_name	format a25 word_wrap	heading 'Index_Name (Part)' 
column type		format a3		heading 'Typ'
column uni		format a3		heading 'Uni'
column tablespace_name	format a10 wrap		heading 'Table Space'
column table_name	noprint			new_value tab
column column_name	format a25 wrap		heading 'Column Name'
column distinct_keys	format 9999999		heading 'DistKeys'
column column_position  noprint
ttitle center 'Indexes for table 'tab skip 2
break on table_name skip page -
      on index_name skip 2 -
      on type -
      on uni -
      on distinct_keys  -
      on tablespace_name
PROMPT 
PROMPT Please enter table name, wildcards allowed
PROMPT
PROMPT eg.: EMP, E% or %
PROMPT
accept table_name char prompt "Table Name <%>: " default "%"
select 	/*+ ordered 
            no_merge(i) 
            no_merge(c) use_hash(c) */ 
        /* first non-partitioned indexes */
                i.index_name,i.table_name,c.column_name,
		decode(i.table_type,'TABLE','TAB','CLUSTER','CLU','???') type,
                decode(i.index_type,'BITMAP','BIT',
                                    'CLUSTER','CLU',
                                    'IOT - TOP','IOT',
                                    'LOB','LOB',
		                     decode(i.uniqueness,'UNIQUE','YES',
                                                         'NONUNIQUE','NO')) UNI,
		i.tablespace_name, i.distinct_keys, c.column_position 
   	from  user_indexes i, user_ind_columns c
  	where i.table_name = c.table_name
    	and i.index_name = c.index_name
    	and i.table_name like upper('&&Table_Name')
        and i.partitioned = 'NO'
 union
select  /*+ ordered 
            no_merge(i) 
            no_merge(ip) use_hash(ip)
            no_merge(c) use_hash(c) 
            no_merge(p) use_hash(p) */ 
        /* and now partitioned indexes */ 
        i.index_name||' ('||ip.partition_name||') '||
                    ' (P:'||p.locality||' '||p.alignment||')' index_name,
        c.table_name,c.column_name,
                decode(i.table_type,'TABLE','TAB','CLUSTER','CLU','???') type,
                decode(i.index_type,'BITMAP','BIT',
                                    'CLUSTER','CLU',
                                    'IOT - TOP','IOT',
                                    'LOB','LOB',
                                     decode(i.uniqueness,'UNIQUE','YES',
                                                         'NONUNIQUE','NO')) UNI,
                ip.tablespace_name, i.distinct_keys, c.column_position
        from  user_indexes i, user_ind_partitions ip,
              user_ind_columns c, user_part_indexes p
        where i.table_name = c.table_name
        and p.index_name = ip.index_name
        and i.index_name = ip.index_name
        and ip.index_name = c.index_name
        and i.table_name like upper('&&Table_Name')
        and ip.tablespace_name is not null /* Comp. part. Indexes */
 union
select  /*+ ordered 
            no_merge(i) 
            no_merge(ip) use_hash(ip)
            no_merge(c) use_hash(c) 
            no_merge(p) use_hash(p) */ 
        /* and now sub-partitioned indexes */ 
        i.index_name||' ('||ip.subpartition_name||') '||
                    ' (SP:'||p.locality||' '||p.alignment||')' index_name,
        c.table_name,c.column_name,
                decode(i.table_type,'TABLE','TAB','CLUSTER','CLU','???') type,
                decode(i.index_type,'BITMAP','BIT',
                                    'CLUSTER','CLU',
                                    'IOT - TOP','IOT',
                                    'LOB','LOB',
                                     decode(i.uniqueness,'UNIQUE','YES',
                                                         'NONUNIQUE','NO')) UNI,
                ip.tablespace_name, i.distinct_keys, c.column_position
        from  user_indexes i, user_ind_subpartitions ip,
              user_ind_columns c, user_part_indexes p
        where i.table_name = c.table_name
        and p.index_name = ip.index_name
        and i.index_name = ip.index_name
        and ip.index_name = c.index_name
        and i.table_name like upper('&&Table_Name')
 union
select /*+ ordered 
            no_merge(i) 
            no_merge(l) use_hash(l) */ 
       /* and now the LOB-Indexes */
       l.index_name, l.table_name, l.column_name,'LOB' TYPE,
       'LOB' UNI, i.tablespace_name,
       -1,1
       from user_indexes i, user_lobs l
       where l.index_name = i.index_name
       and   l.table_name = i.table_name
       and   l.table_name like upper('&&Table_Name')
order by 2, 5 desc, 1, 8;

set pause off
ttitle off
clear break compute     
column index_name	CLEAR
column type		CLEAR
column uni              CLEAR
column tablespace_name	CLEAR
column table_name	CLEAR
column column_name	CLEAR
column distinct_keys	CLEAR
column column_position  CLEAR
undefine table_name

