rem ---------------------------------------------------------------------------
rem  Trivadis AG, Baden-D�ttwil/Basel/Bern/Lausanne/Z�rich
rem               D�sseldorf/Frankfurt/Freiburg i.Br./Hamburg/M�nchen/Stuttgart
rem               Wien
rem               Switzerland/Germany/Austria Internet: http://www.trivadis.com
rem ---------------------------------------------------------------------------
rem $Id: soxplrw.sql 207 2009-02-18 16:26:18Z cha $
rem ---------------------------------------------------------------------------
rem  Group/Privileges.: User
rem  Script Name......: soxplrw.sql
rem  Developer........: Christian Antognini (ChA)
rem  Date.............: 12.07.2001
rem  Version..........: Oracle Database 10g
rem  Description......: Shows either why a query failed to rewrite or which 
rem                     materialized view is used for query rewrite.
rem  Usage............: 
rem  Input parameters.: 
rem  Output...........: 
rem  Called by........:
rem  Requirements.....: 
rem  Remarks..........: The table REWRITE_TABLE must exists (it can be created
rem                     with the script ?/rdbms/admin/utlxrw.sql)
rem                     Lower/mixed case object names are not supported.
rem
rem ---------------------------------------------------------------------------
rem Changes:
rem DD.MM.YYYY Developer Change
rem ---------------------------------------------------------------------------
rem 03.09.2002 ThJ       OK for Oracle9i R2
rem 15.09.2003 AnK       OK for 10.1
rem 21.11.2008 ChA       Fixed header + Formatting + Get query from SQL*Plus
rem                      buffer
rem 18.02.2009 ChA       Fixed handling of the parameter mview_name
rem ---------------------------------------------------------------------------

set verify off linesize 100

prompt 
prompt The following query in the buffer is used for calling EXPLAIN_REWRITE
prompt

list

prompt 
prompt Please enter materialized view name, wildcards NOT allowed
prompt
accept mview_name char prompt "Materialized View Name: " 

variable statement_id varchar2(30)

0   l_query := q'[
0 BEGIN
0   l_query CLOB;;
0 DECLARE
9999   ]';;
9999   SELECT substr(sys_guid(),1,30) INTO :statement_id FROM dual;;
9999   DELETE rewrite_table WHERE statement_id = :statement_id;;
9999   DBMS_MVIEW.EXPLAIN_REWRITE(l_query, '&mview_name',:statement_id);;
9999 END;;
/

ttitle center 'Query rewrite possible?' skip 2

SELECT message
FROM   rewrite_table
WHERE  statement_id = :statement_id;

ttitle off

undef mview_name
undef statement_id

set verify off
