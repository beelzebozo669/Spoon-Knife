rem -------------------------------------------------------------------------
rem        Trivadis AG, Baden/Basel/Bern/Lausanne/Z�rich
rem                     Frankfurt/Freiburg i.Br./M�nchen/Stuttgart
rem                     Switzerland/Germany Internet: http://www.trivadis.com
rem -------------------------------------------------------------------------
rem   $Header$
rem -------------------------------------------------------------------------
rem   Group/Privileges.: Utilities
rem   Script-Name......: lotabcmt.sql
rem   Developer........: Urs Meier (urm) urs.meier@trivadis.com
rem   Date.............: 18.04.1990
rem   Version..........: Oracle10g
rem   Usage............: Lists comments in the data dictionary
rem   Input parameters.:
rem   Output.......... : 
rem   Called by........:
rem   Remarks..........:
rem -----------------------------------------------------------------------
rem Changes:
rem
rem $Log$
rem Revision 1.1  2003/09/09 16:02:42  ank
rem - OK for 10.1
rem
rem Revision 1.1  2002/04/04 08:26:38  ank
rem - added to CVS
rem
rem
rem
rem DD.MM.YYYY Consultant Change
rem -----------------------------------------------------------------------
rem 05.04.1997 urs.meier	rename
rem                             added default %
rem 02.08.1997 andri.kisseleff Oracle8
rem 20.04.1999 AnK             OK for Oracle8i
rem -----------------------------------------------------------------------
rem
rem


        undefine tab_name
        clear columns
        clear breaks
        set pagesize 66
        set newpage 0
        set verify off
        set recsep off
        set recsepchar ' '
rem
rem
        column dummy                noprint             
        column oderby               noprint
        column table_name   format  a24         heading 'Table / Column'
        column column_name  like    table_name    
        column comments     format  a55 word    heading 'Comment'
rem
rem
rem
rem
        break on dummy skip page
rem
rem
@@foenvtit "Tables, attributes and comments"
ACCEPT tab_name CHAR PROMPT "Comments for table(s) [%]: " Default "%"

        spool lotabcmt.lis
        select  1 oderby,table_name dummy,table_name,comments
             from user_tab_comments
         where table_name like upper('&&tab_name')
                   union
        select 2 oderby,table_name dummy,' '||column_name,comments
          from user_col_comments
         where table_name like upper('&&tab_name')
         order by 2,1;
	spool off
ttitle off
        column dummy clear 
        column oderby clear
        column table_name clear
        column column_name clear
        column comments clear
        undefine tab_name

prompt lotabcmt.lis has been spooled
