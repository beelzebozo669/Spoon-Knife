rem ---------------------------------------------------------------------------
rem  Trivadis AG, Baden-D�ttwil/Basel/Bern/Lausanne/Z�rich
rem               D�sseldorf/Frankfurt/Freiburg i.Br./Hamburg/M�nchen/Stuttgart
rem               Wien
rem               Switzerland/Germany/Austria Internet: http://www.trivadis.com
rem ---------------------------------------------------------------------------
rem $Id: sdfkoind.sql 182 2008-11-30 22:32:47Z cha $
rem ---------------------------------------------------------------------------
rem  Group/Privileges.: DBA
rem  Script Name......: sdfkoind.sql
rem  Developer........: Peter Nuding (PeN)
rem  Date.............: 12.10.1998
rem  Version..........: Oracle Database 10g
rem  Description......: Shows unindexed foreign keys of any user
rem  Usage............: 
rem  Input parameters.: 
rem  Output...........: 
rem  Called by........:
rem  Requirements.....: 
rem  Remarks..........: 
rem
rem ---------------------------------------------------------------------------
rem Changes:
rem DD.MM.YYYY Developer Change
rem ---------------------------------------------------------------------------
rem 12.10.1998 AnK       Made DBA-Version for all owners based on PeN's sofkoind.sql
rem                      Title similar to foenvtit
rem                      Removed DECODE
rem 20.04.1999 AnK       OK for Oracle8i	
rem 10.12.2001 SvV       Change query for better performance (minus)
rem 02.09.2002 ThJ       OK for Oracle9i R2
rem 09.09.2003 AnK       OK for 10.1
rem 30.11.2008 ChA       Fixed header + Formatting
rem ---------------------------------------------------------------------------

store SET temp.tmp REPLACE
SET echo off
SET verify off
SET linesize 92
SET pages 80 pause ON pause "Hit <RETURN>..."
SET PAUSE OFF
break ON OWNER skip page

COLUMN OWNER noprint new_value own
COLUMN TABLE_NAME format a30 heading "Table Name"
COLUMN CONSTRAINT_NAME format a30 heading "Constraint Name"
COLUMN COLUMN_NAME format a30 heading "1. Column"

COLUMN	TIME_RUNNING	NEW_VALUE TIME_RUNNING
COLUMN 	GLOBAL_NAME 	NEW_VALUE GLOBAL_NAME

SET TERMOUT OFF
SELECT 	TO_CHAR(open_time,'DD.MM.YYYY HH24:MI')||' - '|| 
	TO_CHAR(SYSDATE,'DD.MM.YYYY HH24:MI')||
        ' ('||TO_CHAR(ROUND((SYSDATE-OPEN_TIME)*24,1))||' h)'
        TIME_RUNNING
FROM 	v$thread;
SELECT 	global_name
FROM 	global_name;
SET TERMOUT ON

TTITLE  CENTER 'Unindexed foreign keys owned by ' own  SKIP 1 -
	CENTER ''GLOBAL_NAME'' SKIP 1 -
	CENTER ''TIME_RUNNING''  SKIP 2 
COLUMN GLOBAL_NAME CLEAR
COLUMN TIME_RUNNING CLEAR

PROMPT 
PROMPT Please enter owner name AND TABLE name. Wildcards allowed (DEFAULT: %)
PROMPT
PROMPT eg.:  SCOTT, S% OR %
PROMPT eg.:  EMP, E% OR %
PROMPT

ACCEPT vOwner prompt "Owner  <%>: " DEFAULT %
ACCEPT vTable prompt "Tables <%>: " DEFAULT %

SELECT OWNER, TABLE_NAME, CONSTRAINT_NAME, COLUMN_NAME
  FROM DBA_CONS_COLUMNS c
  WHERE position=1 AND 
   (OWNER, TABLE_NAME, COLUMN_NAME) IN 
   ( SELECT c.OWNER, c.TABLE_NAME,cc.COLUMN_NAME
       FROM  DBA_CONSTRAINTS  c, DBA_CONS_COLUMNS cc
       WHERE c.CONSTRAINT_NAME = cc.CONSTRAINT_NAME
        AND  c.TABLE_NAME      = cc.TABLE_NAME
        AND  c.OWNER           = cc.OWNER
        AND  c.CONSTRAINT_TYPE = 'R'
        AND  cc.POSITION       = 1
        AND  c.OWNER           LIKE UPPER('&vOwner')
        AND  c.TABLE_NAME      LIKE UPPER('&vTable')
     MINUS
     SELECT table_owner, table_name, column_name
       FROM    DBA_IND_COLUMNS  
       WHERE COLUMN_POSITION = 1
        AND  TABLE_OWNER LIKE UPPER('&vOwner')
        AND  TABLE_NAME  LIKE UPPER('&vTable')
   )
  ORDER BY OWNER, TABLE_NAME, CONSTRAINT_NAME;

ttitle off
COLUMN TABLE_NAME clear
COLUMN CONSTRAINT_NAME clear
COLUMN COLUMN_NAME clear
clear breaks
@temp.tmp


