rem ---------------------------------------------------------------------------
rem  Trivadis AG, Baden-D�ttwil/Basel/Bern/Lausanne/Z�rich
rem               D�sseldorf/Frankfurt/Freiburg i.Br./Hamburg/M�nchen/Stuttgart
rem               Wien
rem               Switzerland/Germany/Austria Internet: http://www.trivadis.com
rem ---------------------------------------------------------------------------
rem $Id: sdsesrs.sql 149 2008-11-28 13:17:42Z cha $
rem ---------------------------------------------------------------------------
rem  Group/Privileges.: DBA
rem  Script Name......: sdsesrs.sql
rem  Developer........: Andri Kisseleff (AnK)
rem  Date.............: 29.05.1995
rem  Version..........: Oracle Database 10g
rem  Description......: Show mapping between session and undo segment
rem  Usage............: 
rem  Input parameters.: 
rem  Output...........: 
rem  Called by........:
rem  Requirements.....: 
rem  Remarks..........: Shows open transactions and in which rollback segment
rem                     they are. Lock-Wait-Status, O/S-User, O/S-PID, etc.
rem                     MTS-Servers are shown in (...) as not to kill them
rem                     by mistake.
rem                     If the first DML statement of a TX is a lock wait
rem                     the TX will not be shown in V$TRANSACTION. For this
rem                     reason, we make the UNION on V$LOCK only. In such 
rem                     cases no RS/UNDO-Segment is yet allocated.
rem                     If a lock wait is not the first DML of a TX, the
rem                     user is shown twice. One line with the RS of the
rem                     previous statements and an other line with the
rem                     Lock-Wait. O/S-ID and SESS-ID are identical in such
rem                     cases.
rem                     Server shows NONE if it is a shared server connection
rem ---------------------------------------------------------------------------
rem Changes:
rem DD.MM.YYYY Developer Change
rem ---------------------------------------------------------------------------
rem 21.04.1999 AnK        OK for Oracle8i. Addes USED_UREC and USED_UBLK
rem                       USED_UREC = changed records (it seems that an
rem                       update/insert/delete of 1 record makes 3 entries)
rem                       USED_UBLK = changed blocks by this transaction
rem 03.09.2001 SvV        Corrected a typo
rem 27.08.2002 MaW        Ok for Oracle9i R2
rem 09.09.2003 AnK        OK for 10.1 (removed used blocks/used records) +
rem                       Changed TTITLE for UNDO and RS
rem 28.11.2008 ChA        Fixed header + Formatting
rem 28.11.2008 ChA        Renamed (sssesrs.sql -> sdsesrs.sql)
rem ---------------------------------------------------------------------------

set logsource "dummy"
store set temp.tmp replace

SET PAGES 24 LINES 120 FEED ON ECHO OFF TERMOUT ON HEAD ON
COL LOCKER FORMAT A23 TRUNC HEADING "ORACLE|USER"
COL WAIT FORMAT A4 HEADING "LOCK|WAIT"
COL RS_NAME FORMAT A15 TRUNC HEADING "UNDO|SEGMENT"
COL SID FORMAT A10 HEADING "ORACLE|SID"
COL SPID FORMAT A15 HEADING "O/S|PID"
COL OSUSER FORMAT A20 HEADING "O/S|USER"
COL START_TIME FORMAT A17 HEADING "TX START TIME"
COL SERVER FORMAT A9 HEADING "SERVER|TYPE"

@@foenvtit "Open transactions and undo segments actually in use"
REM
        select	t.start_time, S.OSUSER,
                decode(S.SERVER,'SHARED','('||P.SPID||')',
                                'NONE','('||P.SPID||')',
                                                        P.SPID) SPID,
                to_char(S.SID) SID, 
		S.USERNAME as LOCKER,
                R.NAME  as RS_NAME,
                S.SERVER,
	       	decode(L.REQUEST,0,'NO','YES')  as WAIT
	from   	V$LOCK L,
		V$SESSION S,
                V$TRANSACTION T,
                V$ROLLNAME R,
                V$PROCESS P
	where  	S.SID = L.SID
    	and     S.TADDR = T.ADDR
    	and     R.USN = T.XIDUSN
    	and     S.PADDR = P.ADDR
         union
        select	'N/A',S.OSUSER,
                decode(S.SERVER,'SHARED','('||P.SPID||')',P.SPID) SPID,
                to_char(S.SID) SID, 
                S.USERNAME as LOCKER,
                'WAIT',
                S.SERVER,
                decode(L.REQUEST,0,'NO','YES')  as WAIT
	from    V$LOCK L,
                V$SESSION S,
                V$PROCESS P
	where   S.SID = L.SID
    	and     S.PADDR = P.ADDR
        and     S.TYPE not in ('BACKGROUND')
        and     L.REQUEST > 0
    	order by 1, 4, 2
/
COL LOCKER CLEAR
COL WAIT CLEAR
COL RS_NAME CLEAR
COL SID CLEAR
COL SPID CLEAR
COL OSUSER CLEAR
COL SERVER CLEAR
TTITLE OFF
PROMPT
PROMPT O/S PIDs IN (...) are shared server connections. Do not kill the dispatcher!
PROMPT
PROMPT
@temp.tmp
