rem -----------------------------------------------------------------------------------
rem        Trivadis AG, Basel/Bern/Brugg/Lausanne/Zuerich
rem                     Duesseldorf/Frankfurt/Freiburg i.Br./Hamburg/Muenchen/Stuttgart
rem                     Wien
rem                     Switzerland/Germany/Austria Internet: http://www.trivadis.com
rem -----------------------------------------------------------------------------------
rem $Id:  $
rem -----------------------------------------------------------------------------------
rem  Group/Privileges.: DBA
rem  Script-Name......: sdrdohst.sql
rem  Developer........: Peter Jensch (PeJ) peter.jensch@trivadis.com
rem  Date.............: September 2014
rem  Version..........: Oracle Database 11g
rem  Description......: Displays the history of all redo log switches
rem  Usage............: 
rem  Input parameters.: Amount of days to show. Default value is 30 days.
rem  Output.......... :
rem  Called by........:
rem  Remarks..........:
rem
rem -----------------------------------------------------------------------------------
rem Changes:
rem DD.MM.YYYY Consultant Change
rem -----------------------------------------------------------------------------------
rem 20.10.2014 DaH        Implemented basenv like features and default value of &1
rem 16.03.2015 DaH        Added formattings for all columns
rem -----------------------------------------------------------------------------------

set logsource "Dummy"
store set temp.tmp replace
clear   columns -
        breaks -
        computes


SET VERIFY OFF
SET TERMOUT OFF

COLUMN 1 NEW_VALUE 1
SELECT '' "1" FROM dual WHERE rownum = 0;

COLUMN days NEW_VALUE days
SELECT CASE WHEN nvl('&1',0) = '0' THEN '30' ELSE '&1' END "days" FROM dual;

SET TERMOUT ON

SET PAGESIZE      100
SET LINESIZE      160
SET FEEDBACK      ON

COLUMN DAY    FORMAT A10
COLUMN TOTAL  FORMAT A6
COLUMN "  00" FORMAT A4
COLUMN "  01" FORMAT A4
COLUMN "  02" FORMAT A4
COLUMN "  03" FORMAT A4
COLUMN "  04" FORMAT A4
COLUMN "  05" FORMAT A4
COLUMN "  06" FORMAT A4
COLUMN "  07" FORMAT A4
COLUMN "  08" FORMAT A4
COLUMN "  09" FORMAT A4
COLUMN "  10" FORMAT A4
COLUMN "  11" FORMAT A4
COLUMN "  12" FORMAT A4
COLUMN "  13" FORMAT A4
COLUMN "  14" FORMAT A4
COLUMN "  15" FORMAT A4
COLUMN "  16" FORMAT A4
COLUMN "  17" FORMAT A4
COLUMN "  18" FORMAT A4
COLUMN "  19" FORMAT A4
COLUMN "  20" FORMAT A4
COLUMN "  21" FORMAT A4
COLUMN "  22" FORMAT A4
COLUMN "  23" FORMAT A4

@@foenvtit "History of redolog switches"

SELECT to_char(first_time,'YYYY-MM-DD') "DAY",
       to_char(sum(decode(to_char(first_time,'hh24'),'00',1,0)),'990') "  00",
       to_char(sum(decode(to_char(first_time,'hh24'),'01',1,0)),'990') "  01",
       to_char(sum(decode(to_char(first_time,'hh24'),'02',1,0)),'990') "  02",
       to_char(sum(decode(to_char(first_time,'hh24'),'03',1,0)),'990') "  03",
       to_char(sum(decode(to_char(first_time,'hh24'),'04',1,0)),'990') "  04",
       to_char(sum(decode(to_char(first_time,'hh24'),'05',1,0)),'990') "  05",
       to_char(sum(decode(to_char(first_time,'hh24'),'06',1,0)),'990') "  06",
       to_char(sum(decode(to_char(first_time,'hh24'),'07',1,0)),'990') "  07",
       to_char(sum(decode(to_char(first_time,'hh24'),'08',1,0)),'990') "  08",
       to_char(sum(decode(to_char(first_time,'hh24'),'09',1,0)),'990') "  09",
       to_char(sum(decode(to_char(first_time,'hh24'),'10',1,0)),'990') "  10",
       to_char(sum(decode(to_char(first_time,'hh24'),'11',1,0)),'990') "  11",
       to_char(sum(decode(to_char(first_time,'hh24'),'12',1,0)),'990') "  12",
       to_char(sum(decode(to_char(first_time,'hh24'),'13',1,0)),'990') "  13",
       to_char(sum(decode(to_char(first_time,'hh24'),'14',1,0)),'990') "  14",
       to_char(sum(decode(to_char(first_time,'hh24'),'15',1,0)),'990') "  15",
       to_char(sum(decode(to_char(first_time,'hh24'),'16',1,0)),'990') "  16",
       to_char(sum(decode(to_char(first_time,'hh24'),'17',1,0)),'990') "  17",
       to_char(sum(decode(to_char(first_time,'hh24'),'18',1,0)),'990') "  18",
       to_char(sum(decode(to_char(first_time,'hh24'),'19',1,0)),'990') "  19",
       to_char(sum(decode(to_char(first_time,'hh24'),'20',1,0)),'990') "  20",
       to_char(sum(decode(to_char(first_time,'hh24'),'21',1,0)),'990') "  21",
       to_char(sum(decode(to_char(first_time,'hh24'),'22',1,0)),'990') "  22",
       to_char(sum(decode(to_char(first_time,'hh24'),'23',1,0)),'990') "  23",
       to_char(count(*),'99990') "TOTAL"
  FROM v$log_history
 WHERE first_time > sysdate - &days
 GROUP BY to_char(first_time,'YYYY-MM-DD')
 ORDER BY 1;

undefine 1
undefine days
ttitle off

@temp.tmp
