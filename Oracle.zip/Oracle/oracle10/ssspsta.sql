rem -------------------------------------------------------------------------
rem        Trivadis AG, Baden/Basel/Bern/Lausanne/Z�rich
rem                     Frankfurt/Freiburg i.Br./M�nchen/Stuttgart
rem                     Switzerland/Germany Internet: http://www.trivadis.com
rem -------------------------------------------------------------------------
rem   $Header$
rem   **********************************************************************
rem   Group/Privileges.: Utilities
rem   Script-Name......: ssspsta.sql
rem   Developer........: Urs Meier (urm) urs.meier@trivadis.com
rem   Date.............: 30.09.1994
rem   Version..........: Oracle10g
rem   Usage............: Shows statistics for shared pool
rem   Input parameters.:
rem   Output.......... : 
rem   Called by........:
rem   Remarks..........:
rem -----------------------------------------------------------------------
rem
rem $Log$
rem Revision 1.4  2003/11/20 15:25:07  ank
rem - changed SET PAGESIZE
rem
rem Revision 1.3  2003/11/20 11:38:12  ank
rem - Still open how to identify the flushes (norm/reserved pool).
rem No way found how to join ADDR (or so) to the corresponding pool.
rem
rem Revision 1.2  2003/09/09 09:12:12  ank
rem The 2nd select must be analyzed more in detail as in 10.1 Beta it is
rem returning 2 rows, in all other versions only one row. (flushes)
rem
rem Revision 1.3  2002/08/30 13:16:09  far
rem getestet/angepasst f�r 9.2
rem
rem Revision 1.2  2001/07/22 12:59:28  ank
rem - Load initial release Oracle9i 9.0.x
rem
rem
rem
rem Changes:
rem DD.MM.YYYY Consultant Change
rem -----------------------------------------------------------------------
rem 25.09.1995 urs.meier  Added v$shared_pool_reserved
rem 05.04.1995 urs.meier  rename
rem 19.06.1997 AnK        added  "R-" Decodes for reserved Pool
rem 02.08.1997 AnK        Oracle8
rem 21.04.1999 AnK        OK for Oracle8i
rem 27.08.2002 MaW        OK for Oracle9i R2
rem -----------------------------------------------------------------------
rem
rem

rem
@@foenvtit "Shared pool statistics"
clear	columns -
	breaks -
	computes 

set     pagesize 80 -
	verify off -
        heading on -
        echo off -
        termout on -
        newpage 0
@@fopauon
set pages 80
COLUMN text 		FORMAT A35
COLUMN sum	 	FORMAT 999,999,999	HEADING 'Sum' 
COLUMN max		FORMAT 999,999,999	HEADING 'Max'
COLUMN cou 		FORMAT 999,999,999	HEADING 'Count'

col "Parameter" format a40 trunc
col "Session" format a10 trunc
col "Instance" format a10 trunc
col "S-Mod" format a5 trunc
col "I-Mod" format a5 trunc



select  a.ksppinm  "Parameter",
  decode(p.isses_modifiable,'FALSE',NULL,NULL,NULL,b.ksppstvl) "Session",
  c.ksppstvl "Instance",
  p.isses_modifiable "S-Mod",
  p.issys_modifiable "I-Mod"
     from x$ksppi a, x$ksppcv b, x$ksppsv c, v$parameter p
    where a.indx = b.indx and a.indx = c.indx
      and p.name(+) = a.ksppinm
      and upper(a.ksppinm) like '%SHARED_POOL%'
  order by a.ksppinm
/

select * from v$sgainfo
/
select * from v$sgastat where name = 'free memory'
/


SELECT DECODE(ksmchcls,
                       'R-recr',    'Res. Pool: Recreatable, flushable',
                       'R-freea',   'Res. Pool: Used, not flushable',
                       'R-free',    'Res. Pool: Free',
                       'R-perm',    'Res. Pool: Permanent',
                       'recr',    'Norm. Pool: Recreatable, flushable',
                       'freeabl', 'Norm. Pool: Used, not flushable',
                       'free',    'Norm. Pool: Free',
                       'perm',    'Norm. Pool: Permanent',
                                  ksmchcls) text ,
       SUM(ksmchsiz) sum, 
	MAX(ksmchsiz) max, 
	COUNT(*) cou
  FROM sys.x$ksmsp
  WHERE ksmchcls IN ('R-free','free')
 GROUP BY ksmchcls;


COLUMN kghlufsh HEADING "Flushes"
COLUMN kghluops HEADING "Operations"

SELECT kghlufsh,kghluops
  FROM sys.x$kghlu;


COLUMN ksmlrnum HEADING "Flushed|SP-Pieces" FORMAT 999,990
COLUMN ksmlrcom HEADING "Comment" 
COLUMN ksmlrhon HEADING "Command"
COLUMN ksmlrsiz HEADING "Size" 
 
SELECT ksmlrhon,ksmlrcom,ksmlrsiz,ksmlrnum
  FROM sys.x$ksmlru;


COLUMN request_failures 	Heading 'Nbr.4031-Errors'
COLUMN last_failure_size	Heading 'Chunk Bytes (last fail.)'
COLUMN last_aborted_size	Heading 'Aborted Alloc. before 4031'
SELECT requests,
       request_failures,
       last_failure_size,
       last_aborted_size
  FROM v$shared_pool_reserved;
col "Parameter" clear
col "Session" clear
col "Instance" clear
col "S-Mod" clear
col "I-Mod" clear

set pages 42
ttitle off
@@fopauoff
