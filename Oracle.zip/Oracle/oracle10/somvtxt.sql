rem ---------------------------------------------------------------------------
rem  Trivadis AG, Baden-D�ttwil/Basel/Bern/Lausanne/Z�rich
rem               D�sseldorf/Frankfurt/Freiburg i.Br./Hamburg/M�nchen/Stuttgart
rem               Wien
rem               Switzerland/Germany/Austria Internet: http://www.trivadis.com
rem ---------------------------------------------------------------------------
rem $Id: somvtxt.sql 179 2008-11-30 22:18:01Z cha $
rem ---------------------------------------------------------------------------
rem  Group/Privileges.: User
rem  Script Name......: somvtxt.sql
rem  Developer........: Christian Antognini (ChA)
rem  Date.............: 05.07.2001
rem  Version..........: Oracle Database 10g
rem  Description......: Show query associated with materialized views
rem  Usage............: 
rem  Input parameters.: 
rem  Output...........: 
rem  Called by........:
rem  Requirements.....: 
rem  Remarks..........: Lower/mixed case object names are not supported
rem
rem ---------------------------------------------------------------------------
rem Changes:
rem DD.MM.YYYY Developer Change
rem ---------------------------------------------------------------------------
rem 03.09.2002 ThJ       OK for Oracle9i R2
rem 15.09.2003 AnK       OK for 10.1
rem 30.11.2008 ChA       Fixed header + Formatting
rem ---------------------------------------------------------------------------

store set temp.tmp replace

ACCEPT vname CHAR PROMPT "Text for materialized view(s) [%]: " Default "%"

SET PAUSE OFF ECHO OFF TERMOUT OFF
CLEAR COLUMNS BREAKS COMPUTES
COLUMN maxlong  NOPRINT NEW_VALUE maxlong
COLUMN mview_name NOPRINT NEW_VALUE mview_name
COLUMN query FORMAT A80 WRAP

SELECT MAX(query_len) maxlong
FROM   user_mviews
WHERE  mview_name LIKE UPPER('&&vname');

SET LONG &maxlong

SET TERMOUT ON FEEDBACK ON VERIFY OFF LINESIZE 80
   
@@fopauon

BREAK ON mview_name SKIP PAGE

TTITLE CENTER "Query associated to "mview_name

SELECT mview_name, query
 FROM user_mviews
WHERE mview_name LIKE UPPER('&&vname')
ORDER BY mview_name;

TTITLE OFF
col maxlong clear
col mview_name clear

@@fopauoff
@temp.tmp
