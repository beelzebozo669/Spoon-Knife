rem -------------------------------------------------------------------------
rem        Trivadis AG, Baden/Basel/Bern/Lausanne/Mellingen/Z�rich
rem                     Frankfurt/Freiburg i.Br./M�nchen/Stuttgart
rem                     Switzerland/Germany Internet: http://www.trivadis.com
rem -------------------------------------------------------------------------
rem   $Id: sdts.sql 130 2008-01-07 10:06:59Z cha $
rem   **********************************************************************
rem   Bereich..........:  DBA
rem   Name.............:  sdts.sql
rem   Entwickler.......:  Urs Meier urm urs.meier@trivadis.com
rem   Datum............:  14.11.1994
rem   Version..........:  Oracle9i - 2.0
rem   Zweck............:  Display free space in all tablespaces as well
rem                       as free-space fragmentation
rem   Input Parameter..:
rem   Output.......... :
rem   Wird aufgerufen..:
rem   Bemerkung........:
rem -----------------------------------------------------------------------
rem
rem DD.MM.YYYY Entwickler Aenderung
rem -----------------------------------------------------------------------
rem 02.08.1997 AnK        Oracle8 (added contents to status and 
rem                       prompt comments at the end)
rem 21.04.1999 AnK        Added locally managed tablespaces. 
rem 21.04.1999 AnK        Show also full tablespaces
rem 27.11.2001 SvV        Show SUM_FREE und %FREE in tempfile temp-ts
rem 30.11.2001 SvV        Show correct values for full locally managed-ts
rem 05.04.2002 MaW        Added display of autoextend
rem 08.27.2002 MaW        OK for Oracle9i R2
rem 06.10.2002 FaR        Changed NULL to 0 in union
rem 29.11.2004 MaW        Added Segement Space Management
rem 18.10.2007 ChA        Fixed formatting problem because of cursor_sharing
rem                       and show MB instead of bytes
rem 24.10.2007 ChA        Fixed footer
rem 07.01.2008 ChA        Removed hint RULE + tuning
rem -----------------------------------------------------------------------
rem
rem
set logsource "Dummy"
store set temp.tmp replace
clear	columns -
	breaks -
	computes 
set pagesize 100 linesize 100

@@foenvtit "Tablespace statistics"

column tablespace_name format a30
column status format a3 trunc
column extent_management format a3 trunc heading MGM
column allocation_type format a3 trunc heading ALL
column space_management format a1
column auto format a1
column logging format a3 trunc heading LOG
column t format 9,999,990 heading TOTAL_MB
column s format 9,999,990 heading SUM_FREE_MB
column m format 9,999,990 heading MAX_FREE_MB
column c format 9,990 heading COUNT
column p format 990.0 heading "% FREE"
SELECT dt.tablespace_name,substr(dt.status,1,2)||substr(contents,1,1) STATUS,
       dt.extent_management, 
        decode(dt.extent_management,'LOCAL',decode(dt.allocation_type,'USER','MIG',dt.allocation_type),dt.allocation_type) allocation_type,
       substr(segment_space_management,1,1) space_management,
       decode(t.auto,0,'N','Y') auto,
       dt.logging,
       round(t.t/1024/1024) t, round(nvl(u.s,0)/1024/1024) s, nvl(u.s/t.t*100,0) p, round(nvl(u.m,0)/1024/1024) m, nvl(u.c,0) c
  FROM dba_tablespaces dt,
       (SELECT tablespace_name,SUM(bytes) s, MAX(bytes) m, COUNT(*) c
          FROM dba_free_space
         GROUP BY tablespace_name) u,
       (SELECT tablespace_name,SUM(bytes) t, sum(decode(autoextensible,'YES',1,0)) auto
          FROM dba_data_files
         GROUP BY tablespace_name) t
 WHERE dt.tablespace_name = u.tablespace_name(+)
   AND dt.tablespace_name = t.tablespace_name
 UNION
SELECT dt.tablespace_name,substr(dt.status,1,2)||substr(contents,1,1) STATUS,
       dt.extent_management, 
        decode(dt.extent_management,'LOCAL',decode(dt.allocation_type,'USER','MIG',dt.allocation_type),dt.allocation_type) allocation_type,
       substr(segment_space_management,1,1) space_management,
       decode(t.auto,0,'N','Y') auto,
       dt.logging,
       round(t.t/1024/1024) t, round((t.t-nvl(u.s,0))/1024/1024) s, ((t.t-nvl(u.s,0))/t.t*100) p, 0 m, 0 c
  FROM dba_tablespaces dt,
       (SELECT tablespace_name,SUM(bytes_cached) s
          FROM v$temp_extent_pool 
         GROUP BY tablespace_name) u,
       (SELECT tablespace_name,SUM(bytes) t, sum(decode(autoextensible,'YES',1,0)) auto
          FROM dba_temp_files
         GROUP BY tablespace_name) t
 WHERE dt.tablespace_name = u.tablespace_name(+)
   AND dt.tablespace_name = t.tablespace_name
 ORDER BY 1;
column tablespace_name clear
column status clear
column t clear
column s clear
column m clear
column c clear
column p clear
ttitle off
prompt
prompt STA: ON=Online OF=Offline P=Permanent T=Temporary U=Undo R=Read only
prompt MGM: LOC=Locally managed DIC=Dictionary managed
prompt ALL: SYS=Autoallocate UNI=Uniform USE=Dictionary managed MIG=Uniform migrated with DBMS_SPACE_ADMIN
prompt S  : Segment space management is (A)uto or (M)anual
prompt A  : Y=Tablespace contains autoextensible files N=Tablespace contains no autoextensible files
prompt LOG: LOG=LOGGING NOL=NOLOGGING
prompt
@temp.tmp
