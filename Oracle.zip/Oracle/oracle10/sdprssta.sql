rem -------------------------------------------------------------------------
rem        Trivadis AG,  Baden/Basel/Bern/Lausanne/Z�rich
rem                     Frankfurt/Freiburg i.Br./M�nchen/Stuttgart
rem                     Switzerland/Germany Internet: http://www.trivadis.com
rem -------------------------------------------------------------------------
rem   $Header$
rem   **********************************************************************
rem   Group/Privileges.: DBA
rem   Script-Name......: sdprssta.sql
rem   Developer........: Urs Meier (urm) urs.meier@trivadis.com
rem   Date.............: 1995
rem   Version..........: Oracle10g
rem   Usage............: Show Parse-Statistics
rem   Input parameters.:
rem   Output.......... : 
rem   Called by........:
rem   Remarks..........:
rem -----------------------------------------------------------------------
rem
rem $Log$
rem Revision 1.1  2003/09/09 18:24:56  ank
rem - OK for 10.1
rem
rem Revision 1.4  2002/09/09 16:56:24  far
rem 9.2 f�hig checked by ThJ
rem
rem Revision 1.2  2001/07/22 12:59:28  ank
rem - Load initial release Oracle9i 9.0.x
rem
rem
rem
rem Changes:
rem DD.MM.YYYY Consultant Change
rem -----------------------------------------------------------------------
rem 05.04.1997 urs.meier  rename
rem 02.08.1997 AnK        Oracle8 (parse count --> parse count (total))
rem 20.04.1999 AnK        OK for Oracle8i
rem 03.09.2002 ThJ        OK for Oracle9i R2                            
rem -----------------------------------------------------------------------
rem
rem
COLUMN O NOPRINT
COLUMN VALUE FORMAT 999,999,990.99
@@foenvtit "Parse statistics"
@@fopauon
        SELECT  'Number of user calls: ' STAT, value, 1 O
	FROM    v$sysstat
	WHERE   name = 'user calls'
	UNION
	SELECT  'Number of parse calls: ' STAT, value, 2 O
	FROM    v$sysstat
	WHERE	name = 'parse count (total)'
	UNION
	SELECT	'Number of user calls per parse: ' STAT,
		ROUND(ucall.value/pcall.value,5) VALUE, 3 O
	FROM 	v$sysstat ucall, v$sysstat pcall
	WHERE	ucall.name = 'user calls'
	AND	pcall.name = 'parse count (total)'
	UNION
        SELECT  'Session hits per parse in %: ' STAT,
                ROUND((ucall.value/pcall.value*100),2) VALUE, 4 O
        FROM    v$sysstat ucall, v$sysstat pcall
        WHERE   ucall.name = 'session cursor cache hits'
        AND     pcall.name = 'parse count (total)'
         AND     ucall.value > 0 
	ORDER BY O;
TTITLE OFF
COLUMN O CLEAR
COLUMN VALUE CLEAR
@@fopauoff
