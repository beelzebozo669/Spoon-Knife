rem -------------------------------------------------------------------------
rem        Trivadis AG, Baden/Basel/Bern/Lausanne/Z�rich
rem                     Frankfurt/Freiburg i.Br./M�nchen/Stuttgart
rem                     Switzerland/Germany Internet: http://www.trivadis.com
rem -------------------------------------------------------------------------
rem   $Header$
rem   **********************************************************************
rem
rem   Group/Privileges.: SYS
rem   Script-Name......: csprcsto.sql
rem   Developer........: Andri Kisseleff (ank) andri.kisseleff@trivadis.com
rem   Date.............: 21.11.1995
rem   Version..........: Oracle10g
rem   Usage............: show storage details of a table (unused space, etc.)
rem   Input parameters.:
rem   Output.......... :
rem   Called by........:
rem   Remarks..........:
rem                      ORACLE 7.2 and higher using dbms_space.unused_space
rem
rem
rem                      required direct grants from sys to the owner of these packages:
rem
rem                      IMPORTANT: if SYS does not have the PRIVILEGE "ANALYZE ANY"
rem                                 the call to DBMS_SPACE will fail with "insufficient privileges"
rem                                 in many Oracle releases (i.e. 8.0.3)
rem                      Please grant then: GRANT ANALYZE ANY TO SYS;
rem
rem
rem
rem	Special cases:
rem	- Index must be owned by table owner
rem	- Cases where index_name = table_name not handled
rem - ANALYZE INDEX VALIDATE STRUCTURE not supported by Oracle for sub-part. Indexes
rem   with 8.1.5 and 8.1.6 (INDEX_STATS allways empty) --> EXACT=TRUE for such
rem   index sub-partitions not supported by this version (Gives a documented error)
rem
rem   Changed:
rem       'SELECT COUNT(DISTINCT(SUBSTR(dbms_rowid.rowid_to_restricted(T.rowid,0),1,8)||'||
rem                            'SUBSTR(dbms_rowid.rowid_to_restricted(T.rowid,0),15,4))) '||
rem   first to:
rem       dbms_rowid.rowid_block_number(rowid) || dbms_rowid.rowid_relative_fno(rowid)
rem   and then to:
rem       substr(rowid,1,15) 
rem   Result is correct, and *much* faster
rem
rem History:
rem -----------------------------------------------------------------------
rem $Log$
rem Revision 1.2  2004/04/25 17:36:35  mnb
rem Changes for bigfile tablespaces
rem Tuning for non-bigfile tablespaces:
rem using substr(rowid,7,3) instead dbms_rowid.rowid_relative_fno(rowid)
rem
rem Revision 1.1  2003/09/10 07:56:08  ank
rem - OK for 10.1
rem (removed double declaration of v_partition_name in package body)
rem
rem Revision 1.3  2002/08/30 13:16:09  far
rem getestet/angepasst f�r 9.2
rem
rem Revision 1.2  2001/07/22 12:59:28  ank
rem - Load initial release Oracle9i 9.0.x
rem
rem Revision 1.3  2000/11/12 04:09:28  ank
rem - Replaced DBMS_ROWID with SUBSTR(ROWID for performance reasons
rem   (must be tested again with new Versions if OK/NOT OK)
rem
rem
rem -----------------------------------------------------------------------
rem Changes:
rem DD.MM.YYYY Consultant Change
rem -----------------------------------------------------------------------
rem 02.08.1997 ank     Oracle8. Rowid changes
rem 18.11.1997 ank     Removed HIDE in ACCEPT (Bug SQL*Plus 8.0.3, NT)
rem 18.11.1997 ank        Removed HIDE in ACCEPT (Bug SQL*Plus 8.0.3, NT)
rem 20.04.1999 AnK        OK for Oracle8i. Added HIDE again. 
rem                       NOT ready for Partitioning
rem 26.11.1999 clk     using dynamic SQL (EXECUTE IMMEDIATE) in
rem                    fkt_get_tab_space_used
rem 02.12.1999 clk     added new function fkt_get_tab_part_name
rem 10.12.1999 clk     changed fkt_segment type 
rem                    select segment_type...select distinct(segment_type)
rem 10.12.1999 clk     added new function fkt_get_ind_part_name
rem
rem 29.01.2000 AnK     Tested for tables, table partitions, table subpartition
rem                    indexes, index partitions, Indexes of IOTs --> OK
rem                    For index subpartitions sys.dbms_space gives ORA-00600 [25012]
rem                    on 8.1.5 and 8.1.6 --> Subpartitioned Indexes are actually not supported
rem 27.08.2002 MaW     Ok for Oracle9i R2, tested comp range-list part
rem
rem -----------------------------------------------------------------------
rem
rem
prompt "Must be run as SYS..."
Show User
prompt
pause <Return> or CTRL C...
set verify off
grant analyze any to sys;
prompt
prompt ---> package pck_dba_tools
prompt
create or replace package pck_dba_tools
/*
   pck_dba_tools
   21.11.1995/Trivadis AG, Andri Kisseleff
   Package with several useful functions/procedures used in different procedures
*/
as
v_cursor integer;
v_rows_processed integer;
v_nbr_extents integer;
v_file_name sys.dba_data_files.file_name%TYPE;
v_segment_type sys.dba_segments.segment_type%TYPE;
v_uniqueness sys.dba_indexes.uniqueness%TYPE;
v_tablespace_name sys.dba_tablespaces.tablespace_name%TYPE;
v_table_name sys.dba_tables.table_name%TYPE;
v_partition_name sys.dba_tab_partitions.partition_name%TYPE;
v_partitioned sys.dba_tables.partitioned%TYPE;
v_composite sys.dba_tab_partitions.composite%TYPE;
v_last_used_extent_file_id sys.dba_data_files.file_id%TYPE;

/*
  fkt_seg_tablespace_name returns the tablespace name of a given object
*/
function fkt_get_seg_tablespace_name
         (v_owner varchar2,
          v_segment_name varchar2,
          v_segment_type varchar2) return varchar2;
/*
   fkt_segment_type: returns the segment type of a given owner/segment_name
*/
function fkt_segment_type
         (v_owner  varchar2,
          v_segment_name  varchar2) return varchar2;

function fkt_get_ind_part_name 
         (v_owner varchar2, v_segment_name varchar2,v_partition_name varchar2) 
            return varchar2;

function fkt_get_tab_part_name
         (v_owner varchar2, v_segment_name varchar2,v_partition_name varchar2) 
            return varchar2;

/*
   fkt_uniqueness: return UNIQUE or NULL for given owner/index_name
*/
function fkt_uniqueness
         (v_owner varchar2,
          v_index_name varchar2) return varchar2;
/*
   fkt_get_nbr_extents: returns number of extents of a given segment
*/
function fkt_get_nbr_extents
         (v_owner varchar2,
          v_segment_name varchar2,
          v_segment_type varchar2) return integer;
/*
   fkt_get_table_name: returns table name for a given index
*/
function fkt_get_table_name
	 (v_owner varchar2,
	  v_index_name varchar2) return varchar2;
/*
   fkt_get_blocksize: returns the blocksize of the DB (DB_BLOCK_SIZE)
*/
function fkt_get_blocksize return number;



/*
   fkt_get_tab_space_used: number of blocks of a table filled with at least
   one record
*/
function fkt_get_tab_space_used
         (v_owner varchar2,
          v_table_name varchar2,
          v_partition_name varchar2) return number;

/*
   fkt_get_data_file_name: get file name of TS-file based on file_id
*/
function  fkt_get_data_file_name
          (v_file_id number) return varchar2;

function fkt_hex_to_number (v_string varchar2) return integer;
-- fkt_hex_to_number
-- 27.11.95/Trivadis AG, Andri Kisseleff
-- function to return decimal value
-- IN:     hex string (ex. F1)
-- RETURN: decimal values (ex. 17)
--
function fkt_get_index_pct_used (v_owner in varchar2,v_index_name in varchar2,v_partition_name in varchar2)
   return number;
-- fkt_get_index_pct_used
-- 18.02.96/Trivadis AG, Andri Kisseleff
-- function to return the used space in percent of an index
-- IN:     Index owner and name
-- RETURN: percentage used space
function fkt_get_index_lf_rows (v_owner in varchar2,v_index_name in varchar2)
   return number;
-- fkt_get_index_lf_rows
-- 18.02.96/Trivadis AG, Andri Kisseleff
-- function to return the number of leaf rows of an index
-- IN:     Index owner and name
-- RETURN: Number of leaf rows
function fkt_get_index_del_lf_rows (v_owner in varchar2,v_index_name in varchar2)
   return number;
   -- fkt_get_index_del_lf_rows
   -- 18.02.96/Trivadis AG, Andri Kisseleff
   -- function to return the number of deleted leaf rows of an index
   -- IN:     Index owner and name
   -- RETURN: Number of leaf rows
function fkt_get_index_distinct_keys(v_owner in varchar2,v_index_name in varchar2)
   return number;
   -- fkt_get_index_distinct_keys
   -- 18.02.96/Trivadis AG, Andri Kisseleff
   -- function to return the number of distinct key values of an index
   -- IN:     Index owner and name
   -- RETURN: Number of distinct keys of an index
end pck_dba_tools;
/
show errors package pck_dba_tools
create or replace package body pck_dba_tools
as
v_blocksize integer;

function fkt_segment_type
         (v_owner  varchar2,
          v_segment_name  varchar2) return varchar2
as
begin
select distinct(segment_type)
into   pck_dba_tools.v_segment_type
from   sys.dba_segments
where  owner = upper(v_owner)
and    segment_name = upper(v_segment_name);
return pck_dba_tools.v_segment_type;
exception
 when no_data_found
  then raise_application_error(-20999,upper(v_owner)||'.'||
                                      upper(v_segment_name)||
                                     ' does not exist');
 when too_many_rows
   then raise_application_error(-20999,upper(v_owner)||'.'||
			 upper(v_segment_name)||
		      ': Index and table with same name. Not handled! ');
 when others
  then raise_application_error(-20000,substr(sqlerrm,1,200));
end fkt_segment_type;

function fkt_get_ind_part_name
         (v_owner varchar2,
          v_segment_name varchar2,
          v_partition_name varchar2) return varchar2
as

begin
  SELECT DISTINCT(I.PARTITIONED) into pck_dba_tools.v_partitioned
  FROM DBA_INDEXES I 
  WHERE I.INDEX_NAME=upper(v_segment_name) AND I.OWNER=upper(v_owner);

  if  pck_dba_tools.v_partitioned ='YES'
  then
    SELECT DISTINCT(SUBSTR(P.COMPOSITE,1,1)) INTO pck_dba_tools.v_composite
    FROM DBA_IND_PARTITIONS P 
    WHERE P.INDEX_NAME=upper(v_segment_name) AND P.INDEX_OWNER=upper(v_owner);
  end if;


  if pck_dba_tools.v_partitioned='YES' and v_partition_name is null
  then 
    dbms_output.put_line('****************************************');
    dbms_output.put_line('The following partitions have been found');
    dbms_output.put_line('****************************************');
    if pck_dba_tools.v_composite ='N'
    then
    for part_rec in 
    (SELECT PARTITION_NAME FROM DBA_IND_PARTITIONS 
    WHERE INDEX_NAME=upper(v_segment_name) 
    AND INDEX_OWNER=upper(v_owner)) 
    loop
       dbms_output.put_line(part_rec.PARTITION_NAME);
    end loop;
    elsif  pck_dba_tools.v_composite ='Y'
      then
        for part_rec in 
        (SELECT SUBPARTITION_NAME FROM DBA_IND_SUBPARTITIONS 
        WHERE INDEX_NAME=upper(v_segment_name) 
        AND INDEX_OWNER=upper(v_owner)) 
        loop
           dbms_output.put_line(part_rec.SUBPARTITION_NAME);
        end loop;
      end if;

    dbms_output.put_line('****************************************');
    pck_dba_tools.v_partition_name:=null; 
    raise_application_error(-20999,'Please restart the procedure by selecting one of the above partitions');
  elsif pck_dba_tools.v_partitioned='YES' and v_partition_name is not null 
  then 
   if pck_dba_tools.v_composite ='N'
   then
    SELECT PARTITION_NAME into pck_dba_tools.v_partition_name FROM DBA_IND_PARTITIONS 
    WHERE INDEX_NAME=upper(v_segment_name) 
    AND   INDEX_OWNER=upper(v_owner) 
    AND   PARTITION_NAME=upper(v_partition_name);
   elsif pck_dba_tools.v_composite ='Y'
    then
    SELECT SUBPARTITION_NAME into pck_dba_tools.v_partition_name FROM DBA_IND_SUBPARTITIONS 
    WHERE INDEX_NAME=upper(v_segment_name) 
    AND   INDEX_OWNER=upper(v_owner) 
    AND   SUBPARTITION_NAME=upper(v_partition_name);
   end if; 
    if pck_dba_tools.v_partition_name is not null 
    then
      pck_dba_tools.v_partition_name:=upper(v_partition_name);
    end if;
  else
    pck_dba_tools.v_partition_name:=null; 
  end if;
  return (pck_dba_tools.v_partition_name); 
exception
when no_data_found 
then 
   raise_application_error(-20999,'Please restart the procedure by providing a correct partition name');
end fkt_get_ind_part_name;


function fkt_get_tab_part_name
         (v_owner varchar2,
          v_segment_name varchar2,
          v_partition_name varchar2) return varchar2
as

begin
  SELECT DISTINCT(T.PARTITIONED) INTO pck_dba_tools.v_partitioned
  FROM DBA_TABLES T 
  WHERE T.TABLE_NAME=upper(v_segment_name) AND T.OWNER=upper(v_owner);

  if  pck_dba_tools.v_partitioned ='YES'
  then
    SELECT DISTINCT(SUBSTR(P.COMPOSITE,1,1)) INTO pck_dba_tools.v_composite
    FROM DBA_TAB_PARTITIONS P 
    WHERE P.TABLE_NAME=upper(v_segment_name) AND P.TABLE_OWNER=upper(v_owner);
  end if;

    if pck_dba_tools.v_partitioned='YES' and v_partition_name is NULL
    then 
      dbms_output.put_line('****************************************');
      dbms_output.put_line('The following partitions have been found');
      dbms_output.put_line('****************************************');

      if pck_dba_tools.v_composite ='N'
      then
        for part_rec in 
        (SELECT PARTITION_NAME FROM DBA_TAB_PARTITIONS 
        WHERE TABLE_NAME=upper(v_segment_name) 
        AND TABLE_OWNER=upper(v_owner)) 
        loop
           dbms_output.put_line(part_rec.PARTITION_NAME);
        end loop;
        elsif  pck_dba_tools.v_composite ='Y'
      then
        for part_rec in 
        (SELECT SUBPARTITION_NAME FROM DBA_TAB_SUBPARTITIONS 
        WHERE TABLE_NAME=upper(v_segment_name) 
        AND TABLE_OWNER=upper(v_owner)) 
        loop
           dbms_output.put_line(part_rec.SUBPARTITION_NAME);
        end loop;
      end if;
        dbms_output.put_line('****************************************');
        pck_dba_tools.v_partition_name:=null; 
        raise_application_error(-20999,'Please restart the procedure by selecting one of the above partitions');
      
    elsif pck_dba_tools.v_partitioned='YES' and v_partition_name is not null 
    then 
      if pck_dba_tools.v_composite ='N'
      then
        SELECT PARTITION_NAME into pck_dba_tools.v_partition_name FROM DBA_TAB_PARTITIONS 
        WHERE TABLE_NAME=upper(v_segment_name) 
        AND   TABLE_OWNER=upper(v_owner) 
        AND   PARTITION_NAME=upper(v_partition_name);
      elsif pck_dba_tools.v_composite ='Y'
      then
        SELECT SUBPARTITION_NAME into pck_dba_tools.v_partition_name FROM DBA_TAB_SUBPARTITIONS 
        WHERE TABLE_NAME=upper(v_segment_name) 
        AND   TABLE_OWNER=upper(v_owner) 
        AND   SUBPARTITION_NAME=upper(v_partition_name);
      end if;      
        if pck_dba_tools.v_partition_name is not null 
        then
          pck_dba_tools.v_partition_name:=upper(v_partition_name);
        end if;
    else
      pck_dba_tools.v_partition_name:=null; 
    end if;
  return (pck_dba_tools.v_partition_name); 
exception
when no_data_found 
then 
   raise_application_error(-20999,'Please restart the procedure by providing a correct partition name');
end fkt_get_tab_part_name;



function fkt_uniqueness
         (v_owner varchar2,
          v_index_name varchar2) return varchar2
as
begin
select uniqueness
into   pck_dba_tools.v_uniqueness
from   sys.dba_indexes
where  owner = upper(v_owner)
and    index_name = upper(v_index_name);
return pck_dba_tools.v_uniqueness;
exception
 when no_data_found
  then raise_application_error(-20999,upper(v_owner)||'.'||
                                      upper(v_index_name)||
                                     ' does not exist');
 when others
  then raise_application_error(-20000,substr(sqlerrm,1,200));
end fkt_uniqueness;


function fkt_get_table_name
	 (v_owner varchar2,
	  v_index_name varchar2) return varchar2
as
begin
select table_name
into   pck_dba_tools.v_table_name
from   sys.dba_indexes
where  owner = upper(v_owner)
and    index_name = upper(v_index_name);
return pck_dba_tools.v_table_name;
exception
 when no_data_found
  then raise_application_error(-20999,upper(v_owner)||'.'||
                                      upper(v_index_name)||
                                     ' does not exist');
 when others
  then raise_application_error(-20000,substr(sqlerrm,1,200));
end fkt_get_table_name;

function fkt_get_seg_tablespace_name
         (v_owner varchar2,
          v_segment_name varchar2,
          v_segment_type varchar2) return varchar2
as

begin
if pck_dba_tools.v_partition_name is not null
then
  select tablespace_name
  into   pck_dba_tools.v_tablespace_name
  from   sys.dba_segments
  where  owner = upper(v_owner)
  and    segment_name = upper(v_segment_name)
  and    segment_type = upper(v_segment_type)
  and    partition_name = upper(pck_dba_tools.v_partition_name);
  return pck_dba_tools.v_tablespace_name;
else
  select tablespace_name
  into   pck_dba_tools.v_tablespace_name
  from   sys.dba_segments
  where  owner = upper(v_owner)
  and    segment_name = upper(v_segment_name)
  and    segment_type = upper(v_segment_type);
  return pck_dba_tools.v_tablespace_name;
end if;
exception
 when no_data_found
  then raise_application_error(-20999,upper(v_owner)||'.'||
                                      upper(v_segment_name)||
                                     ' does not exist');
 when others
  then raise_application_error(-20000,substr(sqlerrm,1,200));
end fkt_get_seg_tablespace_name;

function fkt_get_nbr_extents
         (v_owner varchar2,
          v_segment_name varchar2,
          v_segment_type varchar2) return integer
as
begin
  if pck_dba_tools.v_partition_name is not null
  then
    select extents
    into   pck_dba_tools.v_nbr_extents
    from   sys.dba_segments
    where  owner = upper(v_owner)
    and    segment_name = upper(v_segment_name)
    and    segment_type = upper(v_segment_type)
    and    partition_name = upper(pck_dba_tools.v_partition_name) ;
    return pck_dba_tools.v_nbr_extents;
  else
    select extents
    into   pck_dba_tools.v_nbr_extents
    from   sys.dba_segments
    where  owner = upper(v_owner)
    and segment_name = upper(v_segment_name)
    and    segment_type = upper(v_segment_type);
    return pck_dba_tools.v_nbr_extents;
  end if;
exception
 when no_data_found
  then raise_application_error(-20999,upper(v_owner)||'.'||
                                      upper(v_segment_name)||
                                     ' does not exist');
 when others
  then raise_application_error(-20000,substr(sqlerrm,1,200));
end fkt_get_nbr_extents;

function fkt_get_blocksize return number
as
v_blocksize integer;
begin
 select value
 into   v_blocksize
 from   sys.v_$parameter
 where  upper(name) = 'DB_BLOCK_SIZE';
 return v_blocksize;
 exception
  when no_data_found
   then
     raise_application_error(-20999,'pck_dba_tools.fkt_get_blocksize:'||
                                    ' NO DATA FOUND');
  when others
   then raise_application_error(-20000,substr(sqlerrm,1,200));
end fkt_get_blocksize;

function fkt_get_tab_space_used
         (v_owner varchar2,
          v_table_name varchar2,
          v_partition_name varchar2) return number
as
v_number_blocks integer;

begin
  v_blocksize := pck_dba_tools.fkt_get_blocksize;  /* blocksize (2048, etc.) */

  if v_partition_name is not null
  then
    if pck_dba_tools.v_composite='N'
    then
      EXECUTE IMMEDIATE
      'SELECT COUNT(DISTINCT(SUBSTR(T.rowid,1,15)))'||
                            ' FROM '||v_owner||'.'||v_table_name||' PARTITION ('||v_partition_name||') T'
      into v_number_blocks;
    elsif pck_dba_tools.v_composite='Y' 
    then
      EXECUTE IMMEDIATE
      'SELECT COUNT(DISTINCT(SUBSTR(T.rowid,1,15)))'||
                            ' FROM '||v_owner||'.'||v_table_name||' SUBPARTITION ('||v_partition_name||') T'
      into v_number_blocks;
    end if;
  else
    EXECUTE IMMEDIATE
    'SELECT COUNT(DISTINCT(SUBSTR(T.rowid,1,15)))'||
                          ' FROM '||v_owner||'.'||v_table_name||' T'
    into v_number_blocks;
  end if;
  return (v_number_blocks);
end fkt_get_tab_space_used;

function fkt_get_data_file_name
         (v_file_id number) return varchar2
as
v_file_name sys.dba_data_files.file_name%TYPE;
begin
 select file_name
 into   v_file_name
 from   sys.dba_data_files
  where  relative_fno = v_file_id 
     or ( relative_fno = 1024 and file_id = v_file_id ) --bigfile
 ;
 return v_file_name;
 exception
  when no_data_found
   then
     raise_application_error(-20999,'No such file.  Id: '||to_char(v_file_id));
  when others
   then raise_application_error(-20000,substr(sqlerrm,1,200));
end fkt_get_data_file_name;

function fkt_hex_to_number (v_string varchar2) return integer
-- fkt_hex_to_number
-- 27.11.95/Trivadis AG, Andri Kisseleff
-- function to return decimal value
-- IN:     hex string (ex. F1)
-- RETURN: decimal values (ex. 17)
--
as
v_char    char(1);
v_number  number;
v_result  integer default 0;
v_counter integer default 0;
begin
 for i in reverse 1 .. length(v_string)
  loop
   v_counter := v_counter+1;
   v_char := upper(substr(v_string,i,1));
   if    (v_char = 'A') then v_number := '10';
   elsif (v_char = 'B') then v_number := '11';
   elsif (v_char = 'C') then v_number := '12';
   elsif (v_char = 'D') then v_number := '13';
   elsif (v_char = 'E') then v_number := '14';
   elsif (v_char = 'F') then v_number := '15';
   else  v_number := to_number(v_char);
   end if;
   v_result := v_result + v_number*power(16,v_counter-1);
  end loop;
 return v_result;
end fkt_hex_to_number;

function fkt_get_index_pct_used (v_owner in varchar2,
                                 v_index_name in varchar2,
                                 v_partition_name in varchar2) return number
as
-- fkt_get_index_pct_used
-- 18.02.96/Trivadis AG, Andri Kisseleff
-- function to return the used space in percent of an index
-- IN:     Index owner and name
-- RETURN: percentage used space
v_pct_used index_stats.pct_used%type;
 begin
  if pck_dba_tools.v_partitioned ='YES'
  then
    EXECUTE IMMEDIATE
    'ANALYZE INDEX '||v_owner||'.'||v_index_name||' PARTITION ('||v_partition_name||') VALIDATE STRUCTURE';
  else
    EXECUTE IMMEDIATE
    'ANALYZE INDEX '||v_owner||'.'||v_index_name||' VALIDATE STRUCTURE';
  end if;
  
  select pct_used
  into   v_pct_used
  from   index_stats;
  return v_pct_used;
  exception
   when no_data_found
    then
    raise_application_error(-20999,'sys.fkt_get_index_pct_used: NO DATA FOUND. Error in Program or Sub-Part Index (Oracle-Bug in 8.1.5/8.1.6');
 end fkt_get_index_pct_used;


function fkt_get_index_lf_rows (v_owner in varchar2,
	     v_index_name in varchar2) return number
as
-- fkt_get_index_lf_rows
-- 18.02.96/Trivadis AG, Andri Kisseleff
-- function to return the number of leaf rows of an index
-- IN:     Index owner and name
-- RETURN: Number of leaf rows
v_lf_rows index_stats.lf_rows%type;
 begin
  select lf_rows
  into   v_lf_rows
  from   index_stats;
  return v_lf_rows;
  exception
   when no_data_found
    then
    raise_application_error(-20999,'fkt_get_index_lf_rows: NO DATA FOUND');
 end fkt_get_index_lf_rows;
function fkt_get_index_del_lf_rows (v_owner in varchar2,
             v_index_name in varchar2) return number
as
-- fkt_get_index_del_lf_rows
-- 18.02.96/Trivadis AG, Andri Kisseleff
-- function to return the number of deleted leaf rows of an index
-- IN:     Index owner and name
-- RETURN: Number of deleted leaf rows
v_del_lf_rows index_stats.del_lf_rows%type;
 begin
  select del_lf_rows
  into   v_del_lf_rows
  from   index_stats;
  return v_del_lf_rows;
  exception
   when no_data_found
    then
    raise_application_error(-20999,'fkt_get_index_del_lf_rows: NO DATA FOUND');
 end fkt_get_index_del_lf_rows;


function fkt_get_index_distinct_keys (v_owner in varchar2,
             v_index_name in varchar2) return number
as
-- fkt_get_index_distinct_keys
-- 18.02.96/Trivadis AG, Andri Kisseleff
-- function to return the number of deleted leaf rows of an index
-- IN:     Index owner and name
-- RETURN: Number of deleted leaf rows
v_distinct_keys index_stats.distinct_keys%type;
 begin
  select distinct_keys
  into   v_distinct_keys
  from   index_stats;
  return v_distinct_keys;
  exception
   when no_data_found
    then
    raise_application_error(-20999,'fkt_get_index_distinct_keys: NO DATA FOUND');
 end fkt_get_index_distinct_keys;
end pck_dba_tools;
/
show errors package body pck_dba_tools
rem
create or replace procedure prc_show_records_per_file
         (v_owner in varchar2,
          v_segment_name in varchar2)
/*
 prc_show_records_per_file
 21.11.1995, Trivadis AG, Andri Kisseleff
 shows file names of all datafiles where a table has blocks in
*/
as
 v_cursor integer;
 v_rows_processed integer;
 v_file_id_char varchar2(4);
 v_number_records integer;
 v_file_name sys.dba_data_files.file_name%TYPE;
 v_tablespace sys.dba_tablespaces.tablespace_name%TYPE;
 v_bigfile varchar2(3);
begin
 v_cursor := dbms_sql.open_cursor;
 
 select t.bigfile into v_bigfile 
 from v$tablespace t
 where t.name = pck_dba_tools.v_tablespace_name;

 if pck_dba_tools.v_partitioned='YES' and pck_dba_tools.v_composite='N'
 then
   if v_bigfile='NO' then
   -- no bigfile --> relative file number is stored in position 7-9 of rowid
   -- group by substr(rowid,7,3) is much faster than group by dbms_rowid.rowid_relative_fno(rowid)
    dbms_sql.parse(v_cursor,
                  --'SELECT dbms_rowid.rowid_relative_fno(rowid),
                  'SELECT dbms_rowid.rowid_relative_fno(''AAAAAA''||substr(rowid,7,3)||''AAAAAAAAA''),
                   COUNT(*) '||
                  'FROM '||v_owner||'.'||v_segment_name||' PARTITION ('||pck_dba_tools.v_partition_name||')'||
                  ' GROUP BY substr(rowid,7,3)',
                  --' GROUP BY dbms_rowid.rowid_relative_fno(rowid)',
                dbms_sql.native);
   else
   -- when bigfile, we only have 1 datafile with a constant file_id
    dbms_sql.parse(v_cursor,
                  'SELECT 0,
                   COUNT(*) '||
                  'FROM '||v_owner||'.'||v_segment_name||' PARTITION ('||pck_dba_tools.v_partition_name||')',
                dbms_sql.native);
   end if;
 elsif pck_dba_tools.v_partitioned='YES' and pck_dba_tools.v_composite='Y'
 then
   if v_bigfile='NO' then
     dbms_sql.parse(v_cursor,
                  'SELECT dbms_rowid.rowid_relative_fno(''AAAAAA''||substr(rowid,7,3)||''AAAAAAAAA''),
                   COUNT(*) '||
                  'FROM '||v_owner||'.'||v_segment_name||' SUBPARTITION ('||pck_dba_tools.v_partition_name||')'||
                  ' GROUP BY substr(rowid,7,3)',
                dbms_sql.native);
   else
     dbms_sql.parse(v_cursor,
                  'SELECT 0,
                   COUNT(*) '||
                  'FROM '||v_owner||'.'||v_segment_name||' SUBPARTITION ('||pck_dba_tools.v_partition_name||')',
                dbms_sql.native);
   end if;
 else
   if v_bigfile='NO' then
     dbms_sql.parse(v_cursor,
                  'SELECT dbms_rowid.rowid_relative_fno(''AAAAAA''||substr(rowid,7,3)||''AAAAAAAAA''),
                   COUNT(*) '||
                  'FROM '||v_owner||'.'||v_segment_name||
                  ' GROUP BY substr(rowid,7,3)',
                dbms_sql.native);
   else
     dbms_sql.parse(v_cursor,
                  'SELECT 0,
                   COUNT(*) '||
                  'FROM '||v_owner||'.'||v_segment_name,
                dbms_sql.native);
   end if;
 end if;
 dbms_sql.define_column(v_cursor,1,v_file_id_char,4);
 dbms_sql.define_column(v_cursor,2,v_number_records);
 dbms_output.put_line('Number of records per file (bigfile='||v_bigfile||'):');
 v_rows_processed := dbms_sql.execute(v_cursor);
 loop
  if (dbms_sql.fetch_rows(v_cursor) > 0)
   then
    dbms_sql.column_value(v_cursor,1,v_file_id_char);
    dbms_sql.column_value(v_cursor,2,v_number_records);
    if v_bigfile='NO' then
      v_file_name :=  pck_dba_tools.fkt_get_data_file_name(v_file_id_char);
    else
      v_file_name := pck_dba_tools.fkt_get_data_file_name(pck_dba_tools.v_last_used_extent_file_id);
    end if;
    dbms_output.put_line('--> '||v_file_name||': '||to_char(v_number_records));
   else
    exit;
  end if;
 end loop;
 dbms_sql.close_cursor(v_cursor);
end prc_show_records_per_file;
/
show errors procedure  prc_show_records_per_file
create or replace procedure prc_show_columns_of_index
	 (v_owner in varchar2,
	  v_segment_name in varchar2)
/* 18.02.1996, Trivadis AG, Andri Kisseleff
   shows attributes of a given index
*/
as
 v_l varchar2(80);
 cursor cur_col is
              select i.column_name, data_type, data_length,
		     data_precision, data_scale,
		     decode(nullable,'N','NOT NULL') nullable, i.column_position
              from   sys.dba_ind_columns i, sys.dba_tab_columns c
              where  i.index_owner = c.owner
              and    i.table_name = c.table_name
	      and    i.column_name = c.column_name
              and    i.index_owner = upper(v_owner)
              and    i.index_name = upper(v_segment_name)
	      order by i.column_position;
begin
 for rec_col in cur_col
 loop
  v_l := rpad(to_char(rec_col.column_position),12)||'  '||
	 rpad(rec_col.column_name,30)||' '||': '||
		 rec_col.data_type;
    if rec_col.data_type not in ('LONG','LONG RAW','DATE','ROWID')
     then
      if (rec_col.data_type not in ('NUMBER','FLOAT'))
       then  /* CHAR, VARCHAR, VARCHAR2 */
        v_l := v_l||'('||rec_col.data_length||')';
       else  /* NUMBER or FLOAT */
        if (rec_col.data_precision is null and rec_col.data_scale is null)
         then /* NUMBER */
          v_l := v_l;
        elsif (rec_col.data_precision is not null and rec_col.data_scale is null)
         then /* FLOAT */
          v_l := v_l||'('||rec_col.data_precision||')';
        elsif (rec_col.data_precision is null and rec_col.data_scale is not null)
         then /* INTEGER */
          v_l := v_l||'(38)';
        elsif (rec_col.data_precision is not null and rec_col.data_scale is not null)
         then /* NUMBER(7,2), NUMBER(38,0), etc. */
          v_l := v_l||'('||rec_col.data_precision||','||rec_col.data_scale||')';
         else /* Unknown or bug */
          v_l := v_l||'bug: please contact A. Kisseleff';
        end if;
      end if;
    end if;
    v_l := v_l||' '||rec_col.nullable;
  dbms_output.put_line(v_l);
 end loop;
end prc_show_columns_of_index;
/
show errors procedure prc_show_columns_of_index





create or replace procedure prcsto
         (v_owner in varchar2,
          v_segment_name in varchar2,
          v_exact in boolean default FALSE,
          v_partition_name varchar2 default NULL )
/*
   prcsto
   21.11.1995, Trivadis AG, Andri Kisseleff
   show storage statistics of a segment

   v_exact = TRUE : more accurate statistics, takes more time...
*/
as
v_total_blocks number;
v_total_bytes number;
v_unused_blocks number;
v_unused_bytes number;
v_last_used_extent_block_id number;
v_last_used_block number;
v_used_blocks number;
v_used_bytes number;
v_empty_blocks number;
v_partitioned varchar2(3);
v_composite varchar2(3);

begin
 dbms_output.enable(200000);
 pck_dba_tools.v_partitioned:= 'NO';
 pck_dba_tools.v_composite:='N';
 pck_dba_tools.v_segment_type := pck_dba_tools.fkt_segment_type(v_owner,v_segment_name);
 if (pck_dba_tools.v_segment_type ='TABLE PARTITION') or (pck_dba_tools.v_segment_type ='TABLE SUBPARTITION')
 then
   pck_dba_tools.v_partition_name:=pck_dba_tools.fkt_get_tab_part_name(v_owner,v_segment_name,v_partition_name);
 elsif (pck_dba_tools.v_segment_type ='INDEX PARTITION') or (pck_dba_tools.v_segment_type ='INDEX SUBPARTITION')
 then
   pck_dba_tools.v_partition_name:=pck_dba_tools.fkt_get_ind_part_name(v_owner,v_segment_name,v_partition_name);
 elsif (pck_dba_tools.v_segment_type ='INDEX')
 then
   pck_dba_tools.v_partition_name:=NULL;
 end if;
 dbms_space.unused_space(upper(v_owner),
                         upper(v_segment_name),
                         pck_dba_tools.v_segment_type,
                         v_total_blocks,
                         v_total_bytes,
                         v_unused_blocks,
                         v_unused_bytes,
                         pck_dba_tools.v_last_used_extent_file_id,
                         v_last_used_extent_block_id,
                         v_last_used_block,
 			 pck_dba_tools.v_partition_name);
 if (v_exact)
  then
   if (pck_dba_tools.v_segment_type = 'TABLE')
   then
     v_used_blocks := pck_dba_tools.fkt_get_tab_space_used(v_owner,v_segment_name,pck_dba_tools.v_partition_name);
     v_used_bytes  := v_used_blocks*pck_dba_tools.fkt_get_blocksize;
     v_empty_blocks := v_total_blocks-v_used_blocks;
   elsif (pck_dba_tools.v_segment_type = 'TABLE PARTITION') or 
         (pck_dba_tools.v_segment_type = 'TABLE SUBPARTITION')
   then
     v_used_blocks := pck_dba_tools.fkt_get_tab_space_used(v_owner,v_segment_name,pck_dba_tools.v_partition_name);
     v_used_bytes  := v_used_blocks*pck_dba_tools.fkt_get_blocksize;
     v_empty_blocks := v_total_blocks-v_used_blocks;
   end if; /* end table, table_partition */
 end if; /* end v_exact = TRUE */

 if (pck_dba_tools.v_segment_type = 'INDEX') or 
    (pck_dba_tools.v_segment_type = 'INDEX PARTITION')
 then /* get uniqueness */
   pck_dba_tools.v_uniqueness := pck_dba_tools.fkt_uniqueness(v_owner,v_segment_name);
 end if; /* end of index */

 if (pck_dba_tools.v_segment_type = 'TABLE') or 
    (pck_dba_tools.v_segment_type = 'TABLE PARTITION') or 
    (pck_dba_tools.v_segment_type = 'TABLE SUBPARTITION')
 then
  dbms_output.put_line(rpad('*',length(v_owner||'.'||v_segment_name||
                       ' ( '||pck_dba_tools.v_segment_type||' '||v_partition_name||' )')+2,'*'));
  dbms_output.put_line('*'||upper(v_owner)||'.'||upper(v_segment_name)||
                       ' ( '||pck_dba_tools.v_segment_type||' '||v_partition_name||' )*');
  dbms_output.put_line(rpad('*',length(v_owner||'.'||v_segment_name||
                       ' ( '||pck_dba_tools.v_segment_type||' '||v_partition_name||' )')+2,'*'));

 elsif (pck_dba_tools.v_segment_type = 'INDEX') or 
       (pck_dba_tools.v_segment_type = 'INDEX PARTITION') or
       (pck_dba_tools.v_segment_type = 'INDEX SUBPARTITION')
 then
  dbms_output.put_line(rpad('*',length(v_owner||'.'||v_segment_name||
                       ' ( '||pck_dba_tools.v_uniqueness||' '||v_partition_name||
                             pck_dba_tools.v_segment_type||' )')+3,'*'));
  dbms_output.put_line('*'||upper(v_owner)||'.'||upper(v_segment_name)||
                       ' ( '||pck_dba_tools.v_uniqueness||' '||
                             pck_dba_tools.v_segment_type||' '||v_partition_name||' )*');
  dbms_output.put_line(rpad('*',length(v_owner||'.'||v_segment_name||
                       ' ( '||pck_dba_tools.v_uniqueness||' '||v_partition_name||
                             pck_dba_tools.v_segment_type||' )')+3,'*'));
  pck_dba_tools.v_table_name := pck_dba_tools.fkt_get_table_name(v_owner,v_segment_name);
  dbms_output.put_line('Table name:   '||pck_dba_tools.v_table_name);
  dbms_output.put_line('Columns in index:');
 end if; /* end if table,table partition or index  */


 if (pck_dba_tools.v_segment_type = 'INDEX') or
    (pck_dba_tools.v_segment_type = 'INDEX PARTITION') or
    (pck_dba_tools.v_segment_type = 'INDEX SUBPARTITION')
  then
   sys.prc_show_columns_of_index(v_owner, v_segment_name);
 end if; /* end show columns of index */


 pck_dba_tools.v_tablespace_name :=
         pck_dba_tools.fkt_get_seg_tablespace_name
                                   (v_owner,
                                    v_segment_name,
                                    pck_dba_tools.v_segment_type);
 dbms_output.put_line('Tablespace name                              : '||
                                    pck_dba_tools.v_tablespace_name);
 pck_dba_tools.v_nbr_extents :=
         pck_dba_tools.fkt_get_nbr_extents
                                   (v_owner,
                                    v_segment_name,
                                    pck_dba_tools.v_segment_type);
 dbms_output.put_line('Number of extents                            : '||
                                    to_char(pck_dba_tools.v_nbr_extents));
 dbms_output.put_line('Size in Mb                                   : '||
                     to_char(round(v_total_blocks*
                     pck_dba_tools.fkt_get_blocksize/1024/1024,2))||' Mb');
 dbms_output.put_line('Number of allocated blocks                   : '||
                                            to_char(v_total_blocks));
 if (v_exact)
  then
   if (pck_dba_tools.v_segment_type = 'TABLE') or 
      (pck_dba_tools.v_segment_type = 'TABLE PARTITION') or
      (pck_dba_tools.v_segment_type = 'TABLE SUBPARTITION')
   then
     dbms_output.put_line('Used blocks (exact)                          : '||
                                            to_char(v_used_blocks));
     dbms_output.put_line('Empty blocks (exact)                         : '||
                                            to_char(v_empty_blocks));
   end if; /* end table */
 end if; /* end v_exact = TRUE */
 dbms_output.put_line('Highwater mark                               : '||
                       'File: '||to_char(pck_dba_tools.v_last_used_extent_file_id)||
                       ' Block: '||to_char(v_last_used_block));
 dbms_output.put_line('Number of empty blocks after highwater mark  : '||
                                            to_char(v_unused_blocks));
 if (v_exact)
  then
   if (pck_dba_tools.v_segment_type = 'TABLE') or 
      (pck_dba_tools.v_segment_type = 'TABLE PARTITION')  or
      (pck_dba_tools.v_segment_type = 'TABLE SUBPARTITION')
    then
     dbms_output.put_line('Used bytes (Mb) (exact)                      : '||
                        to_char(v_used_bytes)||
                        ' ('||to_char(round(v_used_bytes/1024/1024,2))||' Mb)');
   end if; /* end table */
 end if; /* end v_exact = TRUE */
 dbms_output.put_line('Number of unused bytes (after highwater) (Mb): '||
                      to_char(v_unused_bytes)||
                      ' ('||to_char(round(v_unused_bytes/1024/1024,2))||' Mb)');
 if (v_exact and (pck_dba_tools.v_segment_type = 'INDEX' or 
                  pck_dba_tools.v_segment_type = 'INDEX PARTITION' or
                  pck_dba_tools.v_segment_type = 'INDEX SUBPARTITION'))
  then
   dbms_output.put_line('PCT of space used (exact)                    : '||
        to_char(pck_dba_tools.fkt_get_index_pct_used(v_owner,v_segment_name,v_partition_name))||'%');
   dbms_output.put_line('Number of distinct keys in index             : '||
     to_char(pck_dba_tools.fkt_get_index_distinct_keys(v_owner,v_segment_name)));
   dbms_output.put_line('Number of leaf rows in index                 : '||
     to_char(pck_dba_tools.fkt_get_index_lf_rows(v_owner,v_segment_name)));
   dbms_output.put_line('Number of deleted leaf rows in index         : '||
     to_char(pck_dba_tools.fkt_get_index_del_lf_rows(v_owner,v_segment_name)));
 end if; /* end INDEX and EXACT */
 pck_dba_tools.v_file_name := pck_dba_tools.fkt_get_data_file_name(
              pck_dba_tools.v_last_used_extent_file_id);
 dbms_output.put_line('Highwater block in file: ');
 dbms_output.put_line('--> '||pck_dba_tools.v_file_name||
                           ' (Id.:'||to_char(pck_dba_tools.v_last_used_extent_file_id)||')');
 if (v_exact and pck_dba_tools.v_segment_type = 'TABLE') or
    (v_exact and pck_dba_tools.v_segment_type = 'TABLE PARTITION')  or
    (v_exact and pck_dba_tools.v_segment_type = 'TABLE SUBPARTITION')
  then
   prc_show_records_per_file(v_owner, v_segment_name);
 end if;
end;
/
show errors procedure prcsto
set verify on
show user
prompt
prompt "prcsto has been created..."
prompt
prompt Examples:
prompt
prompt set serveroutput on
prompt execute prcsto('system','help',true);
prompt execute prcsto('scott','emp',false);
prompt execute prcsto('scott','emp_ename_idx',true);
prompt execute prcsto('scott','dept'); -- default FALSE
prompt
prompt the third parameter EXACT (TRUE/FALSE) specified if the statistics
prompt shall be as exact as possible (based on ROWIDs) (TRUE) or only based
prompt on the estimations of analyze (based on HIGHWATER MARK) (FALSE)
prompt
prompt Examples for partitions:
prompt
prompt execute prcsto('SCOTT','BEST',true,'BEST_Q1');
prompt execute prcsto('SCOTT','BEST_HASH_B_NR',TRUE,'BEST_HASH_B_NR_P8');
prompt execute prcsto('SCOTT','BEST_HASH_B_NR',FALSE,'BEST_HASH_B_NR_P8');
prompt
prompt Example for IOTs:
prompt
prompt execute prcsto('SCOTT','SYS_IOT_TOP_33321',true);
prompt
undefine sys_pwd
