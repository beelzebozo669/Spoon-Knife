rem -------------------------------------------------------------------------
rem        Trivadis AG, Baden/Basel/Bern/Lausanne/Z�rich
rem                     Frankfurt/Freiburg i.Br./M�nchen/Stuttgart
rem                     Switzerland/Germany Internet: http://www.trivadis.com
rem -------------------------------------------------------------------------
rem   $Header$
rem   **********************************************************************
rem   Group/Privileges.: SYS
rem   Script-Name......: sscchpol.sql
rem   Developer........: Andri Kisseleff (ank) andri.kisseleff@trivadis.com
rem   Date.............: 09.1997
rem   Version..........: Oracle10g
rem   Usage............: Shows the buffer cache hit rate of the instance
rem                      for each individual pool
rem   Input parameters.:
rem   Output.......... : 
rem   Called by........:
rem   Remarks..........: 
rem 
rem $Log$
rem Revision 1.1  2003/09/09 07:55:00  ank
rem - OK for 10.1
rem
rem Revision 1.4  2002/08/30 13:16:09  far
rem getestet/angepasst f�r 9.2
rem
rem Revision 1.3  2001/10/22 18:23:42  ank
rem - Merged sdcchpol.sql to sscchpol.sql and removed sdcchpol.sql
rem
rem Revision 1.2  2001/07/22 12:59:28  ank
rem - Load initial release Oracle9i 9.0.x
rem
rem
rem
rem -----------------------------------------------------------------------
rem Changes:
rem DD.MM.YYYY Consultant Change
rem -----------------------------------------------------------------------
rem 20.04.1999 AnK        OK for Oracle8i.
rem 14.07.2001 AnK        Added support for Multiple Blocksizes (9i)
rem 08.27.2002 MaW        OK for Oracle9i R2
rem -----------------------------------------------------------------------
rem
rem
rem
@@foenvtit "Cache hit rate for all buffer pools"
	SET FEEDBACK 0 PAGES 24 NEWPAGE 0
	COLUMN name   FORMAT a15 HEADING "DB Pool Name"
	COLUMN ratio  FORMAT 99.99 HEADING "Hit Ratio (%)"
rem

	SELECT name, block_size, 
		(((db_block_gets+consistent_gets)-physical_reads)/
                            (db_block_gets+consistent_gets))*100 ratio
	FROM   	    v$buffer_pool_statistics
                where db_block_gets+consistent_gets > 0
/

	TTITLE off
	SET FEEDBACK ON
	COLUMN name clear
	COLUMN ratio clear
	

