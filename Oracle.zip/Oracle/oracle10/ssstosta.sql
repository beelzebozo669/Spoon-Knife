rem -------------------------------------------------------------------------
rem        Trivadis AG, Baden/Basel/Bern/Lausanne/Z�rich
rem                     Frankfurt/Freiburg i.Br./M�nchen/Stuttgart
rem                     Switzerland/Germany Internet: http://www.trivadis.com
rem -------------------------------------------------------------------------
rem   $Header$
rem   **********************************************************************
rem   Group/Privileges.: SYS
rem   Script-Name......: ssstosta.sql
rem   Developer........: Andri Kisseleff (ank) andri.kissele@trivadis.com
rem   Date.............: 20.02.1996
rem   Version..........: Oracle10g
rem   Usage............: Show STorage of a Table and it`s Indexes
rem   Input parameters.:
rem   Output.......... : 
rem   Called by........:
rem   Remarks..........: csprcsto.sql must have been run before as to create
rem                      the required packages
rem                      Must be run while connected to SYS
rem                      Will only show case insensitive objects 
rem
rem     exact = TRUE gives more accuract statistics, not only based on
rem	the highwater mark as dbms_space.unused_space normally does
rem	This requires more time
rem
rem     Only runs with Oracle 8.0.3 or higher (dbms_space, new ROWID format)
rem -----------------------------------------------------------------------
rem
rem $Log$
rem Revision 1.2  2004/04/25 19:50:08  mnb
rem - exclude objects in recycle bin
rem - only case insensitive objects
rem - exclude non-segment tables (e.g. sys.fet$)
rem
rem Revision 1.1  2003/09/10 07:56:29  ank
rem - OK for 10.1
rem
rem Revision 1.3  2002/08/30 13:16:09  far
rem getestet/angepasst f�r 9.2
rem
rem Revision 1.2  2001/07/22 12:59:28  ank
rem - Load initial release Oracle9i 9.0.x
rem
rem
rem
rem Changes:
rem DD.MM.YYYY Consultant Change
rem -----------------------------------------------------------------------
rem 02.08.1997 ank        Oracle8
rem 21.04.1999 AnK        OK for Oracle8i (Partitions muessen noch gemacht werden)
rem 06.10.1999 FaR		  changed procedure name
rem 30.01.2000 AnK        Finished support for Partitions/Sub-Partitions started by ClK
rem                       - excluded IOTs from DBA_TABLES (IOT_TOP-Indexes are shown)
rem                       - excluded LOB-Indexes from DBA_INDEXES
rem                       - Actually does not work with 8.1.5/8.1.6 with EXACT=TRUE
rem                         for Sub-Partitioned Indexes (INDEX_STATS empty)
rem                       - Excluded Global Temporary Tables 
rem 27.08.2002 MaW        Ok for Oracle9i R2, tested comp range-list part
rem -----------------------------------------------------------------------
rem
prompt
set verify off
prompt "Must be run as SYS..."
Show User
prompt
pause <Return> or CTRL C...
prompt
accept owner      	prompt "The owner of the table to be analyzed   : " 
accept table_name 	prompt "The table name to be analyzed (or %)    : " 
accept exact       	prompt "Exact = TRUE or <FALSE>                 : "
prompt
prompt --> RETURN for unpartitioned tables
prompt --> % or Partition name/Sub-Partition name for partitioned tables
prompt
accept partition_name 	prompt "Partition/Sub-Part Name, % or <NULL>    : "
set feed off echo off head off pages 0 timing off lines 120
spool ssstosta.tmp
prompt set serveroutput on
prompt execute dbms_output.enable(2000000);
prompt spool ssstosta.lis
rem 
rem first case for non-part tables and for cases where user enters a partition name:
rem
select 'execute prcsto('||chr(39)||owner||chr(39)||','
				  ||chr(39)||table_name||chr(39)||','
                                  ||nvl('&exact','FALSE')||','
				  ||chr(39)||nvl('&partition_name','')
			  	  ||chr(39)||');'
from   sys.dba_tables
where  owner = upper('&owner')
and    table_name like upper('&table_name')
and    table_name = upper(table_name)
and    (table_name,owner) in (select segment_name, owner from sys.dba_segments)
and    NVL('&partition_name','X') != '%'
and    iot_type is null
and    temporary = 'N'
and    dropped != 'YES'
order by owner, table_name
/
rem 
rem second case for part tables where user enters % for partition name (all partitions):
rem
select 'execute prcsto('||chr(39)||t.owner||chr(39)||','
				  ||chr(39)||t.table_name||chr(39)||','
                                  ||nvl('&exact','FALSE')||','
				  ||chr(39)||p.partition_name
			  	  ||chr(39)||');'
from   sys.dba_tables t, sys.dba_tab_partitions p
where  t.owner = upper('&owner')
and    t.owner = p.table_owner
and    t.table_name = p.table_name
and    t.table_name like upper('&table_name')
and    t.table_name = upper(t.table_name)
and    (t.table_name,t.owner) in (select segment_name, owner from sys.dba_segments)
and    NVL('&partition_name','X') = '%'
and    p.subpartition_count = 0
and    iot_type is null
and    temporary = 'N'
and    dropped != 'YES'
order by t.owner, t.table_name, p.partition_name
/
rem 
rem third case for sub-part tables where user enters % for sub-partition name (all sub-partitions):
rem
select 'execute prcsto('||chr(39)||t.owner||chr(39)||','
				  ||chr(39)||t.table_name||chr(39)||','
                                  ||nvl('&exact','FALSE')||','
				  ||chr(39)||p.subpartition_name
			  	  ||chr(39)||');'
from   sys.dba_tables t, sys.dba_tab_subpartitions p
where  t.owner = upper('&owner')
and    t.owner = p.table_owner
and    t.table_name = p.table_name
and    t.table_name like upper('&table_name')
and    t.table_name = upper(t.table_name)
and    (t.table_name,t.owner) in (select segment_name, owner from sys.dba_segments)
and    NVL('&partition_name','X') = '%'
and    iot_type is null
and    temporary = 'N'
and    dropped != 'YES'
order by t.owner, t.table_name, p.partition_name, p.subpartition_name
/
rem
rem and now the Indexes:
rem
rem first case for non-part tables and for cases where user enters a partition name:
rem
select 'execute prcsto('||chr(39)||owner||chr(39)||','
				  ||chr(39)||index_name||chr(39)||','
                                  ||nvl('&exact','FALSE')||');'
from   sys.dba_indexes
where  table_owner = upper('&owner')
and    table_name like upper('&table_name')
and    table_name = upper(table_name)
and    index_name = upper(index_name)
and    owner not in ('SYS')
and    NVL('&partition_name','X') = 'X'
and    index_type not in ('LOB')
and    dropped != 'YES'
order by table_owner, table_name, decode(uniqueness,'UNIQUE',1,2),index_name;
rem 
rem second case for part tables where user enters % for partition name (all partitions):
rem
select 'execute prcsto('||chr(39)||i.owner||chr(39)||','
				  ||chr(39)||i.index_name||chr(39)||','
                                  ||nvl('&exact','FALSE')||','
				  ||chr(39)||p.partition_name
			  	  ||chr(39)||');'
from   sys.dba_indexes i, sys.dba_ind_partitions p
where  i.table_owner = upper('&owner')
and    i.owner = p.index_owner
and    i.index_name = p.index_name
and    i.table_name like upper('&table_name')
and    i.table_name = upper(i.table_name)
and    i.index_name = upper(i.index_name)
and    p.subpartition_count = 0
and    owner not in ('SYS')
and    NVL('&partition_name','X') = '%'
and    index_type not in ('LOB')
and    dropped != 'YES'
order by i.table_owner, i.table_name, decode(i.uniqueness,'UNIQUE',1,2),i.index_name,p.partition_name;

rem 
rem third case for sub-part tables where user enters % for sub-partition name (all sub-partitions):
rem
select 'execute prcsto('||chr(39)||i.owner||chr(39)||','
				  ||chr(39)||i.index_name||chr(39)||','
                                  ||nvl('&exact','FALSE')||','
				  ||chr(39)||p.subpartition_name
			  	  ||chr(39)||');'
from   sys.dba_indexes i, sys.dba_ind_subpartitions p
where  i.table_owner = upper('&owner')
and    i.owner = p.index_owner
and    i.index_name = p.index_name
and    i.table_name like upper('&table_name')
and    i.index_name = upper(i.index_name)
and    owner not in ('SYS')
and    NVL('&partition_name','X') = '%'
and    index_type not in ('LOB')
and    dropped != 'YES'
order by i.table_owner, i.table_name, decode(i.uniqueness,'UNIQUE',1,2),i.index_name,p.partition_name,
         p.subpartition_name;

prompt spool off

prompt set echo off
prompt prompt
prompt prompt ssstosta.lis has been spooled...
prompt prompt
spool off
set echo on termout on feed on verify on pages 24 head on
@ssstosta.tmp
set echo off
undefine sys_pwd
