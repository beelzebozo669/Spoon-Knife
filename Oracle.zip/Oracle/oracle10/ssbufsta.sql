rem ---------------------------------------------------------------------------
rem  Trivadis AG, Baden-D�ttwil/Basel/Bern/Lausanne/Z�rich
rem               D�sseldorf/Frankfurt/Freiburg i.Br./Hamburg/M�nchen/Stuttgart
rem               Wien
rem               Switzerland/Germany/Austria Internet: http://www.trivadis.com
rem ---------------------------------------------------------------------------
rem $Id: ssbufsta.sql 144 2008-11-28 10:48:09Z cha $
rem ---------------------------------------------------------------------------
rem  Group/Privileges.: SYSDBA
rem  Script Name......: ssbufsta.sql
rem  Developer........: Andri Kisseleff (AnK)
rem  Date.............: 1996
rem  Version..........: Oracle Database 10g
rem  Description......: Show status of blocks in the buffer cache
rem  Usage............: 
rem  Input parameters.: 
rem  Output...........: 
rem  Called by........:
rem  Requirements.....: 
rem  Remarks..........: 
rem
rem ---------------------------------------------------------------------------
rem Changes:
rem DD.MM.YYYY Developer Change
rem ---------------------------------------------------------------------------
rem 02.08.1997 ank       Oracle8
rem 21.04.1999 AnK       OK for Oracle8i
rem 03.09.2002 ThJ       OK for Oracle9i R2
rem 09.09.2003 AnK       OK for 10.1
rem 28.11.2008 ChA       Fixed header + Added much more details + Formatting
rem ---------------------------------------------------------------------------

store set temp.tmp replace
set linesize 80
@foenvtit "Status of blocks in the buffer cache"
col status format a65
col cnt format 9,999,999,999
select
   decode(state,0,'FREE: no valid block image',
                1,'XCUR: a current mode block, exclusive to this instance',
                2,'SCUR: a current mode block, shared with other instances',
                3,'CR: a consistent read (stale) block image', 
                4,'READ: buffer is reserved for a block being read from disk',
                5,'MREC: a block in media recovery mode',
                6,'IREC: a block in instance (crash) recovery mode',
                8,'PI: a past image block',
                  'Other') as status, 
   count(*) as cnt
from
   sys.x$bh
group by
   decode(state,0,'FREE: no valid block image',
                1,'XCUR: a current mode block, exclusive to this instance',
                2,'SCUR: a current mode block, shared with other instances',
                3,'CR: a consistent read (stale) block image', 
                4,'READ: buffer is reserved for a block being read from disk',
                5,'MREC: a block in media recovery mode',
                6,'IREC: a block in instance (crash) recovery mode',
                8,'PI: a past image block',
                  'Other')
order by 2 desc
/
ttitle off
col status clear
col cnt clear
@temp.tmp
