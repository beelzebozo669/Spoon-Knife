rem ---------------------------------------------------------------------------
rem  Trivadis AG, Baden-D�ttwil/Basel/Bern/Lausanne/Z�rich
rem               D�sseldorf/Frankfurt/Freiburg i.Br./Hamburg/M�nchen/Stuttgart
rem               Wien
rem               Switzerland/Germany/Austria Internet: http://www.trivadis.com
rem ---------------------------------------------------------------------------
rem $Id: soobjsta.sql 177 2008-11-30 22:07:48Z cha $
rem ---------------------------------------------------------------------------
rem  Group/Privileges.: User
rem  Script Name......: soobjsta.sql 
rem  Developer........: Andri Kisseleff (AnK)
rem  Date.............: 12.09.1995
rem  Version..........: Oracle Database 10g
rem  Description......: Show objects of the connected user incl. status
rem  Usage............: 
rem  Input parameters.: 
rem  Output...........: 
rem  Called by........:
rem  Requirements.....: 
rem  Remarks..........: 
rem
rem ---------------------------------------------------------------------------
rem Changes:
rem DD.MM.YYYY Developer Change
rem ---------------------------------------------------------------------------
rem 19.07.1997 UrM       Oracle8, added temporary generated
rem 21.09.1997 AnK       Better Display for object_type for Partitions
rem                      Oracle8-Bug: IOT shows as UNDEFINED (8.0.3)
rem                      Added SUBOBJECT_NAME for Partitions
rem                      Added COL CLEARs
rem 20.04.1999 AnK       OK for Oracle8i (Added DECODE for Sub-Partitions)
rem 03.09.2002 ThJ       OK for Oracle9i R2
rem 15.09.2003 AnK       OK for 10.1 (excluded  objects in recycle bin)
rem 25.04.2004 MnB       Name of objects in recycle bin is 'BIN$%' (instead of
rem                      'RB$%' in 10g beta)
rem 30.11.2008 ChA       Fixed header + Added check about status + Formatting
rem ---------------------------------------------------------------------------

col user noprint new_value user
col date_time noprint new_value date_time
col object_name format a41 WORD_WRAP HEADING "OBJECT_NAME (PART_NAME)"
col object_type format a8 trunc heading OBJ_TYPE
col status format a7 
col last_ddl_time format a17
set echo off termout off pause off
select user, to_char(sysdate,'dd.mm.yyyy hh24:mi') date_time
from dual;
set termout on
set pause return... pause on pages 24 verify off lines 80 timing off
ttitle center 'Objects of user 'user' at 'date_time - 
       right  sql.pno skip 2
accept object_name 	char prompt "Object name, wildcard or <RETURN> for all objects    : "
accept status           char prompt "V = valid, I = invalid, <RETURN> = valid and invalid : "
spool soobjsta.lis
select 	object_name||DECODE(subobject_name,null,null,
                            ' ('||subobject_name||')') object_name, 
        decode(object_type,'PACKAGE','PCK-SPEC',
                           'PACKAGE BODY','PCK-BODY',
                           'DATABASE LINK','DB-LINK',
                           'TABLE PARTITION','TAB-PART',
                           'INDEX PARTITION','IND-PART',
                           'INDEX SUBPARTITION','IND-SUBP',
                           'TABLE SUBPARTITION','TAB-SUBP',
                                           object_type) object_type, 
        status, to_char(last_ddl_time,'dd.mm.yy hh24:mi:ss') last_ddl_time,
        temporary,
        generated
from 	user_objects
where   object_name like nvl(upper('&object_name'),'%')
and     object_name NOT LIKE 'BIN$%'
and     status like decode(upper(substr('&status',1,1)),
                                'V', 'VALID',
                                'I','INVALID',
                                              '%')
order by object_name, subobject_name, object_type
/
spool off
prompt
prompt
prompt Explanation: T = Temporary, G = Generated
prompt
prompt	soobjsta.lis has been spooled
prompt
col user clear
col date_time clear
col object_name clear
col object_type clear
col status clear
col last_ddl_time clear
ttitle off
set pause off verify on
undefine object_name
rem
rem ================================= eof =============================
