rem -------------------------------------------------------------------------
rem        Trivadis AG, Baden/Basel/Bern/Lausanne/Z�rich
rem                     Frankfurt/Freiburg i.Br./M�nchen/Stuttgart
rem                     Switzerland/Germany Internet: http://www.trivadis.com
rem -------------------------------------------------------------------------
rem   $Header$
rem   **********************************************************************
rem   Group/Privileges.: DBA
rem   Script-Name......: sdrbssta.sql
rem   Developer........: Schaller G�rard Gerard.Schaller@trivadis.com
rem   Date.............: 11.12.1999
rem   Version..........: Oracle10g
rem   Usage............: Shows current rollback segment/undo usage, extends, shrinks
rem   Input parameters.:
rem   Output.......... : 
rem   Called by........:
rem   Remarks..........: OK for auto undo mgmt, AnK
rem -----------------------------------------------------------------------
rem
rem $Log$
rem Revision 1.2  2003/09/09 18:23:06  ank
rem Changed title
rem
rem Revision 1.1  2003/09/09 18:17:24  ank
rem - OK for 10.1
rem
rem Revision 1.3  2002/09/09 16:56:24  far
rem 9.2 f�hig checked by ThJ
rem
rem Revision 1.2  2001/07/22 12:59:28  ank
rem - Load initial release Oracle9i 9.0.x
rem
rem
rem
rem Changes:
rem DD.MM.YYYY Consultant Change
rem -----------------------------------------------------------------------
rem 03.09.2002 ThJ        OK for Oracle9i R2
rem -----------------------------------------------------------------------
rem
rem
rem
SET LOGSOURCE "DUMMY"
store set temp.tmp replace
@@foenvtit "Rollback segments/Undo segments"
SET FEEDBACK 0 PAGES 24 NEWPAGE 0 LINESIZE 120
COLUMN name   FORMAT a10 HEADING "RBS-Name"
select name,extents,rssize, xacts "ACT.TX",gets,waits,extends,shrinks,aveactive,optsize,status 
from v$rollstat r, v$rollname r1 where r.usn=r1.usn;
COLUMN name CLEAR
@temp.tmp
