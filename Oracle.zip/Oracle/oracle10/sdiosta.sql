rem -------------------------------------------------------------------------
rem        Trivadis AG, Baden/Basel/Bern/Lausanne/Z�rich
rem                     Frankfurt/Freiburg i.Br./M�nchen/Stuttgart
rem                     Switzerland/Germany Internet: http://www.trivadis.com
rem -------------------------------------------------------------------------
rem   $Header$
rem   **********************************************************************
rem   Group/Privileges.: DBA
rem   Script-Name......: sdiosta.sql
rem   Developer........: Andri Kisseleff (ank) andri.kisseleff@trivadis.com
rem   Date.............: 07.1993
rem   Version..........: Oracle10g
rem   Usage............: show I/O on datafiles per filesystem/file 
rem   Input parameters.:
rem   Output.......... : 
rem   Called by........:
rem   Remarks..........: SUBSTR(NAME,1,INSTR(NAME,':')) DISK        VMS
rem		         SUBSTR(NAME,1,INSTR(NAME,'/',-1)-1) DISK   UNIX 
rem		         SUBSTR(NAME,1,INSTR(NAME,'\',-1)-1) DISK   NT
rem -----------------------------------------------------------------------
rem
rem $Log$
rem Revision 1.1  2003/09/09 18:26:50  ank
rem - OK for 10.1
rem
rem Revision 1.3  2002/08/30 13:16:09  far
rem getestet/angepasst f�r 9.2
rem
rem Revision 1.2  2001/07/22 12:59:28  ank
rem - Load initial release Oracle9i 9.0.x
rem
rem
rem
rem Changes:
rem DD.MM.YYYY Consultant Change
rem -----------------------------------------------------------------------
rem    03.1996 ank        generic for unix/VMS/NT
rem 18.06.1996 ank	  title and new header
rem 02.08.1997 ank        Oracle8
rem 20.04.1999 AnK        OK for Oracle8i
rem 21.04.1999 AnK        Added Temp-Files (temporary locally managed Tablespaces)
rem 27.08.2002 MaW        OK for Oracle9i R2
rem -----------------------------------------------------------------------
rem
rem
set logsource "Dummy"
store set temp.tmp replace
set lines 116
@@foenvtit "I/O distribution per file-system/file"
	COLUMN DUMMY NOPRINT
	SET ECHO OFF FEED OFF PAUSE OFF HEAD OFF
	SELECT * FROM DUAL;
	SET FEED ON HEAD ON
	TTITLE  LEFT    FORMAT A8 datum ' / ' sql.user -		
                CENTER  'I/O per disk/file-system [Summary]' -		
                RIGHT   'page :' FORMAT 099 sql.pno -		
                SKIP -		
                CENTER  '(1 Oracle-block = 'value  bytes) -            		
                SKIP -		
                CENTER  'Oracle version ' FORMAT A15 sql.release -		
                SKIP 2
rem	
SET PAGESIZE 24 NEWPAGE 0	
CLEAR COLUMNS	
COLUMN datum NEW_VALUE datum NOPRINT	
COLUMN DISK  FORMAT A30 HEADING "DISK/File System"	
COLUMN FILE  FORMAT A60 HEADING FILE	
COLUMN WRITTEN FORMAT 999999999 HEADING 'Blk written'	
COLUMN READ FORMAT 999999999 HEADING 'Blk read'	
COLUMN value FORMAT 99999 NEW_VALUE value NOPRINT	
SET ECHO OFF TERMOUT OFF	
SELECT  value	FROM    v$parameter	
WHERE   name = 'db_block_size';	
SET TERMOUT ON	
SELECT TO_CHAR(SYSDATE,'DD.MM.YY') Datum, 'Datafiles' FILE_TYPE,         
NVL(NVL(SUBSTR(NAME,1,INSTR(NAME,'/',-1)-1),
                SUBSTR(NAME,1,INSTR(NAME,'\',-1)-1)),
                SUBSTR(NAME,1,INSTR(NAME,':'))) DISK,
	       SUM(PHYBLKWRT) WRITTEN,	       SUM(PHYBLKRD)  READ	
               FROM   V$DBFILE A,V$FILESTAT B	
WHERE  A.FILE# = B.FILE#        
GROUP BY NVL(NVL(SUBSTR(NAME,1,INSTR(NAME,'/',-1)-1),
                 SUBSTR(NAME,1,INSTR(NAME,'\',-1)-1)),
                 SUBSTR(NAME,1,INSTR(NAME,':')))
         UNION
        SELECT TO_CHAR(SYSDATE,'DD.MM.YY') Datum, 'Tempfiles' FILE_TYPE,         
NVL(NVL(SUBSTR(NAME,1,INSTR(NAME,'/',-1)-1),
                SUBSTR(NAME,1,INSTR(NAME,'\',-1)-1)),
                SUBSTR(NAME,1,INSTR(NAME,':'))) DISK,
	       SUM(PHYBLKWRT) WRITTEN,	       SUM(PHYBLKRD)  READ	
FROM   V$TEMPFILE A,V$TEMPSTAT B	
WHERE  A.FILE# = B.FILE#        
GROUP BY NVL(NVL(SUBSTR(NAME,1,INSTR(NAME,'/',-1)-1),
                 SUBSTR(NAME,1,INSTR(NAME,'\',-1)-1)),
                 SUBSTR(NAME,1,INSTR(NAME,':')))
        ORDER BY 2,3;
	ACCEPT DUMMY CHAR PROMPT "Return..."	
TTITLE  LEFT    FORMAT A8 datum ' / ' sql.user -		
CENTER  'I/O per datafile [Detail]' -		
RIGHT   'page :' FORMAT 099 sql.pno -		
SKIP -		CENTER  '(1 Oracle-block = 'value  bytes) -            		
SKIP -		CENTER  'Oracle version ' FORMAT A15 sql.release -		
SKIP 2	
SELECT 'D' TYPE, RPAD(NAME,60,'.') "FILE",	       
PHYBLKWRT WRITTEN,	       
PHYBLKRD  READ,
               ROUND(PHYBLKRD/DECODE(PHYRDS,0,1,PHYRDS),2) "Blk reads/reads"	
FROM   V$DBFILE A, V$FILESTAT B	
WHERE  A.FILE# = B.FILE#
         UNION
SELECT 'T' TYPE, RPAD(NAME,60,'.') "FILE",	       
PHYBLKWRT WRITTEN,	       
PHYBLKRD  READ,
ROUND(PHYBLKRD/DECODE(PHYRDS,0,1,PHYRDS),2) "Blk reads/reads"	
FROM   V$TEMPFILE A, V$TEMPSTAT B	
WHERE  A.FILE# = B.FILE#	
ORDER BY 2;
prompt
prompt D = Datafile T = Tempfile
prompt	
ttitle off	
column value clear
column read clear
column written clear
column file clear
column disk clear
column datum clear
@temp.tmp
