rem -------------------------------------------------------------------------
rem        Trivadis AG, Baden/Basel/Bern/Lausanne/Z�rich
rem                     Frankfurt/Freiburg i.Br./M�nchen/Stuttgart
rem                     Switzerland/Germany Internet: http://www.trivadis.com
rem -------------------------------------------------------------------------
rem   $Header$
rem   GROUP/Privileges.: SYS
rem   Script-Name......: sshdrwai.sql
rem   Developer........: Sven Vetter (SvV) Sven.Vetter@trivadis.com
rem   Date.............: 21.02.2001
rem   Version..........: Oracle10g
rem   Oracle-Version...: 7.3.4 - 10.1
rem   Usage............: Shows Header Waits per Datafile (Freelist Waits, ...)
rem   Input parameters.:
rem   Output.......... : 
rem   Called by........: 
rem   Remarks..........: must be run as sys
rem -----------------------------------------------------------------------
rem
rem DD.MM.YYYY Consultant Change
rem -----------------------------------------------------------------------
rem $Log$
rem Revision 1.1  2003/09/15 09:08:29  ank
rem - OK for 10.1
rem
rem Revision 1.3  2002/09/09 16:56:24  far
rem 9.2 f�hig checked by ThJ
rem
rem Revision 2.0  2002/09/03           thj
rem - OK for Oracle9i R2
rem
rem Revision 1.1  2002/02/22 10:25:57  ank
rem - Initial Load CVS (SvV)
rem
rem -----------------------------------------------------------------------
rem
rem
SET echo off
SET verify off
SET linesize 90
@@fopauon
ttitle center 'Segment Header Waits per Datafile ' skip 2

column name format a50 heading "Datafile"

SELECT  name, count, time 
  FROM  x$kcbfwait , v$datafile 
  WHERE indx+1=file# AND COUNT>0 
  ORDER BY time DESC, count DESC;

column name clear
ttitle off
set pause off
