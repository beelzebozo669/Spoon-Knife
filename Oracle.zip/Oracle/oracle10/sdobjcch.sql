rem -------------------------------------------------------------------------
rem        Trivadis AG, Baden/Basel/Bern/Lausanne/Z�rich
rem                     Frankfurt/Freiburg i.Br./M�nchen/Stuttgart
rem                     Switzerland/Germany Internet: http://www.trivadis.com
rem -------------------------------------------------------------------------
rem   $Header$
rem   **********************************************************************
rem   Group/Privileges.: DBA
rem   Script-Name......: sdobjcch.sql
rem   Developer........: Urs Meier (urm) urs.meier@trivadis.com
rem   Date.............: 1995
rem   Version..........: Oracle10g
rem   Usage............: Object cache statistics
rem   Input parameters.:
rem   Output.......... : 
rem   Called by........:
rem   Remarks..........:
rem -----------------------------------------------------------------------
rem
rem $Log$
rem Revision 1.1  2003/09/09 18:46:00  ank
rem - OK for 10.1
rem
rem Revision 1.3  2002/09/09 16:56:24  far
rem 9.2 f�hig checked by ThJ
rem
rem Revision 1.2  2001/07/22 12:59:28  ank
rem - Load initial release Oracle9i 9.0.x
rem
rem
rem
rem Changes:
rem DD.MM.YYYY Consultant Change
rem -----------------------------------------------------------------------
rem 05.04.1997 urs.meier  rename
rem 02.08.1997 AnK        Oracle8
rem 20.04.1999 AnK        OK for Oracle8i. Changed Output.
rem 03.09.2002 ThJ        OK for Oracle9i R2
rem -----------------------------------------------------------------------
rem
rem
col namespace format a15
col type format a13 
@@foenvtit "Object cache statistics"
@@fopauon
select namespace,type,sum(sharable_mem),sum(loads),sum(executions)
from v$db_object_cache
group by namespace,type;

ttitle off
@@fopauoff
col namespace clear
col type clear


