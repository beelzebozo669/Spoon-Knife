rem -------------------------------------------------------------------------
rem        Trivadis AG, Baden/Basel/Bern/Lausanne/Z�rich
rem                     Frankfurt/Freiburg i.Br./M�nchen/Stuttgart
rem                     Switzerland/Germany Internet: http://www.trivadis.com
rem -------------------------------------------------------------------------
rem   $Id: sdactusr.sql 129 2007-11-15 13:17:44Z cha $
rem   **********************************************************************
rem   Group/Privileges.: DBA
rem   Script-Name......: sdactusr.sql
rem   Developer........: Urs Meier (urm) urs.meier@trivadis.com
rem   Date.............: Feb. 1995
rem   Version..........: Oracle10g
rem   Usage............: Shows PIDs and server type of connected sessions
rem   Input parameters.:
rem   Output.......... :
rem   Called by........:
rem   Remarks..........: Server "NONE" means: connected via "Shared Server"
rem -----------------------------------------------------------------------
rem
rem Changes:
rem DD.MM.YYYY Consultant Change
rem -----------------------------------------------------------------------
rem 02.08.1997 AnK        Oracle8 + changed decode for "machine" (SNP?)
rem 20.04.1999 AnK        OK for Oracle8i. Addes SERIAL#. 
rem                       Changed DECODE Username
rem 17.08.2000 urm        Idle Time in minutes    
rem 05.05.2002 FaR        Changed call of temp.tmp from @@ to @
rem 08.27.2002 ChA        OK for Oracle9i R2
rem 15.11.2007 ChA        Added column to mark current session + changed 
rem                       formatting of several columns
rem -----------------------------------------------------------------------
rem
set logsource "dummy"
store set temp.tmp replace
set linesize 120
col current_session format a1 trunc
col users format a25 trunc
col machine format a30 trunc
col program format a20 trunc
col spid format a20 trunc
col idle_min format 999,999 head IDLE_MIN
@@foenvtit "Currently connected sessions"
@@fopauon
SELECT
        decode(s.sid, sys_context('userenv','sid'),'*',NULL) AS current_session,
        replace(p.username,chr(0))||decode(s.username,NULL,NULL,' as '||s.username) AS users,
        nvl(s.machine,'Batch/Win16/SNP?') machine,
        s.sid, 
        s.serial#,
        p.spid,
        s.server,
        round(s.last_call_et/60) AS idle_min
FROM	v$session s,
        v$process p
WHERE	s.paddr = p.addr
AND     type != 'BACKGROUND'
AND     p.username is not null /* PSEUDO-Server, probably killed */
ORDER BY 2
/
col users clear
col machine clear
col program clear
ttitle off
@@fopauoff
@temp.tmp
