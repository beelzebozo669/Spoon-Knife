rem ---------------------------------------------------------------------------
rem  Trivadis AG, Baden-D�ttwil/Basel/Bern/Lausanne/Z�rich
rem               D�sseldorf/Frankfurt/Freiburg i.Br./Hamburg/M�nchen/Stuttgart
rem               Wien
rem               Switzerland/Germany/Austria Internet: http://www.trivadis.com
rem ---------------------------------------------------------------------------
rem $Id: sdobjsta.sql 141 2008-11-25 14:10:30Z cha $
rem ---------------------------------------------------------------------------
rem  Group/Privileges.: DBA
rem  Script Name......: sdobjsta.sql
rem  Developer........: Andri Kisseleff (AnK)
rem  Date.............: 12.09.1995
rem  Version..........: Oracle Database 10g
rem  Description......: Show object of a user or wildcard incl. status
rem                     (choice valid or invalid (default both))
rem  Usage............: 
rem  Input parameters.: 
rem  Output...........: 
rem  Called by........:
rem  Requirements.....: 
rem  Remarks..........: 
rem
rem ---------------------------------------------------------------------------
rem Changes:
rem DD.MM.YYYY Developer Change
rem ---------------------------------------------------------------------------
rem 19.07.1997 UrM       Oracle8, added temporary and generated
rem 21.09.1997 AnK       Better Display for object_type for Partitions
rem                      Oracle8-Bug: IOT shows as UNDEFINED (8.0.3)
rem                      Added SUBOBJECT_NAME for Partitions
rem                      Added COL CLEARs
rem 20.04.1999 AnK       OK for Oracle8i (Added DECODE f�r Sub-Partitions)
rem 03.09.2002 ThJ       OK for Oracle9i R2
rem 10.09.2003 AnK       added comment for T=Temporary, G=Generated
rem                      OK for 10.1
rem 25.11.2008 ChA       Fixed header + Query of input parameters +
rem                      Added short description for MATERIALIZED VIEW
rem ---------------------------------------------------------------------------

col user_name noprint new_value user_name
col date_time noprint new_value date_time
col owner format a10 trunc
col object_name format a30 WORD_WRAP HEADING "OBJECT_NAME (PART_NAME)"
col object_type format a8 trunc heading OBJ_TYPE
col status format a7 
col last_ddl_time format a17
accept user_name 	char prompt "User name, wildcard or <RETURN> for all users        : "
accept object_name 	char prompt "Object name, wildcard or <RETURN> for all objects    : "
accept status           char prompt "V = valid, I = invalid, <RETURN> = valid and invalid : "
prompt
prompt Explanation: T = Temporary, G = Generated
prompt
set echo off termout off pause off
select upper(nvl('&&user_name','%')) user_name, 
       to_char(sysdate,'dd.mm.yyyy hh24:mi') date_time
from dual;
set termout on
set pause return... pause on pages 24 verify off lines 80 timing off
ttitle center 'Objects of user 'user_name' at 'date_time - 
       right  sql.pno skip 2
spool sdobjsta.lis
select 	owner, object_name||DECODE(subobject_name,null,null,
                            ' ('||subobject_name||')') object_name, 
        decode(object_type,'PACKAGE','PCK-SPEC',
                           'PACKAGE BODY','PCK-BODY',
                           'DATABASE LINK','DB-LINK',
                           'TABLE PARTITION','TAB-PART',
                           'INDEX PARTITION','IND-PART',
                           'INDEX SUBPARTITION','IND-SUBP',
                           'TABLE SUBPARTITION','TAB-SUBP',
                           'MATERIALIZED VIEW','MVIEW',
                                           object_type) object_type, 
        status, to_char(last_ddl_time,'dd.mm.yy hh24:mi:ss') last_ddl_time,
        temporary,
        generated
from 	sys.dba_objects
where   owner like nvl(upper('&user_name'),'%')
and     object_name like nvl(upper('&object_name'),'%')
and     status like decode(upper(substr('&status',1,1)),
                                'V', 'VALID',
                                'I','INVALID',
                                              '%')
order by owner, object_name, subobject_name, object_type
/
spool off
prompt
prompt	sdobjsta.lis has been spooled
prompt
col user_name clear
col date_time clear
col owner clear clear
col object_name clear
col object_type clear
col status clear
col last_ddl_time clear

ttitle off
set pause off verify on
undefine object_name user_name
rem
rem ================================= eof =============================
