rem ---------------------------------------------------------------------------
rem  Trivadis AG, Baden-D�ttwil/Basel/Bern/Lausanne/Z�rich
rem               D�sseldorf/Frankfurt/Freiburg i.Br./Hamburg/M�nchen/Stuttgart
rem               Wien
rem               Switzerland/Germany/Austria Internet: http://www.trivadis.com
rem ---------------------------------------------------------------------------
rem $Id: soxplpln.sql 143 2008-11-25 16:54:24Z cha $
rem ---------------------------------------------------------------------------
rem  Group/Privileges.: User
rem  Script Name......: soxplpln.sql
rem  Developer........: Urs Meier (UrM)
rem  Date.............: September 2007
rem  Version..........: Oracle Database 10g
rem  Description......: Shows an execution plan inserted in the default
rem                     plan table (PLAN_TABLE)
rem  Usage............: 
rem  Input parameters.: 
rem  Output...........: 
rem  Called by........:
rem  Requirements.....: 
rem  Remarks..........: The format ADVANCED is available as of 10gR2 only
rem
rem ---------------------------------------------------------------------------
rem Changes:
rem DD.MM.YYYY Developer Change
rem ---------------------------------------------------------------------------
rem 05.04.1997 urs.meier  rename
rem 24.10.1997 AnK        Oracle8 (Partitons, etc.)
rem 21.04.1999 AnK        OK for Oracle8i
rem 20.03.2001 ChA        Added display for advanced features (partitioning,
rem                       parallel processing, star transformation and 
rem                       remote execution)
rem 28.08.2002 ChA        Added transaction management to support forced PDML
rem 15.09.2003 AnK        OK for 10.1
rem 25.11.2008 ChA        Fixed header + Rewritten to use DBMS_XPLAN
rem ---------------------------------------------------------------------------

STORE SET temp.tmp REPLACE
SET LINESIZE 100 PAGESIZE 0 SCAN ON VERIFY OFF FEEDBACK OFF

PROMPT
ACCEPT statement_id CHAR PROMPT "Statement ID or <RETURN> for most recently generated plan  : "
ACCEPT format CHAR PROMPT "Format (BASIC|SERIAL|ALL|ADVANCED) or <RETURN> for TYPICAL : "
PROMPT

SELECT *
FROM table(dbms_xplan.display('PLAN_TABLE','&statement_id',nvl('&format','TYPICAL')));
                        
UNDEFINE statement_id
UNDEFINE format

@temp.tmp
