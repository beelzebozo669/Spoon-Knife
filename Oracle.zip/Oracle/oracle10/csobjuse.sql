rem ---------------------------------------------------------------------------
rem  Trivadis AG, Baden-D�ttwil/Basel/Bern/Lausanne/Z�rich
rem               D�sseldorf/Frankfurt/Freiburg i.Br./Hamburg/M�nchen/Stuttgart
rem               Wien
rem               Switzerland/Germany/Austria Internet: http://www.trivadis.com
rem ---------------------------------------------------------------------------
rem $Id: csobjuse.sql 190 2008-11-30 23:58:07Z cha $
rem ---------------------------------------------------------------------------
rem  Group/Privileges.: SYSDBA
rem  Script Name......: csobjuse.sql
rem  Developer........: Fabio Roth (FaR)
rem  Date.............: October 2001
rem  Version..........: Oracle Database 10g
rem  Description......: Creates view TVD_OBJECT_USAGE (lists all indexes  
rem                     where MONITORING USAGE has been enabled)
rem  Usage............: 
rem  Input parameters.: 
rem  Output...........: 
rem  Called by........:
rem  Requirements.....: 
rem  Remarks..........: Necessary, as v$object_usage only shows for the users
rem                     own indexes
rem
rem ---------------------------------------------------------------------------
rem Changes:
rem DD.MM.YYYY Developer Change
rem ---------------------------------------------------------------------------
rem 22.10.2001 FaR	 created 
rem 17.09.2002 ThJ       OK for Oracle9i R2
rem 09.09.2003 AnK       OK for 10.1
rem 01.12.2008 ChA       Fixed header + Renamed view (was MONI_ALL_INDEX_USAGE)
rem ---------------------------------------------------------------------------

drop view tvd_object_usage;
create view tvd_object_usage 
    (OWNER,
     INDEX_NAME,
     TABLE_NAME,
     MONITORING,
     USED,
     START_MONITORING,
     END_MONITORING)
as
select us.name, io.name, t.name,
       decode(bitand(i.flags, 65536), 0, 'NO', 'YES'),
       decode(bitand(ou.flags, 1), 0, 'NO', 'YES'),
       ou.start_monitoring,
       ou.end_monitoring
from sys.obj$ io, sys.obj$ t, sys.ind$ i, sys.object_usage ou, sys.user$ us
where io.owner# = us.user#
  and i.obj# = ou.obj#
  and io.obj# = ou.obj#
  and t.obj# = i.bo#
;
create or replace public synonym tvd_object_usage for tvd_object_usage
;
grant select on tvd_object_usage to select_catalog_role;
