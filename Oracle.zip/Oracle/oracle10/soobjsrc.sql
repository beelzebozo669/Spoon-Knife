rem ---------------------------------------------------------------------------
rem  Trivadis AG, Baden-D�ttwil/Basel/Bern/Lausanne/Z�rich
rem               D�sseldorf/Frankfurt/Freiburg i.Br./Hamburg/M�nchen/Stuttgart
rem               Wien
rem               Switzerland/Germany/Austria Internet: http://www.trivadis.com
rem ---------------------------------------------------------------------------
rem $Id: soobjsrc.sql 142 2008-11-25 15:57:14Z cha $
rem ---------------------------------------------------------------------------
rem  Group/Privileges.: User
rem  Script Name......: soobjsrc.sql
rem  Developer........: Urs Meier (UrM)
rem  Date.............: 11.08.1992
rem  Version..........: Oracle Database 10g
rem  Description......: Show the source code for a PL/SQL object
rem  Usage............: 
rem  Input parameters.: 
rem  Output...........: 
rem  Called by........:
rem  Requirements.....: 
rem  Remarks..........: 
rem
rem ---------------------------------------------------------------------------
rem Changes:
rem DD.MM.YYYY Developer Change
rem ---------------------------------------------------------------------------
rem 05.04.1997 UrM       rename
rem 21.09.1997 AnK       Oracle8
rem 21.04.1999 AnK       OK for Oracle8i
rem 03.09.2002 ThJ       OK for Oracle9i R2
rem 15.09.2003 AnK       OK for 10.1
rem 25.11.2008 ChA       Fixed header + Removed unnecessary tabs
rem ---------------------------------------------------------------------------

CLEAR column -
      breaks -
      computes
SET echo off -
    feedback off -
    pagesize 22 -
    termout on -
    verify off

COLUMN name	NOPRINT		NEW_VALUE name
COLUMN type	NOPRINT		NEW_VALUE type
COLUMN status	NOPRINT		NEW_VALUE status

BREAK ON name SKIP PAGE
@@fopauon
TTITLE CENTER 'Source-Code for 'type ' ' name ' --> ' status skip 2

ACCEPT obj CHAR PROMPT "Show source code for object(s) [%]: " Default "%"

SELECT src.name, src.type, obj.status, src.text
  FROM user_source src,
       user_objects obj
 WHERE src.name = obj.object_name
   AND src.type = obj.object_type
   AND src.name LIKE UPPER('&obj')
 ORDER BY src.type,src.name,src.line;

@@fopauoff
TTITLE off
CLEAR BREAKS COMPUTES

COLUMN name	CLEAR
COLUMN type	CLEAR
COLUMN status	CLEAR

