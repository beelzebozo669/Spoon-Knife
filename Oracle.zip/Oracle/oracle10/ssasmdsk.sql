rem ---------------------------------------------------------------------------
rem  Trivadis AG, Baden-D�ttwil/Basel/Bern/Lausanne/Z�rich
rem               D�sseldorf/Frankfurt/Freiburg i.Br./Hamburg/M�nchen/Stuttgart
rem               Wien
rem               Switzerland/Germany/Austria Internet: http://www.trivadis.com
rem ---------------------------------------------------------------------------
rem $Id$
rem ---------------------------------------------------------------------------
rem  Group/Privileges.: SYSDBA
rem  Script-Name......: ssasmdsk.sql
rem  Developer........: Peter Hulm (peter.hulm@trivadis.com)
rem  Date.............: January 2005
rem  Version..........: Oracle Database 10g
rem  Description......: Shows the ASM disks composing each ASM disk group
rem  Usage............: 
rem  Input parameters.: 
rem  Output...........: 
rem  Called by........:
rem  Requirements.....: 
rem  Remark...........: To have all information the script should be run while 
rem                     connected to the +ASM instance. 
rem ---------------------------------------------------------------------------
rem Changes:
rem DD.MM.YYYY Developer Change
rem ---------------------------------------------------------------------------
rem 18.10.2007 ChA       Added information about database and diskgroup
rem ---------------------------------------------------------------------------

set linesize 120 pagesize 100

column diskgroup_name noprint new_value diskgroup_name
column failgroup_name format a25
column disk_name format a25
column status format a15
column total_mb format 9,999,990
column free_percent format 990.0 heading "FREE%"
column device format a34

break on diskgroup_name skip page
ttitle center "Disk Group " ''diskgroup_name'' skip 2

select g.name diskgroup_name, d.failgroup failgroup_name, d.name disk_name,
       d.state||'/'||d.mount_status status, d.total_mb, 
       d.free_mb/nullif(d.total_mb,0)*100 free_percent, d.path device
from v$asm_diskgroup g, v$asm_disk d
where g.group_number = d.group_number
order by g.name, d.failgroup, d.name
/

clear break
ttitle off

column diskgroup_name clear
column failgroup_name clear
column disk_name clear
column status clear
column total_mb clear
column free_percent clear
column device clear
