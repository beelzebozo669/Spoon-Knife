rem -------------------------------------------------------------------------
rem        Trivadis AG, Baden/Basel/Bern/Lausanne/Z�rich
rem                     Frankfurt/Freiburg i.Br./M�nchen/Stuttgart
rem                     Switzerland/Germany Internet: http://www.trivadis.com
rem -------------------------------------------------------------------------
rem $Header$
rem
rem   GROUP/Privileges.: DBA
rem   Script-Name......: sdseqcch.sql
rem   Developer........: Sven Vetter (SvV) Sven.Vetter@trivadis.com
rem   Date.............: 10.12.2001
rem   Version..........: Oracle10g
rem   Usage............: Shows overview sequences, cache-parameter and latch
rem   Input parameters.:
rem   Output.......... : 
rem   Called by........: 
rem   Remarks..........: DBA-Version
rem                      without Sequences from schema sys and system
rem -----------------------------------------------------------------------
rem
rem
rem Changes:
rem
rem $Log$
rem Revision 1.2  2003/09/10 10:43:12  ank
rem Replaced ttitle by foenvtit.sql
rem
rem Revision 1.1  2003/09/10 10:40:31  ank
rem - OK for 10.1
rem
rem Revision 1.2  2002/09/09 16:56:24  far
rem 9.2 f�hig checked by ThJ
rem
rem Revision 1.1  2001/12/15 13:54:05  ank
rem - initial load (SvV)
rem
rem
rem DD.MM.YYYY Consultant Change
rem -----------------------------------------------------------------------
rem 03.09.2002 ThJ        OK for Oracle9i R2
rem -----------------------------------------------------------------------
rem
rem
SET echo off
SET verify off
@@fopauon
@@foenvtit 'Overview sequences and cache-parameter '

SELECT SEQUENCE_OWNER, COUNT(*) count,
  DECODE(
  DECODE(CACHE_SIZE,0,0,1,1,2,1,3,1,4,1,5,1,6,1,7,1,8,1,9,1,10,1,
    11,1,12,1,13,1,14,1,15,1,16,1,17,1,18,1,19,1,2),
     0,'no cache',1,'cache < 20','cache >= 20') CACHE_AREA
  FROM dba_sequences 
  WHERE SEQUENCE_OWNER NOT IN ('SYS','SYSTEM')
  GROUP BY SEQUENCE_OWNER,
    DECODE(CACHE_SIZE,0,0,1,1,2,1,3,1,4,1,5,1,6,1,7,1,8,1,9,1,10,1,
      11,1,12,1,13,1,14,1,15,1,16,1,17,1,18,1,19,1,2) 
  ORDER BY SEQUENCE_OWNER, CACHE_AREA;

@@foenvtit 'Sequence-Latch'
col name  format a15
col ratio format 990D99

SELECT name,gets,misses,misses/gets*100 ratio
 FROM v$latch
 WHERE NAME='sequence cache';
col name  clear
col ratio clear
ttitle off
set pause off
