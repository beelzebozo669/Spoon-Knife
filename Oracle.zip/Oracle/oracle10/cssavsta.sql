rem -------------------------------------------------------------------------
rem        Trivadis AG, Baden/Basel/Bern/Lausanne/Z�rich
rem                     Frankfurt/Freiburg i.Br./M�nchen/Stuttgart
rem                     Switzerland/Germany Internet: http://www.trivadis.com
rem -------------------------------------------------------------------------
rem   $Header$
rem   **********************************************************************
rem   Privilegien......: SYS
rem   Name.............: cssavsta.sql
rem   Entwickler.......: Sven Vetter (ssv) Sven.Vetter@trivadis.com
rem   Datum............: 22.08.1999
rem   Version..........: Oracle10g
rem   Zweck............: Programm zum Abspeichern und Vergleichen von Statistiken
rem                      aus v$sysstat und v$waitstat
rem   Input parameters.:
rem   Output.......... : 
rem   Called by........:
rem   Remarks..........: To be run while connected as SYS
rem -----------------------------------------------------------------------
rem
rem $Log$
rem Revision 1.1  2003/09/10 08:28:54  ank
rem - OK for 10.1
rem
rem Revision 1.3  2002/09/09 16:56:24  far
rem 9.2 f�hig checked by ThJ
rem
rem Revision 1.2  2001/07/22 12:59:28  ank
rem - Load initial release Oracle9i 9.0.x
rem
rem
rem
rem Changes:
rem DD.MM.YYYY Consultant Ver Change
rem 21.04.1999 ssv        1.1 Bessere Formatierung der Ausgabe
rem 22.08.1999 ssv        2.0 ReDesign der Datenspeicherung (2 Tabellen)
rem 04.09.2002 thj        2.1 OK for Oracle9i R2

rem Description
rem -----------
rem Pro Aufruf des Programmes (execute sys.comp_sysstat.read_values) werden in der
rem Tabelle sys.css_save_stats aktuelle Ratios und Statistiken gespeichert. Dabei kann
rem durch einen optionalen numerischen Parameter angegeben werden, wieviele alten Daten-
rem versionen behalten werden sollen (Standard=10). Diese Werte koennen durch die
rem Scripts sssavsta (letzten 4 Werte) oder sssavst1 (letzten 10 Werte) angezeigt und
rem verglichen werden.
rem Es werden standardmaessig die DB-Buffer cache hit rate, 42 Statistiken aus v$sysstat
rem sowie 7 Statistiken aus v$waitstat angezeigt (jeweils Count und Time).
rem Erscheint hinter dem Wert ein "+", ist dies das Delta zum vorangegangenen, ohne "+"
rem ist es der aktuelle Wert (Datenbank neu gestartet oder erster Aufruf).
rem 
rem Wollen Sie weitere Statistiken hinzufuegen, geben Sie folgenden Befehl ein:
rem Execute sys.comp_sysstat.new_param(tcName,tcKategorie)
rem  wobei tcName      = Name der Statistik
rem        tcKategorie = '1' (fuer Statistik aus v$sysstat)
rem        tcKategorie = '2' (fuer Statistik aus v$waitstat)


spool cssavsta.lis
rem -----------------------------------------------------------------------
rem
rem Tabelle zum Speichern der Werte erzeugen
rem
drop table sys.css_save_stats;
create table sys.css_save_stats
  (key number (3) not null, counter number(3) not null,art varchar(1),
   wert1 varchar(17),oldvalue number
  ) storage (initial 1m next 1m);
ALTER TABLE sys.css_save_stats
 ADD CONSTRAINT pk_cv_save_value PRIMARY KEY (key,counter,art);

rem -----------------------------------------------------------------------
rem
rem Tabelle zum Speichern der Parameter erzeugen
rem
drop table sys.css_save_stats_params;
create table sys.css_save_stats_params
  (key number (3) not null CONSTRAINT pk_cv_save_value_params PRIMARY KEY, 
   bezeichnung varchar2(64), kategory varchar(1)
  ) storage (initial 1m next 1m);


rem -----------------------------------------------------------------------
rem
rem die ersten Parameter einfuegen
rem
insert into sys.css_save_stats_params (key,bezeichnung,kategory) values (0,'Datum/Uhrzeit','0');
insert into sys.css_save_stats_params (key,bezeichnung,kategory) values (1,'DB-Buffer cache hit rate','3');

insert into sys.css_save_stats_params (key,bezeichnung,kategory) values (100,'logons cumulative','1');
insert into sys.css_save_stats_params (key,bezeichnung,kategory) values (101,'opened cursors cumulative','1');
insert into sys.css_save_stats_params (key,bezeichnung,kategory) values (102,'user commits','1');
insert into sys.css_save_stats_params (key,bezeichnung,kategory) values (103,'user rollbacks','1');
insert into sys.css_save_stats_params (key,bezeichnung,kategory) values (104,'user calls','1');
insert into sys.css_save_stats_params (key,bezeichnung,kategory) values (105,'recursive calls','1');
insert into sys.css_save_stats_params (key,bezeichnung,kategory) values (106,'recursive cpu usage','1');
insert into sys.css_save_stats_params (key,bezeichnung,kategory) values (107,'bytes sent via SQL*Net to client','1');
insert into sys.css_save_stats_params (key,bezeichnung,kategory) values (108,'bytes received via SQL*Net from client','1');
insert into sys.css_save_stats_params (key,bezeichnung,kategory) values (109,'SQL*Net roundtrips to/from client','1');
insert into sys.css_save_stats_params (key,bezeichnung,kategory) values (110,'bytes sent via SQL*Net to dblink','1');
insert into sys.css_save_stats_params (key,bezeichnung,kategory) values (111,'bytes received via SQL*Net from dblink','1');
insert into sys.css_save_stats_params (key,bezeichnung,kategory) values (112,'SQL*Net roundtrips to/from dblink','1');
insert into sys.css_save_stats_params (key,bezeichnung,kategory) values (113,'enqueue deadlocks','1');
insert into sys.css_save_stats_params (key,bezeichnung,kategory) values (114,'db block gets','1');
insert into sys.css_save_stats_params (key,bezeichnung,kategory) values (115,'consistent gets','1');
insert into sys.css_save_stats_params (key,bezeichnung,kategory) values (116,'physical reads','1');
insert into sys.css_save_stats_params (key,bezeichnung,kategory) values (117,'physical writes','1');
insert into sys.css_save_stats_params (key,bezeichnung,kategory) values (118,'write complete waits','1');
insert into sys.css_save_stats_params (key,bezeichnung,kategory) values (119,'buffer busy waits','1');
insert into sys.css_save_stats_params (key,bezeichnung,kategory) values (120,'dbwr free needed','1');
insert into sys.css_save_stats_params (key,bezeichnung,kategory) values (121,'dbwr free low','1');
insert into sys.css_save_stats_params (key,bezeichnung,kategory) values (122,'redo size','1');
insert into sys.css_save_stats_params (key,bezeichnung,kategory) values (123,'redo log space requests','1');
insert into sys.css_save_stats_params (key,bezeichnung,kategory) values (124,'redo log space wait time','1');
insert into sys.css_save_stats_params (key,bezeichnung,kategory) values (125,'table scans (short tables)','1');
insert into sys.css_save_stats_params (key,bezeichnung,kategory) values (126,'table scans (long tables)','1');
insert into sys.css_save_stats_params (key,bezeichnung,kategory) values (127,'table scan rows gotten','1');
insert into sys.css_save_stats_params (key,bezeichnung,kategory) values (128,'table scan blocks gotten','1');
insert into sys.css_save_stats_params (key,bezeichnung,kategory) values (129,'table fetch by rowid','1');
insert into sys.css_save_stats_params (key,bezeichnung,kategory) values (130,'table fetch continued row','1');
insert into sys.css_save_stats_params (key,bezeichnung,kategory) values (131,'parse count (total)','1');
insert into sys.css_save_stats_params (key,bezeichnung,kategory) values (132,'parse time cpu','1');
insert into sys.css_save_stats_params (key,bezeichnung,kategory) values (133,'parse time elapsed','1');
insert into sys.css_save_stats_params (key,bezeichnung,kategory) values (134,'sorts (memory)','1');
insert into sys.css_save_stats_params (key,bezeichnung,kategory) values (135,'sorts (disk)','1');
insert into sys.css_save_stats_params (key,bezeichnung,kategory) values (136,'sorts (rows)','1');
insert into sys.css_save_stats_params (key,bezeichnung,kategory) values (137,'execute count','1');
insert into sys.css_save_stats_params (key,bezeichnung,kategory) values (138,'DBWR checkpoints','1');
insert into sys.css_save_stats_params (key,bezeichnung,kategory) values (139,'queries parallelized','1');
insert into sys.css_save_stats_params (key,bezeichnung,kategory) values (140,'DML statements parallelized','1');
insert into sys.css_save_stats_params (key,bezeichnung,kategory) values (141,'DDL statements parallelized','1');

insert into sys.css_save_stats_params (key,bezeichnung,kategory) values (500,'data block','2');
insert into sys.css_save_stats_params (key,bezeichnung,kategory) values (501,'sort block','2');
insert into sys.css_save_stats_params (key,bezeichnung,kategory) values (502,'free list','2');
insert into sys.css_save_stats_params (key,bezeichnung,kategory) values (503,'bitmap block','2');
insert into sys.css_save_stats_params (key,bezeichnung,kategory) values (504,'bitmap index block','2');
insert into sys.css_save_stats_params (key,bezeichnung,kategory) values (505,'undo header','2');
insert into sys.css_save_stats_params (key,bezeichnung,kategory) values (506,'undo block','2');


commit;

rem -----------------------------------------------------------------------
rem
rem Package erzeugen
rem

CREATE OR REPLACE
package SYS.comp_sysstat is
/*
=========================================================================
          Trivadis AG, Basel/Bern/Mellingen/Stuttgart/Z�rich
=========================================================================
  Privilegien......: SYS
  Name.............: cssavsta.sql
  Entwickler.......: Sven Vetter (ssv) Sven.Vetter@trivadis.com
  Datum............: 22.08.1999
  Version..........: 2.0
  Zweck............: Programm zum Abspeichern und Vergleichen von Statistiken
                     aus v$sysstat und v$waitstat
  Input parameters.:
  Output.......... :
  Called by........:
  Remarks..........: To be run while connected as SYS
-----------------------------------------------------------------------
Changes:
DD.MM.YYYY Consultant Ver Change
21.04.1999 ssv        1.1 Bessere Formatierung der Ausgabe
22.08.1999 ssv        2.0 ReDesign der Datenspeicherung (2 Tabellen)
*/

 procedure read_values (Max_Columns IN number default 10);
 procedure new_param(tcName varchar2,tcKategorie varchar2 default '1');
end;
/
show errors;

CREATE OR REPLACE
package body SYS.comp_sysstat is

 procedure write_values (tnKey in number,tnValue in number,tcArt in varchar,tlRestart in boolean) is
   lnOldValue number;
   lcString Sys.css_save_stats.wert1%type;
 begin
   begin
     select OldValue into lnOldValue from Sys.css_save_stats where
       key=tnKey and art=tcArt and counter=2;
   exception
     when no_data_found then
       lnOldValue:=0;
   end;

   if tlRestart then
     lcString:=to_char(tnValue,'9999G999G999G999');
   else
     lcString:=to_char(tnValue-lnOldValue,'99G999G999G999') || ' +';
   end if;

   insert into Sys.css_save_stats (key,counter,wert1,art,oldvalue)
     values (tnKey,1,lcString,tcArt,tnValue);
 end;

/************************************************************************
 **                                                                    **
 **  Alte Werte eine Spalte nach rechts schieben, neue Werte ermitteln **
 **                                                                    **
 ************************************************************************/
 procedure read_values (Max_Columns IN number  default 10) is
  lcWert  v$sysstat.value%type;
  lnWert  number(8,2);
  lnCount v$waitstat.count%type;
  lnTime  v$waitstat.time%type;
  ldDateOpen  Date;
  ldDateLast  Date;
  llRestart   boolean:=False;

  cursor cur_Values is
    select * from sys.css_save_stats_params;

 begin
  update Sys.css_save_stats set counter=counter+1;
  delete from Sys.css_save_stats where counter>Max_Columns;
  commit;

-- *** Test, ob Datenbank neu gestartet wurde
  select open_time into ldDateOpen from v$thread;
  begin
    select to_date(wert1,'DD.MM.YY HH24:MI:SS') into ldDateLast
      from Sys.css_save_stats where counter=2 and key=0;
    if ldDateOpen>ldDateLast then
      llRestart:=true;
    end if;
  exception
    when no_data_found then
      llRestart:=true;
  end;

  for rec_Values in cur_Values loop
   begin
-- *** aktuelles Datum speichern ***
     if rec_Values.kategory='0' then
      insert into Sys.css_save_stats (key,counter,wert1,art)
        values (rec_Values.key,1,to_char(sysdate,'DD.MM.YY HH24:MI:SS'),'0');

-- *** DB-Buffer cache hit rate ermitteln und speichern ***
    elsif rec_Values.kategory='3' then
      SELECT (((a.value+b.value)-c.value)/(a.value+b.value))*100 into lnWert
       FROM    v$sysstat a, v$sysstat b, v$sysstat c
       WHERE   a.name = 'db block gets'
       AND     b.name = 'consistent gets'
       AND     c.name = 'physical reads';
      insert into Sys.css_save_stats (key,counter,wert1,art)
        values (rec_Values.key,1,LPAD((to_char(lnWert,'99.99')) || ' %',17),'0');

-- *** Werte aus v$sysstat holen und speichern ***
    elsif rec_Values.kategory='1' then
      SELECT value into lcWert
	FROM 	v$sysstat where name=rec_values.bezeichnung;
      write_values(rec_Values.key,to_number(lcWert),'0',llRestart);

-- *** Werte aus v$waitstat holen und speichern ***
    elsif rec_Values.kategory='2' then
      SELECT "COUNT",time into lnCount,lnTime
	 FROM 	v$waitstat where class=rec_values.bezeichnung;
      write_values(rec_Values.key,lnCount,'1',llRestart);
      write_values(rec_Values.key,lnTime ,'2',llRestart);

     end if;
   exception
     when NO_DATA_FOUND then
        null;
     when others then
        raise_application_error(-20003,sqlerrm);
   end;
  end loop;
  commit;
 end;

/************************************************************************
 **                                                                    **
 **  Neuen Parameter eingeben, fuer den Werte aus v$sysstat ermittelt  **
 **  werden sollen.                                                    **
 **                                                                    **
 ************************************************************************/
 procedure new_param(tcName varchar2,tcKategorie varchar2 default '1') is
   lnMaxWert       sys.css_save_stats_params.key%type;
   lnKey           sys.css_save_stats_params.key%type;
   leDataExist     EXCEPTION;
   leWrongCategory EXCEPTION;
   lcStatName      varchar2(20) := 'v$sysstat';
 begin
   if tcKategorie not in ('1','2') then                         -- falsche Kategorie ?
      raise leWrongCategory;
   end if;
   begin                                                        -- Test, ob Paramater existiert
     if tcKategorie='1' then
       SELECT 1 into lnMaxWert FROM v$sysstat where name=tcName;
     else
       lcStatName:='v$waitstat';
       SELECT 1 into lnMaxWert FROM v$waitstat where class=tcName;
     end if;
   exception
     when NO_DATA_FOUND then
       raise_application_error(-20001,'Parameter ''' || tcName || ''' existiert nicht in '||lcStatName||'.');
   end;

   select max(key)+1 into lnMaxWert from sys.css_save_stats_params; -- h�chsten Key + 1 holen
   if lnMaxWert is null or lnMaxWert<600 then                       -- Userparameter sollen ab 600 beginnen
     lnMaxWert:=600;
   end if;

   select key into lnKey from sys.css_save_stats_params where bezeichnung=tcName
    and kategory=tcKategorie;

   raise leDataExist;                                            -- key gibts schon - Error

 exception
   when NO_DATA_FOUND then
     insert into sys.css_save_stats_params (key,bezeichnung,kategory) values (lnMaxWert,tcName,tcKategorie);
     commit;
     dbms_output.put_line('Parameter ' || tcName || ' eingef�gt.');

   when TOO_MANY_ROWS or leDataExist then
     raise_application_error(-20002,'Parameter ''' || tcName || ''' existiert schon.');

   when leWrongCategory then
     raise_application_error(-20004,'Kategorie ''' || tcKategorie || ''' existiert nicht (nur ''1'' und ''2'' zugelassen).');

   when others then
     raise_application_error(-20003,sqlerrm);
 end;


end;
/

show errors;


rem -----------------------------------------------------------------------
rem
rem Rechte verteilen und Synonyme erzeugen
rem
drop   public synonym css_save_stats;
drop   public synonym css_save_stats_params;
drop   public synonym comp_sysstat;
create public synonym css_save_stats        for sys.css_save_stats;
create public synonym css_save_stats_params for sys.css_save_stats_params;
create public synonym comp_sysstat          for sys.comp_sysstat;

grant execute on comp_sysstat         to dba;
grant select on css_save_stats        to dba;
grant select on css_save_stats_params to dba;

spool off;