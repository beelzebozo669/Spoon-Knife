rem ---------------------------------------------------------------------------
rem  Trivadis AG, Baden-D�ttwil/Basel/Bern/Lausanne/Z�rich
rem               D�sseldorf/Frankfurt/Freiburg i.Br./Hamburg/M�nchen/Stuttgart
rem               Wien
rem               Switzerland/Germany/Austria Internet: http://www.trivadis.com
rem ---------------------------------------------------------------------------
rem $Id: lodblind.sql 192 2008-12-01 00:29:22Z cha $
rem ---------------------------------------------------------------------------
rem  Group/Privileges.: User
rem  Script Name......: lodblind.sql
rem  Developer........: Urs Meier (UrM)
rem  Date.............: 26.12.1996
rem  Version..........: Oracle Database 10g
rem  Description......: Find indexes which start with same column
rem  Usage............: 
rem  Input parameters.: 
rem  Output...........: 
rem  Called by........:
rem  Requirements.....: 
rem  Remarks..........: 
rem
rem ---------------------------------------------------------------------------
rem Changes:
rem DD.MM.YYYY Developer Change
rem ---------------------------------------------------------------------------
rem 05.04.1997 UrM       rename
rem 15.11.1997 UrM       V8
rem 20.04.1999 AnK       OK for Oracle8i. Changed to ALL_ind_columns
rem                      as Partitioned Indexes can also be seen there.
rem                      All type of partitioned Indexes now supported.
rem 04.09.2002 ThJ       OK for Oracle9i R2
rem 09.09.2003 AnK       OK for 10.1
rem 01.12.2008 ChA       Fixed header + Formatting
rem ---------------------------------------------------------------------------

column table_name format a30 heading "Table"
column index_name format a30 heading "Index"
column column_name format a30 heading "Column"
@@foenvtit "Indexes starting with the same column"
set linesize 92
spool lodblind.lis
BREAK ON table_name skip 2 

SELECT table_name, index_name, column_name
FROM all_ind_columns
WHERE table_owner = user
AND  (table_owner, table_name,column_name) IN (SELECT table_owner, table_name, column_name
                                               FROM all_ind_columns
                                               WHERE column_position = 1
                                               AND table_owner = user
                                               GROUP BY table_owner, table_name, column_name
                                               HAVING count(*) > 1)
AND column_position = 1
ORDER BY table_name, index_name;

spool off
ttitle off
prompt lodblind.lis has been spooled
