rem -------------------------------------------------------------------------
rem        Trivadis AG, Baden/Basel/Bern/Lausanne/Z�rich
rem                     Frankfurt/Freiburg i.Br./M�nchen/Stuttgart
rem                     Switzerland/Germany Internet: http://www.trivadis.com
rem -------------------------------------------------------------------------
rem   $Header$
rem   **********************************************************************
rem   Group/Privileges.: DBA 
rem   Script-Name......: sdtabind.sql
rem   Developer........: Martin Wunderli (maw) martin.wunderli@trivadis.com
rem   Date.............: 27.09.2000 
rem   Version..........: Oracle10g
rem   Usage............: Shows the indexes for given table(s)
rem                      and given user(s)
rem   Input parameters.: 
rem   Output.......... : 
rem   Called by........: 
rem   Remarks..........: 
rem -------------------------------------------------------------------------
rem HISTORY:
rem
rem
rem $Log$
rem Revision 1.1  2003/09/09 11:38:12  ank
rem - OK for 10.1
rem
rem Revision 1.5  2002/09/09 16:58:52  far
rem 9.2 f�hig checked by ChA
rem
rem Revision 1.3  2001/09/28 10:31:55  ank
rem - Fixed the ORDER BY (YaN)
rem
rem Revision 1.2  2001/07/22 12:59:28  ank
rem - Load initial release Oracle9i 9.0.x
rem
rem
rem
rem -------------------------------------------------------------------------
rem Changes:
rem DD.MM.YYYY Consultant Change
rem -------------------------------------------------------------------------
rem 11.10.2000 MaW       On 8.1.6 much faster with rule hint
rem 14.10.2000 AnK       Changed Owner Example to SCOTT.
rem                      Added UNDEFINE for OWNER
rem 23.01.2001 ChA       Added some hints for better performances
rem 25.07.2002 ChA       Bug correction: the owner was not part of the FKs
rem -------------------------------------------------------------------------
rem
rem =========================================================================
rem
rem
rem
set echo off
set verify off
@@fopauon
column index_name       format a20 word_wrap    heading 'Index_Name (Part)' 
column owner            format a12              heading 'Index Owner'
column type             format a3               heading 'Typ'
column uni              format a3               heading 'Uni'
column tablespace_name  format a10 wrap         heading 'Table Space'
column table_name       noprint                 new_value tab
column column_name      format a18 wrap         heading 'Column Name'
column distinct_keys    format 9999999          heading 'DistKeys'
column column_position  noprint
ttitle center 'Indexes for table 'tab skip 2
break on table_name skip page -
      on index_name skip 2 -
      on type -
      on uni -
      on distinct_keys  -
      on tablespace_name
PROMPT 
PROMPT Please enter table name, wildcards allowed, eg.: EMP, E% or %
PROMPT
accept table_name char prompt "Table Name <%>: " default "%"
PROMPT 
PROMPT Please enter table owner, wildcards allowed, eg.: SCOTT, S% or %
PROMPT
accept owner char prompt "Table Owner <%>: " default "%"
select  /*+ ordered 
            no_merge(i) 
            no_merge(c) use_hash(c) */ 
        /* first non-partitioned indexes */
                i.index_name,i.owner,i.table_name,c.column_name,
                decode(i.table_type,'TABLE','TAB','CLUSTER','CLU','???') type,
                decode(i.index_type,'BITMAP','BIT',
                                    'CLUSTER','CLU',
                                    'IOT - TOP','IOT',
                                    'LOB','LOB',
                                     decode(i.uniqueness,'UNIQUE','YES',
                                                         'NONUNIQUE','NO')) UNI,
                i.tablespace_name, i.distinct_keys, c.column_position 
        from  dba_indexes i, dba_ind_columns c
        where i.table_name = c.table_name
        and i.index_name = c.index_name
        and i.owner = c.index_owner
        and i.table_name like upper('&&Table_Name')
        and i.table_owner like upper('&&Owner')
        and i.partitioned = 'NO'
 union
select  /*+ ordered 
            no_merge(i) 
            no_merge(ip) use_hash(ip)
            no_merge(c) use_hash(c) 
            no_merge(p) use_hash(p) */ 
        /* and now partitioned indexes */ 
        i.index_name||' ('||ip.partition_name||') '||
                    ' (P:'||p.locality||' '||p.alignment||')' index_name,i.owner,
        c.table_name,c.column_name,
                decode(i.table_type,'TABLE','TAB','CLUSTER','CLU','???') type,
                decode(i.index_type,'BITMAP','BIT',
                                    'CLUSTER','CLU',
                                    'IOT - TOP','IOT',
                                    'LOB','LOB',
                                     decode(i.uniqueness,'UNIQUE','YES',
                                                         'NONUNIQUE','NO')) UNI,
                ip.tablespace_name, i.distinct_keys, c.column_position
        from  dba_indexes i, dba_ind_partitions ip,
              dba_ind_columns c, dba_part_indexes p
        where i.table_name = c.table_name
        and i.table_owner = c.table_owner
        and p.index_name = ip.index_name
        and p.owner = ip.index_owner
        and i.index_name = ip.index_name
        and i.owner = ip.index_owner
        and ip.index_name = c.index_name
        and ip.index_owner = c.index_owner
        and i.table_name like upper('&&Table_Name')
        and i.table_owner like upper('&&Owner')
        and ip.tablespace_name is not null /* Comp. part. Indexes */
 union
select  /*+ ordered 
            no_merge(i) 
            no_merge(ip) use_hash(ip)
            no_merge(c) use_hash(c) 
            no_merge(p) use_hash(p) */
        /* and now sub-partitioned indexes */ 
        i.index_name||' ('||ip.subpartition_name||') '||
                    ' (SP:'||p.locality||' '||p.alignment||')' index_name,i.owner, 
        c.table_name,c.column_name,
                decode(i.table_type,'TABLE','TAB','CLUSTER','CLU','???') type,
                decode(i.index_type,'BITMAP','BIT',
                                    'CLUSTER','CLU',
                                    'IOT - TOP','IOT',
                                    'LOB','LOB',
                                     decode(i.uniqueness,'UNIQUE','YES',
                                                         'NONUNIQUE','NO')) UNI,
                ip.tablespace_name, i.distinct_keys, c.column_position
        from  dba_indexes i, dba_ind_subpartitions ip,
              dba_ind_columns c, dba_part_indexes p
        where i.table_name = c.table_name
        and i.table_owner = c.table_owner
        and p.index_name = ip.index_name
        and p.owner = ip.index_owner
        and i.index_name = ip.index_name
        and i.owner = ip.index_owner
        and ip.index_name = c.index_name
        and ip.index_owner = c.index_owner
        and i.table_name like upper('&&Table_Name')
        and i.table_owner like upper('&&Owner')
 union
select /*+ ordered 
            no_merge(i) 
            no_merge(l) use_hash(l) */ 
       /* and now the LOB-Indexes */
       l.index_name, i.owner, l.table_name, l.column_name,'LOB' TYPE,
       'LOB' UNI, i.tablespace_name,
       -1,1
       from dba_indexes i, dba_lobs l
       where l.index_name = i.index_name
       and   l.table_name = i.table_name
       and   l.owner = i.table_owner
       and   l.table_name like upper('&&Table_Name')
       and   i.table_owner like upper('&&Owner')
order by 2, 5 desc, 1, 9;

set pause off
ttitle off
clear break compute     
column index_name       CLEAR
column type             CLEAR
column uni              CLEAR
column tablespace_name  CLEAR
column table_name       CLEAR
column column_name      CLEAR
column distinct_keys    CLEAR
column column_position  CLEAR
undefine table_name
undefine owner
