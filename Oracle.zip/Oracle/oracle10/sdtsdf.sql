rem -----------------------------------------------------------------------------------
rem        Trivadis AG, Basel/Bern/Brugg/Lausanne/Zuerich
rem                     Duesseldorf/Frankfurt/Freiburg i.Br./Hamburg/Muenchen/Stuttgart
rem                     Wien
rem                     Switzerland/Germany/Austria Internet: http://www.trivadis.com
rem -----------------------------------------------------------------------------------
rem $Id:  $
rem -----------------------------------------------------------------------------------
rem  Group/Privileges.: DBA
rem  Script-Name......: sdtsdf.sql
rem  Developer........: Peter Jensch (PeJ) peter.jensch@trivadis.com
rem  Date.............: September 2014
rem  Version..........: Oracle Database 11g
rem  Description......: Lists tablespace / datafile details
rem  Usage............: 
rem  Input parameters.:
rem  Output.......... :
rem  Called by........:
rem  Remarks..........:
rem
rem -----------------------------------------------------------------------------------
rem Changes:
rem DD.MM.YYYY Consultant Change
rem -----------------------------------------------------------------------------------
rem 20.10.2014 DaH        Implemented basenv like features
rem -----------------------------------------------------------------------------------

set logsource "Dummy"
store set temp.tmp replace
clear   columns -
        breaks -
        computes

set linesize 135
set pagesize 1000

@@foenvtit "Tablespace and Datafiles Details"

column tablespace_name format a30 heading "TS Name"
column file_id         format 999 heading "ID"
column file_name       format a55 heading "File Name"
column autoextensible  format a1  heading "A"
column bytes           format 999,999 heading "Size (MB)"
column maxbytes        format 999,999 heading "Max (MB)"
column increment_bytes format 999,999 heading "Inc. by (MB)"

SELECT ts.tablespace_name                              tablespace_name,
       df.file_id                                      file_id,
       df.file_name                                    file_name,
       decode(df.autoextensible,'YES','Y','NO','N')    autoextensible,
       df.bytes / 1024 / 1024                          bytes,
       df.maxbytes / 1024 / 1024                       maxbytes,
       (df.increment_by * ts.block_size) / 1024 / 1024 increment_bytes
  FROM dba_tablespaces ts, dba_data_files  df
 WHERE ts.tablespace_name = df.tablespace_name
 UNION ALL
SELECT ts.tablespace_name                              tablespace_name,
       tf.file_id                                      file_id,
       tf.file_name                                    file_name,
       decode(tf.autoextensible,'YES','Y','NO','N')    autoextensible,
       tf.bytes / 1024 / 1024                          bytes,
       tf.maxbytes / 1024 / 1024                       maxbytes,
       (tf.increment_by * ts.block_size) / 1024 / 1024 increment_bytes
  FROM dba_tablespaces ts, dba_temp_files tf
 WHERE ts.tablespace_name = tf.tablespace_name
 ORDER BY tablespace_name, file_name;

column tablespace_name clear
column file_id         clear
column file_name       clear
column autoextensible  clear
column bytes           clear
column maxbytes        clear
column increment_bytes clear
ttitle off

prompt
prompt A  : Y=Datafile is autoextensible N=Datafile is not autoextensible
prompt

@temp.tmp

