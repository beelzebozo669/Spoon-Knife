rem ---------------------------------------------------------------------------
rem  Trivadis AG, Baden-D�ttwil/Basel/Bern/Lausanne/Z�rich
rem               D�sseldorf/Frankfurt/Freiburg i.Br./Hamburg/M�nchen/Stuttgart
rem               Wien
rem               Switzerland/Germany/Austria Internet: http://www.trivadis.com
rem ---------------------------------------------------------------------------
rem $Id: sdtabprt.sql 198 2008-12-01 01:59:00Z cha $
rem ---------------------------------------------------------------------------
rem  Group/Privileges.: DBA
rem  Script Name......: sdtabprt.sql
rem  Developer........: Marc Bosshard (MBo)
rem  Date.............: 01.2001
rem  Version..........: Oracle Database 10g
rem  Description......: Shows type, tablespace and number of rows of all
rem                     partitions/subpartitions of a partitioned table
rem  Usage............: 
rem  Input parameters.: 
rem  Output...........: 
rem  Called by........:
rem  Requirements.....: 
rem  Remarks..........: 
rem
rem ---------------------------------------------------------------------------
rem Changes:
rem DD.MM.YYYY Developer Change
rem ---------------------------------------------------------------------------
rem 18.09.2002 ThJ       Tested for Oracle9i R2 (incl. Composite Range-
rem                      List Partitioning)
rem 15.09.2003 AnK       OK for 10.1 (check again regarding IOTs, etc.)
rem 25.04.2004 MnB       Name of objects in recycle bin is 'BIN$%' (instead of 
rem                      'RB$%' in 10g beta)
rem 30.11.2008 ChA       Fixed header + Correctly handle (sub)partition_type
rem ---------------------------------------------------------------------------

set serveroutput on size 1000000;
set linesize 200 feedback off echo off verify off;
set pagesize 100

prompt
accept pTable_Owner CHAR PROMPT 'TABLE OWNER: '
select table_name as "LIST OF PARTITIONED TABLE:" from dba_part_tables
where owner= UPPER('&pTable_Owner')
and   table_name not like 'BIN$%'
order by table_name;
prompt
accept pTable_Name CHAR PROMPT 'TABLE NAME: '
accept pEstimation  CHAR PROMPT "USE STATISTICS ROWS ESTIMATION <Y>|N: " DEFAULT "Y"
prompt

set timing on;
DECLARE
	CURSOR c_Partition IS 
		      SELECT part.table_owner owner,
                      	     part.table_name table_name,
                             tab.partitioning_type partitioning_type,
                             tab.subpartitioning_type subpartitioning_type,
                             part.partition_name partition_name,
                             part.tablespace_name tbs_partition,
                             decode(part.composite,'YES',subpart.subpartition_name,'NO') subpartition_name,
                             decode(part.composite,'YES',subpart.tablespace_name,'NO') tbs_subpartition
                        FROM dba_tab_partitions part,
                             dba_tab_subpartitions subpart,
                             dba_part_tables tab
                        WHERE tab.table_name=part.table_name
                              AND subpart.table_name(+)=part.table_name
                              AND subpart.partition_name(+)=part.partition_name
                              AND tab.owner=part.table_owner
                              AND subpart.table_owner(+)=part.table_owner
			      AND tab.owner=UPPER('&pTable_Owner')
	                      AND (tab.table_name = UPPER('&pTable_Name') OR
			           tab.table_name = ('&pTable_Name'))
			      AND  tab.table_name not like 'BIN$%';

 	v_Partition       c_Partition%ROWTYPE;
	v_PartType        VARCHAR2(10)  :='';
	v_SqlStmt         VARCHAR2(500) :='';
	v_CursorID        INTEGER	:=0;
	v_PartRows        NUMBER	:=0;
	v_SubpartRows     NUMBER	:=0;
	v_Total           NUMBER 	:=0;
	v_pTable_Name     VARCHAR2(50)  :='';
	v_MemoPartName    VARCHAR2(50)  :='EMPTY';
	v_MemoSubpartName VARCHAR2(50)  :='EMPTY';
	v_Dummy           INTEGER;

BEGIN
-- H E A D E R 
	DBMS_OUTPUT.PUT_LINE('-------------------- --------- ----------------------------- ----------------------------- --------- ----------------------------- -----------------------------');
        DBMS_OUTPUT.PUT_LINE('TABLE                TYPE      PARTITION                     TABLESPACE PARTITION           ROWS     SUBPARTITION                  TABLESPACE SUBPARTITION');
	DBMS_OUTPUT.PUT_LINE('-------------------- --------- ----------------------------- ----------------------------- --------- ----------------------------- -----------------------------');
	OPEN c_Partition();
	LOOP
-- K I N D   O F    P A R T I T I O N I N G
		FETCH c_Partition INTO v_Partition;
		IF (c_Partition%NOTFOUND) AND (c_Partition%ROWCOUNT = 0) THEN   -- Exit if no partitioned table
			DBMS_OUTPUT.PUT_LINE('NOT PARTITIONED');
			EXIT;
		END IF;
    		EXIT WHEN c_Partition%NOTFOUND; -- Exit at the end of the select output
    		IF (v_Partition.subpartitioning_type = 'NONE')
    		THEN
    			v_partType := v_Partition.partitioning_type;
    		ELSE
    			v_partType := substr(v_Partition.partitioning_type,1,4) ||
    			              '-' ||
    			              substr(v_Partition.subpartitioning_type,1,4);
    		END IF;
--  P A R T I T I O N 
		IF (v_Partition.partition_name != v_MemoPartName) THEN
			v_MemoPartName:= v_Partition.partition_name;
			v_CursorID:= DBMS_SQL.open_cursor();
			IF ('&&pEstimation' = 'N') or ('&&pEstimation' = 'n') THEN    
                		v_SqlStmt:= 'select count(*) from "'||v_Partition.owner||'"."'||v_Partition.table_name||
                                            '" partition('||v_Partition.partition_name||')';
			      ELSE  -- Use statistics
                		v_SqlStmt:= 'select num_rows from dba_tab_partitions where partition_name='''||v_Partition.partition_name||
                                             '''and table_owner='''||v_Partition.owner||
                                             '''and table_name='''||v_Partition.table_name||'''';
			END IF;
			DBMS_SQL.parse(v_CursorID,v_SqlStmt,DBMS_SQL.Native);
			DBMS_SQL.define_column(v_CursorID,1,v_PartRows);
			v_Dummy:= DBMS_SQL.execute(v_CursorID);
			IF DBMS_SQL.fetch_rows(v_CursorID) > 0 THEN
				DBMS_SQL.column_value(v_CursorID,1,v_PartRows);
				IF v_PartRows IS NULL THEN
					v_PartRows:=0;
				END IF;
				v_Total:= v_Total+v_PartRows;
		     	     ELSE
				EXIT;
			END IF;
			DBMS_SQL.close_cursor(v_CursorID);
		END IF;	
-- O U T P U T
  		DBMS_OUTPUT.PUT_LINE(rpad(v_Partition.table_name,20,'.')||' '||
                                     rpad(v_PartType,9,'.')||' '||
  				     rpad(v_Partition.partition_name,29,'.')||' '||
  				     rpad(v_Partition.tbs_partition,29,'.')||' '||
      				     rpad(round(v_PartRows),9,'.')||' '||
   				     rpad(v_Partition.subpartition_name,29,'.')||' '||
  				     rpad(v_Partition.tbs_subpartition,29,'.'));
	END LOOP;
-- F O O T E R
	DBMS_OUTPUT.PUT_LINE('-------------------- --------- ----------------------------- ----------------------------- --------- ----------------------------- -----------------------------');
	DBMS_OUTPUT.PUT_LINE('Total: '||to_char(v_Total,'999999999999')||' rows');
	CLOSE c_Partition;
END;
/
prompt
set feedback on;
set timing off;
set serveroutput off;
