rem ---------------------------------------------------------------------------
rem  Trivadis AG, Baden-D�ttwil/Basel/Bern/Lausanne/Z�rich
rem               D�sseldorf/Frankfurt/Freiburg i.Br./Hamburg/M�nchen/Stuttgart
rem               Wien
rem               Switzerland/Germany/Austria Internet: http://www.trivadis.com
rem ---------------------------------------------------------------------------
rem $Id: cscmpdep.sql 162 2008-11-30 13:45:39Z cha $
rem ---------------------------------------------------------------------------
rem  Group/Privileges.: SYSDBA
rem  Script Name......: cscmpdep.sql
rem  Developer........: Andri Kisseleff (AnK)
rem  Date.............: 07.01.1994
rem  Version..........: Oracle Database 10g
rem  Description......: Create procedure and view used for dependency tracking
rem  Usage............: 
rem  Input parameters.: 
rem  Output...........: 
rem  Called by........:
rem  Requirements.....: 
rem  Remarks..........: sddep.sql and edcmpdep.sql need this procedure
rem                     Ignore "already exists" errors
rem
rem      Examples:
rem        execute cmpdep('procedure', 'scott', 'billing');
rem        select * from cmpdep1$tmp order by seq#;
rem
rem        execute cmpdep('table', 'scott', 'emp');
rem        select * from cmpdep1$tmp order by seq#;
rem
rem        execute cmpdep('package body', 'scott', 'accts_payable');
rem        select * from cmpdep1$tmp order by seq#;
rem
rem        A prettier way to display this information than
rem		select * from cmpdep1$tmp order by seq#;
rem	   is
rem             select * from vcmpdep$tmp;
rem        This shows the dependency relationship via indenting.  Notice
rem        that no order by clause is needed with vcmpdep$tmp.
rem
rem ---------------------------------------------------------------------------
rem Changes:
rem DD.MM.YYYY Developer Change
rem ---------------------------------------------------------------------------
rem 21.09.1997 AnK       Oracle8
rem 20.04.1999 AnK       OK for Oracle8i
rem 27.08.2002 MaW       OK for Oracle9i R2
rem 30.08.2002 FaR       getestet/angepasst f�r 9.2
rem 10.09.2003 AnK       OK for 10.1
rem                      Removed special treatment for SYNONYMS/PUBLIC SYNONYMS
rem                      Added COMPILE for above, as now they are dependent
rem 30.11.2008 ChA       Fixed header
rem ---------------------------------------------------------------------------

drop sequence cmpdep$tmp_seq
/
create sequence cmpdep$tmp_seq cache 200 /* cache 200 to make sequence faster */
/
drop table cmpdep$tmp
/
create table cmpdep$tmp
(
  object_id            number,
  referenced_object_id number,
  nest_level           number,
  seq#                 number      
)
/
create or replace procedure cmpdep (type char, schema char, name char) is
  obj_id number;
begin
  delete from cmpdep$tmp;
  commit;
  select object_id into obj_id from DBA_objects
    where owner        = upper(cmpdep.schema)
    and   object_name  = upper(cmpdep.name)
    and   object_type  = upper(cmpdep.type);
  insert into cmpdep$tmp
    values(obj_id, 0, 0, 0);
  insert into cmpdep$tmp
    select object_id, referenced_object_id,
        level, cmpdep$tmp_seq.nextval
      from public_dependency
      connect by prior object_id = referenced_object_id
      start with referenced_object_id = cmpdep.obj_id;
exception
  when no_data_found then
    raise_application_error(-20000, 'ORU-10013: ' ||
      type || ' ' || schema || '.' || name || ' was not found.');
end;
/

drop view cmpdep1$tmp
/

set echo off
create view sys.cmpdep1$tmp
  (nested_level, type, schema, name, seq#)
as
  select d.nest_level, o.object_type, o.owner, o.object_name, d.seq#
  from cmpdep$tmp d, dba_objects o
  where d.object_id = o.object_id (+)
union all
  select d.nest_level+1, 'CURSOR', '<shared>', '"'||c.kglnaobj||'"', d.seq#+.5
  from cmpdep$tmp d, x$kgldp k, x$kglob g, obj$ o, user$ u, x$kglob c,
      x$kglxs a
    where d.object_id = o.obj#
    and   o.name = g.kglnaobj
    and   o.owner# = u.user#
    and   u.name = g.kglnaown
    and   g.kglhdadr = k.kglrfhdl
    and   k.kglhdadr = a.kglhdadr   /* make sure it is not a transitive */
    and   k.kgldepno = a.kglxsdep   /* reference, but a direct one */
    and   k.kglhdadr = c.kglhdadr
    and   c.kglhdnsp = 0 /* a cursor */
/

drop view vcmpdep$tmp
/
create view vcmpdep$tmp (dependencies)
as
  select lpad(' ',3*(max(nested_level))) || max(nvl(type, '<no permission>')
    || ' ' || schema || decode(type, NULL, '', '.') || name)
  from cmpdep1$tmp
  group by seq# /* So user can omit sort-by when selecting from cmpdep$tmp */
/
grant execute on cmpdep to dba
/
