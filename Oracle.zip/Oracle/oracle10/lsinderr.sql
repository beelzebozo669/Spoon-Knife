rem -------------------------------------------------------------------------
rem        Trivadis AG, Baden/Basel/Bern/Lausanne/Z�rich
rem                     Frankfurt/Freiburg i.Br./M�nchen/Stuttgart
rem                     Switzerland/Germany Internet: http://www.trivadis.com
rem -------------------------------------------------------------------------
rem   $Header$
rem   **********************************************************************
rem   Group/Privileges.: DBA (SYS)
rem   Script-Name......: lsinderr.sql
rem   Developer........: Andri Kisseleff (ank) andri.kisseleff@trivadis.com
rem   Date.............: Nov. 1994
rem   Version..........: Oracle10g
rem   Usage............: Shows indexes where allocated spaced is filled up
rem			at least 50% which would not be able to allocate a new extent
rem			as not enough space in tablespace (and no datafile autoextensible)
rem   Input parameters.:
rem   Output.......... : lsinderr.lis
rem   Called by........:
rem   Remarks..........: Must be run as SYS, unless grants/changes,etc. done
rem                      manually (due to X$KDXST)
rem
rem			Segments in locally managed tablespaces AUTOALLOCATE have
rem			NEXT_EXTENT = NULL in the DD. We assume, that if 64K
rem			would be available, the segment could allocate a next extent
rem
rem -----------------------------------------------------------------------
rem
rem $Log$
rem Revision 1.2  2004/04/25 18:54:37  mnb
rem Exclude indexes in recycle bin (DROPPED='YES' instead of like 'RB$%')
rem
rem Revision 1.1  2003/09/16 08:40:27  ank
rem - OK for 10.1
rem - Added support for Indexes with NEXT_EXTENT=NULL (AUTOALLOCATE)
rem - Excluded indexes of tables in the recycle bin
rem
rem Revision 1.3  2002/09/09 16:56:24  far
rem 9.2 f�hig checked by ThJ
rem
rem Revision 1.2  2001/07/22 12:59:28  ank
rem - Load initial release Oracle9i 9.0.x
rem
rem
rem
rem Changes:
rem DD.MM.YYYY Consultant Change
rem 07.01.1996 ank	  added check if maxextens already reached
rem 18.06.1996 ank	  title and new header
rem 02.08.1997 ank        Oracle8 (subname = partition name)
rem 24.04.1999 AnK        OK for Oracle8i
rem                       - Added support for Part. Tables 
rem                         (Comp. part. Indexes do not show up in INDEX_STATS
rem                          --> Bug Oracle 8.1.5)
rem                       - Also show indexes in Tablespaces 100% full (+)
rem                       - Do not show indexes if one of the datafiles of
rem                         the corresponding tablespace is AUTOEXTENSIBLE = YES
rem 29.01.2000 AnK       Do not analyze Indexes or Partitions in READ ONLY Tablespaces
rem                      Checked Sub-Partitions with INDEX_STATS with 8.1.6
rem                      --> still empty (Bug Oracle)
rem
rem 30.06.2001 AnK	    OK for Oracle9i (Changes to x$kdxst)
rem 04.09.2002 ThJ          OK for Oracle9i R2
rem -----------------------------------------------------------------------
rem
rem -----------------------------------------------------------------------
rem
rem
rem
create or replace function f_c (v_string varchar2)
return varchar2
-- function: f_c
-- Trivadis AG, Reorg-Tools
-- In    : string
-- Return: "string" 
as
begin
 return chr(34)||v_string||chr(34);
end;
/
show errors function f_c

	SET ECHO OFF
	SET TERMOUT ON
/* 

	Check if user is SYS : 
*/
	SET HEAD OFF FEED OFF PAGES 0 TERMOUT OFF ECHO OFF VERIFY OFF 
	SET TIMING OFF
	COLUMN linie FORMAT A130 TRUNC
	SPOOL lsinderr.tmp
	SELECT  'WHENEVER SQLERROR EXIT' linie,
		'PROMPT Must be run as user sys.....' linie,
		'PAUSE Return...', 
		'EXIT' linie
	FROM    DUAL
	WHERE   user != 'SYS'
/
	SPOOL OFF
	SET TERMOUT ON FEED ON VERIFY ON
@lsinderr.tmp       /* Check ob User SYS */
rem HOST delete/noconfirm/nolog lsinderr.tmp.*
	WHENEVER SQLERROR CONTINUE
	
/* 
	
	
	Creating table required for collecting index statistics... : 
*/
	SET LINES 132 ECHO OFF TERMOUT OFF
	DROP TABLE lsinderr$tmp                                           
/
	create or replace view vlsinderr$tmp as    /* here table unpart. Indexes */
select kdxstrot+1      height,                                                  
        kdxstsbk        blocks,                                                 
        o.name,                                                                 
        o.subname       partition_name,                                         
        kdxstlrw        lf_rows,                                                
        kdxstlbk        lf_blks,                                                
        kdxstlln        lf_rows_len,                                            
        kdxstlub        lf_blk_len,                                             
        kdxstbrw        br_rows,                                                
        kdxstbbk        br_blks,                                                
        kdxstbln        br_rows_len,                                            
        kdxstbub        br_blk_len,                                             
        kdxstdrw        del_lf_rows,                                            
        kdxstdln        del_lf_rows_len,                                        
        kdxstdis        distinct_keys,                                          
        kdxstmrl        most_repeated_key,                                      
        kdxstlbk*kdxstlub+kdxstbbk*kdxstbub     btree_space,                    
        kdxstlln+kdxstbln+kdxstpln              used_space,                     
        ceil(((kdxstlln+kdxstbln+kdxstpln)*100)/                                
        (kdxstlbk*kdxstlub+kdxstbbk*kdxstbub))                                  
                                                pct_used,                       
        kdxstlrw/decode(kdxstdis, 0, 1, kdxstdis) rows_per_key,                 
        kdxstrot+1+(kdxstlrw+kdxstdis)/(decode(kdxstdis, 0, 1, kdxstdis)*2)     
                                                blks_gets_per_access,           
        kdxstnpr        pre_rows,                                               
        kdxstpln        pre_rows_len,                                           
        kdxstokc        opt_cmpr_count,                                         
        kdxstpsk        opt_cmpr_pctsave                                        
  from obj$ o, ind$ i, seg$ s, x$kdxst                                          
 where kdxstfil = s.file#                                                       
  and  kdxstblk = s.block#                                                      
  and  kdxsttsn = s.ts#                                                         
  and  s.file#  = i.file#                                                       
  and  s.block# = i.block#                                                      
  and  s.ts# = i.ts#                                                            
  and  i.obj#   = o.obj#                                                        
union all                                                                       
 select kdxstrot+1      height,                                                 
        kdxstsbk        blocks,                                                 
        o.name,                                                                 
        o.subname       partition_name,                                         
        kdxstlrw        lf_rows,                                                
        kdxstlbk        lf_blks,                                                
        kdxstlln        lf_rows_len,                                            
        kdxstlub        lf_blk_len,                                             
        kdxstbrw        br_rows,                                                
        kdxstbbk        br_blks,                                                
        kdxstbln        br_rows_len,                                            
        kdxstbub        br_blk_len,                                             
        kdxstdrw        del_lf_rows,                                            
        kdxstdln        del_lf_rows_len,                                        
        kdxstdis        distinct_keys,                                          
        kdxstmrl        most_repeated_key,                                      
        kdxstlbk*kdxstlub+kdxstbbk*kdxstbub     btree_space,                    
        kdxstlln+kdxstbln+kdxstpln              used_space,                     
        ceil(((kdxstlln+kdxstbln)*100)/                                         
        (kdxstlbk*kdxstlub+kdxstbbk*kdxstbub))                                  
                                                pct_used,                       
        kdxstlrw/decode(kdxstdis, 0, 1, kdxstdis) rows_per_key,                 
        kdxstrot+1+(kdxstlrw+kdxstdis)/(decode(kdxstdis, 0, 1, kdxstdis)*2)     
                                                blks_gets_per_access,           
        kdxstnpr        pre_rows,                                               
        kdxstpln        pre_rows_len,                                           
        kdxstokc        opt_cmpr_count,                                         
        kdxstpsk        opt_cmpr_pctsave                                        
  from obj$ o, seg$ s, indpart$ ip, x$kdxst                                     
 where kdxstfil = s.file#                                                       
  and  kdxstblk = s.block#                                                      
  and  kdxsttsn = s.ts#                                                         
  and  s.file#  = ip.file#                                                      
  and  s.block# = ip.block#                                                     
  and  s.ts#    = ip.ts#                                                        
  and  ip.obj#  = o.obj#                                                        
union all                                                                       
 select kdxstrot+1      height,                                                 
        kdxstsbk        blocks,                                                 
        o.name,                                                                 
        o.subname       partition_name,                                         
        kdxstlrw        lf_rows,                                                
        kdxstlbk        lf_blks,                                                
        kdxstlln        lf_rows_len,                                            
        kdxstlub        lf_blk_len,                                             
        kdxstbrw        br_rows,                                                
        kdxstbbk        br_blks,                                                
        kdxstbln        br_rows_len,                                            
        kdxstbub        br_blk_len,                                             
        kdxstdrw        del_lf_rows,                                            
        kdxstdln        del_lf_rows_len,                                        
        kdxstdis        distinct_keys,                                          
        kdxstmrl        most_repeated_key,                                      
        kdxstlbk*kdxstlub+kdxstbbk*kdxstbub     btree_space,                    
        kdxstlln+kdxstbln+kdxstpln              used_space,                     
        ceil(((kdxstlln+kdxstbln)*100)/                                         
        (kdxstlbk*kdxstlub+kdxstbbk*kdxstbub))                                  
                                                pct_used,                       
        kdxstlrw/decode(kdxstdis, 0, 1, kdxstdis) rows_per_key,                 
        kdxstrot+1+(kdxstlrw+kdxstdis)/(decode(kdxstdis, 0, 1, kdxstdis)*2)     
                                                blks_gets_per_access,           
        kdxstnpr        pre_rows,                                               
        kdxstpln        pre_rows_len,                                           
        kdxstokc        opt_cmpr_count,                                         
        kdxstpsk        opt_cmpr_pctsave                                        
  from obj$ o, seg$ s, indsubpart$ isp, x$kdxst                                 
 where kdxstfil = s.file#                                                       
  and  kdxstblk = s.block#                                                      
  and  kdxsttsn = s.ts#                                                         
  and  s.file#  = isp.file#                                                     
  and  s.block# = isp.block#                                                    
  and  s.ts#    = isp.ts#                                                       
  and  isp.obj#  = o.obj#                                                       
/
        TRUNCATE TABLE lsinderr2$tmp;
	CREATE TABLE lsinderr2$tmp /* Create if it does not yet exist */
	AS SELECT OWNER,TABLE_NAME, stat.* 
	FROM    index_stats stat,
		dba_indexes
	WHERE 1=2
/
	CREATE INDEX stats_owner_table_name ON 
		lsinderr2$tmp(owner,table_name,partition_name)
/
	SET TERMOUT ON
/*

	Generating the required VALIDATE INDEX, etc. commands... :
*/
	SET PAGES 0 HEAD OFF FEED OFF NEWPAGE 0 ECHO OFF TERMOUT OFF
	CLEAR COLUMNS
	CLEAR BREAKS
	TTITLE OFF
	BTITLE OFF
	CLEAR COMPUTE
	COLUMN linie FORMAT A130 WRAP
	SET TERMOUT ON
        PROMPT
        PROMPT Schema Name is case-sensitive (i.E. SCOTT, scott)
        PROMPT
	ACCEPT WELCHER_BENUTZER CHAR PROMPT "Owner (schema) ( % = all ) : "
	SET TERMOUT OFF
	SPOOL lsinderr.tmp
	PROMPT REM lsinderr.tmp
	PROMPT REM generated by lsinderr.sql
	PROMPT REM
rem
rem First the non partitioned Indexes...
rem 
	SET VERIFY OFF
	SELECT 'PROMPT Schema: '||OWNER||', Table: '||TABLE_NAME||', Index: '||INDEX_NAME linie,
	'VALIDATE INDEX '||f_c(OWNER)||'.'||f_c(INDEX_NAME)||';' linie,
	'INSERT INTO lsinderr2$tmp ' linie,
	'SELECT '||''''||OWNER||''''||','||''''||TABLE_NAME||''''||', stat.*  ' linie,
	' FROM vlsinderr$tmp stat;' linie,
	'COMMIT;' linie
	FROM DBA_INDEXES I, DBA_TABLESPACES TS
	WHERE OWNER NOT IN ('SYS')
	AND   OWNER LIKE NVL('&WELCHER_BENUTZER'||'%','%')
        AND   PARTITIONED = 'NO'
        AND   DROPPED != 'YES'
        AND   TS.TABLESPACE_NAME = I.TABLESPACE_NAME
        AND   TS.STATUS != 'READ ONLY'
	ORDER BY OWNER,TABLE_NAME,INDEX_NAME
/
rem
rem Now partitioned Indexes (not the subpartitioned Indexes)
rem
	SELECT  'PROMPT Schema: '||OWNER||', Table: '||TABLE_NAME||
        ', Partition: '||PARTITION_NAME||
        ', Index: '||i.INDEX_NAME linie,
	'ANALYZE INDEX '||f_c(INDEX_OWNER)||'.'||f_c(i.INDEX_NAME) linie,
        ' partition ('||f_c(PARTITION_NAME)||') VALIDATE STRUCTURE;' linie,
	'INSERT INTO lsinderr2$tmp ' linie,
	'SELECT '||''''||OWNER||''''||','||''''||TABLE_NAME||''''||
             ', stat.*  ' linie,
	' FROM vlsinderr$tmp stat;' linie,
	'COMMIT;' linie
	FROM DBA_IND_PARTITIONS p, DBA_INDEXES i, DBA_TABLESPACES TS
	WHERE i.owner = p.index_owner
        AND   i.index_name = p.index_name
        AND   INDEX_OWNER NOT IN ('SYS')
        AND   DROPPED != 'YES'
	AND   INDEX_OWNER LIKE NVL('&WELCHER_BENUTZER'||'%','%')
        AND   SUBPARTITION_COUNT = 0
        AND   TS.TABLESPACE_NAME = p.TABLESPACE_NAME
        AND   TS.STATUS != 'READ ONLY'
	ORDER BY INDEX_OWNER,TABLE_NAME,p.PARTITION_NAME, i.INDEX_NAME
/
rem
rem Now sub-partitioned Indexes (composite partitions)
rem
	SELECT  'PROMPT Schema: '||OWNER||', Table: '||TABLE_NAME||
        ', Sub-Partition: '||SUBPARTITION_NAME||
        ', Index: '||i.INDEX_NAME linie,
	'ANALYZE INDEX '||f_c(INDEX_OWNER)||'.'||f_c(i.INDEX_NAME) linie,
        ' partition ('||f_c(SUBPARTITION_NAME)||') VALIDATE STRUCTURE;' linie,
	'INSERT INTO lsinderr2$tmp ' linie,
	'SELECT '||''''||OWNER||''''||','||''''||TABLE_NAME||''''||
             ', stat.*  ' linie,
	' FROM vlsinderr$tmp stat;' linie,
	'COMMIT;' linie
	FROM DBA_IND_SUBPARTITIONS p, DBA_INDEXES i, DBA_TABLESPACES ts
	WHERE i.owner = p.index_owner
        AND   i.index_name = p.index_name
        AND   INDEX_OWNER NOT IN ('SYS')
        AND   DROPPED != 'YES'
	AND   INDEX_OWNER LIKE NVL('&WELCHER_BENUTZER'||'%','%')
        AND   TS.TABLESPACE_NAME = p.TABLESPACE_NAME
        AND   TS.STATUS != 'READ ONLY'
	ORDER BY INDEX_OWNER,TABLE_NAME,p.SUBPARTITION_NAME, i.INDEX_NAME
/
	SPOOL OFF
/*

	Validate selected indexes:
*/
	SET TERMOUT ON

@@lsinderr.tmp

	COL datum       NEW_VALUE       datum   NOPRINT
	select to_char(sysdate,'dd.mm.yy') datum
	from dual
/
	SET PAGES 48 LINES 132 HEAD ON FEED ON
	TTITLE LEFT FORMAT A8 datum ' / ' sql.user -
	CENTER 'Indexes with potential risk (no more space in TS)' -
	RIGHT 'Page: ' FORMAT 099 sql.pno -
	SKIP -
	CENTER '(alloc. space filled up over 50% and no more space for next extent)' -
	SKIP -
	CENTER '(or MAXEXTENTS reached)' -
	SKIP -
        CENTER '(Indexes in AUTOEXTENSIBLE Datafiles are not shown)' -
        SKIP -
        CENTER '(Indexes in READ ONLY Tablespaces are not analyzed)' -
        SKIP -
	CENTER 'ORACLE8i Version 'FORMAT A15 sql.release -
	SKIP 2
	COL owner FORMAT A10 TRUNC
	COL tablespace_name FORMAT A20 TRUNC
        COL index_name FORMAT A30 WORD_WRAP
	SPOOL lsinderr.lis
	select  I.OWNER, I.TABLE_NAME, I.INDEX_NAME, I.TABLESPACE_NAME,
		S.PCT_USED, nvl(I.NEXT_EXTENT,65536) NEXT_EXTENT
	from    SYS.DBA_INDEXES I, SYS.DBA_SEGMENTS SEG,
		lsinderr2$tmp S
	where   S.TABLE_NAME = I.TABLE_NAME
	and     S.NAME = I.INDEX_NAME
	and     SEG.SEGMENT_NAME = I.INDEX_NAME
	and     SEG.OWNER = I.OWNER
	and     SEG.SEGMENT_TYPE = 'INDEX'
	and     S.OWNER = I.OWNER
	and     S.PCT_USED > 50
	and     ( nvl(I.NEXT_EXTENT,65536) > (select nvl(max(F.BYTES),0)
				   from   SYS.DBA_FREE_SPACE F
				   where  I.TABLESPACE_NAME = F.TABLESPACE_NAME(+))
        and     SEG.TABLESPACE_NAME NOT IN ( select D.TABLESPACE_NAME
                                             from   SYS.DBA_DATA_FILES D
                                             where  SEG.TABLESPACE_NAME = SEG.TABLESPACE_NAME
                                              and    d.AUTOEXTENSIBLE = 'YES')
            or
		  I.MAX_EXTENTS <= SEG.EXTENTS )
       UNION
        select  
                I.OWNER, I.TABLE_NAME, 
                I.INDEX_NAME||' ('||IP.PARTITION_NAME||') ' INDEX_NAME, 
                IP.TABLESPACE_NAME,
		S.PCT_USED, nvl(IP.NEXT_EXTENT,65536) NEXT_EXTENT
	from    SYS.DBA_IND_PARTITIONS IP, SYS.DBA_PART_INDEXES I, SYS.DBA_SEGMENTS SEG,
		lsinderr2$tmp S
	where   S.TABLE_NAME = I.TABLE_NAME
	and     S.NAME = I.INDEX_NAME
	and     SEG.SEGMENT_NAME = I.INDEX_NAME
	and     SEG.OWNER = I.OWNER
	and     SEG.SEGMENT_TYPE IN  ('INDEX PARTITION','INDEX SUBPARTITION')
	and     S.OWNER = I.OWNER
        and     IP.INDEX_OWNER = I.OWNER
        and     IP.INDEX_NAME = I.INDEX_NAME
        and     S.PARTITION_NAME = IP.PARTITION_NAME
        and     IP.SUBPARTITION_COUNT = 0
	and     S.PCT_USED > 50
	and     ( nvl(IP.NEXT_EXTENT,65536) > (select nvl(max(F.BYTES),0)
				   from   SYS.DBA_FREE_SPACE F
				   where  IP.TABLESPACE_NAME = F.TABLESPACE_NAME(+))
        and     IP.TABLESPACE_NAME NOT IN ( select D.TABLESPACE_NAME
                                             from   SYS.DBA_DATA_FILES D
                                             where  SEG.TABLESPACE_NAME = SEG.TABLESPACE_NAME
                                              and    d.AUTOEXTENSIBLE = 'YES')
            or
		  IP.MAX_EXTENT <= SEG.EXTENTS )
	order by 1,2,3
/
	spool off
	ttitle off
	clear columns
	set pages 24 lines 80
	prompt 
	prompt lsinderr.lis has been spooled (A4 landscape)...
	prompt


REM Ende des Programmes
