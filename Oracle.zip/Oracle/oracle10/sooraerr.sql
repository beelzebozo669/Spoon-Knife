rem ---------------------------------------------------------------------------
rem  Trivadis AG, Baden-D�ttwil/Basel/Bern/Lausanne/Z�rich
rem               D�sseldorf/Frankfurt/Freiburg i.Br./Hamburg/M�nchen/Stuttgart
rem               Wien
rem               Switzerland/Germany/Austria Internet: http://www.trivadis.com
rem ---------------------------------------------------------------------------
rem $Id: sooraerr.sql 164 2008-11-30 14:16:24Z cha $
rem ---------------------------------------------------------------------------
rem  Group/Privileges.: User
rem  Script Name......: sooraerr.sql
rem  Developer........: Urs Meier (UrM)
rem  Date.............: 28.02.1996
rem  Version..........: Oracle Database 10g
rem  Description......: Displays error text for an error number
rem  Usage............: 
rem  Input parameters.: 
rem  Output...........: 
rem  Called by........:
rem  Requirements.....: 
rem  Remarks..........: Example: @sooraerr 942
rem
rem ---------------------------------------------------------------------------
rem Changes:
rem DD.MM.YYYY Developer Change
rem ---------------------------------------------------------------------------
rem 05.04.1997 UrM       rename
rem 02.08.1997 ank       Oracle8
rem 21.04.1999 AnK       OK for Oracle8i
rem 03.09.2002 ThJ       OK for Oracle9i R2
rem 09.09.2003 AnK       OK for 10.1
rem 30.11.2008 ChA       Fixed header + Added "undefine 1"
rem ---------------------------------------------------------------------------

set serveroutput on verify off feedback off
execute dbms_output.put_line(sqlerrm(-&1));
set serveroutput off feedback on
undefine 1
