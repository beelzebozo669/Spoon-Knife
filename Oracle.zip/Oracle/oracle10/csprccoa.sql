rem -------------------------------------------------------------------------
rem        Trivadis AG, Baden/Basel/Bern/Lausanne/Z�rich
rem                     Frankfurt/Freiburg i.Br./M�nchen/Stuttgart
rem                     Switzerland/Germany Internet: http://www.trivadis.com
rem -------------------------------------------------------------------------
rem   $Header$
rem   **********************************************************************
rem   Group/Privileges.: SYS (or grant manually to a DBA)
rem   Script-Name......: csprccoa.sql
rem   Developer........: Andri Kisseleff (ank) andri.kisseleff@trivadis.com
rem   Date.............: 13.11.1995
rem   Version..........: Oracle10g
rem   Usage............: creates procedure prc_coalesce under SYS
rem   Input parameters.:
rem   Output.......... :
rem   Called by........:
rem   Remarks..........: allows to coalesce contigous free extens in all
rem			 tablespaces (only meaningful for dictionary managed tablespaces)
rem
rem                      in SQL*Plus:
rem                       execute prccoa;
rem
rem                      in PL/SQL:
rem                       begin
rem                        prccoa;
rem                       end;
rem                       /
rem
rem -----------------------------------------------------------------------
rem
rem $Log$
rem Revision 1.1  2003/09/09 15:42:15  ank
rem - OK for 10.1
rem
rem Revision 1.2  2001/07/22 12:59:28  ank
rem - Load initial release Oracle9i 9.0.x
rem
rem
rem
rem Changes:
rem DD.MM.YYYY Consultant Change
rem 18.06.1996 ank        title and new header
rem 27.07.1997 urm        Migrated to Oracle8 and changed event to ALTER
rem                       TABLESPACE
rem                       Changed name of procedure to new standard
rem 21.09.1997 ank        Comments up-to-date
rem 20.04.1999 AnK        OK for Oracle8i
rem 08.11.1999 clk        Changed to EXECUTE IMMEDIATE dynamic SQL
rem -----------------------------------------------------------------------
rem
rem -----------------------------------------------------------------------
rem
rem

CREATE OR REPLACE PROCEDURE prccoa IS

BEGIN
  FOR tsrec IN (SELECT tablespace_name,
                TO_CHAR(percent_blocks_coalesced,'990.00') percent_blocks_coalesced
                  FROM dba_free_space_coalesced
                 WHERE percent_blocks_coalesced < 100) LOOP
                 
    execute immediate 'ALTER TABLESPACE '||tsrec.tablespace_name||' coalesce';
    
    dbms_output.put('Tablespace ');
    dbms_output.put(RPAD(tsrec.tablespace_name,30,'.'));
    dbms_output.put(': ');
    dbms_output.put(tsrec.percent_blocks_coalesced);
    dbms_output.new_line;

  END LOOP;
  
END;
/

show error

prompt use "Set Serveroutput on" (optional) and then "EXECUTE prccoa"

