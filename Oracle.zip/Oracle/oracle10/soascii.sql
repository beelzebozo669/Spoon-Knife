rem -------------------------------------------------------------------------
rem        Trivadis AG, Baden/Basel/Bern/Lausanne/Z�rich
rem                     Frankfurt/Freiburg i.Br./M�nchen/Stuttgart
rem                     Switzerland/Germany Internet: http://www.trivadis.com
rem -------------------------------------------------------------------------
rem   $Header$
rem   **********************************************************************
rem   Group/Privileges.: User
rem   Script-Name......: soascii.sql
rem   Developer........: Stephan Borsodi (SBo) stephan.borsodi@trivadis.com
rem   Date.............: December 2000
rem   Version..........: Oracle10g
rem   Usage............: Creates an ascii coding list (ascii_nr: value)
rem                      valid for the instance on which the script is
rem                      executed.
rem   Input parameters.:
rem   Output.......... :
rem   Called by........:
rem   Remarks..........: anonymous pl/sql block
rem -----------------------------------------------------------------------
rem Changes:
rem
rem $Log$
rem Revision 1.1  2003/09/15 08:41:39  ank
rem - OK for 10.1
rem
rem Revision 1.3  2002/09/09 16:56:24  far
rem 9.2 f�hig checked by ThJ
rem
rem Revision 1.2  2001/07/22 12:59:28  ank
rem - Load initial release Oracle9i 9.0.x
rem
rem
rem
rem -----------------------------------------------------------------------
rem 22.12.2000 SBo        Initial version created
rem 03.09.2002 ThJ        OK for Oracle9i R2
rem
rem -----------------------------------------------------------------------
rem

set serverout on size 100000

begin
	dbms_output.put_line('ASCII codings on this database');
	dbms_output.put_line('=============================='||CHR(10));
	dbms_output.put_line('Ascii   Character');
	dbms_output.put_line('------- ---------');
	for i in 1 .. 256 loop
		dbms_output.put_line(rpad(to_char(i, '099'), 7, '.')||': '||CHR(i));
	end loop;
end;
/


