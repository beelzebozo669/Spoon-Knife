rem ---------------------------------------------------------------------------
rem  Trivadis AG, Baden-D�ttwil/Basel/Bern/Lausanne/Z�rich
rem               D�sseldorf/Frankfurt/Freiburg i.Br./Hamburg/M�nchen/Stuttgart
rem               Wien
rem               Switzerland/Germany/Austria Internet: http://www.trivadis.com
rem ---------------------------------------------------------------------------
rem $Id: edcmpdep.sql 163 2008-11-30 14:07:21Z cha $
rem ---------------------------------------------------------------------------
rem  Group/Privileges.: DBA
rem  Script Name......: edcmpdep.sql
rem  Developer........: Andri Kisseleff (AnK)
rem  Date.............: 07.01.1994
rem  Version..........: Oracle Database 10g
rem  Description......: Show and compile dependent objects that are invalid
rem  Usage............: 
rem  Input parameters.: 
rem  Output...........: 
rem  Called by........:
rem  Requirements.....: 
rem  Remarks..........: cscmpdep.sql must be run previousley under SYS (once)
rem
rem ---------------------------------------------------------------------------
rem Changes:
rem DD.MM.YYYY Developer Change
rem ---------------------------------------------------------------------------
rem 21.09.1997 ank       Oracle8. Fixed bug. Not select ideptree, but
rem                      SYS.VCMPDEP$TMP
rem 20.04.1999 AnK       OK for Oracle8i
rem 04.09.2002 ThJ       OK for Oracle9i R2
rem 10.09.2003 AnK       OK for 10.1
rem                      Removed special treatment for SYNONYMS/PUBLIC SYNONYMS
rem                      Added COMPILE for above, as now they are dependent
rem 30.11.2008 ChA       Fixed header + Display error if cscmpdep.sql was not run
rem ---------------------------------------------------------------------------

SET VERIFY OFF ECHO OFF SERVEROUTPUT ON

DECLARE
  l_count PLS_INTEGER;
BEGIN
  SELECT count(*) INTO l_count
  FROM all_objects
  WHERE object_name = 'CMPDEP'
  AND owner = 'SYS';
  IF l_count = 0
  THEN
    dbms_output.put_line('****************************************************************');
    dbms_output.put_line('* ERROR: cscmpdep.sql must be run previousley under SYS (once) *');
    dbms_output.put_line('****************************************************************');
  END IF;
END;
/

ACCEPT OWNER		CHAR	PROMPT 'Owner of table or View: '
ACCEPT TABLE_NAME	CHAR	PROMPT 'Name (table, view)    : '
ACCEPT TABLE_VIEW	CHAR	PROMPT 'Type: TABLE or VIEW   : '

EXECUTE SYS.cmpdep(UPPER('&TABLE_VIEW'),UPPER('&OWNER'),UPPER('&TABLE_NAME'));

SELECT	* FROM SYS.VCMPDEP$TMP
ORDER BY 1 DESC
/

SET PAGES 0 FEED OFF ECHO OFF

SPOOL escmpdep.tmp
SELECT  CASE
          WHEN SCHEMA != 'PUBLIC'
           THEN 'ALTER '||decode(TYPE,'PACKAGE BODY','PACKAGE',TYPE)
           ELSE  'ALTER PUBLIC '||decode(TYPE,'PACKAGE BODY','PACKAGE',TYPE)
        END ||' '||
	decode(SCHEMA,'PUBLIC',NULL,SCHEMA)||DECODE(SCHEMA,'PUBLIC',NULL,'.')||NAME||' COMPILE '||
	decode(TYPE,'PACKAGE BODY','BODY',NULL)||';'
FROM 	SYS.CMPDEP1$TMP D, SYS.DBA_OBJECTS O
WHERE	D.TYPE NOT IN ('TABLE','CURSOR')
AND     D.SCHEMA = O.OWNER
AND     D.TYPE = O.OBJECT_TYPE
AND     D.NAME = O.OBJECT_NAME
AND     O.STATUS = 'INVALID'
ORDER BY NESTED_LEVEL
/
SPOOL OFF

SET FEED ON PAGES 24 ECHO ON SERVEROUTPUT OFF
@escmpdep.tmp
SET VERIFY ON ECHO OFF
UNDEFINE OWNER
UNDEFINE TABLE_NAME
UNDEFINE TABLE_VIEW
