Query to check status
SET LINESIZE 150
SET PAGESIZE 25

COLUMN name  FORMAT A50
COLUMN owner FORMAT A30

  SELECT owner, name, enqueue_enabled, dequeue_enabled
    FROM dba_queues
   WHERE owner NOT IN ('GSMADMIN_INTERNAL','SYS','SYSTEM','WMSYS')
     AND name IN ('XXAQ_OP_JMS_TXT_Q','XXAQ_CLASS_JMS_TXT_Q','PAY_JMS_TXT_Q','LAC_JMS_TXT_Q','CONF_JMS_TXT_Q','XXAQ_FV_CLA_JMS_TXT_Q','XXAQ_FV_JMS_TXT_Q')
ORDER BY owner, name;
   
   
XXAQ_HEI_APP_JMS_TXT_Q
execute dbms_aqadm.stop_queue ('XXAQ.XXAQ_HEI_APP_JMS_TXT_Q');
execute dbms_aqadm.start_queue ('XXAQ.XXAQ_HEI_APP_JMS_TXT_Q');

XXAQ stop
execute dbms_aqadm.stop_queue ('XXAQ.XXAQ_FV_CLA_JMS_TXT_Q');
execute dbms_aqadm.stop_queue ('XXAQ.XXAQ_FV_JMS_TXT_Q');

XXAQ start
execute dbms_aqadm.start_queue ('XXAQ.XXAQ_FV_CLA_JMS_TXT_Q');
execute dbms_aqadm.start_queue ('XXAQ.XXAQ_FV_JMS_TXT_Q');

XXOP queue stop script
execute dbms_aqadm.stop_queue ('XXAQ.XXAQ_OP_JMS_TXT_Q');
execute dbms_aqadm.stop_queue ('XXAQ.XXAQ_CLASS_JMS_TXT_Q');

XXOP queue start script
execute dbms_aqadm.start_queue ('XXAQ.XXAQ_OP_JMS_TXT_Q');
execute dbms_aqadm.start_queue ('XXAQ.XXAQ_CLASS_JMS_TXT_Q');

XXPREPAY queue stop script
execute dbms_aqadm.stop_queue ('XXPREPAY.PAY_JMS_TXT_Q');
execute dbms_aqadm.stop_queue ('XXPREPAY.LAC_JMS_TXT_Q');
execute dbms_aqadm.stop_queue ('XXPREPAY.CONF_JMS_TXT_Q');

XXPREPAY queue start script
execute dbms_aqadm.start_queue ('XXPREPAY.PAY_JMS_TXT_Q');
execute dbms_aqadm.start_queue ('XXPREPAY.LAC_JMS_TXT_Q');
execute dbms_aqadm.start_queue ('XXPREPAY.CONF_JMS_TXT_Q');


  select queue.user_data.text_vc, queue.q_name, queue.enq_time, queue.deq_time, queue.retry_count
    from xxaq.xxaq_fv_cla_jms_txt_qt queue
order by enq_time desc;

  select queue.q_name, queue.enq_time, queue.deq_time, queue.retry_count
    from xxaq.xxaq_fv_cla_jms_txt_qt queue
order by enq_time desc;


  select queue.q_name, queue.state, queue.delay, queue.enq_time, queue.deq_time, queue.retry_count
    from xxaq.xxaq_fv_cla_jms_txt_qt queue
order by enq_time desc;


ps -ef | egrep -i 'CL_BULK_S|CL_HEI_S|CL_PAY_S|CL_REP_S|CL_S'

grep -il CL12CNT /u01/app/oracle/product/10.1.2_OAI/integration/interconnect/adapters/*/adapter.ini | grep _S | awk -F'/' '{print "ps -ef " $10}' | tr '\n' ' '
''
declare
purgeOption dbms_aqadm.aq$_purge_options_t;
begin
purgeOption.block := FALSE;
dbms_aqadm.purge_queue_table(
     queue_table     => 'queue_table',
     purge_condition => NULL,
     purge_options   => purgeOption);
end;
/


  select count(*),
         queue,
         msg_state,
         consumer_name
    from xxprepay.aq$xxprepay_conf_jms_txt_qt_e
group by msg_state, consumer_name, queue; 

  select count(*),
         queue,
         msg_state,
         consumer_name
    from xxprepay.xxprepay_conf_jms_txt_qt
group by msg_state, consumer_name, queue; 


As user
  select count(*),
         q_name,
         state,
         consumer_name
    from xxprepay.xxprepay_conf_jms_txt_qt
group by state, consumer_name, q_name; 


