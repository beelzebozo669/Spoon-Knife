rem -------------------------------------------------------------------------
rem        Trivadis AG, Baden/Basel/Bern/Lausanne/Mellingen/Z�rich
rem                     Frankfurt/Freiburg i.Br./M�nchen/Stuttgart
rem                     Switzerland/Germany Internet: http://www.trivadis.com
rem -------------------------------------------------------------------------
rem   $Header$
rem   **********************************************************************
rem   Group/Privileges.: SYS (Utilities)
rem   Script-Name......: sslongop.sql
rem   Developer........: Urs Meier (urm) urs.meier@trivadis.com
rem   Date.............: 19.07.1997
rem   Version..........: Oracle9i - 2.1
rem   Usage............: Show Long Operations with Oracle8/9
rem   Input parameters.:
rem   Output.......... : 
rem   Called by........:
rem   Remarks..........:
rem -----------------------------------------------------------------------
rem
rem $Log$
rem Revision 1.3  2002/09/09 16:56:24  far
rem 9.2 f�hig checked by ThJ
rem
rem Revision 1.2  2001/07/22 12:59:28  ank
rem - Load initial release Oracle9i 9.0.x
rem
rem
rem
rem Changes:
rem DD.MM.YYYY Consultant Change
rem -----------------------------------------------------------------------
rem 21.09.1997 ank        Added COL CLEAR
rem                       Copy of UrM sdlongop.sql
rem                       but only shows working sessions
rem 21.04.1999 AnK        OK for Oracle8i. v$session_lonops completely 
rem                       changed between 8.0 and 8.1. OBJ# not any longer
rem                       available --> Join to v$sqlarea as to see the
rem                       SQL-Command.
rem 04.09.2002 ThJ        OK for Oracle9i R2
rem -----------------------------------------------------------------------
rem
rem
set logsource "dummy"
store set temp.tmp replace
column username 		noprint new_value username
column schemaname		noprint new_value schemaname
column logon_time		noprint new_value logon_time
column name			format a20
column units                    format a60
set pages 80
break on username duplicate skip page

Ttitle center username " as " schemaname " logged in since " logon_time skip 2


SELECT NVL(s.username,'SNP (inactive)') username, 
       s.schemaname, TO_CHAR(s.logon_time,'DD.MM.YYYY HH24:MI.SS') logon_time,
       message, /* sofar, totalwork, units, */ elapsed_seconds, time_remaining,
       q.sql_text
  FROM sys.v$session s,
       sys.v$session_longops l,
       sys.v$sqlarea q
 WHERE s.sid = l.sid
   AND s.serial# = l.serial#
   AND l.sofar < l.totalwork
   AND q.address(+) = l.sql_address
   AND q.hash_value(+) = l.sql_hash_value
 ORDER BY s.username, s.schemaname, logon_time;



column username 		clear
column schemaname		clear
column logon_time		clear
column units                    clear
clear breaks
@temp.tmp
ttitle off
