rem -------------------------------------------------------------------------
rem        Trivadis AG, Baden/Basel/Bern/Lausanne/Mellingen/Z�rich
rem                     Frankfurt/Freiburg i.Br./M�nchen/Stuttgart
rem                     Switzerland/Germany Internet: http://www.trivadis.com
rem -------------------------------------------------------------------------
rem   $Header$
rem   **********************************************************************
rem   Group/Privileges.: Owner
rem   Script-Name......: lodblind.sql
rem   Developer........: Urs Meier (urm) urs.meier@trivadis.com
rem   Date.............: 26.12.1996
rem   Version..........: Oracle9i - 2.1
rem   Usage............: Find indexes which starts with same attribute.
rem   Input parameters.:
rem   Output.......... : 
rem   Called by........:
rem   Remarks..........:
rem -----------------------------------------------------------------------
rem
rem $Log$
rem Revision 1.3  2002/09/09 16:56:24  far
rem 9.2 f�hig checked by ThJ
rem
rem Revision 1.2  2001/07/22 12:59:28  ank
rem - Load initial release Oracle9i 9.0.x
rem
rem
rem
rem Changes:
rem DD.MM.YYYY Consultant Change
rem 
rem -----------------------------------------------------------------------
rem 05.04.1997 urs.meier	rename
rem 15.11.1997 urs.meier	V8
rem 20.04.1999 AnK              OK for Oracle8i. Changed to ALL_ind_columns
rem                             as Partitioned Indexes can also be seen there.
rem                             All type of partitioned Indexes now supported.
rem 04.09.2002 ThJ              OK for Oracle9i R2
rem -----------------------------------------------------------------------
rem
rem
column table_name		format a25	heading "Table"
column index_name		format a25	heading "Index"
column column_name		format a25  heading "Column"
@@foenvtit "Indexes starting with the same attributes"
spool lodblind.lis
BREAK ON table_name skip 2 

SELECT table_name,
       index_name,
       column_name
  FROM all_ind_columns
  WHERE table_owner = USER
  AND  (table_owner, table_name,column_name) IN (SELECT table_owner, table_name, column_name
                                      FROM all_ind_columns
                                     WHERE column_position = 1
                                     AND   table_owner = USER
                                     GROUP BY table_owner, table_name, column_name
                                    HAVING COUNT(*) > 1)
   AND column_position = 1;

spool off
ttitle off
prompt lodblind.lis has been spooled



