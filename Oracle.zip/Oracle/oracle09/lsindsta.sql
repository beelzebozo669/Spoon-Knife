rem -------------------------------------------------------------------------
rem        Trivadis AG, Baden/Basel/Bern/Lausanne/Mellingen/Z�rich
rem                     Frankfurt/Freiburg i.Br./M�nchen/Stuttgart
rem                     Switzerland/Germany Internet: http://www.trivadis.com
rem -------------------------------------------------------------------------
rem   $Header$
rem   **********************************************************************
rem   Group/Privileges.: SYS
rem   Script-Name......: lsindsta.sql
rem   Developer........: Andri Kisseleff (ank) andri.kisseleff@trivadis.com
rem   Date.............: Nov. 1991
rem   Version..........: Oracle9i - 3.1
rem   Usage............: Analyze Index validate structure for all indexes
rem                      of one user or all users. Detail-Statistics including
rem                      summary histogram
rem   Input parameters.: Schema name or wildcard
rem   Output.......... : lsindsta.lis (can be printed A4 landscape)
rem   Called by........:
rem   Remarks..........: runs under Oracle9i only
rem			 This script locks the tables and uses resources
rem                      (Versions for Oracle6, 7, 8.0, 8.1 also available)
rem -----------------------------------------------------------------------
rem
rem $Log$
rem Revision 1.3  2002/09/09 16:56:24  far
rem 9.2 f�hig checked by ThJ
rem
rem Revision 1.2  2001/07/22 12:59:28  ank
rem - Load initial release Oracle9i 9.0.x
rem
rem
rem
rem Changes:
rem DD.MM.YYYY Consultant Change
rem -----------------------------------------------------------------------
rem 26.12.1996 urm        Exclude Bitmap Indexes for V73 PQO
rem 02.08.1997 ank        Oracle8 (subname = partition name)
rem	                  Rewrite for BITMAP Indexes, Partitioned Indexes,
rem                       Partitioned Tables, Part. bitmaped Indexes
rem                       Removed summary at the end of the report
rem 22.04.1999 AnK        OK for Oracle8i. (Hash & Comp. Partitons added)
rem                       - changes in x$kdxst
rem                       - excluse Sub-Partitions in PARTITION-Select
rem                         (SUBPARTITION_COUNT)
rem                       - 8.1.5: ANALYZE INDEX for Sub-Partitons does not
rem                         generate any entries in INDEX_STATS (not if
rem                         the sub-partition is analyzed and also not
rem                         if the partition is analyzed --> Bug Oracle
rem                       - added hints for better performance
rem
rem 22.04.1999 AnK        New: 
rem                       - Support for case-sensitive Schema, Table-Name,
rem                         Index-Name, Partition-Name
rem                       - added HEIGHT > 4 Indexes
rem
rem 30.06.2001 AnK        PK for 9i (changes in x$kdxst implemented)
rem 04.09.2002 ThJ        OK for Oracle9i R2
rem -----------------------------------------------------------------------
rem
rem
REM
set logsource "dummy"
store set temp.tmp replace
create or replace function f_c (v_string varchar2)
return varchar2
-- function: f_c
-- Trivadis AG, Reorg-Tools
-- In    : string
-- Return: "string" 
as
begin
 return chr(34)||v_string||chr(34);
end;
/
show errors function f_c
	SET ECHO OFF
	SET TERMOUT ON
/* 

	Check connected Schema is SYS : 
*/
	SET HEAD OFF
	SET FEED OFF
	SET PAGES 0
	SET TERMOUT OFF
	SET ECHO OFF
	SET VERIFY OFF
	COLUMN linie FORMAT A130 TRUNC
	SPOOL lsindsta.tmp
	SELECT  'WHENEVER SQLERROR EXIT' linie,
		'PROMPT Must be run while connected as SYS.....' linie,
		'PAUSE ' linie, 
		'EXIT' linie
	FROM    DUAL
	WHERE   user != 'SYS'
/
	SPOOL OFF
	SET TERMOUT ON
	SET FEED ON
	SET VERIFY ON
@lsindsta.tmp       /* Check ob User SYS */
rem HOST delete/noconfirm/nolog lsindsta.tmp.*
	WHENEVER SQLERROR CONTINUE
	
/* 
	
	
	Create temporary table for statistics : 
*/
	SET LINES 132
	SET ECHO OFF TRIMSPOOL ON
	SET TERMOUT OFF

	DROP TABLE indsta1$tmp                                             
/
	drop view vindsta$tmp
/
	create view vindsta$tmp as    /* here table unpart. Indexes */
select kdxstrot+1      height,                                                  
        kdxstsbk        blocks,                                                 
        o.name,                                                                 
        o.subname       partition_name,                                         
        kdxstlrw        lf_rows,                                                
        kdxstlbk        lf_blks,                                                
        kdxstlln        lf_rows_len,                                            
        kdxstlub        lf_blk_len,                                             
        kdxstbrw        br_rows,                                                
        kdxstbbk        br_blks,                                                
        kdxstbln        br_rows_len,                                            
        kdxstbub        br_blk_len,                                             
        kdxstdrw        del_lf_rows,                                            
        kdxstdln        del_lf_rows_len,                                        
        kdxstdis        distinct_keys,                                          
        kdxstmrl        most_repeated_key,                                      
        kdxstlbk*kdxstlub+kdxstbbk*kdxstbub     btree_space,                    
        kdxstlln+kdxstbln+kdxstpln              used_space,                     
        ceil(((kdxstlln+kdxstbln+kdxstpln)*100)/                                
        (kdxstlbk*kdxstlub+kdxstbbk*kdxstbub))                                  
                                                pct_used,                       
        kdxstlrw/decode(kdxstdis, 0, 1, kdxstdis) rows_per_key,                 
        kdxstrot+1+(kdxstlrw+kdxstdis)/(decode(kdxstdis, 0, 1, kdxstdis)*2)     
                                                blks_gets_per_access,           
        kdxstnpr        pre_rows,                                               
        kdxstpln        pre_rows_len,                                           
        kdxstokc        opt_cmpr_count,                                         
        kdxstpsk        opt_cmpr_pctsave                                        
  from obj$ o, ind$ i, seg$ s, x$kdxst                                          
 where kdxstfil = s.file#                                                       
  and  kdxstblk = s.block#                                                      
  and  kdxsttsn = s.ts#                                                         
  and  s.file#  = i.file#                                                       
  and  s.block# = i.block#                                                      
  and  s.ts# = i.ts#                                                            
  and  i.obj#   = o.obj#                                                        
union all                                                                       
 select kdxstrot+1      height,                                                 
        kdxstsbk        blocks,                                                 
        o.name,                                                                 
        o.subname       partition_name,                                         
        kdxstlrw        lf_rows,                                                
        kdxstlbk        lf_blks,                                                
        kdxstlln        lf_rows_len,                                            
        kdxstlub        lf_blk_len,                                             
        kdxstbrw        br_rows,                                                
        kdxstbbk        br_blks,                                                
        kdxstbln        br_rows_len,                                            
        kdxstbub        br_blk_len,                                             
        kdxstdrw        del_lf_rows,                                            
        kdxstdln        del_lf_rows_len,                                        
        kdxstdis        distinct_keys,                                          
        kdxstmrl        most_repeated_key,                                      
        kdxstlbk*kdxstlub+kdxstbbk*kdxstbub     btree_space,                    
        kdxstlln+kdxstbln+kdxstpln              used_space,                     
        ceil(((kdxstlln+kdxstbln)*100)/                                         
        (kdxstlbk*kdxstlub+kdxstbbk*kdxstbub))                                  
                                                pct_used,                       
        kdxstlrw/decode(kdxstdis, 0, 1, kdxstdis) rows_per_key,                 
        kdxstrot+1+(kdxstlrw+kdxstdis)/(decode(kdxstdis, 0, 1, kdxstdis)*2)     
                                                blks_gets_per_access,           
        kdxstnpr        pre_rows,                                               
        kdxstpln        pre_rows_len,                                           
        kdxstokc        opt_cmpr_count,                                         
        kdxstpsk        opt_cmpr_pctsave                                        
  from obj$ o, seg$ s, indpart$ ip, x$kdxst                                     
 where kdxstfil = s.file#                                                       
  and  kdxstblk = s.block#                                                      
  and  kdxsttsn = s.ts#                                                         
  and  s.file#  = ip.file#                                                      
  and  s.block# = ip.block#                                                     
  and  s.ts#    = ip.ts#                                                        
  and  ip.obj#  = o.obj#                                                        
union all                                                                       
 select kdxstrot+1      height,                                                 
        kdxstsbk        blocks,                                                 
        o.name,                                                                 
        o.subname       partition_name,                                         
        kdxstlrw        lf_rows,                                                
        kdxstlbk        lf_blks,                                                
        kdxstlln        lf_rows_len,                                            
        kdxstlub        lf_blk_len,                                             
        kdxstbrw        br_rows,                                                
        kdxstbbk        br_blks,                                                
        kdxstbln        br_rows_len,                                            
        kdxstbub        br_blk_len,                                             
        kdxstdrw        del_lf_rows,                                            
        kdxstdln        del_lf_rows_len,                                        
        kdxstdis        distinct_keys,                                          
        kdxstmrl        most_repeated_key,                                      
        kdxstlbk*kdxstlub+kdxstbbk*kdxstbub     btree_space,                    
        kdxstlln+kdxstbln+kdxstpln              used_space,                     
        ceil(((kdxstlln+kdxstbln)*100)/                                         
        (kdxstlbk*kdxstlub+kdxstbbk*kdxstbub))                                  
                                                pct_used,                       
        kdxstlrw/decode(kdxstdis, 0, 1, kdxstdis) rows_per_key,                 
        kdxstrot+1+(kdxstlrw+kdxstdis)/(decode(kdxstdis, 0, 1, kdxstdis)*2)     
                                                blks_gets_per_access,           
        kdxstnpr        pre_rows,                                               
        kdxstpln        pre_rows_len,                                           
        kdxstokc        opt_cmpr_count,                                         
        kdxstpsk        opt_cmpr_pctsave                                        
  from obj$ o, seg$ s, indsubpart$ isp, x$kdxst                                 
 where kdxstfil = s.file#                                                       
  and  kdxstblk = s.block#                                                      
  and  kdxsttsn = s.ts#                                                         
  and  s.file#  = isp.file#                                                     
  and  s.block# = isp.block#                                                    
  and  s.ts#    = isp.ts#                                                       
  and  isp.obj#  = o.obj#                                                       
/
	CREATE TABLE indsta1$tmp
	AS SELECT OWNER,TABLE_NAME, stat.* 
	FROM    index_stats stat,
		dba_indexes i
	WHERE 1=2
/
	CREATE INDEX stats_owner_table_name ON 
		indsta1$tmp(owner,table_name,partition_name)
/
	SET TERMOUT ON
/*

	Generate the ANALYZE INDEX VALIDATE commands
*/
	SET PAGES 0
	SET HEAD OFF
	SET FEED OFF
	SET NEWPAGE 0
	SET ECHO OFF
	SET TERMOUT OFF
	CLEAR COLUMNS
	CLEAR BREAKS
	TTITLE OFF
	BTITLE OFF
	CLEAR COMPUTE
	COLUMN linie FORMAT A130 WRAP
	SET TERMOUT ON
        PROMPT
        PROMPT Schema Name is case-sensitive (i.E. SCOTT, scott)
        PROMPT
	ACCEPT WELCHER_BENUTZER CHAR PROMPT "Schema Name ( % = all ) : "
	SET TERMOUT OFF
	SPOOL allind.tmp
	PROMPT REM allind.tmp
	PROMPT REM generated by lsindsta.sql
	PROMPT REM
	SET VERIFY OFF
rem
rem First unpartitioned Indexes
rem
	SELECT /*+ RULE */ 'PROMPT Schema: '||OWNER||', Table: '||TABLE_NAME||
        ', Index: ' ||INDEX_NAME linie,
	'ANALYZE INDEX '||f_c(OWNER)||'.'||f_c(INDEX_NAME) linie,
        ' VALIDATE STRUCTURE;' linie,
	'INSERT INTO indsta1$tmp ' linie,
        'SELECT '||''''||OWNER||''''||','||''''||TABLE_NAME||''''||
           ', stat.*  ' linie,
	' FROM vindsta$tmp stat;' linie,
	'COMMIT;' linie
	FROM DBA_INDEXES
	WHERE OWNER NOT IN ('SYS','SYSTEM','WEBDB','OUTLN')
	AND   OWNER LIKE NVL('&WELCHER_BENUTZER'||'%','%')
	AND   INDEX_TYPE NOT IN ('BITMAP','IOT - TOP')
        AND   PARTITIONED = 'NO'
	ORDER BY OWNER,TABLE_NAME,INDEX_NAME
/
rem
rem Now partitioned Indexes (not the subpartitioned Indexes)
rem
	SELECT /*+ RULE */ 'PROMPT Schema: '||OWNER||', Table: '||TABLE_NAME||
        ', Partition: '||PARTITION_NAME||
        ', Index: '||i.INDEX_NAME linie,
	'ANALYZE INDEX '||f_c(INDEX_OWNER)||'.'||f_c(i.INDEX_NAME) linie,
        ' partition ('||f_c(PARTITION_NAME)||') VALIDATE STRUCTURE;' linie,
	'INSERT INTO indsta1$tmp ' linie,
	'SELECT '||''''||OWNER||''''||','||''''||TABLE_NAME||''''||
             ', stat.*  ' linie,
	' FROM vindsta$tmp stat;' linie,
	'COMMIT;' linie
	FROM DBA_IND_PARTITIONS p, DBA_INDEXES i
	WHERE i.owner = p.index_owner
        AND   i.index_name = p.index_name
        AND   INDEX_TYPE NOT IN ('BITMAP')
        AND   INDEX_OWNER NOT IN ('SYS','SYSTEM','WEBDB','OUTLN')
	AND   INDEX_OWNER LIKE NVL('&WELCHER_BENUTZER'||'%','%')
        AND   SUBPARTITION_COUNT = 0
	ORDER BY INDEX_OWNER,TABLE_NAME,p.PARTITION_NAME, i.INDEX_NAME
/
rem
rem Now sub-partitioned Indexes (composite partitions)
rem
	SELECT /*+ RULE */ 'PROMPT Schema: '||OWNER||', Table: '||TABLE_NAME||
        ', Sub-Partition: '||SUBPARTITION_NAME||
        ', Index: '||i.INDEX_NAME linie,
	'ANALYZE INDEX '||f_c(INDEX_OWNER)||'.'||f_c(i.INDEX_NAME) linie,
        ' partition ('||f_c(SUBPARTITION_NAME)||') VALIDATE STRUCTURE;' linie,
	'INSERT INTO indsta1$tmp ' linie,
	'SELECT '||''''||OWNER||''''||','||''''||TABLE_NAME||''''||
             ', stat.*  ' linie,
	' FROM vindsta$tmp stat;' linie,
	'COMMIT;' linie
	FROM DBA_IND_SUBPARTITIONS p, DBA_INDEXES i
	WHERE i.owner = p.index_owner
        AND   i.index_name = p.index_name
        AND   INDEX_TYPE NOT IN ('BITMAP')
        AND   INDEX_OWNER NOT IN ('SYS','SYSTEM','WEBDB','OUTLN')
	AND   INDEX_OWNER LIKE NVL('&WELCHER_BENUTZER'||'%','%')
	ORDER BY INDEX_OWNER,TABLE_NAME,p.SUBPARTITION_NAME, i.INDEX_NAME
/
	SPOOL OFF
/*

	Validate all indexes
*/
	SET TERMOUT ON

@allind.tmp

rem $ set term/wid=132 
	SET LINES 113
	SET PAGES 45
	SET NEWPAGE 0
	SET FEEDBACK OFF
	SET ECHO OFF
	SET HEAD ON
	SET TERMOUT OFF
        SET PAUSE OFF
        SET TIMING OFF
	COLUMN OWNER FORMAT A30
	COLUMN TABLE_NAME FORMAT A30 WORD_WRAP HEADING "TABLE_NAME (PART_NAME)"
	COLUMN TABLESPACE_NAME FORMAT A30
	COLUMN INDEX_NAME FORMAT A30
	COLUMN BLOCKS FORMAT 9999999999
	SPOOL lsindsta.lis
	TTITLE "Tables without any Index"
	SELECT /*+ ALL_ROWS */ t.owner,
                t.table_name||decode(s.partition_name,null,null,
                                        ' ('||s.partition_name||')') table_name,
                s.tablespace_name,s.blocks
	FROM    dba_segments s, dba_tables t, indsta1$tmp i
	WHERE   s.owner = t.owner(+)
	AND     t.owner = i.owner(+)
	AND     t.owner LIKE NVL('&WELCHER_BENUTZER'||'%','%')
	AND     t.table_name = i.table_name(+)
        AND     t.iot_type IS NULL
	AND     t.table_name(+) = s.segment_name
	AND     i.owner IS NULL
	AND     t.owner  NOT IN  ('SYS','SYSTEM','WEBDB','OUTLN')
        AND     (t.owner,t.table_name) NOT IN  /* do not show tables with indexes */
           ( SELECT /*+ ALL_ROWS */ table_owner,table_name     /* in other schemas */
             FROM    dba_indexes
             WHERE   table_owner != owner
             AND     ( table_owner LIKE NVL('&WELCHER_BENUTZER'||'%','%')
             OR        owner LIKE NVL('&WELCHER_BENUTZER'||'%','%') ) )
        AND     (t.owner, t.table_name) NOT IN /* tables with only bitmap ind. */
           ( SELECT /*+ ALL_ROWS */ table_owner, table_name
             FROM   dba_indexes ii
             WHERE  t.owner = ii.owner
             AND    t.table_name = ii.table_name
             AND    ii.index_type = 'BITMAP' )
        AND     (t.owner, t.table_name) NOT IN /* table part. Indexes. */
           ( SELECT /*+ ALL_ROWS */ iiii.table_owner, iiii.table_name
             FROM   dba_part_indexes iii, dba_indexes iiii
             WHERE  t.owner = iii.owner
             AND    t.table_name = iii.table_name
             AND    iii.INDEX_NAME = iiii.INDEX_NAME
             AND    iii.OWNER = iiii.OWNER)
	ORDER BY t.owner,t.table_name, s.partition_name
/
	SET NEWPAGE 0
	COLUMN OWNER FORMAT A30 
	COLUMN TABLE_NAME FORMAT A30 WORD_WRAP HEADING "TABLE_NAME (PART_NAME)"
	COLUMN BLOCKS FORMAT 9999999
	TTITLE "Tables with indexes, but none is UNIQUE"
	SELECT /*+ RULE */  owner,
                 segment_name||decode(partition_name,null,null,
                                        ' ('||partition_name||')') table_name,
                 blocks
	FROM    dba_segments 
	WHERE   owner NOT IN ('SYS','SYSTEM','WEBDB','OUTLN')
	AND     owner LIKE NVL('&WELCHER_BENUTZER'||'%','%')
	AND     segment_type IN ('TABLE','TABLE PARTITION')
	MINUS
	SELECT /*+ RULE */ stat.owner,stat.table_name||decode(seg.partition_name,null,null,
                                        ' ('||seg.partition_name||')') table_name, seg.blocks
	FROM    dba_segments seg, dba_indexes ind, indsta1$tmp stat
	WHERE   stat.owner = seg.owner
	AND     stat.table_name = seg.segment_name
	AND     seg.owner = ind.owner
	AND     stat.table_name = ind.table_name
	AND     ind.uniqueness='UNIQUE'
	AND     stat.owner LIKE NVL('&WELCHER_BENUTZER'||'%','%') 
	MINUS
	SELECT /*+ RULE */  t.owner,
                segment_name||decode(s.partition_name,null,null,
                                        ' ('||s.partition_name||')') table_name,
                s.blocks
	FROM    dba_segments s, dba_tables t, indsta1$tmp i
	WHERE   s.owner = t.owner(+)
	AND     t.owner = i.owner(+)
	AND     t.owner LIKE NVL('&WELCHER_BENUTZER'||'%','%')
	AND     t.table_name = i.table_name(+)
	AND     t.table_name(+) = s.segment_name
	AND     i.owner IS NULL
	AND     t.owner  NOT IN  ('SYS','SYSTEM','WEBDB','OUTLN')
	ORDER BY 1,2
/
	SET NEWPAGE 0
	COLUMN OWNER FORMAT A20 TRUNC
	COLUMN INDEX_OWNER FORMAT A20 TRUNC
	COLUMN TABLE_NAME FORMAT A30 HEADING "TABLE_NAME"
	COLUMN TABLESPACE_NAME FORMAT A30 
	COLUMN BLOCKS FORMAT 99999999
	TTITLE "Indexes not owned by the same schema as the table "
	SELECT /*+ RULE */  owner index_owner,table_owner,table_name,index_name
	FROM    dba_indexes
	WHERE   table_owner != owner
	AND     ( table_owner LIKE NVL('&WELCHER_BENUTZER'||'%','%')
	OR        owner LIKE NVL('&WELCHER_BENUTZER'||'%','%') )
        AND     partitioned = 'NO'
       UNION
        SELECT /*+ RULE */  
                i.owner index_owner,i.table_owner,
                i.table_name,
                i.index_name||' ('||p.partition_name||')'
	FROM    dba_ind_partitions p, dba_indexes i
	WHERE   i.table_owner != i.owner
        AND     p.index_owner = i.owner
        AND     p.index_name = i.index_name
        AND     p.subpartition_count = 0
	AND     ( i.table_owner LIKE NVL('&WELCHER_BENUTZER'||'%','%')
	OR        i.owner LIKE NVL('&WELCHER_BENUTZER'||'%','%') )
       UNION
        SELECT /*+ RULE */  
                i.owner index_owner,i.table_owner,
                i.table_name,
                i.index_name||' ('||p.subpartition_name||')'
	FROM    dba_ind_subpartitions p, dba_indexes i
	WHERE   i.table_owner != i.owner
        AND     p.index_owner = i.owner
        AND     p.index_name = i.index_name
	AND     ( i.table_owner LIKE NVL('&WELCHER_BENUTZER'||'%','%')
	OR        i.owner LIKE NVL('&WELCHER_BENUTZER'||'%','%') )
	ORDER BY 1,2,3,4
/
	SET NEWPAGE 0
	COLUMN OWNER FORMAT A30
	COLUMN INDEX_NAME FORMAT A30 WORD_WRAP HEADING "INDEX_NAME (PART_NAME)"
	TTITLE  "Fragmented Indexes (Check storage clause)"
	SELECT /*+ RULE */  ind.owner,table_name,
                segment_name||decode(partition_name,null,null,
                                        ' ('||partition_name||')') index_name,
                blocks,extents
	FROM    dba_segments seg, dba_indexes ind
	WHERE   ind.owner = seg.owner
	AND     ind.index_name = seg.segment_name
	AND     segment_type IN ('INDEX','INDEX PARTITION','INDEX SUBPARTITION')
	AND     extents > 1
	AND     seg.owner NOT IN ('SYS','SYSTEM','WEBDB','OUTLN')
	AND     seg.owner LIKE NVL('&WELCHER_BENUTZER'||'%','%')
	ORDER BY owner, table_name, segment_name, partition_name
/
	SET NEWPAGE 0
	COLUMN OWNER FORMAT A16 TRUNC
	COLUMN TABLE_NAME FORMAT A30 
	COLUMN INDEX_NAME FORMAT A30
	COLUMN COLUMN_NAME FORMAT A30
	COLUMN COLUMN_POSITION FORMAT 99 HEADING POS
	TTITLE "Unique Indexes including NULLs"
	SELECT /*+ RULE */  ind.owner,ind.table_name,ind.index_name,
		col.column_name,icol.column_position
	FROM    dba_tab_columns col, dba_ind_columns icol, dba_indexes ind
	WHERE   ind.index_name = icol.index_name
	AND     col.column_name = icol.column_name
	AND     icol.table_owner = ind.table_owner
	AND     col.owner = ind.table_owner
	AND     ind.table_name = icol.table_name
	AND     ind.table_name = col.table_name
	AND     col.table_name = icol.table_name
	AND     ind.uniqueness = 'UNIQUE'
	AND     col.nullable = 'Y'
	AND     ind.table_owner NOT IN ('SYS','SYSTEM','WEBDB','OUTLN')
	AND     ind.table_owner LIKE NVL('&WELCHER_BENUTZER'||'%','%')
        AND     ind.partitioned = 'NO'
       UNION 
	SELECT /*+ RULE */  
                ind.owner,
                ind.table_name,
                ind.index_name||' ('||pind.partition_name||')',
		col.column_name,icol.column_position
	FROM    dba_tab_columns col, dba_ind_columns icol, dba_indexes ind, dba_ind_partitions pind
	WHERE   ind.index_name = icol.index_name
	AND     col.column_name = icol.column_name
	AND     icol.table_owner = ind.table_owner
        AND     pind.index_owner = ind.owner
        AND     pind.index_name = ind.index_name
	AND     col.owner = ind.table_owner
	AND     ind.table_name = icol.table_name
	AND     ind.table_name = col.table_name
	AND     col.table_name = icol.table_name
	AND     ind.uniqueness = 'UNIQUE'
	AND     col.nullable = 'Y'
	AND     ind.table_owner NOT IN ('SYS','SYSTEM','WEBDB','OUTLN')
	AND     ind.table_owner LIKE NVL('&WELCHER_BENUTZER'||'%','%')
        AND     pind.subpartition_count = 0
       UNION
	SELECT /*+ RULE */  
                ind.owner,
                ind.table_name,
                ind.index_name||' ('||pind.subpartition_name||')',
		col.column_name,icol.column_position
	FROM    dba_tab_columns col, dba_ind_columns icol, dba_indexes ind, dba_ind_subpartitions pind
	WHERE   ind.index_name = icol.index_name
	AND     col.column_name = icol.column_name
	AND     icol.table_owner = ind.table_owner
        AND     pind.index_owner = ind.owner
        AND     pind.index_name = ind.index_name
	AND     col.owner = ind.table_owner
	AND     ind.table_name = icol.table_name
	AND     ind.table_name = col.table_name
	AND     col.table_name = icol.table_name
	AND     ind.uniqueness = 'UNIQUE'
	AND     col.nullable = 'Y'
	AND     ind.table_owner NOT IN ('SYS','SYSTEM','WEBDB','OUTLN')
	AND     ind.table_owner LIKE NVL('&WELCHER_BENUTZER'||'%','%')
	ORDER BY 1,2,3,5
/
	SET NEWPAGE 0
	COLUMN OWNER FORMAT A10 TRUNC 
	COLUMN TABLE_NAME FORMAT A30
	COLUMN INDEX_NAME FORMAT A40 WORD_WRAP Heading "INDEX_NAME (PART_NAME)"
	COLUMN BLOCKS FORMAT 9999999
	COLUMN HEIGHT FORMAT 999 HEADING HEIGHT
	TTITLE "Indexes with HEIGHT > 4 (Rebuild)"
	SELECT /*+ RULE */  owner,table_name,
                name||decode(partition_name,null,null,
                                        ' ('||partition_name||')') index_name,
                blocks,HEIGHT
	FROM    indsta1$tmp
	WHERE   HEIGHT > 4
	ORDER BY owner,table_name,name,partition_name
/
	SET NEWPAGE 0
	COLUMN OWNER FORMAT A10 TRUNC 
	COLUMN TABLE_NAME FORMAT A30
	COLUMN INDEX_NAME FORMAT A27 WORD_WRAP Heading "INDEX_NAME (PART_NAME)"
	COLUMN BLOCKS FORMAT 9999999
	COLUMN DISTINCT_KEYS FORMAT 999999999 HEADING DIST_KEYS
	TTITLE "Indexes with a low cardinality (>25% hits in average)"
	SELECT /*+ RULE */  owner,table_name,
                name||decode(partition_name,null,null,
                                        ' ('||partition_name||')') index_name,
                blocks,lf_rows,distinct_keys,rows_per_key
	FROM    indsta1$tmp
	WHERE   lf_rows/DECODE(rows_per_key,0,1,rows_per_key) <=4
	AND     rows_per_key > 1    /* Unique Indexes nicht anzeigen */
	ORDER BY owner,table_name,name,partition_name
/
	SET NEWPAGE 0
	COLUMN OWNER FORMAT A18 TRUNC
	COLUMN TABLE_NAME FORMAT A30 
	COLUMN INDEX_NAME FORMAT A30 WORD_WRAP HEADING "INDEX_NAME (PART_NAME)"
	COLUMN BLOCKS FORMAT 999999999
	COLUMN LF_ROWS FORMAT 999999999 HEADING LF_ROWS
	COLUMN DEL_LF_ROWS FORMAT 999999999 HEADING DEL_ROWS
	TTITLE  "Indexes with over 10% deleted entries (reorganise)"
	SELECT /*+ RULE */  owner,table_name,
                name||decode(partition_name,null,null,
                                        ' ('||partition_name||')') index_name,
                blocks,lf_rows,del_lf_rows
	FROM    indsta1$tmp
	WHERE   del_lf_rows > 0
	AND     lf_rows/DECODE(del_lf_rows,0,1,del_lf_rows) <=10
	AND     owner LIKE NVL('&WELCHER_BENUTZER'||'%','%')
	ORDER BY owner,table_name
/
	SET NEWPAGE 0
	COLUMN OWNER FORMAT A18 TRUNC
	COLUMN TABLE_NAME FORMAT A30 WORD_WRAP HEADING "TABLE_NAME (PART_NAME)"
	COLUMN INDEX_NAME FORMAT A30 WORD_WRAP HEADING "INDEX_NAME (PART_NAME)"
	COLUMN TAB_BLOCKS FORMAT 9999999
	COLUMN IND_BLOCKS FORMAT 9999999
	COLUMN BLKS_GETS_PER_ACCESS FORMAT 9999999.9 HEADING B_G_P_A
	TTITLE "Indexes with a large BLK_GETS_PER_ACCESS ( >= 25% of table size)"
        SELECT /*+ RULE */  seg.owner,
                stat.table_name||decode(seg.partition_name,null,null,
                                ' ('||seg.partition_name||')')  table_name,
                stat.name||decode(stat.partition_name,null,null,
                                ' ('||stat.partition_name||')') index_name,
                seg.blocks tab_blocks,
                stat.blocks ind_blocks,
                stat.blks_gets_per_access
        FROM    dba_segments seg, indsta1$tmp stat
        WHERE   seg.owner = stat.owner
        AND     seg.segment_name = stat.table_name
        AND     nvl(seg.partition_name,'xxx') = nvl(stat.partition_name,'xxx')
        AND     stat.blocks/blks_gets_per_access <= 4
        AND     stat.blocks >= 20
        AND     stat.owner LIKE NVL('&WELCHER_BENUTZER'||'%','%')
        ORDER BY seg.owner, stat.table_name, seg.partition_name, stat.name
/

	SET NEWPAGE 0
	COLUMN OWNER FORMAT A30
	COLUMN TABLE_NAME FORMAT A30 
	COLUMN INDEX_NAME FORMAT A30 WORD_WRAP HEADING "INDEX_NAME (PART_NAME)"
	COLUMN BLOCKS FORMAT 9999999
	COLUMN PCT_USED FORMAT 99
	TTITLE "Indexes where allocated space is used less than 50% (poss. save space)"
	SELECT /*+ RULE */  owner,table_name,
                name||decode(partition_name,null,null,
                                        ' ('||partition_name||')') index_name,
                blocks,pct_used
	FROM    indsta1$tmp
	WHERE   pct_used <= 50
	AND     blocks > 10
	AND     owner LIKE NVL('&WELCHER_BENUTZER'||'%','%')
	ORDER BY owner,table_name,name
/
	SET NEWPAGE 0
	COLUMN INDEX_NAME FORMAT A30 TRUNC
	COLUMN TABLE_NAME FORMAT A30 TRUNC
	COLUMN TABLE_BLOCKS FORMAT 999999999
	COLUMN INDEX_BLOCKS FORMAT 999999999
	COLUMN OWNER FORMAT A25 TRUNC
	TTITLE  "Indexes larger than 50% of table size"
	COLUMN BLOCKS FORMAT 9999999
	SELECT /*+ RULE */  s1.owner,s1.segment_name table_name,s2.segment_name index_name,
		s1.blocks table_blocks,s2.blocks index_blocks
	FROM    dba_segments s1, dba_segments s2, dba_ind_columns ind
	WHERE   s1.owner = s2.owner
	AND     s1.segment_name = ind.table_name
	AND     s1.owner = ind.table_owner
	AND     s2.segment_name = ind.index_name
	AND     s2.owner = ind.index_owner
	AND     s2.segment_type = 'INDEX'
	AND     s1.segment_type = 'TABLE'
	AND     s1.owner NOT IN ('SYS','SYSTEM','WEBDB','OUTLN')
	AND     ind.column_position = 1
	AND     s1.blocks/s2.blocks <=2
	AND     s1.blocks>=20    /* ganz kleine Tabellen nicht betrachten */
	AND     s1.owner LIKE NVL('&WELCHER_BENUTZER'||'%','%')
       UNION
        SELECT /*+ RULE */  
                s1.owner,
                s1.segment_name||' ('||s1.partition_name||')' table_name,
                s2.segment_name||' ('||s2.partition_name||')' index_name,
		s1.blocks table_blocks,s2.blocks index_blocks
	FROM    dba_segments s1, dba_segments s2, dba_ind_columns ind, dba_part_indexes p, 
                dba_ind_partitions ip, dba_tab_partitions tp
	WHERE   s1.owner = s2.owner
	AND     s1.segment_name = ind.table_name
	AND     s1.owner = ind.table_owner
        AND     s2.segment_name = p.index_name
	AND     s2.partition_name = ip.partition_name
	AND     s2.owner = p.owner
        AND     ind.index_name = p.index_name
        AND     ind.index_name = ip.index_name
        AND     ind.index_owner = p.owner
        AND     ind.index_owner = ip.index_owner
        AND     tp.table_owner = s1.owner
        AND     tp.table_name = s1.segment_name
        AND     tp.partition_name = s1.partition_name
        AND     tp.partition_position = ip.partition_position
	AND     s2.segment_type = 'INDEX PARTITION'
	AND     s1.segment_type IN  ('TABLE','TABLE PARTITION')
	AND     s1.owner NOT IN ('SYS','SYSTEM','WEBDB','OUTLN')
	AND     ind.column_position = 1
	AND     s1.blocks/s2.blocks <=2 
	AND     s1.blocks>=20    /* ganz kleine Tabellen nicht betrachten */
	AND     s1.owner LIKE NVL('&WELCHER_BENUTZER'||'%','%')
      UNION
        SELECT /*+ RULE */  
                s1.owner,
                s1.segment_name||' ('||s1.partition_name||')' table_name,
                s2.segment_name||' ('||s2.partition_name||')' index_name,
		s1.blocks table_blocks,s2.blocks index_blocks
	FROM    dba_segments s1, dba_segments s2, dba_ind_columns ind, dba_part_indexes p, 
                dba_ind_subpartitions ip, dba_tab_subpartitions tp
	WHERE   s1.owner = s2.owner
	AND     s1.segment_name = ind.table_name
	AND     s1.owner = ind.table_owner
        AND     s2.segment_name = p.index_name
	AND     s2.partition_name = ip.subpartition_name
	AND     s2.owner = p.owner
        AND     ind.index_name = p.index_name
        AND     ind.index_name = ip.index_name
        AND     ind.index_owner = p.owner
        AND     ind.index_owner = ip.index_owner
        AND     tp.table_owner = s1.owner
        AND     tp.table_name = s1.segment_name
        AND     tp.subpartition_name = s1.partition_name
        AND     tp.subpartition_position = ip.subpartition_position
	AND     s2.segment_type = 'INDEX SUBPARTITION'
	AND     s1.segment_type =  'TABLE SUBPARTITION'
	AND     s1.owner NOT IN ('SYS','SYSTEM','WEBDB','OUTLN')
	AND     ind.column_position = 1
	AND     s1.blocks/s2.blocks <=2 
	AND     s1.blocks>=20    /* ganz kleine Tabellen nicht betrachten */
	AND     s1.owner LIKE NVL('&WELCHER_BENUTZER'||'%','%')
	ORDER BY 1,2,3
/
	SPOOL OFF

	UNDEFINE WELCHER_BENUTZER
	SET TERMOUT ON
	SET FEED ON
	CLEAR COLUMNS
	TTITLE OFF
	SET PAGES 24
	PROMPT lsindsta.lis can be printed now ... (Landscape: 113 X 45, min.)

@temp.tmp
REM Ende des Programmes
