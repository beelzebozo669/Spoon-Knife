rem -------------------------------------------------------------------------
rem        Trivadis AG, Baden/Basel/Bern/Lausanne/Mellingen/Z�rich
rem                     Frankfurt/Freiburg i.Br./M�nchen/Stuttgart
rem                     Switzerland/Germany Internet: http://www.trivadis.com
rem -------------------------------------------------------------------------
rem   $Header$
rem   **********************************************************************
rem   Group/Privileges.: DBA (SYS)
rem   Script-Name......: sslckwai.sql
rem   Developer........: Andri Kisseleff (ank) andri.kisseleff@trivadis.com
rem   Date.............: August 1993
rem   Version..........: Oracle9i - 2.0
rem   Usage............: Shows actual DML-Locks (incl. Table-Name)
rem                      WAIT = YES are users waiting for a lock
rem   Input parameters.:
rem   Output.......... : 
rem   Called by........:
rem   Remarks..........:
rem -----------------------------------------------------------------------
rem
rem $Log$
rem Revision 1.3  2002/09/09 16:56:24  far
rem 9.2 f�hig checked by ThJ
rem
rem Revision 1.2  2001/07/22 12:59:28  ank
rem - Load initial release Oracle9i 9.0.x
rem
rem
rem Changes:
rem DD.MM.YYYY Consultant Change
rem -----------------------------------------------------------------------
rem 21.09.1997 ank        Oracle8
rem 21.04.1999 AnK        OK for Oracle8i
rem 03.09.2002 ThJ        OK for Oracle9i R2
rem -----------------------------------------------------------------------
rem
rem
set logsource "dummy"
store set temp.tmp replace

	SET PAGES 24 LINES 80 FEED ON ECHO OFF TERMOUT ON HEAD ON
	COLUMN PROGRAM FORMAT A80 TRUNC
	COLUMN LOCKER FORMAT A10 TRUNC
	COLUMN T_OWNER FORMAT A10 TRUNC
	COLUMN OBJECT_NAME FORMAT A25 TRUNC
	COLUMN WAIT FORMAT A4
@@foenvtit "Actual DML-Locks (TM+TX)"
REM
	select  decode(L.REQUEST,0,'NO','YES') WAIT,
		S.OSUSER,
		S.PROCESS,
		S.USERNAME LOCKER,
		U.NAME T_OWNER,
		O.NAME OBJECT_NAME,
		'  '||S.PROGRAM PROGRAM
	from    V$LOCK L,
		USER$ U,
		OBJ$ O,
		V$SESSION S
	where   U.USER# = O.OWNER#
	and     S.SID = L.SID
	and     L.ID1 = O.OBJ#
	and     L.TYPE = 'TM'
	 union
	select  decode(L.REQUEST,0,'NO','YES') WAIT,
		S.OSUSER,
		S.PROCESS,
		S.USERNAME LOCKER,
		'-',
		'Record(s)',
		'  '||S.PROGRAM PROGRAM
	from    V$LOCK L,
		V$SESSION S
	where   S.SID = L.SID
	and     L.TYPE = 'TX'
	order by 7,5,1,2,6
/
ttitle off
col program clear
col locker clear
col t_owner clear
col object_name clear
col wait clear
@temp.tmp
