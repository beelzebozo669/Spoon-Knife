rem -------------------------------------------------------------------------
rem        Trivadis AG, Baden/Basel/Bern/Lausanne/Mellingen/Stuttgart/Z�rich
rem                     Switzerland/Germany Internet: http://www.trivadis.com
rem -------------------------------------------------------------------------
rem   Group/Privileges.: DBA
rem   Script-Name......: lslcksta.sql
rem   Developer........: Peter Jensch (pej) peter.jensch@trivadis.com
rem                      Stephan Borsodi (sbo) stephan.borsodi@trivadis.com
rem   Date.............: July 2002
rem   Version..........: Oracle9i - 1.0
rem   Usage............: Shows records from trivadis tables with information
rem                      from deadlock-problems
rem   Input parameters.:
rem   Output.......... : lslcksta.lis
rem   Called by........:
rem   Remarks..........: script cstrglck.sql must be run first as user sys
rem                      to collect records after ORA-00060
rem -----------------------------------------------------------------------
rem Changes:
rem DD.MM.YYYY Consultant Change
rem -----------------------------------------------------------------------
rem -----------------------------------------------------------------------
rem

SET LINESIZE 155
SET PAGESIZE 40
SET ECHO OFF PAUSE OFF
SET TRIMOUT OFF TRIMSPOOL ON

COLUMN TSTAMP NOPRINT
COLUMN LOCK_DATE          FORMAT A9  HEADING "Time|Stamp"
COLUMN OS_LOCKER          FORMAT A10 HEADING "OS usr Lck"
COLUMN LOCKER_SID_SERIAL# FORMAT A15 HEADING "sid,serial#|Locker"
COLUMN LOCKER_SQL         FORMAT A45 HEADING "Locker SQL in SGA" WRAP
COLUMN OS_WAITER          FORMAT A10 HEADING "OS usr Wai"
COLUMN WAITER_SID_SERIAL# FORMAT A15 HEADING "sid,serial#|Waiter"
COLUMN WAITER_SQL         FORMAT A45 HEADING "Waiter SQL in SGA" WRAP

BREAK ON LOCK_DATE

SET FEEDBACK OFF
@@foenvtit "Deadlock Report"

prompt Creating logfile ...
SPOOL lslcksta.lis

SELECT LOCK_DATE TSTAMP
     , TO_CHAR (LOCK_DATE, 'DD.MM.RR')|| CHR(10)|| TO_CHAR(LOCK_DATE, 'HH24:MI:SS') LOCK_DATE
     , OS_LOCKER
     , ''''||LOCKER_SID_SERIAL#||'''' LOCKER_SID_SERIAL#
     , LOCKER_SQL
     , OS_WAITER
     , ''''||WAITER_SID_SERIAL#||'''' WAITER_SID_SERIAL#
     , WAITER_SQL
FROM TVD_LOCK_INFO_1
ORDER BY TSTAMP
;
SPOOL OFF
SET TERMOUT ON FEEDBACK ON

prompt
prompt *** logfile lslcksta.lis to use ***
prompt
