rem ---------------------------------------------------------------------------
rem  Trivadis AG, Baden-D�ttwil/Basel/Bern/Lausanne/Z�rich
rem               D�sseldorf/Frankfurt/Freiburg i.Br./Hamburg/M�nchen/Stuttgart
rem               Wien
rem               Switzerland/Germany/Austria Internet: http://www.trivadis.com
rem ---------------------------------------------------------------------------
rem $Id: help.sql 95 2009-04-08 11:03:04Z gha $
rem ---------------------------------------------------------------------------
rem  Group/Privileges.: User
rem  Script Name......: help.sql
rem  Developer........: Christian Antognini (ChA)
rem  Date.............: 01.12.2008
rem  Version..........: Oracle9i
rem  Description......: Show short description of all scripts
rem  Usage............: 
rem  Input parameters.: 
rem  Output...........: 
rem  Called by........:
rem  Requirements.....: 
rem  Remarks..........: 
rem
rem ---------------------------------------------------------------------------
rem Changes:
rem DD.MM.YYYY Developer Change
rem ---------------------------------------------------------------------------
rem 01.12.2008 ChA       Created
rem ---------------------------------------------------------------------------

STORE SET temp.tmp REPLACE

SET LINESIZE 100 PAGESIZE 1000 VERIFY OFF RECSEP OFF

COLUMN name FORMAT A19 TRUNC
COLUMN description FORMAT A80 WORD_WRAP

ACCEPT search_string CHAR PROMPT "Search string: [%] "

SELECT name, description
FROM (
  SELECT 'cscmpdep.sql' AS name, 'Create objects used for dependency tracking' AS description FROM dual UNION ALL
  SELECT 'cssyn.sql' AS name, 'Create view TVD_SYNONYMS' AS description FROM dual UNION ALL
  SELECT 'csobjuse.sql' AS name, 'Create view TVD_OBJECT_USAGE to list all indexes with MONITORING USAGE enabled' AS description FROM dual UNION ALL
  SELECT 'cswhoami.sql' AS name, 'Create view WHOAMI and grant select privilege on it to public' AS description FROM dual UNION ALL
  SELECT 'edcmpdep.sql' AS name, 'Show and compile dependent objects that are invalid' AS description FROM dual UNION ALL
  SELECT 'foenvtit.sql' AS name, 'Formatting the titles for all scripts' AS description FROM dual UNION ALL
  SELECT 'fopauoff.sql' AS name, 'Set pause off' AS description FROM dual UNION ALL
  SELECT 'fopauon.sql' AS name, 'Set pause on for interactive scripts' AS description FROM dual UNION ALL
  SELECT 'help.sql' AS name, 'Show description of all scripts' AS description FROM dual UNION ALL
  SELECT 'ldkill.sql' AS name, 'Generate SQL and KSH scripts to kill all user sessions' AS description FROM dual UNION ALL
  SELECT 'lodblind.sql' AS name, 'List indexes which start with same column' AS description FROM dual UNION ALL
  SELECT 'lstsres.sql' AS name, 'Show the minimal size to which a datafile can be resized' AS description FROM dual UNION ALL
  SELECT 'o10sto97.xls' AS name, 'Space calculation for tables and indexes (Excel 97 or higher)' AS description FROM dual UNION ALL
  SELECT 'sdactsql.sql' AS name, 'Show SQL statements in execution' AS description FROM dual UNION ALL
  SELECT 'sdactusr.sql' AS name, 'Show currently logged in users' AS description FROM dual UNION ALL
  SELECT 'sddep.sql' AS name, 'Show dependent objects for a given object' AS description FROM dual UNION ALL
  SELECT 'sdfkoind.sql' AS name, 'Show unindexed foreign keys of any user' AS description FROM dual UNION ALL
  SELECT 'sdindprt.sql' AS name, 'Show tablespace and status of all (sub)partitions of a partitioned index' AS description FROM dual UNION ALL
  SELECT 'sdinvobj.sql' AS name, 'Show a database-wide overview of invalid objects' AS description FROM dual UNION ALL
  SELECT 'sdjob.sql' AS name, 'Show jobs scheduled with DBMS_JOB' AS description FROM dual UNION ALL
  SELECT 'sdobjsta.sql' AS name, 'Show a list of objects (incl. status) selected by owner, object name or status' AS description FROM dual UNION ALL
  SELECT 'sdpkfk.sql' AS name, 'Show all foreign keys of a given primary key or vice verca' AS description FROM dual UNION ALL
  SELECT 'sdpkux.sql' AS name, 'Shows unique and primary key constraint names which are different from the unique index names' AS description FROM dual UNION ALL
  SELECT 'sdsegts.sql' AS name, 'Show information about segments grouped by user or tablespace' AS description FROM dual UNION ALL
  SELECT 'sdsesrs.sql' AS name, 'Show mapping between sessions and undo segments' AS description FROM dual UNION ALL
  SELECT 'sdsyn.sql' AS name, 'Show information about synonyms' AS description FROM dual UNION ALL
  SELECT 'sdsynerr.sql' AS name, 'Show synonyms with an invalid reference' AS description FROM dual UNION ALL
  SELECT 'sdsyssta.sql' AS name, 'Show system-wide statistics since last instance startup ' AS description FROM dual UNION ALL
  SELECT 'sdtabind.sql' AS name, 'Show the indexes for given table(s) and given user(s)' AS description FROM dual UNION ALL
  SELECT 'sdtabprt.sql' AS name, 'Show type, tablespace and number of rows of all (sub)partitions of a partitioned table' AS description FROM dual UNION ALL
  SELECT 'sdts.sql' AS name, 'Show information about all tablespaces' AS description FROM dual UNION ALL
  SELECT 'soascii.sql' AS name, 'Show ASCII-coding list' AS description FROM dual UNION ALL
  SELECT 'sofkoind.sql' AS name, 'Show unindexed foreign keys of current user' AS description FROM dual UNION ALL
  SELECT 'somvtxt.sql' AS name, 'Show query associated with materialized view' AS description FROM dual UNION ALL
  SELECT 'soobjsrc.sql' AS name, 'Show the source code for a PL/SQL object' AS description FROM dual UNION ALL
  SELECT 'soobjsta.sql' AS name, 'Show a list of objects (incl. status) of the current user selected by object name or status' AS description FROM dual UNION ALL
  SELECT 'sooraerr.sql' AS name, 'Display error message for a given error code' AS description FROM dual UNION ALL
  SELECT 'soprv.sql' AS name, 'Show all privileges of the connected user' AS description FROM dual UNION ALL
  SELECT 'sotabfbi.sql' AS name, 'Show indexes for given table(s) with decoding FBI expressions' AS description FROM dual UNION ALL
  SELECT 'sotabind.sql' AS name, 'Show indexes for given table(s) without decoding FBI expressions' AS description FROM dual UNION ALL
  SELECT 'sousrinf.sql' AS name, 'Show information about the connected user' AS description FROM dual UNION ALL
  SELECT 'soxplmv.sql' AS name, 'Show materialized view''s capabilities' AS description FROM dual UNION ALL
  SELECT 'soxplpln.sql' AS name, 'Show an execution plan stored in the default plan table (PLAN_TABLE)' AS description FROM dual UNION ALL
  SELECT 'soxplrw.sql' AS name, 'Show either why a query failed to rewrite or which materialized view is used for the rewrite' AS description FROM dual UNION ALL
  SELECT 'ssasmdsk.sql' AS name, 'Show the ASM disks composing each ASM disk group' AS description FROM dual UNION ALL
  SELECT 'ssasmfil.sql' AS name, 'Show, for each database, the files stored in ASM' AS description FROM dual UNION ALL
  SELECT 'ssasmgrp.sql' AS name, 'Show available ASM disk groups' AS description FROM dual UNION ALL
  SELECT 'ssbufsta.sql' AS name, 'Show status of blocks in the buffer cache' AS description FROM dual UNION ALL
  SELECT 'ssinipar.sql' AS name, 'Show instance and session values of initialization parameters' AS description FROM dual UNION ALL
  SELECT 'ssinipard.sql' AS name, 'Show description of initialization parameter' AS description FROM dual UNION ALL
  SELECT 'sslckwa1.sql' AS name, 'Show users waiting for a lock and the SQL statement they are waiting for' AS description FROM dual UNION ALL
  SELECT 'sslckwai.sql' AS name, 'Show lock waits (holder and waiter are shown)' AS description FROM dual UNION ALL
  SELECT 'sslongop.sql' AS name, 'Show active long operations' AS description FROM dual UNION ALL
  SELECT 'ssprv.sql' AS name, 'Show all privileges of a given user' AS description FROM dual UNION ALL
  SELECT 'ssseqval.sql' AS name, 'Show the next sequence number of any sequence (cached or not); this is done without incrementing the sequence with nextval' AS description FROM dual UNION ALL
  SELECT 'usobjsta.sql' AS name, 'Compile invalid objects for one or several schemas' AS description FROM dual UNION ALL
  SELECT '' AS name, '' AS description FROM dual UNION ALL
  SELECT '' AS name, '' AS description FROM dual
) h
WHERE upper(name) LIKE upper('%&search_string%')
OR upper(description) LIKE upper('%&search_string%')
ORDER BY 1;

UNDEFINE search_string

@temp.tmp
