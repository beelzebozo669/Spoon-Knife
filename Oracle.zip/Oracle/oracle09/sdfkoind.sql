rem -------------------------------------------------------------------------
rem        Trivadis AG, Baden/Basel/Bern/Lausanne/Mellingen/Z�rich
rem                     Frankfurt/Freiburg i.Br./M�nchen/Stuttgart
rem                     Switzerland/Germany Internet: http://www.trivadis.com
rem -------------------------------------------------------------------------
rem   $Header$
rem   **********************************************************************
rem   Group/Privileges.: DBA
rem   Script-Name......: sdfkoind.sql
rem   Developer........: Peter Nuding (pen) pnuding@trivadis.com
rem   Date.............: 12.10.1998
rem   Version..........: Oracle 9i 2.0
rem   Usage............: Shows the foreign keys without appropiate index
rem   Input parameters.:
rem   Output.......... : 
rem   Called by........: 
rem   Remarks..........: DBA-Version
rem -----------------------------------------------------------------------
rem
rem $Log$
rem Revision 1.4  2002/09/09 16:56:24  far
rem 9.2 f�hig checked by ThJ
rem
rem Revision 1.3  2001/12/15 13:44:32  ank
rem - rewritten the main query by SvV for better performance
rem
rem Revision 1.2  2001/07/22 12:59:28  ank
rem - Load initial release Oracle9i 9.0.x
rem
rem
rem
rem Changes:
rem DD.MM.YYYY Consultant Change
rem -----------------------------------------------------------------------
rem 12.10.1998 AnK        Made DBA-Version for all owners based on PeN's sofkoind.sql
rem                       Title similar to foenvtit
rem                       Removed DECODE
rem 20.04.1999 AnK        OK for Oracle8i	
rem 10.12.2001 SvV        Change query for better performance (minus)
rem 02.09.2002 ThJ        OK for Oracle9i R2
rem -----------------------------------------------------------------------
rem
rem
SET echo off
SET verify off

COLUMN OWNER noprint new_value own
COLUMN TABLE_NAME format a24 wrap heading "Table Name"
COLUMN CONSTRAINT_NAME format a24 wrap heading "Constraint Name"
COLUMN CONSTRAINT_TYPE format a3 heading "Typ"
COLUMN COLUMN_NAME format a24 wrap heading "1. Column"
break ON OWNER skip page
store SET temp.tmp REPLACE
SET pages 80 pause ON pause "Hit <RETURN>..."
	COLUMN	TIME_RUNNING	NEW_VALUE TIME_RUNNING
	COLUMN 	GLOBAL_NAME 	NEW_VALUE GLOBAL_NAME
	SET ECHO OFF TERMOUT OFF PAUSE OFF
	SELECT 	TO_CHAR(open_time,'DD.MM.YYYY HH24:MI')||' - '|| 
		TO_CHAR(SYSDATE,'DD.MM.YYYY HH24:MI')||
                ' ('||TO_CHAR(ROUND((SYSDATE-OPEN_TIME)*24,1))||' h)'
                TIME_RUNNING
	FROM 	v$thread;
	SELECT 	global_name
	FROM 	global_name;
rem
	SET TERMOUT ON
	TTITLE  CENTER 'Unindexed Constraints owned by Const. Owner: ' own  SKIP 1 -
		CENTER ''GLOBAL_NAME'' SKIP 1 -
		CENTER ''TIME_RUNNING''  SKIP 2 
	COLUMN GLOBAL_NAME CLEAR
	COLUMN TIME_RUNNING CLEAR
PROMPT 
PROMPT Please enter owner name AND TABLE name. Wildcards allowed (DEFAULT: %)
PROMPT
PROMPT eg.:  SCOTT, S% OR %
PROMPT eg.:  EMP, E% OR %
PROMPT

ACCEPT vOwner prompt "Owner  <%>: " DEFAULT %
ACCEPT vTable prompt "Tables <%>: " DEFAULT %

SELECT OWNER, TABLE_NAME, COLUMN_NAME, CONSTRAINT_NAME 
  FROM DBA_CONS_COLUMNS c
  WHERE position=1 AND 
   (OWNER, TABLE_NAME, COLUMN_NAME) IN 
   ( SELECT c.OWNER, c.TABLE_NAME,cc.COLUMN_NAME
       FROM  DBA_CONSTRAINTS  c, DBA_CONS_COLUMNS cc
       WHERE c.CONSTRAINT_NAME = cc.CONSTRAINT_NAME
        AND  c.TABLE_NAME      = cc.TABLE_NAME
        AND  c.OWNER           = cc.OWNER
        AND  c.CONSTRAINT_TYPE = 'R'
        AND  cc.POSITION       = 1
        AND  c.OWNER           LIKE UPPER('&vOwner')
        AND  c.TABLE_NAME      LIKE UPPER('&vTable')
     MINUS
     SELECT table_owner, table_name, column_name
       FROM    DBA_IND_COLUMNS  
       WHERE COLUMN_POSITION = 1
        AND  TABLE_OWNER LIKE UPPER('&vOwner')
        AND  TABLE_NAME  LIKE UPPER('&vTable')
   )
  ORDER BY OWNER, TABLE_NAME, CONSTRAINT_NAME;

ttitle off
SET pause off
COLUMN TABLE_NAME clear
COLUMN CONSTRAINT_NAME clear
COLUMN CONSTRAINT_TYPE clear
COLUMN COLUMN_NAME clear
clear breaks
@temp.tmp


