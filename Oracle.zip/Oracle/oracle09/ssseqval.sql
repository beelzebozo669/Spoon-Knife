rem -------------------------------------------------------------------------
rem        Trivadis AG, Baden/Basel/Bern/Lausanne/Mellingen/Z�rich
rem                     Frankfurt/Freiburg i.Br./M�nchen/Stuttgart
rem                     Switzerland/Germany Internet: http://www.trivadis.com
rem -------------------------------------------------------------------------
rem   $Header$
rem   **********************************************************************
rem   Group/Privileges.: SYS
rem   Script-Name......: ssseqval.sql
rem   Developer........: Andri Kisseleff (ank) andri.kisseleff@trivadis.com
rem   Date.............: 04.1997
rem   Version..........: Oracle9i - 1.0
rem   Usage............: Shows next sequence number of any sequence (cached or not)
rem			 This without incrementing the sequence with nextval
rem   Input parameters.:
rem   Output.......... :
rem   Called by........:
rem   Remarks..........:
rem -----------------------------------------------------------------------
rem
rem $Log$
rem Revision 1.3  2002/09/09 16:56:24  far
rem 9.2 f�hig checked by ThJ
rem
rem Revision 1.2  2001/07/22 12:59:28  ank
rem - Load initial release Oracle9i 9.0.x
rem
rem
rem
rem Changes:
rem DD.MM.YYYY Consultant Change
rem -----------------------------------------------------------------------
rem 18.06.1996 ank        title and new header
rem 02.08.1997 ank 	  Oracle8
rem 21.04.1999 AnK        OK for Oracle8i
rem 04.08.2002 ThJ        OK for Oracle9i R2
rem -----------------------------------------------------------------------
rem
set verify off
rem
accept sequence_owner char prompt "Sequence Owner <%> : " default %
accept sequence_name char prompt "Sequence Name  <%> : " default %
col sequence_owner format a20 trunc
col sequence_name format a25
select sequence_owner, sequence_name, next_seq, cache 
from (select sequence_owner, sequence_name, 
       nextvalue next_seq, 'in cache' cache
      from v$_sequences
      where nextvalue is not null
       union
      select sequence_owner, sequence_name, 
       highwater next_seq, 'created NOCACHE' cache
      from v$_sequences
      where nextvalue is null
       union
      select sequence_owner, sequence_name, 
       last_number next_seq, 'not in cache' cache
      from dba_sequences s
      where not exists (select  sequence_owner, sequence_name
                        from v$_sequences v
                        where v.sequence_name = s.sequence_name
                        and   v.sequence_owner = s.sequence_owner))
where   sequence_owner like upper('&sequence_owner')
and     sequence_name like upper('&sequence_name')
order by sequence_owner, sequence_name
/
undefine sequence_owner
undefine sequence_name
col sequence_owner clear
col sequence_name clear
set verify on

