rem -------------------------------------------------------------------------
rem        Trivadis AG, Baden/Basel/Bern/Lausanne/Mellingen/Z�rich
rem                     Frankfurt/Freiburg i.Br./M�nchen/Stuttgart
rem                     Switzerland/Germany Internet: http://www.trivadis.com
rem -------------------------------------------------------------------------
rem   $Header$
rem   **********************************************************************
rem   Group/Privileges.: DBA
rem   Script-Name......: sdactusr.sql
rem   Developer........: Urs Meier (urm) urs.meier@trivadis.com
rem   Date.............: Feb. 1995
rem   Version..........: Oracle9i - 2.0
rem   Usage............: Shows PIDs and server type of connected sessions
rem   Input parameters.:
rem   Output.......... :
rem   Called by........:
rem   Remarks..........:
rem -----------------------------------------------------------------------
rem
rem $Log$
rem Revision 1.4  2002/08/30 13:16:09  far
rem getestet/angepasst f�r 9.2
rem
rem Revision 1.3  2002/05/12 09:46:57  far
rem changed call of temp.tmp
rem
rem Revision 1.2  2001/07/22 12:59:28  ank
rem - Load initial release Oracle9i 9.0.x
rem
rem
rem
rem Changes:
rem DD.MM.YYYY Consultant Change
rem -----------------------------------------------------------------------
rem 02.08.1997 AnK        Oracle8 + changed decode for "machine" (SNP?)
rem 20.04.1999 AnK        OK for Oracle8i. Addes SERIAL#. 
rem                       Changed DECODE Username
rem 17.08.2000 urm        Idle Time in minutes    
rem 05.05.2002 FaR        Changed call of temp.tmp from @@ to @
rem 08.27.2002 ChA        OK for Oracle9i R2
rem -----------------------------------------------------------------------
rem
set logsource "dummy"
store set temp.tmp replace
set lines 130
col users format a20 trunc
col machine format a20 trunc
col program format a20 trunc
col idle_min format 9999 head "idle|min"
@@foenvtit "Currently connected sessions"
@@fopauon
SELECT
        replace(p.username,chr(0))||
          DECODE(s.username,NULL,NULL,' as '||s.username) users,
        nvl(s.machine,'Batch/Win 16/SNP?') machine,
        s.sid, s.serial#,
        p.spid,
        s.server,
        round(s.last_call_et/60) idle_min
FROM	v$session s,
        v$process p
WHERE	s.paddr = p.addr
AND     type != 'BACKGROUND'
AND     p.username is not null /* PSEUDO-Server, probably killed */
ORDER BY 1
/
col users clear
col machine clear
col program clear
ttitle off
@@fopauoff
@temp.tmp
