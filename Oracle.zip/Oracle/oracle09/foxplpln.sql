rem -------------------------------------------------------------------------
rem        Trivadis AG, Baden/Basel/Bern/Lausanne/Mellingen/Z�rich
rem                     Frankfurt/Freiburg i.Br./M�nchen/Stuttgart
rem                     Switzerland/Germany Internet: http://www.trivadis.com
rem -------------------------------------------------------------------------
rem   $Header$
rem   **********************************************************************
rem
rem   Group/Privileges.: Development
rem   Script-Name......: foxplpln.sql
rem   Developer........: Urs Meier (urm) urs.meier@trivadis.com
rem   Date.............: 30.12.1996
rem   Version..........: Oracle9i - 1.0
rem   Usage............: Re-Format Output for AutoTrace.
rem                      Better than original ! Truncates lines
rem                      Useful, when some other script sent a CLEAR COLUMN
rem                      command.
rem   Input parameters.:
rem   Output.......... : 
rem   Called by........:
rem   Remarks..........:
rem -----------------------------------------------------------------------
rem
rem $Log$
rem Revision 1.2  2002/08/30 13:16:09  far
rem getestet/angepasst f�r 9.2
rem
rem Revision 1.1  2001/07/23 05:34:33  ank
rem - Initial Release Oracle9i (9.0.x).
rem
rem
rem
rem Changes:
rem DD.MM.YYYY Consultant Change
rem -----------------------------------------------------------------------
rem 05.04.1997 urs.meier  rename
rem 20.04.1999 AnK        OK for Oracle8i  
rem 08.27.2002 ChA        OK for Oracle9i R2
rem -----------------------------------------------------------------------
rem
rem
show linesize
ACCEPT ls CHAR PROMPT "Enter column length for execution plan [60]: " Default 60
column id_plus_exp 		format 990 heading i		NOPRINT
column parent_id_plus_exp 	format 990 heading p	NOPRINT
column plan_plus_exp 		format a&ls 			TRUNC
column object_node_plus_exp 	format a8
column other_tag_plus_exp 	format a29
column other_plus_exp 		format a44

