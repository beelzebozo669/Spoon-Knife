rem -------------------------------------------------------------------------
rem        Trivadis AG, Baden/Basel/Bern/Lausanne/Mellingen/Z�rich
rem                     Frankfurt/Freiburg i.Br./M�nchen/Stuttgart
rem                     Switzerland/Germany Internet: http://www.trivadis.com
rem -------------------------------------------------------------------------
rem   $Header$
rem   **********************************************************************
rem   Group/Privileges.: DBA
rem   Script-Name......: sdcchrat.sql
rem   Developer........: Andri Kisseleff (ank) andri.kisseleff@trivadis.com
rem   Date.............: 07.1993
rem   Version..........: Oracle9i - 2.0
rem   Usage............: Shows the buffer cache hit rate of the instance
rem   Input parameters.:
rem   Output.......... : 
rem   Called by........:
rem   Remarks..........:
rem -----------------------------------------------------------------------
rem
rem $Log$
rem Revision 1.4  2003/08/12 16:35:57  ank
rem - Correct calculation (Yann Neuhaus)
rem
rem Revision 1.3  2002/08/30 13:16:09  far
rem getestet/angepasst f�r 9.2
rem
rem Revision 1.2  2001/07/22 12:59:28  ank
rem - Load initial release Oracle9i 9.0.x
rem
rem
rem
rem Changes:
rem -----------------------------------------------------------------------
rem DD.MM.YYYY Consultant Change
rem 18.06.1996 ank	  title and new header
rem 20.04.1999 AnK        OK for Oracle8i
rem 08.27.2002 MaW        OK for Oracle9i R2
rem -----------------------------------------------------------------------
rem
rem
rem
@@foenvtit "DB-Buffer Cache hit rate"
	SET FEEDBACK 0 PAGES 24 NEWPAGE 0
	COLUMN name   FORMAT a31
	COLUMN value  FORMAT 99.99
rem


	SELECT 'DB-Buffer cache hit rate in % : ' Name,
		(1-(c.value-d.value)/(a.value+b.value))*100 Value
	FROM   	v$sysstat a, v$sysstat b, v$sysstat c,v$sysstat d
	WHERE   a.name = 'db block gets'
	AND    	b.name = 'consistent gets'
	AND    	c.name = 'physical reads'
	AND    	d.name = 'physical reads direct'
/
	TTITLE off
	SET FEEDBACK ON
	COLUMN name clear
	COLUMN value clear
	

