rem -------------------------------------------------------------------------
rem        Trivadis AG, Baden/Basel/Bern/Lausanne/Mellingen/Z�rich
rem                     Frankfurt/Freiburg i.Br./M�nchen/Stuttgart
rem                     Switzerland/Germany Internet: http://www.trivadis.com
rem -------------------------------------------------------------------------
rem   $Header$
rem   **********************************************************************
rem   Group/Privileges.: Utilities
rem   Script-Name......: ssspsta.sql
rem   Developer........: Urs Meier (urm) urs.meier@trivadis.com
rem   Date.............: 30.09.1994
rem   Version..........: Oracle9i - 2.0
rem   Usage............: Shows statistics for shared pool
rem   Input parameters.:
rem   Output.......... : 
rem   Called by........:
rem   Remarks..........:
rem -----------------------------------------------------------------------
rem
rem $Log$
rem Revision 1.3  2002/08/30 13:16:09  far
rem getestet/angepasst f�r 9.2
rem
rem Revision 1.2  2001/07/22 12:59:28  ank
rem - Load initial release Oracle9i 9.0.x
rem
rem
rem
rem Changes:
rem DD.MM.YYYY Consultant Change
rem -----------------------------------------------------------------------
rem 25.09.1995 urs.meier  Added v$shared_pool_reserved
rem 05.04.1995 urs.meier  rename
rem 19.06.1997 AnK        added  "R-" Decodes for reserved Pool
rem 02.08.1997 AnK        Oracle8
rem 21.04.1999 AnK        OK for Oracle8i
rem 27.08.2002 MaW        OK for Oracle9i R2
rem -----------------------------------------------------------------------
rem
rem

rem
@@foenvtit "Shared pool statistics"
clear	columns -
	breaks -
	computes 

set     pagesize 24 -
	verify off -
        heading on -
        echo off -
        termout on -
        newpage 0
@@fopauon
COLUMN text 		FORMAT A35
COLUMN sum	 	FORMAT 999,999,999	HEADING 'Sum' 
COLUMN max		FORMAT 999,999,999	HEADING 'Max'
COLUMN cou 		FORMAT 999,999,999	HEADING 'Count'
SELECT DECODE(ksmchcls,
                       'R-recr',    'Res. Pool: Recreatable, flushable',
                       'R-freea',   'Res. Pool: Used, not flushable',
                       'R-free',    'Res. Pool: Free',
                       'R-perm',    'Res. Pool: Permanent',
                       'recr',    'Norm. Pool: Recreatable, flushable',
                       'freeabl', 'Norm. Pool: Used, not flushable',
                       'free',    'Norm. Pool: Free',
                       'perm',    'Norm. Pool: Permanent',
                                  ksmchcls) text ,
       SUM(ksmchsiz) sum, 
	MAX(ksmchsiz) max, 
	COUNT(*) cou
  FROM sys.x$ksmsp
 GROUP BY ksmchcls;


COLUMN kghlufsh HEADING "Flushes"
COLUMN kghluops HEADING "Operations"
COLUMN kghlurcr HEADING "Recurrent Pieces"
COLUMN kghlutrn HEADING "Transient Pieces"

SELECT kghlufsh,kghluops,kghlurcr,kghlutrn 
  FROM sys.x$kghlu;


COLUMN ksmlrnum HEADING "Flushed|SP-Pieces" FORMAT 999,990
COLUMN ksmlrcom HEADING "Comment" 
COLUMN ksmlrhon HEADING "Command"
COLUMN ksmlrsiz HEADING "Size" 
 
SELECT ksmlrhon,ksmlrcom,ksmlrsiz,ksmlrnum
  FROM sys.x$ksmlru;


COLUMN request_failures 	Heading 'Nbr.4031-Errors'
COLUMN last_failure_size	Heading 'Chunk Bytes (last fail.)'
COLUMN last_aborted_size	Heading 'Aborted Alloc. before 4031'
SELECT requests,
       request_failures,
       last_failure_size,
       last_aborted_size
  FROM v$shared_pool_reserved;
set pages 24
ttitle off
@@fopauoff
