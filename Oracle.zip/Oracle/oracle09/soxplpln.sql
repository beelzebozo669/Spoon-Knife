rem -------------------------------------------------------------------------
rem        Trivadis AG, Baden/Basel/Bern/Lausanne/Mellingen/Z�rich
rem                     Frankfurt/Freiburg i.Br./M�nchen/Stuttgart
rem                     Switzerland/Germany Internet: http://www.trivadis.com
rem -------------------------------------------------------------------------
rem   $Header$
rem   **********************************************************************
rem   Group/Privileges.: Owner (Utilities)
rem   Script-Name......: soxplpln.sql
rem   Developer........: Urs Meier (urm) urs.meier@trivadis.com
rem   Date.............: 
rem   Version..........: Oracle9i - 2.0
rem   Usage............: 
rem   Input parameters.:
rem   Output.......... : 
rem   Called by........:
rem   Remarks..........: Plan table must exist.
rem			 Normally created by utlxplan.sql
rem -----------------------------------------------------------------------
rem
rem $Log$
rem Revision 1.4  2002/09/09 18:00:03  far
rem added commit and rollback by ChA
rem
rem Revision 1.2  2001/07/22 12:59:28  ank
rem - Load initial release Oracle9i 9.0.x
rem
rem
rem Changes:
rem DD.MM.YYYY Consultant Change
rem -----------------------------------------------------------------------
rem 05.04.1997 urs.meier  rename
rem 24.10.1997 AnK        Oracle8 (Partitons, etc.)
rem 21.04.1999 AnK        OK for Oracle8i
rem 20.03.2001 ChA        Added display for advanced features (partitioning,
rem                       parallel processing, star transformation and 
rem                       remote execution)
rem 28.08.2002 ChA        Added transaction management to support forced PDML
rem -----------------------------------------------------------------------
rem
rem

clear breaks computes columns
break on report skip 1
rem set recsep off null '' pages 0 newpage 0 verify off feed on echo off 
rem set pause off
rem set verify off
rem set echo off
set recsep off 
set null '' 
set pagesize 0 
set verify off 
set feedback off
set echo off 
set pause off
set scan on
set long 1000

SELECT NULL 
FROM   DUAL 
WHERE  DUMMY = '&&STATEMENT_ID';

SELECT LPAD(' ',2*(LEVEL-1))||OPERATION||
       CASE
         WHEN OTHER IS NOT NULL OR OTHER_TAG IS NOT NULL OR OBJECT_NODE IS NOT NULL
         THEN ' *'||ID||'* ' 
       END||
       DECODE(OPTIONS,NULL,'','('||OPTIONS||')')||
       DECODE(OBJECT_NAME,NULL,'',' OF '''||OBJECT_NAME||
       DECODE(PARTITION_START,NULL,'',' (PSTART='||SUBSTR(PARTITION_START,1,3)||
       DECODE(PARTITION_STOP,NULL,'',' PSTOP='||SUBSTR(PARTITION_STOP,1,3)||')'))||'''')||
       DECODE(OBJECT_TYPE,NULL,'',' ('||OBJECT_TYPE||')')||
       DECODE(ID,0,DECODE(OPTIMIZER,NULL,'',' Optimizer='||OPTIMIZER))||
       DECODE(COST,NULL,'',' (Cost='||COST||
       DECODE(CARDINALITY,NULL,'',' Card='||CARDINALITY)||
       DECODE(BYTES,NULL,'',' Bytes='||BYTES)||')') "Execution plan"
FROM   PLAN_TABLE
WHERE  NVL(STATEMENT_ID,0) = NVL('&&STATEMENT_ID',0)
CONNECT BY PRIOR ID = PARENT_ID AND NVL(STATEMENT_ID,0) = NVL('&&STATEMENT_ID',0)
START WITH ID = 0 AND NVL(STATEMENT_ID,0) = NVL('&&STATEMENT_ID',0)
ORDER BY ID;

break on row skip 1
col operation format a5
col description format a30
col database_link format a43
col statement format a74

SELECT '*'||ID||'*' operation,
       OTHER_TAG description,
       OBJECT_NODE database_link,
       OTHER statement
FROM   PLAN_TABLE
WHERE  NVL(STATEMENT_ID,0) = NVL('&&STATEMENT_ID',0)
AND    (OTHER IS NOT NULL OR OTHER_TAG IS NOT NULL OR OBJECT_NODE IS NOT NULL)
ORDER BY ID;

set feedback on

COMMIT;

DELETE FROM PLAN_TABLE
WHERE NVL(STATEMENT_ID,0)= NVL('&&STATEMENT_ID',0)
AND SUBSTR(UPPER('&DELETE_Y_N'),1,1) IN ('Y','J');

COMMIT;

undefine statement_id
set pagesize 24
set verify on
set long 80
clear columns breaks computes
