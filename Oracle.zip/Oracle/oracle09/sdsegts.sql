rem -------------------------------------------------------------------------
rem        Trivadis AG, Baden/Basel/Bern/Lausanne/Mellingen/Z�rich
rem                     Frankfurt/Freiburg i.Br./M�nchen/Stuttgart
rem                     Switzerland/Germany Internet: http://www.trivadis.com
rem -------------------------------------------------------------------------
rem   $Header$
rem   **********************************************************************
rem   Group/Privileges.:  DBA
rem   Script-Name......:  sdsegts.sql
rem   Developer........:  Ingo Frost ingo.frost@trivadis.com
rem   Date.............:  01.08.2001
rem   Version..........:  Oracle9i - 2.0
rem   Usage............:  Display Segment Information per User or per TS 
rem   Input parameters.:
rem   Output.......... :
rem   Called by........:
rem   Remarks..........:
rem
rem   History: 
rem 
rem   $Log$
rem   Revision 1.2  2002/09/09 16:56:24  far
rem   9.2 f�hig checked by ThJ
rem
rem   Revision 1.1  2001/08/20 07:10:52  ank
rem   - Initial Load into CVS
rem
rem
rem Changes:
rem DD.MM.YYYY Consultant Change
rem -----------------------------------------------------------------------
rem 03.09.2002 ThJ        OK for Oracle9i R2
rem -----------------------------------------------------------------------
rem
rem
set echo off
set verify off
set logsource "Dummy"
store set temp.tmp replace
clear   columns -
        breaks -
        computes
set pagesize 24 linesize 130

PROMPT
PROMPT Please enter Username and/or Tablespace , wildcards allowed
PROMPT
PROMPT eg.: SCOTT, S% or %
PROMPT eg.: IDX, DATA% or %
PROMPT
accept user_name char prompt "User Name <%> : " default "%"
accept ts_name char prompt "Tablespace <%>: " default "%"
PROMPT
accept v_type char prompt "Output per Tablespace or per User (T/<U>) :" default "U"

col v_sel_col noprint new_value v_sel_col
col v_text noprint new_value v_text

set termout off
select  decode('&v_type','U','owner','u','owner','tablespace_name') v_sel_col,
        decode('&v_type','U','User','u','User', 'Tablespace') v_text
from dual;
set termout on

@@foenvtit "Segment statistics per &v_text"

col owner format a20
col tablespace_name  format a20
col TC_COUNT heading "Tab/Clu|Count" format 999G999
col TC_SUM heading "Tab/Clu|Alloc" format 999G990D0
col I_COUNT heading "Index|Count" format 999G999
col I_SUM heading "Index|Alloc" format 999G990D9
col PT_COUNT heading "Part-Tab|Count" format 999G999
col PT_SUM heading "Part-Tab|Alloc" format 999G990D0
col PI_COUNT heading "Part-Idx|Count" format 999G999
col PI_SUM heading "Part-Idx|Alloc" format 999G990D0
col L_COUNT heading "Lob|Count" format 999G999
col L_SUM heading "Lob|Alloc" format 999G990D0


break on report
compute sum label "Total:" of L_Sum on report 
compute sum label "Total:" of I_Sum on report 
compute sum label "Total:" of TC_Sum on report 
compute sum label "Total:" of PT_Sum on report 
compute sum label "Total:" of PI_Sum on report 
compute sum label "Total:" of L_count on report 
compute sum label "Total:" of I_count on report 
compute sum label "Total:" of TC_count on report 
compute sum label "Total:" of PT_count on report 
compute sum label "Total:" of PI_count on report 

select 	&v_sel_col , 
	count(decode(segment_type, 'TABLE','x','CLUSTER','x', null) ) TC_Count,
	round(sum(decode(segment_type, 'TABLE',bytes,'CLUSTER',bytes, 0) )/1024/1024,1) TC_Sum,
	count(decode(segment_type, 'INDEX','x', null) ) I_Count,
	round(sum(decode(segment_type, 'INDEX',bytes, 0) )/1024/1024,1) I_Sum,
        count(decode(segment_type, 'TABLE PARTITION','x','TABLE SUBPARTITION','x', null) ) PT_Count,
        round(sum(decode(segment_type, 'TABLE PARTITION',bytes,'TABLE SUBPARTITION',bytes, 0) )/1024/1024,1) PT_Sum,
        count(decode(segment_type, 'INDEX PARTITION','x','INDEX SUBPARTITION','x', null) ) PI_Count,
        round(sum(decode(segment_type, 'INDEX PARTITION',bytes,'INDEX SUBPARTITION',bytes, 0) )/1024/1024,1) PI_Sum,
	count(decode(segment_type, 'LOBSEGMENT','x','LOBINDEX','x', null) ) L_Count,
	round(sum(decode(segment_type, 'LOBSEGMENT',bytes,'LOBINDEX',bytes, 0) )/1024/1024,1) L_Sum
from dba_segments
where SEGMENT_TYPE in ('TABLE','CLUSTER','INDEX','LOGSEGMENT','LOBINDEX', 'TABLE SUBPARTITION', 'TABLE PARTITION', 'INDEX PARTITION' , 'INDEX SUBPARTITION')
and owner like upper('&&user_Name')
and tablespace_name like upper('&&ts_name')
group by &v_sel_col;

col owner clear
col tablespace_name clear
col TC_COUNT clear
col TC_SUM clear
col I_COUNT clear
col I_SUM clear
col L_COUNT clear
col L_SUM clear
ttitle off
prompt  Only Users and Tablespaces with segments are listed 
prompt (Report Parameter: User_Name = &&user_name , Tablespace = &&ts_name )
prompt
prompt  Tab/Clu  : Tables and Clusters
prompt  LOB      : Lob-Segments and Lob-Indexes
prompt  Part-Tab : Partitioned Tables , Sub Partitioned Tables
prompt  Part-Idx : Partitioned Indexes , Sub Partitioned Indexes
prompt  Count    : Number of Segments in the Tablespace
prompt  Alloc    : Space allocated by these segments in Mb
prompt
undefine user_name
undefine ts_name
undefine v_type
@temp.tmp
