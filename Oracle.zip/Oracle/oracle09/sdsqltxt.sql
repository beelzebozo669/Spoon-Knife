rem -------------------------------------------------------------------------
rem        Trivadis AG, Baden/Basel/Bern/Lausanne/Mellingen/Z�rich
rem                     Frankfurt/Freiburg i.Br./M�nchen/Stuttgart
rem                     Switzerland/Germany Internet: http://www.trivadis.com
rem -------------------------------------------------------------------------
rem   $Header$
rem   **********************************************************************
rem   Group/Privileges.: DBA
rem   Script-Name......: sdsqltxt.sql
rem   Developer........: Urs Meier (urm) urs.meier@trivadis.com
rem   Date.............: 1995
rem   Version..........: Oracle9i - 2.0
rem   Usage............: Show SQL-Comands of connected sessions and
rem                      number of executions
rem   Input parameters.:
rem   Output.......... : 
rem   Called by........:
rem   Remarks..........:
rem -----------------------------------------------------------------------
rem  
rem $Log$
rem Revision 1.3  2002/09/09 16:56:24  far
rem 9.2 f�hig checked by ThJ
rem
rem Revision 1.2  2001/07/22 12:59:28  ank
rem - Load initial release Oracle9i 9.0.x
rem
rem
rem Changes:
rem DD.MM.YYYY Consultant Change
rem -----------------------------------------------------------------------
rem 05.04.1997 urs.meier  rename
rem 02.08.1997 AnK        Oracle8
rem 21.04.1999 AnK        OK for Oracle8i 
rem 16.06.2000 UrM        Shows only "users executing > 0" (actually running SQL-Commands)
rem 03.09.2002 ThJ        OK for Oracle9i R2
rem -----------------------------------------------------------------------
rem
rem
REM	Last SQL-Commands of connected sessions and
REM	number of executions
REM
@@foenvtit "SQL of connected sessions (currently executing)"
@@fopauon
column sql_text format a62 word_wrap
column username format a10
column executions format 99999 heading "Exec."
break on sql_text skip 1

select NVL(username,type) username,sql_text,executions
  from v$session, v$sqlarea
 where sql_hash_value = hash_value
 and users_executing > 0
 order by sql_text;
clear breaks
column sql_text clear
column username clear
column executions clear
ttitle off
@@fopauoff




