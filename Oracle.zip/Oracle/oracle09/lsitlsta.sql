rem -------------------------------------------------------------------------
rem        Trivadis AG, Baden/Basel/Bern/Lausanne/Mellingen/Z�rich
rem                     Frankfurt/Freiburg i.Br./M�nchen/Stuttgart
rem                     Switzerland/Germany Internet: http://www.trivadis.com
rem -------------------------------------------------------------------------
rem   $Header$
rem   **********************************************************************
rem   Group/Privileges.: SYS
rem   Script-Name......: lsitlsta.sql
rem   Developer........: Andri Kisseleff (ank) andri.kisseleff@trivadis.com
rem   Date.............: Feb. 2003
rem   Version..........: Oracle9i 9.2 (does not run with 9.0.x)
rem   Usage............: Shows Number of ITL-Waits per table (Interested 
rem                      Transaction List). INITRANS and/or PCTFREE
rem                      for those tables is to small
rem                      (could also be that MAXTRANS is too small...)
rem   Input parameters.: 
rem   Output.......... : 
rem   Called by........:
rem   Remarks..........: STATISTICS_LEVEL must be set to TYPICAL or ALL
rem -----------------------------------------------------------------------
rem Changes:
rem
rem $Log$
rem Revision 1.1  2003/02/23 16:54:35  far
rem Added new script
rem
rem
rem 
@foenvtit "ITL-Waits per table (interested transaction list) (INITRANS to small)"
store set "dummy.tmp" replace
set pages 1000
col owner format a15 trunc
col object_name format a30 word_wrap
col value format 999,999,999 heading "NBR. ITL WAITS"
spool lsitlsta.lis
select owner, object_name||' '||subobject_name object_name, value
from v$segment_statistics
where statistic_name = 'ITL waits'
and value > 0
order by 3,1,2;
spool off
col owner clear
col object_name clear
col value clear
ttitle off
@dummy.tmp
prompt
prompt lsitlsta.lis has been spooled...
prompt
prompt Please note that v$segment_statistics is only updated at the
prompt moment the ITL-wait *is solved* (and not while the
prompt user is waiting for a free ITL-entry)
prompt

