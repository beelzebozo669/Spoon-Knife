rem -------------------------------------------------------------------------
rem        Trivadis AG, Baden/Basel/Bern/Lausanne/Mellingen/Z�rich
rem                     Frankfurt/Freiburg i.Br./M�nchen/Stuttgart
rem                     Switzerland/Germany Internet: http://www.trivadis.com
rem -------------------------------------------------------------------------
rem   $Header$
rem   **********************************************************************
rem   Group/Privileges.: DBA
rem   Script-Name......: cswhoami.sql
rem   Developer........: Urs Meier (urm)/Andri Kisseleff (ank) 
rem                      andri.kisseleff@trivadis.com
rem   Date.............: January 1995
rem   Version..........: Oracle9i - 2.0
rem   Usage............: Creates view whoami and grants select to public
rem                      Shows PID of foreground and shadow/Server-Process
rem                      as well as the server type (SHARED/DEDICATED)
rem   Input parameters.:
rem   Output.......... : 
rem   Called by........:
rem   Remarks..........: To be run while connected as SYS
rem -----------------------------------------------------------------------
rem
rem $Log$
rem Revision 1.4  2002/12/10 16:08:10  ank
rem - Added additional SID, as SYS did not show up correctly in 9.x
rem
rem Revision 1.2  2001/07/22 12:59:28  ank
rem - Load initial release Oracle9i 9.0.x
rem
rem
rem Changes:
rem DD.MM.YYYY Consultant Change
rem -----------------------------------------------------------------------
rem 05.04.1997 urs.meier  rename
rem 02.08.1997 ank        Oracle8
rem 20.04.1999 AnK        OK for Oracle8i 
rem 08.27.2002 ChA        OK for Oracle9i R2
rem 10.12.2002 AnK        Added (and sid in select sid from v$mystat)
rem                as the user SYS has always AUDSID=O (so SYS is shown
rem                as many times as he is connected, not only the current session
rem                OK for 9.0 and 9.2
rem -----------------------------------------------------------------------
rem
rem
rem
CREATE OR REPLACE VIEW whoami 
	(
 	who,
	frontend,
	backend,
	servertype
	)
AS SELECT
	substr(p.username||' as '||s.username||' at '||g.global_name,1,50),
	s.process,
	p.spid,
	s.server
FROM	v$session s,
        v$process p,
        global_name g
WHERE	s.paddr = p.addr
AND  	s.audsid = USERENV('sessionid')
and     s.sid in (select sid from v$mystat)
/
DROP PUBLIC SYNONYM whoami;
CREATE PUBLIC SYNONYM whoami FOR sys.whoami
/
GRANT SELECT ON whoami TO PUBLIC
/
SELECT * FROM whoami;
