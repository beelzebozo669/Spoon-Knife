rem -------------------------------------------------------------------------
rem        Trivadis AG, Baden/Basel/Bern/Lausanne/Mellingen/Z�rich
rem                     Frankfurt/Freiburg i.Br./M�nchen/Stuttgart
rem                     Switzerland/Germany Internet: http://www.trivadis.com
rem -------------------------------------------------------------------------
rem   $Header$
rem   **********************************************************************
rem   Group/Privileges.: DBA
rem   Script-Name......: sdindprt.sql
rem   Developer........: Marc Bosshard (mbo) marc.bosshard@trivadis.com
rem   Date.............: 01.2001
rem   Version..........: Oracle9i - 2.0
rem   Usage............: Shows tablespace,status of all
rem                      partitions/subpartitions of a partitioned index
rem   Input parameters.:
rem   Output.......... :
rem   Called by........:
rem   Remarks..........:
rem -----------------------------------------------------------------------
rem HISTORY:
rem
rem $Log$
rem Revision 1.4  2002/10/06 14:44:18  far
rem Tested for 9.2 by ThJ
rem
rem Revision 1.2  2001/07/22 12:59:28  ank
rem - Load initial release Oracle9i 9.0.x
rem
rem
rem
rem -----------------------------------------------------------------------
rem Changes:
rem DD.MM.YYYY Consultant Change
rem -----------------------------------------------------------------------
rem 18.09.2002 ThJ        Tested for Oracle9i R2 (incl. Composite Range-
rem                       List Partitioning)
rem -----------------------------------------------------------------------

set serveroutput on size 1000000;
set linesize 240 feedback off echo off verify off;
set pagesize 200

prompt
accept pIndex_Owner CHAR PROMPT 'INDEX OWNER: '
prompt
select rpad(index_name,30,'.') || ' ('||table_name||')' as "LIST OF PARTITIONED INDEX:" from dba_part_indexes
where owner= UPPER('&pIndex_Owner')
order by 1;
prompt
ACCEPT pIndex_Name CHAR PROMPT 'INDEX NAME: '
prompt

set timing on;
DECLARE
	CURSOR c_Partition IS 
		      SELECT part.index_owner owner,
                      	     part.index_name index_name,
                             part.partition_name partition_name,
                             part.tablespace_name tbs_partition,
                             decode(part.composite,'YES',subpart.subpartition_name,'NO') subpartition_name,
                             decode(part.composite,'YES',subpart.tablespace_name,'NO') tbs_subpartition,
                             decode(part.composite,'YES',subpart.status,part.status) status 
                        FROM dba_ind_partitions part,
                             dba_ind_subpartitions subpart,
                             dba_indexes ind
                        WHERE ind.index_name=part.index_name
                              AND subpart.index_name(+)=part.index_name
                              AND subpart.partition_name(+)=part.partition_name
                              AND ind.owner=part.index_owner
			      AND ind.owner=UPPER('&pIndex_Owner')
                              AND subpart.index_owner(+)=part.index_owner
	                      AND (ind.index_name = UPPER('&pIndex_Name') OR
			           ind.index_name = ('&pIndex_Name'));

 	v_Partition       c_Partition%ROWTYPE;
	v_CursorID        INTEGER	:=0;

BEGIN
-- H E A D E R 
	DBMS_OUTPUT.PUT_LINE('-------------------- ----------------------------- ----------------------------- ----------------------------- ----------------------------- ----------');
	DBMS_OUTPUT.PUT_LINE('INDEX                PARTITION                     TABLESPACE PARTITION          SUBPARTITION                  TABLESPACE SUBPARTITION       STATUS'); 
	DBMS_OUTPUT.PUT_LINE('-------------------- ----------------------------- ----------------------------- ----------------------------- ----------------------------- ----------');
	OPEN c_Partition();
	LOOP
-- K I N D   O F    P A R T I T I O N I N G
		FETCH c_Partition INTO v_Partition;
		IF (c_Partition%NOTFOUND) AND (c_Partition%ROWCOUNT = 0) THEN   -- Exit if no partitioned index
			DBMS_OUTPUT.PUT_LINE('NOT PARTITIONED');
			EXIT;
		END IF;
    		EXIT WHEN c_Partition%NOTFOUND; -- Exit at the end of select output
-- O U T P U T
		DBMS_OUTPUT.PUT_LINE(rpad(v_Partition.index_name,20,'.')||' '||
				     rpad(v_Partition.partition_name,29,'.')||' '||
				     rpad(NVL(v_Partition.tbs_partition,'.'),29,'.')||' '||
  				     rpad(v_Partition.subpartition_name,29,'.')||' '||
				     rpad(v_Partition.tbs_subpartition,29,'.')||' '||
				     rpad(v_Partition.status,10,'.'));
	END LOOP;
-- F O O T E R
	DBMS_OUTPUT.PUT_LINE('-------------------- ----------------------------- ----------------------------- ----------------------------- ----------------------------- ----------');
	CLOSE c_Partition;
END;
/
prompt
set feedback on;
set timing off;
set serveroutput off;
