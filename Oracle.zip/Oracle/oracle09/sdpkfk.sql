rem -------------------------------------------------------------------------
rem        Trivadis AG, Baden/Basel/Bern/Lausanne/Mellingen/Z�rich
rem                     Frankfurt/Freiburg i.Br./M�nchen/Stuttgart
rem                     Switzerland/Germany Internet: http://www.trivadis.com
rem -------------------------------------------------------------------------
rem   $Header$
rem   **********************************************************************
rem   Group/Privileges.: DBA
rem   Script-Name......: sdpfkf.sql
rem   Developer........: Andri Kisseleff (ank) andri.kisseleff@trivadis.com
rem   Date.............: 11.06.1995
rem   Version..........: Oracle9i - 2.0
rem   Usage............: shows all FK of a given PK table or vice verca
rem   Input parameters.:
rem   Output.......... : 
rem   Called by........:
rem   Remarks..........: enter either a PK-Table *or* a FK-Table
rem -----------------------------------------------------------------------
rem
rem $Log$
rem Revision 1.3  2002/09/09 16:56:24  far
rem 9.2 f�hig checked by ThJ
rem
rem Revision 1.2  2001/07/22 12:59:28  ank
rem - Load initial release Oracle9i 9.0.x
rem
rem
rem
rem Changes:
rem DD.MM.YYYY Consultant Change
rem -----------------------------------------------------------------------
rem 20.04.1999 AnK        OK for Oracle8i
rem 03.09.2002 ThJ        OK for Oracle9i R2
rem -----------------------------------------------------------------------
rem
rem
accept pk_owner char prompt "Owner of PK or Wildcard <%> : "
accept pk_table char prompt "Table of PK or Wildcard <%> : "
accept fk_owner char prompt "Owner of FK or Wildcard <%> : "
accept fk_table char prompt "Table of FK or Wildcard <%> : "
@@foenvtit "PK-FK relationships"
col pk_owner format a10 trunc heading "PK-Owner"
col fk_owner format a10 trunc heading "FK-Owner"
col pk_table format a28 trunc heading "PK-Table"
col fk_table format a28 trunc heading "FK-Table"
col pk_col   format a30 trunc heading "PK-Columns"
col pos      format 999       heading "Pos"
break on pk_owner skip 1 on pk_table skip 1 on fk_owner skip 1 on fk_table skip 1
set lines 116 pages 10000 head on feed on echo off termout on verify off
spool sdpkfk.lis
	select distinct P.OWNER pk_owner, P.TABLE_NAME pk_table,
               F.OWNER fk_owner, F.TABLE_NAME fk_table,
               PC.POSITION pos,
               PC.COLUMN_NAME pk_col 
        from   SYS.DBA_CONSTRAINTS P,
               SYS.DBA_CONSTRAINTS F,
               SYS.DBA_CONS_COLUMNS PC,
               SYS.DBA_CONS_COLUMNS FC
        where  P.CONSTRAINT_NAME = F.R_CONSTRAINT_NAME
        and    P.OWNER = F.R_OWNER
        and    P.CONSTRAINT_TYPE = 'P'
        and    F.CONSTRAINT_TYPE = 'R'
        and    P.CONSTRAINT_NAME = PC.CONSTRAINT_NAME
        and    F.CONSTRAINT_NAME = FC.CONSTRAINT_NAME
        and    P.TABLE_NAME = PC.TABLE_NAME
        and    F.TABLE_NAME = FC.TABLE_NAME
        and    P.OWNER = PC.OWNER 
        and    F.OWNER = FC.OWNER
        and    P.OWNER like upper(nvl('&pk_owner','%'))
        and    F.OWNER like upper(nvl('&fk_owner','%'))
        and    P.TABLE_NAME like upper(nvl('&pk_table','%'))
        and    F.TABLE_NAME like upper(nvl('&fk_table','%'))
        order by P.OWNER, P.TABLE_NAME, F.OWNER, F.TABLE_NAME, 
                 PC.POSITION
/
spool off
ttitle off
col pk_owner clear
col fk_owner clear
col pk_table clear
col fk_table clear
col pk_col clear
col pos clear
set lines 80 pages 24 verify on
prompt
prompt sdpkfk.lis has been spooled...
prompt
rem
