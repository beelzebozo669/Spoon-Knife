rem -------------------------------------------------------------------------
rem        Trivadis AG, Baden/Basel/Bern/Lausanne/Mellingen/Z�rich
rem                     Frankfurt/Freiburg i.Br./M�nchen/Stuttgart
rem                     Switzerland/Germany Internet: http://www.trivadis.com
rem -------------------------------------------------------------------------
rem   Group/Privileges.: DBA
rem   Script-Name......: ldtabcom.sql
rem   Developer........: Peter Hulm (PHu) peter.hulm@trivadis.com
rem   Date.............: Dezember 2003
rem   Version..........: Oracle9i
rem   Usage............: find tables appropriate for compression
rem   Input parameters.: Schemaname (User), Tablename, minimum Table size MB
rem   Output.......... : ldtabcom.lis
rem   Called by........:
rem   Remarks..........: To be run with DBA privileges
rem                      in case the accuracy of estimation is not
rem                      satisfying, adjust the number of sample blocks
rem                      accordingly. It defines the minimum number of blocks
rem                      used for the estimation. Be aware that the real number
rem                      can be much higher. The script needs enough memory
rem                      within the particular TS to create a temporary table.
rem -----------------------------------------------------------------------
rem
rem Changes:
rem DD.MM.YYYY Consultant Change
rem -----------------------------------------------------------------------
rem -----------------------------------------------------------------------
rem
SET LOGSOURCE "DUMMY" 
STORE SET temp.tmp REPLACE
ACCEPT user_namen CHAR PROMPT 'Username or Wildcard <%> : ' DEFAULT '%'
ACCEPT tabellen_namen CHAR PROMPT 'Tablename or Wildcard <%> : ' DEFAULT '%'
ACCEPT min_size CHAR PROMPT 'minimum table size for analysis; MB or Wildcard <%> : ' DEFAULT 0 
PROMPT
PROMPT adjust the following parameter just
PROMPT 1. in case the accuracy of estimation was not saisfying!
PROMPT 2. and you have a basic understandig of the subject!
PROMPT normally the default should be OK!
PROMPT
ACCEPT blocknum CHAR PROMPT 'minimum number of sample blocks; NUMBER (default 1000) : ' DEFAULT 1000 
SET PAGES 100 LINES 132  VERIFY OFF
SET ECHO OFF TERMOUT ON 
create table TEMP$$SUMMARY (tabname varchar2(30), tabpart varchar2(3), 
                            alloc_BL number (10), used_BL number (10),
                            alloc_MB number(12,2), used_MB number(12,2), 
                            MB_reorg number(12,2), MB_compress number(12,2), 
                            cr_reorg number(6,2), cr_compress number(6,2), 
                            save_MB_reorg number(12,2), save_MB_compress number(12,2),
                            sample_size number(10,5)); 
declare 
   pct number;
   blkcnt number := 0;
   blkcntc number;
   username varchar2(20);
   tabname varchar2(30);
   v_cr_reorg number(6,2);
   v_cr_compress number(6,2);
   v_MB_reorg number(12,2);
   v_MB_compress number(12,2);
   v_save_MB_reorg number(12,2);
   v_save_MB_compress number(12,2);
   v_DB_blksize number(10);
begin
   username := upper('&user_namen');
   select value into v_db_blksize from v$parameter where NAME = 'db_block_size';
   insert into TEMP$$SUMMARY (tabname,tabpart,alloc_BL,used_BL,alloc_MB,used_MB)
        SELECT T.table_name, 'NO', S.blocks, T.blocks, round((S.blocks*v_DB_blksize)/1048576,2), round((T.blocks*v_DB_blksize)/1048576,2)
        FROM   sys.dba_tables T, sys.dba_segments S
        WHERE  T.owner = S.owner
        AND    T.table_name = S.segment_name
        AND    T.owner LIKE UPPER('&user_namen')
        AND    T.table_name LIKE UPPER('&tabellen_namen')
        AND    (select count(C.DATA_TYPE)
                  from sys.dba_tab_columns C
                 where C.table_name = T.table_name
                   and C.DATA_TYPE not in ('CHAR','VARCHAR2','NUMBER', 'DATE')) = 0
        AND    T.cluster_name IS NULL
        AND    T.OWNER NOT IN ('SYS','SYSTEM')
        AND    T.PARTITIONED = 'NO';
   commit;
   insert into TEMP$$SUMMARY (tabname,tabpart,alloc_BL,used_BL,alloc_MB,used_MB)
        SELECT T.table_name, 'YES', sum(S.blocks), sum(T.blocks), round((sum(S.blocks)*v_DB_blksize)/1048576,2), round((sum(T.blocks)*v_DB_blksize)/1048576,2)
        FROM   sys.dba_tab_partitions T, sys.dba_segments S
        WHERE  T.table_owner = S.owner
        AND    T.table_name = S.segment_name
        AND    T.partition_name = S.partition_name
        AND    T.table_owner LIKE UPPER('&user_namen')
        AND    T.table_name LIKE UPPER('&tabellen_namen')
        AND    (select count(C.DATA_TYPE)
                  from sys.dba_tab_columns C
                 where C.table_name = T.table_name
                   and C.DATA_TYPE not in ('CHAR','VARCHAR2','NUMBER', 'DATE')) = 0
        AND    T.table_owner NOT IN ('SYS','SYSTEM')
        AND    T.subpartition_count = 0
        group by (T.table_name, 'YES');
   commit;
   insert into TEMP$$SUMMARY (tabname,tabpart,alloc_BL,used_BL,alloc_MB,used_MB)
        SELECT T.table_name, 'YES', sum(S.blocks), sum(T.blocks), round((sum(S.blocks)*v_DB_blksize)/1048576,2), round((sum(T.blocks)*v_DB_blksize)/1048576,2)
        FROM   sys.dba_tab_subpartitions T, sys.dba_segments S
        WHERE  T.table_owner = S.owner
        AND    T.table_name = S.segment_name
        AND    T.subpartition_name = S.partition_name
        AND    T.table_owner LIKE UPPER('&user_namen')
        AND    T.table_name LIKE UPPER('&tabellen_namen')
        AND    (select count(C.DATA_TYPE)
                  from sys.dba_tab_columns C
                 where C.table_name = T.table_name
                   and C.DATA_TYPE not in ('CHAR','VARCHAR2','NUMBER', 'DATE')) = 0
        AND    T.table_owner NOT IN ('SYS','SYSTEM')
        group by (T.table_name, 'YES');
   commit;

   for c in ( select rowid, tabname, used_MB 
                from TEMP$$SUMMARY
               where used_MB > &min_size ) loop     
     tabname := c.tabname;
     execute immediate 'create table TEMP$$FOR_TEST pctfree 0 as select * from '||username||'.'||tabname||' where rownum < 1';

     pct := 0.0099;
     blkcnt := 0;
     while ((pct < 100) and (blkcnt < &blocknum)) loop
       execute immediate 'truncate table TEMP$$FOR_TEST';
       execute immediate 'insert /*+ APPEND */ into TEMP$$FOR_TEST (select * from '||username||'.'||tabname||' sample block ('||pct||'))';
       commit;
       execute immediate 'select count(distinct(dbms_rowid.rowid_block_number(rowid))) from TEMP$$FOR_TEST' into blkcnt;
       pct := pct * 10;
     end loop;
     pct := pct / 10;

     v_MB_reorg         := round(((v_DB_blksize * blkcnt ) * round(100/pct,2)) / 1048576,2);
     v_save_MB_reorg    := c.used_MB - v_MB_reorg;

     if v_MB_reorg = 0 then
       v_cr_reorg := -1;
     else 
       v_cr_reorg := round(c.used_MB/v_MB_reorg,2);
     end if;

     execute immediate 'alter table TEMP$$FOR_TEST move compress ';
     execute immediate 'select count(distinct(dbms_rowid.rowid_block_number(rowid))) from TEMP$$FOR_TEST' into blkcntc;

     v_MB_compress      := round(((v_DB_blksize * blkcntc ) * round(100/pct,2)) / 1048576,2);
     v_save_MB_compress := v_MB_reorg - v_MB_compress;

     if blkcntc = 0 then
       v_cr_compress := -1;
     else 
       v_cr_compress := round(blkcnt/blkcntc,2);
     end if;

     update TEMP$$SUMMARY set         cr_reorg = v_cr_reorg,
                                   cr_compress = v_cr_compress,
                                      MB_reorg = v_MB_reorg,
                                   MB_compress = v_MB_compress,
                                 save_MB_reorg = v_save_MB_reorg,
                              save_MB_compress = v_save_MB_compress,
                                   sample_size = pct
      where rowid = c.rowid;
     commit;
 
    execute immediate 'drop table TEMP$$FOR_TEST';
  end loop;
exception
 when others then
   dbms_output.put_line(SQLERRM); 
   execute immediate 'drop table TEMP$$FOR_TEST';
end;
/
SPOOL ldtabcom.lis
select * from TEMP$$SUMMARY;
select sum(alloc_MB), sum(used_MB), sum(save_MB_reorg), sum(save_MB_compress) from TEMP$$SUMMARY;
drop table TEMP$$SUMMARY;
SPOOL OFF
SET VERIFY ON TERMOUT ON PAUSE OFF
TTITLE OFF
CLEAR COMPUTES BREAKS
PROMPT
prompt ldtabcom.lis (132 w) has been spooled...
prompt

REM Reset "SETs"	                       	       
@temp.tmp
