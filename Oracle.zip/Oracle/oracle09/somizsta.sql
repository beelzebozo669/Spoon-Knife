rem -------------------------------------------------------------------------
rem        Trivadis AG, Baden/Basel/Bern/Lausanne/Mellingen/Z�rich
rem                     Frankfurt/Freiburg i.Br./M�nchen/Stuttgart
rem                     Switzerland/Germany Internet: http://www.trivadis.com
rem -------------------------------------------------------------------------
rem   $Header$
rem   **********************************************************************
rem   Group/Privileges.: Owner
rem   Script-Name......: somizsta.sql
rem   Developer........: Urs Meier (urm) urs.meier@trivadis.com
rem   Date.............: 12.08.1992
rem   Version..........: Oracle9i - 2.0
rem   Usage............: Show optimizer statistics (once analyzed)
rem   Input parameters.:
rem   Output.......... : 
rem   Called by........:
rem   Remarks..........: Table and indexes
rem -----------------------------------------------------------------------
rem
rem $Log$
rem Revision 1.3  2002/08/30 13:16:09  far
rem getestet/angepasst f�r 9.2
rem
rem Revision 1.2  2001/07/22 12:59:28  ank
rem - Load initial release Oracle9i 9.0.x
rem
rem
rem
rem Changes:
rem DD.MM.YYYY Consultant Change
rem -----------------------------------------------------------------------
rem 07.04.1996 urs.meier  upgrade to V73
rem 05.04.1997 urs.meier  rename
rem 02.08.1997 AnK        upgrade to Oracle8
rem 15.11.1997 urs.meier  Include sample size/date and go for all_tables
rem 21.04.1999 AnK        OK for Oracle8i (col. ambig. defined part. ind. stat query)
rem                       Tested for Hash-Part. Tables. 
rem                       Added support for Composite Partitioning
rem 08.27.2002 ChA        OK for Oracle9i R2
rem -----------------------------------------------------------------------
rem
rem

set logsource "dummy"
store set temp.tmp replace

	ACCEPT pTable_Name CHAR -
		PROMPT "Show Statistics for Table: "

	COLUMN num_rows					HEADING '#rows'
	COLUMN blocks					HEADING '#blks'
	COLUMN empty_blocks				HEADING '#empty|blks'
	COLUMN avg_space				HEADING 'AVG|space'
	COLUMN chain_cnt				HEADING '#chain'
	COLUMN avg_row_len				HEADING 'AVG row|length'
	
	COLUMN column_name				HEADING 'Column Name' 	FORMAT A30
	COLUMN num_distinct				HEADING 'Distinct'
	COLUMN num_nulls				HEADING 'Nulls'         FORMAT A7 
	COLUMN num_buckets				HEADING 'Buckets'
	COLUMN last_analyzed			HEADING 'Last|Analyzed'
	COLUMN sample_size				HEADING 'Sampled' 		
	COLUMN indexed					HEADING 'Ind'

	COLUMN index_name				HEADING 'Index'			FORMAT A30
	COLUMN uniqueness				HEADING 'Unique'
	COLUMN blevel					HEADING 'LEV'
	COLUMN leaf_blocks				HEADING '#leaf|blk'
	COLUMN distinct_keys			HEADING '#dist.|keys'
	COLUMN avg_leaf_blocks_per_key	HEADING 'AVG|LF/key'
	COLUMN avg_data_blocks_per_key	HEADING 'AVG|Data/key'
	COLUMN clustering_factor 		HEADING 'Clust.'

	COLUMN partition_name   		HEADING 'Partition Name' FORMAT A30
	COLUMN subpartition_name   		HEADING 'Sub-Partition Name' FORMAT A30
    COLUMN locality                 HEADING 'Loc'
    COLUMN alignment                HEADING 'Ali'
set verify off linesize 80
spool somizsta.lis
	@@foenvtit "Table Statistics for &pTable_Name"
    @@fopauon
	
	ALTER SESSION SET nls_date_format = 'DD.MM HH24:MI'
			          nls_numeric_characters = '.''';

	SELECT /*+ RULE */ TO_CHAR(num_rows,'9G999G999') num_rows,
		TO_CHAR(blocks,'999G999') blocks,
		TO_CHAR(empty_blocks,'999G999') empty_blocks,
		TO_CHAR(avg_space,'9G999') avg_space, 
		TO_CHAR(chain_cnt,'99G999') chain_cnt,
	    TO_CHAR(avg_row_len,'999') avg_row_len,
	    TO_CHAR(sample_size,'9G999G990') sample_size,
	    last_analyzed
	  FROM user_all_tables
	 WHERE table_name = UPPER('&pTable_Name');

	@@foenvtit "Partition Statistics for &pTable_Name"
    @@fopauon
    set linesize 132
	SELECT /*+ RULE */ partition_name,
		TO_CHAR(num_rows,'9G999G999') num_rows,
		TO_CHAR(blocks,'999G999') blocks,
		TO_CHAR(empty_blocks,'999G999') empty_blocks,
		TO_CHAR(avg_space,'9G999') avg_space, 
		TO_CHAR(chain_cnt,'99G999') chain_cnt,
        TO_CHAR(avg_row_len,'999') avg_row_len,
	    TO_CHAR(sample_size,'9G999G990') sample_size,
	    last_analyzed
	  FROM user_tab_partitions
	 WHERE table_name = UPPER('&pTable_Name');

	@@foenvtit "Sub-Partition Statistics for &pTable_Name"
    @@fopauon
    set linesize 132
	SELECT /*+ RULE */ subpartition_name,
		TO_CHAR(num_rows,'9G999G999') num_rows,
		TO_CHAR(blocks,'999G999') blocks,
		TO_CHAR(empty_blocks,'999G999') empty_blocks,
		TO_CHAR(avg_space,'9G999') avg_space, 
		TO_CHAR(chain_cnt,'99G999') chain_cnt,
        TO_CHAR(avg_row_len,'999') avg_row_len,
	    TO_CHAR(sample_size,'9G999G990') sample_size,
	    last_analyzed
	  FROM user_tab_subpartitions
	 WHERE table_name = UPPER('&pTable_Name');


	@@foenvtit "Column Statistics for &pTable_Name"
    @@fopauon
    set linesize 80
	SELECT /*+ RULE */  utc.column_name,
		TO_CHAR(utc.num_distinct,'9G999G990') num_distinct,
		TO_CHAR(utc.num_nulls,'99G990') num_nulls,
		TO_CHAR(utc.num_buckets,'999') num_buckets,
        	DECODE(TO_CHAR(
			NVL(uic.column_position,0)),'1','Y','N') indexed,
		TO_CHAR(utc.sample_size,'9G999G990') sample_size,
		utc.last_analyzed last_analyzed
 	FROM   user_tab_columns utc,
		(SELECT /*+ RULE */ uic.table_name,
			uic.column_name,
			MIN(uic.column_position) column_position
	   	FROM user_ind_columns uic
          	GROUP BY uic.table_name,
			uic.column_name) uic
 	WHERE utc.table_name = uic.table_name(+)
   	  AND utc.column_name = uic.column_name(+)
   	  AND utc.table_name = UPPER('&pTable_Name')
 	ORDER  BY utc.column_id;


	@@foenvtit "Partition Column Statistics for &pTable_Name"
    @@fopauon
    set linesize 132
    BREAK ON COLUMN_NAME SKIP 1
	SELECT /*+ RULE */  utc.column_name,
                utc.partition_name, 
		TO_CHAR(utc.num_distinct,'9G999G990') num_distinct,
		TO_CHAR(utc.num_nulls,'99G990') num_nulls,
		TO_CHAR(utc.num_buckets,'999') num_buckets,
		TO_CHAR(utc.sample_size,'9G999G990') sample_size,
		utc.last_analyzed last_analyzed
 	FROM   user_part_col_statistics utc,
               user_tab_columns col,
		(SELECT /*+ RULE */ uic.table_name,
			uic.column_name,
			MIN(uic.column_position) column_position
	   	FROM user_ind_columns uic
          	GROUP BY uic.table_name,
			uic.column_name) uic
 	WHERE utc.table_name = uic.table_name(+)
   	  AND utc.column_name = uic.column_name(+)
          AND utc.table_name = col.table_name
          AND utc.column_name = col.column_name
   	  AND utc.table_name = UPPER('&pTable_Name')
          ORDER BY column_id, partition_name;


    CLEAR BREAK

	@@foenvtit "Sub-Partition Column Statistics for &pTable_Name"
    @@fopauon
    set linesize 132
    BREAK ON COLUMN_NAME SKIP 1
	SELECT /*+ RULE */  utc.column_name,
                utc.subpartition_name, 
		TO_CHAR(utc.num_distinct,'9G999G990') num_distinct,
		TO_CHAR(utc.num_nulls,'99G990') num_nulls,
		TO_CHAR(utc.num_buckets,'999') num_buckets,
		TO_CHAR(utc.sample_size,'9G999G990') sample_size,
		utc.last_analyzed last_analyzed
 	FROM   user_subpart_col_statistics utc,
               user_tab_columns col,
		(SELECT /*+ RULE */ uic.table_name,
			uic.column_name,
			MIN(uic.column_position) column_position
	   	FROM user_ind_columns uic
          	GROUP BY uic.table_name,
			uic.column_name) uic
 	WHERE utc.table_name = uic.table_name(+)
   	  AND utc.column_name = uic.column_name(+)
          AND utc.table_name = col.table_name
          AND utc.column_name = col.column_name
   	  AND utc.table_name = UPPER('&pTable_Name')
          ORDER BY column_id, subpartition_name;


    CLEAR BREAK
	@@foenvtit "Index Statistics for &pTable_Name"
    @@fopauon
	set linesize 80
	SELECT /*+ RULE */ index_name,
	       SUBSTR(uniqueness,1,3) uniqueness,
	       TO_CHAR(blevel,'999') blevel,
	       TO_CHAR(leaf_blocks,'999G999') leaf_blocks,
	       TO_CHAR(distinct_keys,'9G999G999') distinct_keys,
	       TO_CHAR(avg_leaf_blocks_per_key,'999') avg_leaf_blocks_per_key,
	       TO_CHAR(avg_data_blocks_per_key,'999') avg_data_blocks_per_key,
	       TO_CHAR(clustering_factor,'999G999') clustering_factor
	  FROM user_indexes
	 WHERE table_name = UPPER('&pTable_Name');

	@@foenvtit "Partition Indexes Statistics for &pTable_Name"
    @@fopauon
    set linesize 132
    BREAK ON index_name SKIP 1
	SELECT /*+ RULE */ ui.index_name, partition_name, 
	       SUBSTR(ui.uniqueness,1,3) uniqueness,
               SUBSTR(upi.locality,1,3) locality,
               SUBSTR(upi.alignment,1,3) alignment,
	       TO_CHAR(uip.blevel,'999') blevel,
	       TO_CHAR(uip.leaf_blocks,'999G999') leaf_blocks,
	       TO_CHAR(uip.distinct_keys,'9G999G999') distinct_keys,
	       TO_CHAR(uip.avg_leaf_blocks_per_key,'999') avg_leaf_blocks_per_key,
	       TO_CHAR(uip.avg_data_blocks_per_key,'999') avg_data_blocks_per_key,
	       TO_CHAR(uip.clustering_factor,'999G999') clustering_factor
	  FROM user_ind_partitions uip, user_part_indexes upi, user_indexes ui
	 WHERE ui.table_name = UPPER('&pTable_Name')
           AND uip.index_name = upi.index_name
           AND uip.index_name = ui.index_name 
        ORDER BY ui.index_name, partition_name;

    CLEAR BREAK

	@@foenvtit "Sub-Partition Indexes Statistics for &pTable_Name"
    @@fopauon
    set linesize 132
    BREAK ON index_name SKIP 1
	SELECT /*+ RULE */ ui.index_name, subpartition_name, 
	       SUBSTR(ui.uniqueness,1,3) uniqueness,
               SUBSTR(upi.locality,1,3) locality,
               SUBSTR(upi.alignment,1,3) alignment,
	       TO_CHAR(uip.blevel,'999') blevel,
	       TO_CHAR(uip.leaf_blocks,'999G999') leaf_blocks,
	       TO_CHAR(uip.distinct_keys,'9G999G999') distinct_keys,
	       TO_CHAR(uip.avg_leaf_blocks_per_key,'999') avg_leaf_blocks_per_key,
	       TO_CHAR(uip.avg_data_blocks_per_key,'999') avg_data_blocks_per_key,
	       TO_CHAR(uip.clustering_factor,'999G999') clustering_factor
	  FROM user_ind_subpartitions uip, user_part_indexes upi, user_indexes ui
	 WHERE ui.table_name = UPPER('&pTable_Name')
           AND uip.index_name = upi.index_name
           AND uip.index_name = ui.index_name 
        ORDER BY ui.index_name, subpartition_name;

    CLEAR BREAK
ttitle off
	COLUMN num_rows	CLEAR
	COLUMN blocks CLEAR
	COLUMN empty_blocks CLEAR
	COLUMN avg_space CLEAR
	COLUMN chain_cnt CLEAR
	COLUMN avg_row_len CLEAR
	
	COLUMN column_name CLEAR
	COLUMN num_distinct CLEAR
	COLUMN num_nulls CLEAR
	COLUMN num_buckets CLEAR
	COLUMN last_analyzed CLEAR
	COLUMN sample_size CLEAR
	COLUMN indexed	 CLEAR

	COLUMN index_name CLEAR
	COLUMN uniqueness CLEAR
	COLUMN blevel CLEAR
	COLUMN leaf_blocks CLEAR
	COLUMN distinct_keys CLEAR
	COLUMN avg_leaf_blocks_per_key CLEAR
	COLUMN avg_data_blocks_per_key CLEAR
	COLUMN clustering_factor CLEAR
	COLUMN partition_name CLEAR
    COLUMN locality CLEAR
    COLUMN alignment CLEAR
    COLUMN subpartition_name CLEAR
@@fopauoff
set verify on
prompt
prompt somizsta.lis has been spooled
prompt (format landscape together with partitions)
prompt
@temp.tmp


