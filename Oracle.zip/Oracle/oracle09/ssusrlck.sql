rem -------------------------------------------------------------------------
rem        Trivadis AG, Baden/Basel/Bern/Lausanne/Mellingen/Z�rich
rem                     Frankfurt/Freiburg i.Br./M�nchen/Stuttgart
rem                     Switzerland/Germany Internet: http://www.trivadis.com
rem -------------------------------------------------------------------------
rem   $Header$
rem   GROUP/Privileges.: SYS
rem   Script-Name......: ssusrlck.sql
rem   Developer........: Sven Vetter (SvV) Sven.Vetter@trivadis.com
rem   Date.............: Juli 2001
rem   Version..........: Oracle9i - 2.0
rem   Usage............: Shows users Locks (FROM PACKAGE dbms_lock)
rem   Input parameters.:
rem   Output.......... : 
rem   Called by........:
rem   Remarks..........: Column B/W = Blk  - Blocker
rem                                 = Wait - Wait for a lock
rem
rem HISTORY:
rem
rem $Log$
rem Revision 1.3  2002/09/09 16:56:24  far
rem 9.2 f�hig checked by ThJ
rem
rem Revision 1.2  2001/08/13 13:42:56  ank
rem - Added information if User waits for an UL-Lock
rem
rem Revision 1.1  2001/07/22 14:34:33  ank
rem - initial Release Oracle9i (9.0.x)
rem
rem
rem -----------------------------------------------------------------------
rem Changes:
rem DD.MM.YYYY Consultant Change
rem -----------------------------------------------------------------------
rem 04.09.2002 ThJ        OK for Oracle9i R2
rem -----------------------------------------------------------------------
rem
rem


SET PAGES 24 LINES 100 FEED ON ECHO OFF TERMOUT ON HEAD ON
COLUMN sid        format 99999
COLUMN username   format a20
COLUMN oseruser   format a20
COLUMN duration   format 99999999
COLUMN lockname   format a20
COLUMN DATABASE   NOPRINT NEW_VALUE DATABASE
COLUMN DATUM_ZEIT NOPRINT NEW_VALUE DATUM_ZEIT

SET TERMOUT OFF ECHO OFF FEED OFF
SELECT NAME DATABASE,
 TO_CHAR(SYSDATE,'DD.MM.YYYY HH24:MI') DATUM_ZEIT
FROM V$DATABASE;
SET TERMOUT ON
TTITLE CENTER 'Current User-Locks - DB: 'DATABASE' ('datum_zeit) SKIP 2

SELECT l.sid, s.username, s.osuser,a.name LockName,l.ctime duration,
 DECODE(l.lmode,0,'Wait',DECODE(l.block,0,NULL,'Blk')) "B/W"
FROM v$lock l, v$session s, sys.dbms_lock_allocated a
WHERE
 l.TYPE='UL' AND
 l.sid=s.sid AND
 l.id1=a.lockid
/
TTITLE OFF
COLUMN sid        clear
COLUMN username   clear
COLUMN oseruser   clear
COLUMN duration   clear
COLUMN lockname   clear
COLUMN DATABASE   clear
COLUMN DATUM_ZEIT clear
