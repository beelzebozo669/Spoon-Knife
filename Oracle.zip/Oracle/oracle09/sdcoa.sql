rem -------------------------------------------------------------------------
rem        Trivadis AG, Baden/Basel/Bern/Lausanne/Mellingen/Z�rich
rem                     Frankfurt/Freiburg i.Br./M�nchen/Stuttgart
rem                     Switzerland/Germany Internet: http://www.trivadis.com
rem -------------------------------------------------------------------------
rem   $Header$
rem   **********************************************************************
rem   Group/Privileges.: DBA
rem   Script-Name......: sdcoa.sql
rem   Developer........: Andri Kisseleff (ank) andri.kisseleff@trivadis.com
rem   Date.............: 13.11.1995
rem   Version..........: Oracle9i - 2.0
rem   Usage............: shows number of contigous free extents per tablespace
rem   Input parameters.:
rem   Output.......... : 
rem   Called by........:
rem   Remarks..........: use ALTER TABLESPACE ... COALESCE in Oracle 7.3+
rem			 (or csprccoa.sql and then execute prccoa; )
rem -----------------------------------------------------------------------
rem
rem $Log$
rem Revision 1.6  2003/08/12 13:42:35  ank
rem - Added the lost GROUP BY again
rem
rem Revision 1.5  2003/03/17 18:45:56  far
rem Anpassungen Ank f�r 9.2
rem
rem Revision 1.2  2001/07/22 12:59:28  ank
rem - Load initial release Oracle9i 9.0.x
rem
rem
rem
rem Changes:
rem DD.MM.YYYY Consultant Change
rem 18.06.1996 ank	  title and new header
rem -----------------------------------------------------------------------
rem 02.08.1997 ank        Oracle8
rem 10.09.1998 ank        Added File_Id
rem 20.04.1999 AnK        OK for Oracle8i. Changed output.
rem 17.09.2002 ThJ        Tested f�r Oracle 9.2.0 (only useful against 
rem                       dictionary managed tablespaces!)
rem -----------------------------------------------------------------------
rem
rem
connect system/manager@db2
@@foenvtit "Number of adjecent free extents per tablespace"
rem
	SELECT  rpad(a1.tablespace_name,30,'.') tablespace_name,
                lpad(' '||TO_CHAR(COUNT(*)),20,'.') nbr_adj_free_extents
	FROM    sys.dba_free_space a1, sys.dba_free_space a2
	WHERE   a1.tablespace_name=a2.tablespace_name
        AND     a1.file_id = a2.file_id
	AND     a1.block_id+a1.blocks = a2.block_id
	GROUP BY A1.tablespace_name
/

ttitle off
