rem -------------------------------------------------------------------------
rem        Trivadis AG, Baden/Basel/Bern/Lausanne/Mellingen/Zuerich
rem                     Frankfurt/Freiburg i.Br./Muenchen/Stuttgart
rem                     Switzerland/Germany Internet: http://www.trivadis.com
rem -------------------------------------------------------------------------
rem   $Header$
rem   **********************************************************************
rem   Group/Privileges.:  DBA
rem   Script-Name......:  lstsres.sql
rem   Developer........:  Martin Bracher martin.bracher@trivadis.com
rem   Date.............:  16.02.2003
rem   Version..........:  Oracle8i/9i
rem   Usage............:  Minimal size in KB for shrinking a datafile
rem   Input parameters.: 
rem   Output.......... :
rem   Called by........:
rem   Remarks..........:  For 9i an alternate SQL-Command is at the end of  
rem                       the script (commented out)  
rem 
rem   History: 
rem 
rem   $Log$
rem   Revision 1.2  2003/08/12 16:21:56  ank
rem   - New Version with correct file ID (Martin Bracher)
rem
rem   Revision 1.1  2003/02/23 16:54:18  far
rem   Added new script
rem
rem
rem
rem -----------------------------------------------------------------------
rem When        Who  What
rem 2003-02-16  MnB  initial version
rem 2003-08-10  MnB  Correction: when file# <> relfile#, no result
rem -----------------------------------------------------------------------
rem
rem
set logsource "dummy"
store set temp.tmp replace
set pages 1000
column tablespace format a20 word_wrap heading "Tablespace"
column file_name  format a39 word_wrap heading "Filename"
column actual     format a9  heading "Actual KB"
column shrink_to  format a9  heading "Shrink KB"
@@foenvtit "Resize of datafiles"
spool lstsres.lis

select tablespace_name tablespace
     , file_name 
     , decode(actual_size,-1,'n/a (offline)',actual_size) actual
     , decode(shrink_to,-1,'n/a',null,'can''t be shrinked',actual_size,'can''t be shrinked', shrink_to) shrink_to
from (
 select -- locally managed files that can be resized (last used block < last free block)
        d.tablespace_name
      , d.file_id 
      , d.file_name
      , d.bytes/1024 actual_size --MB
      , nvl((m.maxblock-1)*t.blocksize/1024, (64*1024+t.bitmapped*t.blocksize)/1024) shrink_to
   from dba_data_files d
      , sys.ts$ t
      , (select u.fileid file_id, max(u.block+u.length) maxblock --last used block +1
         from dba_lmt_used_extents u group by fileid ) m
   where m.file_id(+)=d.file_id 
     and d.tablespace_name =t.name
     and t.bitmapped > 0
     and d.bytes is not null --online
 union  -- Offline LMT (Offline DMT info is still available in datadict.)
 select d.tablespace_name, d.file_id, d.file_name, -1, -1  /* -1 => n/a, null => cannot be resized */
   from dba_data_files d 
   where bytes is null  -- Offline LMT: Size is unknown
 union -- dictionary managed (online + offline)
 select ts.name, a.file#, df.name, ts.blocksize*f.blocks/1024
      , case when nvl(min(a.bl-1),f.blocks) > 2  --nvl: no free space
             then nvl(min(a.bl-1),f.blocks)*(ts.blocksize)/1024
             else 2*(ts.blocksize)/1024 end
   from (select f.ts#, f.file#, block# bl
         from sys.fet$ f 
         start with block#=(select d.blocks-f.length+1 m from sys.file$ d where f.file#=d.relfile#)
           --end of free space area = end of datafile
         connect by prior block#=length+block#  --if area before is also free space
         ) a
       , v$dbfile df
       , sys.file$ f 
       , sys.ts$ ts 
   where f.relfile# = a.file# (+) -- a no rows -> no free space
     and f.ts# = ts.ts#
     and f.file# = df.file#
     and ts.bitmapped=0 --0=dictionary managed, else=locally managed
   group by ts.name, a.file#, df.name, f.blocks , ts.blocksize
)
order by tablespace_name, file_name
;

spool off
@temp.tmp
-- --Oracle 9i
-- select ts.name, a.file_id, df.name, ts.blocksize*f.blocks/1024
--      , case when nvl(min(a.bl-1),f.blocks) > 2  --nvl: no free space
--             then nvl(min(a.bl-1),f.blocks)*(ts.blocksize)/1024
--             else 2*(ts.blocksize)/1024 end
--   from (select  f.file_id, block_id bl
--         from dba_free_space f 
--         , sys.file$ d start with f.block_id=d.blocks-f.blocks+1 --9i
--           --end of free space area = end of datafile
--         connect by prior f.block_id=f.blocks+f.block_id  --if area before is also free space
--         ) a
--       , v$dbfile df
--       , sys.file$ f 
--       , sys.ts$ ts 
--   where f.relfile# = a.file_id (+) -- a no rows -> no free space
--     and f.ts# = ts.ts#
--     and f.file# = df.file#
--     and ts.bitmapped=0 --0=dictionary managed, else=locally managed
--   group by ts.name, a.file_id, df.name, f.blocks , ts.blocksize
column tablespace clear
column file_name  clear
column actual     clear
column shrink_to  clear
ttitle off
prompt
prompt lstsres.lis has been spooled...
prompt
