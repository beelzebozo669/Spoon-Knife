rem -------------------------------------------------------------------------
rem        Trivadis AG, Baden/Basel/Bern/Lausanne/Mellingen/Z�rich
rem                     Frankfurt/Freiburg i.Br./M�nchen/Stuttgart
rem                     Switzerland/Germany Internet: http://www.trivadis.com
rem -------------------------------------------------------------------------
rem   $Header$
rem   **********************************************************************
rem   Group/Privileges.:  DBA
rem   Script-Name......:  sdsynerr.sql
rem   Developer........:  Ingo Frost   ingo.frost@trivadis.com
rem   Date.............:  01.10.2001
rem   Version..........:  Oracle9i - 2.0
rem   Usage............:  shows public synonyms, with an invalid reference
rem                       pointing to itself directly or nowhere
rem                       cycles are *not* recognized
rem   Input parameters.:  
rem   Output.......... :  
rem   Called by........:
rem   Remarks..........:  the SQL*Plus command desc will fail with core dump
rem                       when describing a public synonym  pointing to itself
rem                       (e.g: create public synonym emp for scott.emp; 
rem                       drop table scott.emp; desc emp -> core)
rem                       cssyn.sql must have been run before as to create 
rem                       required a view
rem   History: 
rem 
rem   $Log$
rem   Revision 1.3  2002/09/09 16:56:24  far
rem   9.2 f�hig checked by ThJ
rem
rem   Revision 1.2  2001/10/31 16:25:22  ank
rem   no message
rem
rem   Revision 1.1  2001/10/31 16:21:17  ank
rem   - initial load to CVS (Oracle9i), InF
rem
rem
rem -----------------------------------------------------------------------
rem 03.09.2002 ThJ        OK for Oracle9i R2
rem -----------------------------------------------------------------------
rem
rem
set echo off
set verify off
set logsource "Dummy"
store set temp.tmp replace
clear   columns -
        breaks -
        computes
set pagesize 24 linesize 130

@@foenvtit "Public Synonyms without an invalid reference "

col owner 	 format a20	heading "Synonym Owner"
col synonym_name format a20 	heading "Synonym Name"
col table_owner  format a20 	heading "Dest-Obj Owner"
col table_name 	 format a20 	heading "Dest-Obj Name"
col object_type  format a20 	heading "Type"

select  synonym_name, owner, object_owner, object_name, object_type
from    tvd_synonyms
where   object_type in ('n/a', 'PUBLIC SYNONYM' )
and     object_name = synonym_name
order by 1,2,3,4 ;

ttitle off
prompt  Type "n/a": the synonym points to nowhere, and probably could be deleted 
prompt
@temp.tmp
