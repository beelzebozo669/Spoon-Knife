rem -------------------------------------------------------------------------
rem        Trivadis AG, Baden/Basel/Bern/Lausanne/Mellingen/Z�rich
rem                     Frankfurt/Freiburg i.Br./M�nchen/Stuttgart
rem                     Switzerland/Germany Internet: http://www.trivadis.com
rem -------------------------------------------------------------------------
rem $Header$
rem   GROUP/Privileges.: SYS
rem   Script-Name......: ssosblks.sql
rem   Developer........: Sven Vetter (SvV) Sven.Vetter@trivadis.com
rem   Date.............: 05.03.2002
rem   Version..........: 1.1
rem   Oracle-Version...: 7.3.4 - 9iR2
rem   Usage............: Shows OS-Blocksize
rem                      (unit for log_checkpoint_interval, 
rem                       max_dump_file_size)
rem   Input parameters.:
rem   Output.......... : 
rem   Called by........: 
rem   Remarks..........: must be run as sys
rem -----------------------------------------------------------------------
rem
rem $Log$
rem Revision 1.2  2002/08/30 13:16:09  far
rem getestet/angepasst f�r 9.2
rem
rem Revision 1.1  2002/03/09 07:46:15  ank
rem - Initial Load CVS (SvV)
rem
rem Date:      Consultant What
rem -----------------------------------------------------------------------
rem 27.08.2002 MaW        Ok for Oracle9i R2
rem -----------------------------------------------------------------------
rem
rem
SET echo off
col "OS Blocksize" format a20
SELECT MAX(lebsz)||' Byte' "OS Blocksize" FROM sys.x$kccle;
column "OS Blocksize" clear
