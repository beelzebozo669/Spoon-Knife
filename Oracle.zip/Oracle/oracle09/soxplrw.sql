rem -------------------------------------------------------------------------
rem        Trivadis AG, Baden/Basel/Bern/Lausanne/Mellingen/Z�rich
rem                     Frankfurt/Freiburg i.Br./M�nchen/Stuttgart
rem                     Switzerland/Germany Internet: http://www.trivadis.com
rem -------------------------------------------------------------------------
rem $Header$
rem -------------------------------------------------------------------------
rem   Group/Privileges.: Utilities (User)
rem   Script-Name......: soxplrw.sql
rem   Developer........: Christian Antognini (ChA)
rem   Date.............: 12.07.2001
rem   Version..........: Oracle9i 2.0
rem   Usage............: Used to to know why a query failed to rewrite or 
rem                      which materialized view is used for the query rewrite 
rem   Input parameters.: 
rem   Output.......... : 
rem   Called by........:
rem   Requirements.....: Oracle9i 9.0.1 or higher
rem   Remarks..........: REWRITE_TABLE must exists (can be created
rem                      with the script ?/rdbms/admin/utlxrw.sql)
rem                      Lower/mixed case object names are not supported.
rem
rem -----------------------------------------------------------------------
rem History:
rem $Log$
rem Revision 1.2  2002/09/09 16:56:24  far
rem 9.2 f�hig checked by ThJ
rem
rem Revision 1.1  2001/08/25 06:38:20  ank
rem - Initial Load into CVS
rem
rem Changes:
rem DD.MM.YYYY Consultant Change
rem -----------------------------------------------------------------------
rem 03.09.2002 ThJ        OK for Oracle9i R2
rem -----------------------------------------------------------------------

@@fopauon

set verify off


prompt 
prompt Please enter materialized view name, wildcards NOT allowed
prompt
accept mview_name char prompt "Materialized View Name: " 

prompt 
prompt Please enter the query to be rewritten, only 1 line is supported
prompt
accept query char prompt "Query: "

DELETE rewrite_table
WHERE  UPPER(mv_name) = UPPER('&&mview_name')
AND    mv_owner = user;

EXEC DBMS_MVIEW.EXPLAIN_REWRITE('&&query', '&&mview_name')


ttitle center 'Query rewrite possible?' skip 2

SELECT message
FROM   rewrite_table
WHERE  UPPER(mv_name) = UPPER('&&mview_name')
AND    mv_owner = user;

ttitle off

undef mview_name
undef query


set verify off

@@fopauoff

