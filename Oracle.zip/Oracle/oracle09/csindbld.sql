rem -------------------------------------------------------------------------
rem        Trivadis AG, Baden/Basel/Bern/Lausanne/Mellingen/Z�rich
rem                     Frankfurt/Freiburg i.Br./M�nchen/Stuttgart
rem                     Switzerland/Germany Internet: http://www.trivadis.com
rem -------------------------------------------------------------------------
rem   $Header$
rem   **********************************************************************
rem   Group/Privileges.: DBA
rem   Script-Name......: csindbld.sql
rem   Developer........: Urs Meier (urm) urs.meier@trivadis.com
rem   Date.............: 06.07.1996
rem   Version..........: Oracle9i - 2.0
rem   Usage............:
rem   Input parameters.: The procedure accepts 2 parameters
rem                      pExtents: if an index is found with more than
rem                      so many extents, it will rebuilt
rem                      pLogAction: TRUE = write a log file
rem   Output.......... :
rem   Called by........:
rem   Remarks..........: If there are >1 directories in utl_file_dir
rem                      the procedure uses the first one found.
rem -----------------------------------------------------------------------
rem
rem $Log$
rem Revision 1.3  2002/08/30 13:16:09  far
rem getestet/angepasst f�r 9.2
rem
rem Revision 1.2  2001/07/22 12:59:28  ank
rem - Load initial release Oracle9i 9.0.x
rem
rem
rem
rem Changes:
rem DD.MM.YYYY Consultant Change
rem -----------------------------------------------------------------------
rem 05.04.1997 umeier     rename
rem 24.10.1997 umeier     Oracle8
rem                       Skip Index only Tables (IOT%) and LOBs
rem                       Add Partition Support
rem 20.04.1999 AnK        OK for Oracle8i. Added support for/tested for:
rem                        - secondary Indexes on IOTs
rem                        - Hash Part. Tables
rem                        - Comp. Part Tables (cannot be rebuilt)
rem 09.11.1999 ClK        EXECUTE IMMEDIATE instead of cursor definition
rem                       Dropped variables vdummy, vcursor
rem                       TRIM instead of LTRIM(RTRIM())
rem 11.01.2000 AnK        Added MERGE extents. The indexes are recreated with
rem                       one extent (excluded are hash-partitions and
rem                       composite partitions, as the SQL-Syntax is not supported
rem                       there) 
rem                       Added DBMS_OUTPUT so one can see (if SET SERVEROUTPUT ON)
rem                       the generated and executed syntax
rem 08.04.2001 UrM	  Added tablespace 
rem 27.08.2002 MaW        Ok for 9iR2, but does not support composite
rem                       partitioning
rem -----------------------------------------------------------------------
rem
rem

CREATE OR REPLACE PROCEDURE indbld (pExtents   IN NUMBER  Default 5,
                                    pLogAction IN BOOLEAN Default TRUE) IS

  vLogAction  BOOLEAN         := pLogAction;
  vdirectory  v$parameter.value%TYPE;
  vlogfile	  utl_File.File_Type;
  vfilename   VARCHAR2(30)    := 'indbld.log';
  vmode       VARCHAR2(1)     := 'W';
  vSQL	      VARCHAR2(1000);
  vLogText    VARCHAR2(1000);
  vInitial    INTEGER;


  /* Internal function to find the first valid directory for utl_file.
   * There can be more than one.
   * If there is none, than the fopen will fail..., so make sure that
   * there is one...
   */
  FUNCTION utl_file_dir
  RETURN VARCHAR2 IS
  BEGIN
    BEGIN
      SELECT value
        INTO vDirectory
        FROM v$parameter
       WHERE name = 'utl_file_dir';
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        vDirectory := NULL;
    END;

    IF (INSTR(vDirectory,',') > 0) THEN
      vDirectory := SUBSTR(vDirectory,1,INSTR(vDirectory,',')-1);
    END IF;

    RETURN(TRIM(vDirectory));

  END utl_file_dir;


BEGIN
  IF (vLogAction) THEN

   vlogfile := utl_File.FOpen(utl_file_dir,vfilename,vmode);
   utl_File.Put_Line(vlogfile,TO_CHAR(SYSDATE,'DD.MM.YYYY HH24:MI.SS')||
                     ': Index Reorg startet');
   
  END IF;

  FOR indrec IN (SELECT s.owner, s.segment_name, s.extents,
                        s.partition_name, s.bytes, s.tablespace_name
                   FROM dba_segments s,
                        dba_indexes i
                  WHERE s.owner = i.owner
                    AND s.segment_name = i.index_name
                    AND s.segment_type IN ('INDEX', 'INDEX PARTITION')
                    AND i.index_type NOT LIKE 'IOT%'
                    AND i.index_type != 'LOB'
                    AND s.extents > pExtents
                    AND s.owner NOT IN  ('SYS')
                    AND (s.owner,i.index_name) NOT IN
                     (SELECT pi.owner, pi.index_name
                      FROM   dba_part_indexes pi
                      WHERE  pi.owner = s.owner
                      AND    pi.index_name = i.index_name
                      AND    pi.partitioning_type = 'HASH')
                  ORDER BY s.owner, s.segment_name, s.partition_name) LOOP

    IF (indrec.partition_name IS NULL) THEN
      vSQL     := 'ALTER INDEX '||indrec.owner||'.'||indrec.segment_name||' REBUILD';
      vSQL     := vSQL||' STORAGE (INITIAL '||TO_CHAR(indrec.bytes)||')';
      vSQL     := vSQL||' TABLESPACE '||indrec.tablespace_name;
      vLogText := TO_CHAR(SYSDATE,'DD.MM.YYYY HH24:MI.SS')||
                                 ': Index '||indrec.owner||'.'||indrec.segment_name||' with '||
                                 TO_CHAR(indrec.extents)||' Extents';
    ELSE
      vSQL     := 'ALTER INDEX '||indrec.owner||'.'||indrec.segment_name||' REBUILD '||
                  ' PARTITION '||indrec.partition_name;
      vSQL     := vSQL||' STORAGE (INITIAL '||TO_CHAR(indrec.bytes)||')';
      vSQL     := vSQL||' TABLESPACE '||indrec.tablespace_name;
      vLogText := TO_CHAR(SYSDATE,'DD.MM.YYYY HH24:MI.SS')||
                                 ': Index '||indrec.owner||'.'||indrec.segment_name||
                                 '('||indrec.partition_name||') with '||
                                 TO_CHAR(indrec.extents)||' Extents';
    END IF;
    DBMS_OUTPUT.PUT_LINE(vSQL);
    EXECUTE IMMEDIATE vSQL;

    IF (vLogAction) THEN
      utl_File.Put_Line(vlogfile, vLogText);
    END IF;

  END LOOP;

  IF (vLogAction) THEN
    utl_File.Put_Line(vlogfile,
                      TO_CHAR(SYSDATE,'DD.MM.YYYY HH24:MI.SS')||': Index Reorg ended');
    utl_File.FClose(vlogfile);
  END IF;

EXCEPTION
  WHEN OTHERS THEN

    IF (utl_File.Is_Open(vlogfile)) THEN
      utl_File.FClose(vlogfile);
    END IF;

    RAISE;
END;
/

show error

rem
prompt 
prompt Usage Example: execute indbld(5,FALSE);
prompt
prompt --> For indbld(5); or indbld(5,TRUE); a valid UTL_FILE_DIR is required
prompt


