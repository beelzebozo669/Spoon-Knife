rem -------------------------------------------------------------------------
rem        Trivadis AG, Baden/Basel/Bern/Lausanne/Mellingen/Z�rich
rem                     Frankfurt/Freiburg i.Br./M�nchen/Stuttgart
rem                     Switzerland/Germany Internet: http://www.trivadis.com
rem -------------------------------------------------------------------------
rem   $Header$
rem   ***********************************************************************
rem   Group/Privileges.: DBA
rem   Script-Name......: sdmtssta.sql
rem   Developer........: Andri Kisseleff (ank) andri.kisseleff@trivadis.com
rem   Date.............: 18.12.1993
rem   Version..........: Oracle9i - 2.0
rem   Usage............: Shows wait and other statistics for MTS
rem   Input parameters.:
rem   Output.......... : 
rem   Called by........:
rem   Remarks..........:
rem -----------------------------------------------------------------------
rem
rem $Log$
rem Revision 1.2  2002/09/09 16:56:24  far
rem 9.2 f�hig checked by ThJ
rem
rem Revision 1.1  2001/07/23 05:26:22  ank
rem - Initial Release Oracle9i (9.0.x).
rem
rem
rem
rem Changes:
rem DD.MM.YYYY Consultant Change
rem -----------------------------------------------------------------------
rem 02.08.1997 ank        Oracle8 (changes in v$dispatcher)
rem 20.04.1999 AnK        OK for Oracle8i
rem 19.05.2000 SuM        Changes to the Select for dispatchers
rem 22.07.2001 AnK        Changed INIT.ORA for Oracle9i
rem 03.09.2002 ThJ        Added decode on totalq (fix division by zero)
rem                       OK for Oracle9i R2
rem -----------------------------------------------------------------------
rem
rem
COLUMN NAME FORMAT A25 TRUNC
COLUMN PROTOCOL FORMAT A10 TRUNC
COLUMN VALUE FORMAT A40 TRUNC
@@foenvtit "Actual Shared Server - Parameters"
	SELECT 	NAME, VALUE
	FROM   	V$PARAMETER
	WHERE	(NAME LIKE '%shared%server%'
        OR      NAME LIKE '%dispatcher%'
        OR      NAME LIKE '%circuits%')
        AND     NAME NOT LIKE 'mts%'
        ORDER BY NAME 
/
SET PAUSE "<<<RETURN>>> " PAUSE ON
@@foenvtit "Max. Number of Server-Processes"
	SELECT * FROM V$MTS
/
COLUMN NAME FORMAT A6 TRUNC
@@foenvtit "Waits of Dispatchers"
select name
       ,replace(substr(NETWORK,instr(NETWORK,'PROTOCOL=')+9),'))') "Protokoll"
       ,decode(nvl(totalq,0),0,'not activ','activ') "Activity"
       ,round(wait/decode(totalq,0,NULL),2) "AVG waits (1/100 s)"
from v$dispatcher d
   , v$queue q
 where q.type = 'DISPATCHER'
  and d.paddr=q.paddr
/
/
@@foenvtit "Waits of Shared-Server"
	SELECT 	DECODE(TOTALQ,0,'not activ',
			        ROUND(WAIT/decode(TOTALQ,0,NULL),2)) "AVG Waits (1/100 s)"
	FROM 	V$QUEUE
	WHERE	TYPE = 'COMMON'
/
@@foenvtit "Nbr. Processes actually waiting for a shared server"
	SELECT 	QUEUED
	FROM 	V$QUEUE
	WHERE   TYPE = 'COMMON'
/
SET PAUSE OFF 
col name clear
col protocol clear
col value clear
TTITLE OFF
