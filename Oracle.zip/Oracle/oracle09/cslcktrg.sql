rem -----------------------------------------------------------------------------------
rem        Trivadis AG, Basel/Bern/Lausanne/Zuerich
rem                     Duesseldorf/Frankfurt/Freiburg i.Br./Hamburg/Muenchen/Stuttgart
rem                     Wien
rem                     Switzerland/Germany/Austria Internet: http://www.trivadis.com
rem -----------------------------------------------------------------------------------
rem   Group/Privileges.: DBA
rem   Script-Name......: cslcktrg.sql
rem   Developer........: Peter Jensch (pej) peter.jensch@trivadis.com
rem   Date.............: July 2002
rem   Version..........: Oracle9i
rem   Usage............: Create Table, Procedure and Trigger for automatic
rem                      collection on deadlock-trigger.
rem                      Must run as user sys.
rem                      May be add tablespace parameter for create table commands.
rem   Input parameters.:
rem   Output.......... :
rem   Called by........:
rem   Remarks..........: script lslcksta.sql can be executed for
rem                      formated output on the tables
rem
rem                      OBJECT_NAME               OBJECT_TYPE
rem                      ------------------------- -------------------
rem                      TVD_LOCK_INFO_2           TABLE
rem                      TVD_LOCK_INFO_1           TABLE
rem                      TVD_PRC_LOCK_INFO         PROCEDURE
rem                      TVD_LOG_DEADLOCK_ERRORS   TRIGGER
rem
rem -----------------------------------------------------------------------------------
rem Changes:
rem DD.MM.YYYY Consultant Change
rem -----------------------------------------------------------------------------------
rem 02.05.2012 PeJ        OK for 10g, OK for 11g 
rem -----------------------------------------------------------------------------------
rem


prompt ===================================================
prompt Creating Table: tvd_lock_info_1 ..
prompt ===================================================

DROP TABLE tvd_lock_info_1
;
CREATE TABLE tvd_lock_info_1 (
    lock_date               DATE
  , os_locker               VARCHAR2(30)
  , locker_schema           VARCHAR2(30)
  , locker_pid              VARCHAR2(9)
  , locker_sid_serial#      VARCHAR2(100)
  , os_waiter               VARCHAR2(30)
  , waiter_schema           VARCHAR2(30)
  , waiter_pid              VARCHAR2(9)
  , waiter_sid_serial#      VARCHAR2(100)
  , sql_text_waiter         VARCHAR2(200)
  , locker_sql              VARCHAR2(4000)
  , waiter_sql              VARCHAR2(4000)
  , mutdate                 TIMESTAMP      DEFAULT CURRENT_TIMESTAMP
)
TABLESPACE sysaux
;


prompt ===================================================
prompt Creating Table: tvd_lock_info_2 ...
prompt ===================================================

DROP TABLE tvd_lock_info_2;
CREATE TABLE tvd_lock_info_2 (
    lock_date               DATE
  , wait                    VARCHAR2(3)
  , os_user                 VARCHAR2(30)
  , process                 VARCHAR2(9)
  , sid_serial#             VARCHAR2(100)
  , locker                  VARCHAR2(30)
  , object_owner            VARCHAR2(30)
  , object_name             VARCHAR2(30)
  , program                 VARCHAR2(50)
  , mutdate                 TIMESTAMP      DEFAULT CURRENT_TIMESTAMP
)
TABLESPACE sysaux
;


prompt ===================================================
prompt PL/SQL stored procedure:  tvd_prc_lock_info ...
prompt ===================================================

CREATE OR REPLACE PROCEDURE tvd_prc_lock_info
IS
  PRAGMA AUTONOMOUS_TRANSACTION;

  vSQL_locker	tvd_lock_info_1.locker_sql%type;
  vSQL_waiter	vSQL_locker%type;

  CURSOR lock_cur1 IS
    SELECT   /* first the table-level locks (TM) and mixed TM/TX TX/TM */
             SYSDATE               LOCK_DATE
          ,  S_LOCKER.OSUSER       OS_LOCKER
          ,  S_LOCKER.USERNAME     LOCKER_SCHEMA
          ,  S_LOCKER.PROCESS      LOCKER_PID
          ,  S_WAITER.OSUSER       OS_WAITER
          ,  S_WAITER.USERNAME     WAITER_SCHEMA
          ,  S_WAITER.PROCESS      WAITER_PID
          ,  S_WAITER.SID ||','|| S_WAITER.SERIAL#  WAITER_SID_SERIAL#
          ,  'Table lock (TM): ' || U.NAME || '.' || O.NAME || ' - Mode held: '||
                 DECODE(L_LOCKER.LMODE,
                        0, 'None',           /* same as Monitor */
                        1, 'Null',           /* N */
                        2, 'Row-S (SS)',     /* L */
                        3, 'Row-X (SX)',     /* R */
                        4, 'Share',          /* S */
                        5, 'S/Row-X (SSX)',  /* C */
                        6, 'Exclusive',      /* X */
                        '???: ' || to_char(L_LOCKER.LMODE)) || ' / Mode requested: '||
                 DECODE(L_WAITER.REQUEST,
                        0, 'None',           /* same as Monitor */
                        1, 'Null',           /* N */
                        2, 'Row-S (SS)',     /* L */
                        3, 'Row-X (SX)',     /* R */
                        4, 'Share',          /* S */
                        5, 'S/Row-X (SSX)',  /* C */
                        6, 'Exclusive',      /* X */
                        '???: '||to_char(L_WAITER.REQUEST)) SQL_TEXT_WAITER
           , S_WAITER.SID          WAITER_SID
           , S_WAITER.SERIAL#      WAITER_SERIAL#
           , S_LOCKER.SID          LOCKER_SID
           , S_LOCKER.SERIAL#      LOCKER_SERIAL#
        FROM
             OBJ$             O
           , USER$            U
           , V$LOCK           L_WAITER
           , V$LOCK           L_LOCKER
           , V$SESSION        S_WAITER
           , V$SESSION        S_LOCKER
        WHERE  S_WAITER.SID     = L_WAITER.SID
          AND  L_WAITER.TYPE    IN ('TM')
          AND  S_LOCKER.sid     = L_LOCKER.sid
          AND  L_LOCKER.ID1     = L_WAITER.ID1
          AND  L_WAITER.REQUEST > 0
          AND  L_LOCKER.LMODE   > 0
          AND  L_WAITER.ADDR    != L_LOCKER.ADDR
          AND  L_WAITER.ID1     = O.OBJ#
          AND  U.USER#          = O.OWNER#
      UNION
      SELECT /* now the (usual) row-locks TX */
             SYSDATE                LOCK_DATE
           , S_LOCKER.OSUSER        OS_LOCKER
           , S_LOCKER.USERNAME      LOCKER_SCHEMA
           , S_LOCKER.PROCESS       LOCK_PID
           , S_LOCKER.SID ||','|| S_LOCKER.SERIAL#  LOCKER_SID_SERIAL#
           , S_WAITER.OSUSER        OS_WAITER
           , S_WAITER.USERNAME      WAITER_SCHEMA
           , S_WAITER.PROCESS       WAITER_PID
           , 'TX: ' || O.SQL_TEXT   SQL_TEXT_WAITER
           , S_WAITER.SID           WAITER_SID
           , S_WAITER.SERIAL#       WAITER_SERIAL#
           , S_LOCKER.SID           LOCKER_SID
           , S_LOCKER.SERIAL#       LOCKER_SERIAL#
        FROM
             V$LOCK                 L_WAITER
           , V$LOCK                 L_LOCKER
           , V$SESSION              S_WAITER
           , V$SESSION              S_LOCKER
           , V$_LOCK1               L1_WAITER
           , V$OPEN_CURSOR          O
        WHERE S_WAITER.SID          = L_WAITER.SID
          AND L_WAITER.TYPE         IN ('TX')
          AND S_LOCKER.sid          = L_LOCKER.sid
          AND L_LOCKER.ID1          = L_WAITER.ID1
          AND L_WAITER.REQUEST      > 0
          AND L_LOCKER.LMODE        > 0
          AND L_WAITER.ADDR         != L_LOCKER.ADDR
          AND L1_WAITER.LADDR       = L_WAITER.ADDR
          AND L1_WAITER.KADDR       = L_WAITER.KADDR
          AND L1_WAITER.SADDR       = O.SADDR
    ;
    
    rec1	lock_cur1%ROWTYPE;
    
    /*
    ||----------------------------------------------------
    || Private function to retrieve pieces of SQL code
    || submitted by a user, a session id respectively
    ||----------------------------------------------------
    */
    FUNCTION GET_SQL_IN_SGA(pSID_in IN V$SESSION.SID%type)
    RETURN VARCHAR2
    IS
        vSID    NUMBER(37,0) := pSID_in;
        vString VARCHAR2(4000);
        vPiece  VARCHAR2(64);
        vRest   NUMBER(10,0);
        vSubMsg VARCHAR2(240);

        CURSOR sql_cur (cSID_in IN V$SESSION.SID%type) is
        SELECT  a.SQL_TEXT
          FROM  SYS.V$SQLTEXT_WITH_NEWLINES a
             ,  SYS.V$SESSION b
        WHERE   a.ADDRESS    = b.SQL_ADDRESS
          AND   a.HASH_VALUE = b.SQL_HASH_VALUE
          AND   b.SID        = cSID_in
          ORDER BY  a.ADDRESS, a.HASH_VALUE, a.PIECE;
    BEGIN
        vSubMsg := 'Opening cursor sql_cur('||vSID||')';
        IF NOT sql_cur%ISOPEN THEN
            open sql_cur(vSID);
        END IF;
        LOOP
          vSubMsg := sql_cur%rowcount||'. fetch of sql_cur into vPiece';
          FETCH sql_cur into vPiece;
          EXIT WHEN sql_cur%NOTFOUND;
          vString := vString || vPiece;
        END LOOP;
        vSubMsg := 'Closing sql_cur after '||sql_cur%rowcount||' fetches.';
        CLOSE sql_cur;
        RETURN vString;
    EXCEPTION
        WHEN VALUE_ERROR THEN
            IF sql_cur%ISOPEN THEN
              CLOSE sql_cur;
            END IF;
            /*
            ||------------------------------------------
            || If the fetched sql statement is too long
            || we cut it and fit it to size
            ||------------------------------------------
            */
            vRest   := 4000-length(vString)-1;
            vString := vString || substr(vPiece, 1, vRest);
            RETURN vString;
        WHEN OTHERS THEN
            IF sql_cur%ISOPEN THEN
              CLOSE sql_cur;
            END IF;
            dbms_output.put_line(SQLERRM(SQLCODE));
            dbms_output.put_line('[ERROR]: while '||vSubMsg);
    END GET_SQL_IN_SGA;
    /* --------------- end of private objects section ----------------------*/
BEGIN
  IF NOT lock_cur1%ISOPEN THEN
    OPEN lock_cur1;
  END IF;
  LOOP
      fetch lock_cur1 into rec1;
      exit when lock_cur1%NOTFOUND;

      vSQL_locker := GET_SQL_IN_SGA(rec1.locker_sid);
      vSQL_waiter := GET_SQL_IN_SGA(rec1.waiter_sid);

      INSERT INTO tvd_lock_info_1
            ( lock_date, os_locker, locker_schema,
              locker_pid, locker_sid_serial#,
              os_waiter, waiter_schema,
              waiter_pid, waiter_sid_serial#,
              sql_text_waiter, locker_sql, waiter_sql
            )
      VALUES
            ( rec1.lock_date, rec1.os_locker, rec1.locker_schema,
              rec1.locker_pid, rec1.locker_sid||','||rec1.locker_serial#,
              rec1.os_waiter, rec1.waiter_schema,
              rec1.waiter_pid, rec1.waiter_sid||','||rec1.waiter_serial#,
              rec1.sql_text_waiter, vSQL_locker, vSQL_waiter
            );
            
  END LOOP;
  CLOSE lock_cur1;

  INSERT INTO tvd_lock_info_2
      ( lock_date, wait, os_user, process, sid_serial#,
        locker, object_owner, object_name, program
      )
      SELECT SYSDATE                        LOCK_DATE
           , DECODE(L.REQUEST,0,'NO','YES') WAIT
           , S.OSUSER
           , S.PROCESS
           , S.SID||','||S.SERIAL#          SID_SERIAL#
           , S.USERNAME                     LOCKER
           , U.NAME                         T_OWNER
           , O.NAME                         OBJECT_NAME
           , '  '||S.PROGRAM                PROGRAM
        FROM
             V$LOCK    L
           , USER$     U
           , OBJ$      O
           , V$SESSION S
        WHERE   U.USER# =  O.OWNER#
          AND   S.SID   =  L.SID
          AND   L.ID1   =  O.OBJ#
          AND   L.TYPE  =  'TM'
          AND   U.NAME  != 'SYS'
     UNION
       SELECT SYSDATE                        LOCK_DATE
            , DECODE(L.REQUEST,0,'NO','YES') WAIT
            , S.OSUSER
            , S.PROCESS
            , S.SID||','||S.SERIAL#          SID_SERIAL#
            , S.USERNAME                     LOCKER
            , '-'
            , 'Record(s)'
            , '  '||S.PROGRAM                PROGRAM
         FROM    V$LOCK    L
             ,   V$SESSION S
         WHERE   S.SID  = L.SID
           AND   L.TYPE = 'TX';

  COMMIT;
    
  EXCEPTION
    WHEN OTHERS THEN
      IF lock_cur1%ISOPEN THEN
        CLOSE lock_cur1;
      END IF;
END tvd_prc_lock_info;
/
show errors


prompt ===================================================
prompt Trigger: tvd_log_deadlock_errors ..
prompt ===================================================

CREATE OR REPLACE TRIGGER tvd_log_deadlock_errors
  AFTER SERVERERROR ON DATABASE
BEGIN
  IF (IS_SERVERERROR (60)) THEN

    sys.tvd_prc_lock_info;

  END IF;
END log_deadlock_errors;
/
show errors

commit;

