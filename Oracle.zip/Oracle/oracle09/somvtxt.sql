rem -------------------------------------------------------------------------
rem        Trivadis AG, Baden/Basel/Bern/Lausanne/Mellingen/Z�rich
rem                     Frankfurt/Freiburg i.Br./M�nchen/Stuttgart
rem                     Switzerland/Germany Internet: http://www.trivadis.com
rem -------------------------------------------------------------------------
rem $Header$
rem -------------------------------------------------------------------------
rem   Group/Privileges.: Utilities (User)
rem   Script-Name......: somvtxt.sql
rem   Developer........: Christian Antognini (ChA)
rem   Date.............: 05.07.2001
rem   Version..........: Oracle9i 2.0
rem   Usage............: Used to list the query of a materialized view
rem   Input parameters.: 
rem   Output.......... : 
rem   Called by........:
rem   Requirements.....: 
rem   Remarks..........: Lower/mixed case object names are not supported.
rem
rem -----------------------------------------------------------------------
rem History:
rem $Log$
rem Revision 1.2  2002/09/09 16:56:24  far
rem 9.2 f�hig checked by ThJ
rem
rem Revision 1.1  2001/08/25 06:38:20  ank
rem - Initial Load into CVS
rem
rem Changes:
rem DD.MM.YYYY Consultant Change
rem -----------------------------------------------------------------------
rem 03.09.2002 ThJ        OK for Oracle9i R2
rem -----------------------------------------------------------------------

ACCEPT vname CHAR PROMPT "Text for materialized view(s) [%]: " Default "%"

SET PAUSE OFF ECHO OFF TERMOUT OFF
CLEAR COLUMNS BREAKS COMPUTES
COLUMN maxlong  NOPRINT NEW_VALUE maxlong
COLUMN mview_name NOPRINT NEW_VALUE mview_name

SELECT MAX(query_len) maxlong
FROM   user_mviews
WHERE  mview_name LIKE UPPER('&&vname');

SET LONG &maxlong

SET TERMOUT ON FEEDBACK ON VERIFY OFF 
   
@@fopauon

BREAK ON mview_name SKIP PAGE

TTITLE CENTER "View description for "mview_name

SELECT mview_name, query
 FROM user_mviews
WHERE mview_name LIKE UPPER('&&vname')
ORDER BY mview_name;

set LONG 80
TTITLE OFF
col maxlong clear
col mview_name clear
@@fopauoff

