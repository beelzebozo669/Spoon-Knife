rem -------------------------------------------------------------------------
rem        Trivadis AG, Baden/Basel/Bern/Lausanne/Mellingen/Z�rich
rem                     Frankfurt/Freiburg i.Br./M�nchen/Stuttgart
rem                     Switzerland/Germany Internet: http://www.trivadis.com
rem -------------------------------------------------------------------------
rem   $Header$
rem   **********************************************************************
rem   Group/Privileges.:  DBA
rem   Script-Name......:  sdsyn.sql
rem   Developer........:  Ingo Frost   ingo.frost@trivadis.com
rem   Date.............:  01.10.2001
rem   Version..........:  Oracle9i - 2.0
rem   Usage............:  Information about Synonyms, 
rem   Input parameters.: 
rem   Output.......... :
rem   Called by........:
rem   Remarks..........:  cssyn.sql must have been run before as to 
rem                       create the required view.
rem   History: 
rem 
rem   $Log$
rem   Revision 1.3  2002/08/30 13:16:09  far
rem   getestet/angepasst f�r 9.2
rem
rem   Revision 1.2  2001/10/31 16:25:22  ank
rem   no message
rem
rem   Revision 1.1  2001/10/31 16:21:17  ank
rem   - initial load to CVS (Oracle9i), InF
rem
rem
rem -----------------------------------------------------------------------
rem When        Who  What
rem 2002-08-27  MaW  Ok for Oracle9i R2
rem -----------------------------------------------------------------------
rem
rem
set echo off
set verify off
set logsource "Dummy"
store set temp.tmp replace
clear   columns -
        breaks -
        computes
set pagesize 24 linesize 130

PROMPT
PROMPT Please enter Synonym Owner and/or Destination-Object Owner, wildcards allowed
PROMPT
PROMPT eg.: SCOTT, S% , % or PUBLIC
PROMPT
accept v_owner      char prompt "Synonym Owner <PUBLIC>    : " default "PUBLIC"
accept v_dest_owner char prompt "Destination Owner <%>     : " default "%"

@@foenvtit "Synonym Report"

col owner 	     format a20	    heading "Synonym Owner"
col synonym_name format a20 	heading "Synonym Name"
col object_owner format a20 	heading "Dest-Obj Owner"
col object_name  format a20 	heading "Dest-Obj Name"
col object_type  format a20 	heading "Type"

select owner, synonym_name, object_owner, object_name, object_type
from tvd_synonyms
where owner like upper('&v_owner')
and object_owner like upper('&v_dest_owner')
order by 1,2,3,4 ;

ttitle off
prompt  Type "n/a": the synonym points to nowhere, and probably could be deleted 
prompt
undefine v_owner
undefine v_dest_owner
@temp.tmp
