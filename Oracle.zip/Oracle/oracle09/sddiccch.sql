rem -------------------------------------------------------------------------
rem        Trivadis AG, Baden/Basel/Bern/Lausanne/Mellingen/Z�rich
rem                     Frankfurt/Freiburg i.Br./M�nchen/Stuttgart
rem                     Switzerland/Germany Internet: http://www.trivadis.com
rem -------------------------------------------------------------------------
rem   $Header$
rem   **********************************************************************
rem   Group/Privileges.: DBA
rem   Script-Name......: sddiccch.sql
rem   Developer........: Urs Meier (urm) urs.meier@trivadis.com
rem   Date.............: 01.03.1996
rem   Version..........: Oracle9i - 2.0
rem   Usage............: Show Dictionary Cache statistics and use in 
rem                      the shared pool
rem   Input parameters.:
rem   Output.......... : 
rem   Called by........:
rem   Remarks..........:
rem -----------------------------------------------------------------------
rem
rem $Log$
rem Revision 1.3  2002/09/09 16:56:24  far
rem 9.2 f�hig checked by ThJ
rem
rem Revision 1.2  2001/07/22 12:59:28  ank
rem - Load initial release Oracle9i 9.0.x
rem
rem
rem
rem Changes:
rem DD.MM.YYYY Consultant Change
rem -----------------------------------------------------------------------
rem 05.04.1997	urs.meier Rename
rem 02.08.1997  AnK       Oracle8
rem 20.04.1999  AnK       OK for Oracle8i - Changed Output
rem 02.09.2002  ThJ       OK for Oracle9i R2
rem -----------------------------------------------------------------------
rem
rem
set logsource "dummy"
store set temp.tmp replace
@@foenvtit "Dictionary cache usage and hit ratio"
set pages 35
column misses format 990.0 heading "Misses %"
select PARAMETER,COUNT,USAGE, GETMISSES/decode(GETS,0,1,gets)*100 as Misses
from v$rowcache
order by Misses desc;

column misses clear
ttitle off
@@fopauoff
@@temp.tmp
