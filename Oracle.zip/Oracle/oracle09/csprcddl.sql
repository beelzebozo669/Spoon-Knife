rem -------------------------------------------------------------------------
rem        Trivadis AG, Baden/Basel/Bern/Lausanne/Mellingen/Z�rich
rem                     Frankfurt/Freiburg i.Br./M�nchen/Stuttgart
rem                     Switzerland/Germany Internet: http://www.trivadis.com
rem -------------------------------------------------------------------------
rem $Header$
rem   **********************************************************************
rem   Group/Privileges.: SYS
rem   Script-Name......: csprcddl.sql
rem   Developer........: Sandro Crepaldi (sandro.crepaldi@trivadis.com)
rem   Date.............: September 2001
rem   Version..........: Oracle9i
rem   Usage............: Generates DDL using dbms_metadata
rem   Input parameters.: TableName or Wildcard, PStorage TRUE if storage clause is
rem                      required
rem   Output.......... : *.tab-File (def.tab, if % (all tables) has been selected
rem   Called by........:
rem   Requirements.....: Oracle9i
rem                      note that the 1st param. (dir. path) must be
rem                      included in the database's UTL_FILE_DIR init. parameter.
rem                      If there is none, than the fopen will fail...
rem			 i.e.: utl_file_dir = '/tmp'
rem                      if utl_file_dir = several directories, the first one will
rem                      be taken. If utl_file_dir = * you must specify the directory 
rem                      in the variable dirName in this file
rem
rem                      The package must be run under the table owner.
rem                      The table owner must have execute privilege to the package
rem
rem   **********************************************************************
rem
rem $Log$
rem Revision 1.2  2002/09/09 16:56:24  far
rem 9.2 f�hig checked by ThJ
rem
rem Revision 2.0  2002/09/04 ThJ
rem - OK for Oracle9i R2
rem Revision 1.1  2001/10/23 04:25:17  ank
rem - initial load Oracle9i (new script), SaC
rem
rem
SET ECHO OFF FEEDBACK OFF



CLEAR SCREEN

REM 
REM Retrieving Tables and their Indexes as DDL for all tables in the current schema 
REM For each table it also returns the creation DDL for the indexes defined on the table. 
REM The returned DDL is written to an output file.

CREATE OR REPLACE PACKAGE tvd_metadata
AUTHID CURRENT_USER
AS
   PROCEDURE get_tables (PTableName IN VARCHAR2 DEFAULT 'EMP',
                         PStorage   IN BOOLEAN DEFAULT TRUE);
END;
/
show errors



CREATE OR REPLACE PACKAGE BODY tvd_metadata
AS
-- Global Variables
   fileHandle   UTL_FILE.FILE_TYPE;

-- Exception initialization
   file_not_found EXCEPTION;
   PRAGMA EXCEPTION_INIT(file_not_found, -1309);


-- Package-private routine to write a CLOB to an output file.

	PROCEDURE write_lob(doc IN CLOB) IS

	     outString     	varchar2(32760);
	     cloblen		number;
	     offset		number := 1;
	     amount		number;

	BEGIN
	  cloblen := dbms_lob.getlength(doc);

	  WHILE cloblen > 0
	  LOOP
	    IF cloblen > 32760 THEN
	       amount := 32760;
	    ELSE
	       amount := cloblen;
	    END IF;

	    outString := dbms_lob.substr(doc, amount, offset);
	    utl_file.put(fileHandle, outString);
	    utl_file.fflush(fileHandle);
	    offset  := offset  + amount;
	    cloblen := cloblen - amount;
	    
	  END LOOP;

	  RETURN;
	END write_lob;


-- GET_TABLES: Fetch DDL for tables and their indexes.

PROCEDURE get_tables    (PTableName IN VARCHAR2 DEFAULT 'EMP',
                         PStorage   IN BOOLEAN DEFAULT TRUE)
AS
tableOpenHandle		      NUMBER;
indexOpenHandle		      NUMBER;
tableTransHandle	      NUMBER;
indexTransHandle	      NUMBER;
schemaName		      VARCHAR2(30);
tableName		      VARCHAR2(30);
tableDDLs		      sys.ku$_ddls;
tableDDL		      sys.ku$_ddl;
parsedItems		      sys.ku$_parsed_items;
indexDDL		      CLOB;
fileName                      varchar2(100) := NVL(replace(PTableName,'%',''),'DEF') || '.tab';
dirName                       VARCHAR2(100) := 'C:\temp';
vdirectory                    VARCHAR2(100);

/* Internal function to find the first valid directory for utl_file.
   * There can be more than one.
   * If UTL_FILE_DIR = '*', than the directory specified in the variable dirName
   * in this procedure must be specified.
   * If there is none, than the fopen will fail..., so make sure that
   * there is one...
   */

  FUNCTION utl_file_dir
  RETURN VARCHAR2 IS
  BEGIN
    BEGIN
      SELECT value
        INTO vDirectory
        FROM v$parameter
       WHERE name = 'utl_file_dir';
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        vDirectory := NULL;
    END;

    IF (INSTR(vDirectory,',') > 0) THEN
      vDirectory := SUBSTR(vDirectory,1,INSTR(vDirectory,',')-1);
    END IF;
    IF (vDirectory = '*') THEN
     vDirectory := dirName;
    END IF;

    RETURN(TRIM(vDirectory));

  END utl_file_dir;


BEGIN
 -- open the output file... note that the 1st param. (dir. path) must be
-- included in the database's UTL_FILE_DIR init. parameter.
   BEGIN
    fileHandle := UTL_FILE.fopen(utl_file_dir, fileName, 'w', 32760);
   EXCEPTION
    WHEN OTHERS THEN
	RAISE file_not_found;
   END;

-- Open a handle for tables in the current schema.
   tableOpenHandle := DBMS_METADATA.OPEN('TABLE');

-- Call 'set_count' to request retrieval of one table at a time. 
-- This call is not actually necessary since 1 is the default.
   DBMS_METADATA.SET_COUNT(tableOpenHandle, 1);

-- Retrieve tables whose name starts with 'p_table_name%'. When the filter is
-- 'NAME_EXPR', the filter value string must include the SQL operator. This
-- gives the caller flexibility to use LIKE, IN, NOT IN, subqueries, etc.
   DBMS_METADATA.set_filter(tableOpenHandle, 'NAME_EXPR', 'LIKE ' || '''' || PTableName || '''');

-- Tell Metadata API to parse out each table's schema and name separately
-- so we can use them to set up the calls to retrieve its indexes or triggers.
   DBMS_METADATA.set_parse_item(tableOpenHandle, 'SCHEMA');
   DBMS_METADATA.set_parse_item(tableOpenHandle, 'NAME');

-- Add the DDL transform so we get SQL creation DDL
   tableTransHandle := DBMS_METADATA.add_transform(tableOpenHandle, 'DDL');

-- Tell the XSL stylesheet we want physical storage information (storage,tablespace, etc)
   DBMS_METADATA.set_transform_param(tableTransHandle,'SEGMENT_ATTRIBUTES', PStorage);
-- we want a SQL terminator on each DDL.
   DBMS_METADATA.set_transform_param(tableTransHandle,'SQLTERMINATOR', TRUE);

LOOP
   tableDDLs := DBMS_METADATA.fetch_ddl(tableOpenHandle);  
   EXIT WHEN tableDDLs IS NULL;   -- Get out when no more tables

-- First, write the CREATE TABLE text to our output file, then retrieve the
-- parsed schema and table names.
   tableDDL := tableDDLs(1);
   write_lob(tableDDL.ddltext);
   parsedItems := tableDDL.parsedItems;

-- Must check the name of the returned parse items as ordering isn't guaranteed
   FOR i IN 1..2 LOOP
      IF parsedItems(i).item = 'SCHEMA'
      THEN
        schemaName := parsedItems(i).value;
      ELSE
        tableName  := parsedItems(i).value;
      END IF;
   END LOOP;

-- Then use the schema and table names to set up a 2nd stream for retrieval of
-- the current table's indexes.
   indexOpenHandle := DBMS_METADATA.open('INDEX');
   DBMS_METADATA.set_filter(indexOpenHandle,'BASE_OBJECT_SCHEMA',schemaName);
   DBMS_METADATA.set_filter(indexOpenHandle,'BASE_OBJECT_NAME',tableName);

-- Add the DDL/XML transform and set the same transform options we did for tables
   indexTransHandle := DBMS_METADATA.add_transform(indexOpenHandle, 'DDL');
   DBMS_METADATA.set_transform_param(indexTransHandle,'SEGMENT_ATTRIBUTES', PStorage);
   DBMS_METADATA.set_transform_param(indexTransHandle,'SQLTERMINATOR', TRUE);

-- Retrieve index DDLs as CLOBs and write them to the output file.
   LOOP
      indexDDL := DBMS_METADATA.fetch_clob(indexOpenHandle);
      EXIT WHEN indexDDL IS NULL;
      write_lob(indexDDL);
   END LOOP;

-- Free resources allocated for index stream.
   DBMS_METADATA.close(indexOpenHandle);

END LOOP;

-- Free resources allocated for table stream and close output file.
   DBMS_METADATA.close(tableOpenHandle);
   UTL_FILE.fclose(fileHandle);
   RETURN;

EXCEPTION
   WHEN OTHERS THEN

        DBMS_OUTPUT.put_line ('File ' || dirName || '/' || fileName || ' not found!');
        IF (UTL_FILE.Is_Open(fileHandle)) THEN
           UTL_FILE.FClose(fileHandle);
        END IF;

END get_tables;

END tvd_metadata;
/

show errors

grant execute on tvd_metadata to public;
drop public synonym tvd_metadata;
create public synonym tvd_metadata for tvd_metadata;

prompt
prompt Sample Usage: EXECUTE tvd_metadata.get_tables (PTableName => 'EMP%', PStorage => TRUE);
prompt
prompt (SET SERVEROUTPUT ON first)
prompt
prompt CONNECT under the TABLE OWNER first
prompt

set echo on feedback on;

