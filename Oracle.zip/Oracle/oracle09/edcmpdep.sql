rem -------------------------------------------------------------------------
rem        Trivadis AG, Baden/Basel/Bern/Lausanne/Mellingen/Z�rich
rem                     Frankfurt/Freiburg i.Br./M�nchen/Stuttgart
rem                     Switzerland/Germany Internet: http://www.trivadis.com
rem -------------------------------------------------------------------------
rem   $Header$
rem   **********************************************************************
rem   Group/Privileges.: DBA
rem   Script-Name......: edcmpdep.sql
rem   Developer........: Andri Kisseleff (ank) andri.kisseleff@trivadis.com
rem   Date.............: 07.01.1994
rem   Version..........: Oracle9i  2.1
rem   Usage............: show and compile dependent objects
rem   Input parameters.:
rem   Output.......... : 
rem   Called by........:
rem   Remarks..........: run cscmpdep.sql once first under SYS
rem -----------------------------------------------------------------------
rem
rem $Log$
rem Revision 1.3  2002/09/09 16:56:24  far
rem 9.2 f�hig checked by ThJ
rem
rem Revision 1.2  2001/07/22 12:59:28  ank
rem - Load initial release Oracle9i 9.0.x
rem
rem
rem Changes:
rem DD.MM.YYYY Consultant Change
rem -----------------------------------------------------------------------
rem 21.09.1997 ank        Oracle8. Fixed bug. Not select ideptree, but
rem                       SYS.VCMPDEP$TMP
rem 20.04.1999 AnK        OK for Oracle8i
rem 04.09.2002 ThJ        OK for Oracle9i R2
rem -----------------------------------------------------------------------
rem
rem
SET VERIFY OFF ECHO OFF
ACCEPT OWNER		CHAR	PROMPT 'Owner of table or View: '
ACCEPT TABLE_NAME	CHAR	PROMPT 'Name (table, view)    : '
ACCEPT TABLE_VIEW	CHAR	PROMPT 'Type: TABLE or VIEW   : '
REM
EXECUTE SYS.cmpdep(UPPER('&TABLE_VIEW'),UPPER('&OWNER'),UPPER('&TABLE_NAME'));
REM
	SELECT	* FROM SYS.VCMPDEP$TMP
	UNION
	SELECT 	' ...SYNONYM '||OWNER||'.'||SYNONYM_NAME
	FROM 	DBA_SYNONYMS
	WHERE	(OWNER = UPPER ('&OWNER') OR OWNER = 'PUBLIC')
	AND 	TABLE_NAME = UPPER('&TABLE_NAME')
	ORDER BY 1 DESC
/
SET PAGES 0 FEED OFF ECHO OFF
SPOOL escmpdep.tmp
	SELECT 	'ALTER '||decode(TYPE,'PACKAGE BODY','PACKAGE',TYPE)||' '||
	SCHEMA||'.'||NAME||' COMPILE '||
	decode(TYPE,'PACKAGE BODY','BODY',NULL)||';'
	FROM 	SYS.CMPDEP1$TMP D, SYS.DBA_OBJECTS O
	WHERE	TYPE NOT IN ('TABLE','CURSOR')
        AND     D.SCHEMA = O.OWNER
	AND     D.TYPE = O.OBJECT_TYPE
	AND     D.NAME = O.OBJECT_NAME
	AND     O.STATUS = 'INVALID'
	ORDER BY NESTED_LEVEL
/
SPOOL OFF
SET FEED ON PAGES 24 ECHO ON
@escmpdep.tmp
SET VERIFY ON ECHO OFF
UNDEFINE OWNER
UNDEFINE TABLE_NAME
UNDEFINE TABLE_VIEW
