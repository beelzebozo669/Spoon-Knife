rem -------------------------------------------------------------------------
rem        Trivadis AG, Baden/Basel/Bern/Lausanne/Mellingen/Z�rich
rem                     Frankfurt/Freiburg i.Br./M�nchen/Stuttgart
rem                     Switzerland/Germany Internet: http://www.trivadis.com
rem -------------------------------------------------------------------------
rem   $Header$
rem   **********************************************************************
rem   Group/Privileges.: DBA
rem   Script-Name......: cdpckprv.sql
rem   Developer........: Andri Kisseleff (ank) andri.kisseleff@trivadis.com
rem   Date.............: 15.11.1995
rem   Version..........: 9i - 1.0
rem   Usage............: creates a package in any schema as to use GRANT
rem                      and REVOKE commands with the privileges of the object
rem                      owner.
rem   Input parameters.:
rem   Output.......... :
rem   Called by........:
rem   Remarks..........: Parameter 4 is optional: TRUE = WITH GRANT OPTION
rem
rem	  Examples: (once the package created)
rem
rem begin
rem  scott.pck_grant.prc_grant('SELECT,INSERT','EMP','IKISS',TRUE);
rem end;
rem	/
rem
rem	begin
rem	 scott.pck_grant.prc_grant('ALL','DEPT','PUBLIC');
rem	end;
rem	/
rem
rem	begin
rem	 scott.pck_grant.prc_revoke('ALL','DEPT','PUBLIC');
rem	end;
rem	/
rem
rem -----------------------------------------------------------------------
rem
rem $Log$
rem Revision 1.3  2002/08/30 13:16:09  far
rem getestet/angepasst f�r 9.2
rem
rem Revision 1.2  2001/07/22 12:59:28  ank
rem - Load initial release Oracle9i 9.0.x
rem
rem
rem Changes:
rem DD.MM.YYYY Consultant Change
rem 02.08.1997 ank        Oracle8
rem 20.04.1999 AnK        OK for Oracle8i
rem 09.11.1999 ClK        prc_execute: use EXECUTE IMMEDIATE
rem                                    instead of cursor declaration 
rem 27.08.2002 MaW        Test for 9iR2
rem -----------------------------------------------------------------------
rem
rem -----------------------------------------------------------------------
rem

accept owner prompt "Owner of package pck_grant: "
rem
CREATE OR REPLACE PACKAGE &&owner..pck_grant IS

v_option   	VARCHAR2(20)   default NULL;
v_statement     VARCHAR2(2000) default NULL;

procedure prc_grant (p_privilege IN VARCHAR2,
                     p_object    IN VARCHAR2,
                     p_grantee   IN VARCHAR2,
                     p_option    IN BOOLEAN  DEFAULT FALSE);

--
-- Privileges an einen User vergeben (ab einem DBA, nicht connected
-- als der Objekt-Besitzer)
--
--  p_privilege ==> 'SELECT,INSERT'
--  p_object    ==> 'EMP'
--  p_grantee   ==> 'MEIER'
--  p_option    ==> TRUE ergibt with grant option.


procedure prc_revoke (p_privilege IN VARCHAR2,
                      p_object    IN VARCHAR2,
                      p_grantee   IN VARCHAR2);


END pck_grant;
/

CREATE OR REPLACE PACKAGE BODY &&owner..pck_grant IS

procedure prc_execute (v_statement IN VARCHAR2) IS

BEGIN

  execute immediate v_statement;

EXCEPTION
  WHEN OTHERS THEN
    dbms_output.put_line(SUBSTR(SQLERRM,1,200));

END prc_execute;

procedure prc_grant (p_privilege IN VARCHAR2,
                     p_object    IN VARCHAR2,
                     p_grantee   IN VARCHAR2,
                     p_option    IN BOOLEAN DEFAULT FALSE) IS

BEGIN
  IF ( NOT p_option)
    THEN v_option := '';
    ELSE v_option := 'WITH GRANT OPTION';
  END IF;
  v_statement := 'GRANT '||p_privilege||
          ' ON '  ||p_object||
          ' TO '  ||p_grantee||
          ' '     ||v_option;

  DBMS_OUTPUT.PUT_LINE(v_statement); -- fuer Debug
  prc_execute(v_statement);

end prc_grant;

procedure prc_revoke (p_privilege IN VARCHAR2,
                      p_object    IN VARCHAR2,
                      p_grantee   IN VARCHAR2) IS

BEGIN
  v_statement := 'REVOKE '||p_privilege||
          ' ON '   ||p_object||
          ' FROM ' ||p_grantee;

  DBMS_OUTPUT.PUT_LINE(v_statement); -- fuer Debug
  prc_execute(v_statement);

end prc_revoke;


end pck_grant;
/

undefine owner
prompt
prompt Usage Example: execute scott.pck_grant.prc_grant('SELECT,INSERT','EMP','ADAMS',TRUE);
prompt
prompt (GRANT SELECT,INSERT ON SCOTT.EMP TO ADAMS WITH GRANT OPTION;)
prompt
