rem -------------------------------------------------------------------------
rem        Trivadis AG, Baden/Basel/Bern/Lausanne/Mellingen/Z�rich
rem                     Frankfurt/Freiburg i.Br./M�nchen/Stuttgart
rem                     Switzerland/Germany Internet: http://www.trivadis.com
rem -------------------------------------------------------------------------
rem   $Header$
rem   **********************************************************************
rem   Group/Privileges.: User
rem   Script-Name......: sooraerr.sql
rem   Developer........: Urs Meier (urm) urs.meier@trivadis.com
rem   Date.............: 28.02.1996
rem   Version..........: Oracle9i - 2.0
rem   Usage............: Displays error text for an error number
rem   Input parameters.: error number
rem   Output.......... : 
rem   Called by........:
rem   Remarks..........: Example: @sooraerr 942
rem -----------------------------------------------------------------------
rem
rem $Log$
rem Revision 1.3  2002/09/09 16:56:24  far
rem 9.2 f�hig checked by ThJ
rem
rem Revision 1.2  2001/07/22 12:59:28  ank
rem - Load initial release Oracle9i 9.0.x
rem
rem
rem
rem Changes:
rem DD.MM.YYYY Consultant Change
rem 
rem -----------------------------------------------------------------------
rem 05.04.1997 urs.meier  rename
rem 02.08.1997 ank        Oracle8
rem 21.04.1999 AnK        OK for Oracle8i
rem 03.09.2002 ThJ        OK for Oracle9i R2
rem -----------------------------------------------------------------------
rem
rem
rem
set serveroutput on verify off feedback off
execute dbms_output.put_line(sqlerrm(-&1));
set serveroutput off feedback on

