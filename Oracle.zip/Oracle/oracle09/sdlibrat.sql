rem -------------------------------------------------------------------------
rem        Trivadis AG, Baden/Basel/Bern/Lausanne/Mellingen/Z�rich
rem                     Frankfurt/Freiburg i.Br./M�nchen/Stuttgart
rem                     Switzerland/Germany Internet: http://www.trivadis.com
rem -------------------------------------------------------------------------
rem   $Header$
rem   **********************************************************************
rem   Group/Privileges.: DBA
rem   Script-Name......: sdlibrat.sql
rem   Developer........: Urs Meier (urm) urs.meier@trivadis.com
rem   Date.............: 1995
rem   Version..........: Oracle9i - 2.0
rem   Usage............: Library Hit Ratio (Shared Pool Tuning)
rem   Input parameters.:
rem   Output.......... : 
rem   Called by........:
rem   Remarks..........: 100% HIT and little reloads/invalidations are best
rem -----------------------------------------------------------------------
rem
rem $Log$
rem Revision 1.3  2002/08/30 13:16:09  far
rem getestet/angepasst f�r 9.2
rem
rem Revision 1.2  2001/07/22 12:59:28  ank
rem - Load initial release Oracle9i 9.0.x
rem
rem
rem
rem Changes:
rem DD.MM.YYYY Consultant Change
rem -----------------------------------------------------------------------
rem 02.08.1997 ank        Oracle8
rem 20.04.1999 AnK        OK for Oracle8i
rem 27.08.2002 MaW        OK for Oracle9i R2
rem -----------------------------------------------------------------------
rem
rem
column gethitratio format 990.99
column pinhitratio format 990.99
@@foenvtit "Library cache hit ratio"
@@fopauon
select namespace,gethitratio,pinhitratio,reloads,invalidations
  from v$librarycache;

column gethitratio clear
column pinhitratio clear
ttitle off
@@fopauoff


