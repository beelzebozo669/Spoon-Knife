rem -------------------------------------------------------------------------
rem        Trivadis AG, Baden/Basel/Bern/Lausanne/Mellingen/Z�rich
rem                     Frankfurt/Freiburg i.Br./M�nchen/Stuttgart
rem                     Switzerland/Germany Internet: http://www.trivadis.com
rem -------------------------------------------------------------------------
rem   $Header$
rem   **********************************************************************
rem   Bereich.........: DBA, replication option, job queues
rem   Name............: sdjob.sql 
rem   Entwickler......: Andri Kisseleff (ank) andri.kisseleff@trivadis.com
rem   Datum...........: 12.09.1995
rem   Version.........: Oracle9i - 2.0
rem   Zweck...........: show jobs in the job queue (dba)
rem   Input Parameter.:
rem   Output..........:
rem   Wird aufgerufen.:
rem   Bemerkung.......: must be run as a dba
rem			TOTAL_TIME  in seconds
rem			LOG_USER  : USER who was logged in when the job 
rem			            was submitted
rem                     PRIV_USER:  USER whose default privileges apply 
rem                                 to this job
rem			SCHEMA_USER: select * from bar  means  
rem				     select * from schema_user.bar
set echo off termout on
rem =======================================================================
rem
rem $Log$
rem Revision 1.3  2002/09/09 16:56:24  far
rem 9.2 f�hig checked by ThJ
rem
rem Revision 1.2  2001/07/22 12:59:28  ank
rem - Load initial release Oracle9i 9.0.x
rem
rem
rem
rem   Aenderungen:
rem     DD.MM.YYYY Entwickler Change  
rem =======================================================================
rem     02.08.1997 ank        Oracle8
rem     20.04.1999 AnK        OK for Oracle8i
rem     03.09.2002 ThJ        OK for Oracle9i R2
rem =======================================================================
rem
col date_time noprint new_value date_time
col log_user format a20 trunc
col priv_user format a20 trunc
col schema_user format a20 trunc
col job format 99999
col failures format 999 heading FAIL
col broken format a6
set echo off termout off pause off array 1
@@foenvtit "All Schemas Jobs in Job-Queue"
set termout on
set pages 1000 verify off lines 80 timing off
spool sdjob.lis
select 	job, log_user, priv_user, schema_user, total_time,
        last_date, last_sec, this_sec, 
        next_date, next_sec, broken, failures,
        interval, what 
from    sys.dba_jobs
order by next_date, next_sec, log_user;
spool off
prompt
prompt	sdjob.lis has been spooled
prompt
col date_time clear
col log_user clear
col priv_user clear
col schema_user clear
col job clear
col failures clear
col broken clear
ttitle off
set pause off verify on pages 24
rem
rem ================================= eof =============================
