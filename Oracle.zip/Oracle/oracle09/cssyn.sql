rem -------------------------------------------------------------------------
rem        Trivadis AG, Baden/Basel/Bern/Lausanne/Mellingen/Z�rich
rem                     Frankfurt/Freiburg i.Br./M�nchen/Stuttgart
rem                     Switzerland/Germany Internet: http://www.trivadis.com
rem -------------------------------------------------------------------------
rem   $Header$
rem   **********************************************************************
rem   Group/Privileges.:  DBA
rem   Script-Name......:  cssyn.sql
rem   Developer........:  Ingo Frost   ingo.frost@trivadis.com
rem   Date.............:  01.10.2001
rem   Version..........:  Oracle9i - 2.0
rem   Usage............:  creates view TVD_SYNONYMS, Better than DBA_SYNONYMS 
rem   Input parameters.:  
rem   Output.......... :
rem   Called by........:  needed by sdsyn.sql and sdsynerr.sql
rem   Remarks..........:  shows object_type of destination 
rem                       and if the synonym points to nowhere
rem
rem   History: 
rem 
rem   $Log$
rem   Revision 1.3  2002/08/30 13:16:09  far
rem   getestet/angepasst f�r 9.2
rem
rem   Revision 1.2  2001/10/31 16:25:22  ank
rem   no message
rem
rem   Revision 1.1  2001/10/31 16:21:17  ank
rem   - initial load to CVS (Oracle9i), InF
rem
rem
rem -----------------------------------------------------------------------
rem When        Who  What
rem 2002-08-27  MaW  Ok for Oracle9i R2
rem -----------------------------------------------------------------------
rem
rem

create or replace view tvd_synonyms 
as
select  m.owner, m.SYNONYM_NAME, m.TABLE_OWNER object_owner, 
        m.table_name object_name, 
        nvl(m.object_type,m.pub_syn) object_type
from ( select s.owner, s.SYNONYM_NAME, s.TABLE_OWNER, s.table_name,
        decode(o.object_type ,
                'SYNONYM','PRIVATE SYNONYM',
                o.object_type) object_type,
        decode(o1.object_type,
                'SYNONYM','PUBLIC SYNONYM',
                null,'n/a',
                o1.object_type) pub_syn
        from dba_objects o , dba_synonyms s , dba_objects o1
        where o.owner(+)=s.table_owner
        and o.object_name(+)=s.table_name
        and o.object_type(+) not in ('QUEUE','PACKAGE BODY')
        and o1.object_name(+)=s.table_name
        and o1.object_type(+) ='SYNONYM'
        and o1.owner(+) ='PUBLIC' ) m ;

drop public synonym tvd_synonyms;
create public synonym tvd_synonyms for sys.tvd_synonyms;
grant select on tvd_synonyms to select_catalog_role;

prompt 
prompt The view tvd_synonyms has been created
prompt

