rem -------------------------------------------------------------------------
rem        Trivadis AG, Baden/Basel/Bern/Lausanne/Mellingen/Z�rich
rem                     Frankfurt/Freiburg i.Br./M�nchen/Stuttgart
rem                     Switzerland/Germany Internet: http://www.trivadis.com
rem -------------------------------------------------------------------------
rem   $Header$
rem   **********************************************************************
rem   Group/Privileges.: DBA (sys)
rem   Script-Name......: ssinipar.sql
rem   Developer........: Andri Kisseleff (ank) andri.kisseleff@trivadis.com
rem   Date.............: July 1996
rem   Version..........: Oracle9i - 2.0
rem   Usage............: Show Instance and Session Values of Parameters
rem   Input parameters.: Parameter or Wildcard
rem   Output.......... : 
rem   Called by........:
rem   Remarks..........: Requires 7.3 or higher
rem -----------------------------------------------------------------------
rem Changes:
rem
rem $Log$
rem Revision 1.3  2002/08/30 13:16:09  far
rem getestet/angepasst f�r 9.2
rem
rem Revision 1.2  2001/07/22 12:59:28  ank
rem - Load initial release Oracle9i 9.0.x
rem
rem
rem 
rem -----------------------------------------------------------------------
rem 02.08.1997 AnK        Oracle8 + added SESSION Modifiable + INSTANCE Mod.
rem                       Session Value only shown if modifyable
rem 21.04.1999 AnK        OK for Oracle8i
rem 08.27.2002 ChA        OK for Oracle9i R2
rem -----------------------------------------------------------------------
rem
rem
set logsource "dummy"
store set temp.tmp replace
set pages 100 verify off
col "Parameter" format a40 trunc
col "Session" format a8 trunc
col "Instance" format a8 trunc
col "S-Mod" format a5 trunc
col "I-Mod" format a5 trunc
@@foenvtit "INIT.ORA Parameter"
  select  a.ksppinm  "Parameter",
  decode(p.isses_modifiable,'FALSE',NULL,NULL,NULL,b.ksppstvl) "Session",
  c.ksppstvl "Instance",
  p.isses_modifiable "S-Mod",
  p.issys_modifiable "I-Mod"
     from x$ksppi a, x$ksppcv b, x$ksppsv c, v$parameter p
    where a.indx = b.indx and a.indx = c.indx
      and p.name(+) = a.ksppinm
      and upper(a.ksppinm) like upper('%&Parameter%')
  order by a.ksppinm
/
ttitle off
col "Parameter" clear
col "Session" clear
col "Instance" clear
col "S-Mod" clear
col "I-Mod" clear
undefine parameter
@temp.tmp

