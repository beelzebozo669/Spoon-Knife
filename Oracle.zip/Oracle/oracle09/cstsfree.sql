rem -------------------------------------------------------------------------
rem        Trivadis AG, Baden/Basel/Bern/Lausanne/Mellingen/Z�rich
rem                     Frankfurt/Freiburg i.Br./M�nchen/Stuttgart
rem                     Switzerland/Germany Internet: http://www.trivadis.com
rem -------------------------------------------------------------------------
rem   $Header$
rem   **********************************************************************
rem   Group/Privileges.: SYS
rem   Script-Name......: cstsfree.sql
rem   Developer........: Andri Kisseleff (ank) andri.kisseleff@trivadis.com
rem   Date.............: 01.2001
rem   Version..........: Oracle9i - 1.1
rem   Usage............: create view tsfree under DBA account
rem                      (free space per tablespace)
rem   Input parameters.:
rem   Output.......... : 
rem   Called by........:
rem   Remarks..........: Use also sdts.sql
rem -----------------------------------------------------------------------
rem
rem $Log$
rem Revision 1.3  2002/08/30 13:16:09  far
rem getestet/angepasst f�r 9.2
rem
rem Revision 1.2  2001/07/22 12:59:28  ank
rem - Load initial release Oracle9i 9.0.x
rem
rem
rem
rem Changes:
rem DD.MM.YYYY Consultant Change
rem -----------------------------------------------------------------------
rem 18.06.1996 ank	  Title and new header
rem 02.08.1997 ank        Oracle8
rem 18.01.2001 maw        Oracle8i, used sdts.sql as base for rewrite
rem 27.08.2002 maw        Ok for Oracle9i R2
rem -----------------------------------------------------------------------
rem
rem
CREATE OR REPLACE VIEW tsfree
as
SELECT dt.tablespace_name,substr(dt.status,1,2)||substr(contents,1,1) STATUS,
       dt.extent_management, dt.allocation_type,
       CASE
         WHEN 'YES' in (SELECT autoextensible FROM dba_data_files
                        WHERE dba_data_files.tablespace_name = dt.tablespace_name)
         THEN 'Y'
         ELSE 'N'
       END AS auto,
       dt.logging,
       t.t,nvl(u.s,0) s, nvl(u.s/t.t*100,0) p,nvl(u.m,0) m,nvl(u.c,0) c
  FROM dba_tablespaces dt,
       (SELECT tablespace_name,SUM(bytes) s, MAX(bytes) m, COUNT(*) c
          FROM dba_free_space
         GROUP BY tablespace_name) u,
       (SELECT tablespace_name,SUM(bytes) t
          FROM dba_data_files
         GROUP BY tablespace_name) t
 WHERE dt.tablespace_name = u.tablespace_name(+)
   AND dt.tablespace_name = t.tablespace_name
 UNION
SELECT dt.tablespace_name,substr(dt.status,1,2)||substr(contents,1,1) STATUS,
       dt.extent_management, dt.allocation_type,
       CASE
         WHEN 'YES' in (SELECT autoextensible FROM dba_temp_files
                         WHERE dba_temp_files.tablespace_name = dt.tablespace_name)
         THEN 'Y'
         ELSE 'N'
       END AS auto,
       dt.logging,
       t.t,t.t-nvl(u.s,0) s, ((t.t-nvl(u.s,0))/t.t*100) p, null m,null c
  FROM dba_tablespaces dt,
       (SELECT tablespace_name,SUM(bytes_cached) s
          FROM v$temp_extent_pool
         GROUP BY tablespace_name) u,
       (SELECT tablespace_name,SUM(bytes) t
          FROM dba_temp_files
         GROUP BY tablespace_name) t
 WHERE dt.tablespace_name = u.tablespace_name(+)
   AND dt.tablespace_name = t.tablespace_name
 ORDER BY 1;
prompt 
prompt The view tsfree has been created
prompt
