rem -------------------------------------------------------------------------
rem        Trivadis AG, Baden/Basel/Bern/Lausanne/Mellingen/Z�rich
rem                     Frankfurt/Freiburg i.Br./M�nchen/Stuttgart
rem                     Switzerland/Germany Internet: http://www.trivadis.com
rem -------------------------------------------------------------------------
rem  $Header$
rem   **********************************************************************
rem   Group/Privileges.: Connected User
rem   Script-Name......: sousrinf.sql
rem   Developer........: Sven Vetter (SvV) Sven.Vetter@trivadis.com
rem   Date.............: 15.08.2002
rem   Version..........: Oracle8i - Oracle 9i
rem   Usage............: Shows information about the connected user
rem   Input parameters.: 
rem   Output.......... : 
rem   Called by........: 
rem   Remarks..........: User must have select rights on v$session
rem -------------------------------------------------------------------------
rem HISTORY:
rem
rem -------------------------------------------------------------------------
rem Changes:
rem $Log$
rem Revision 1.2  2002/10/06 14:26:52  far
rem Header/Log eingef�gt
rem
rem DD.MM.YYYY Consultant Change
rem -------------------------------------------------------------------------
rem -------------------------------------------------------------------------
rem
rem =========================================================================
rem
rem
set echo off
SET serveroutput on size 10000
DECLARE
  vSessionRec  v$session%ROWTYPE;
BEGIN
  SELECT * INTO vSessionRec 
    FROM v$session 
    WHERE audsid=USERENV('sessionid') AND type='USER' AND rownum<2;
    
  dbms_output.put_line('Database Information');
  dbms_output.put_line('--------------------');
  dbms_output.put_line('- DB_NAME            : '||sys_context('userenv','DB_NAME'));
  dbms_output.put_line('- DB_DOMAIN          : '||sys_context('userenv','DB_DOMAIN'));
  dbms_output.put_line('- INSTANCE           : '||sys_context('userenv','INSTANCE'));
  dbms_output.put_line('- HOST               : '||sys_context('userenv','HOST'));
  dbms_output.put_line('-');

  dbms_output.put_line('Authentification Information');
  dbms_output.put_line('----------------------------');
  dbms_output.put_line('- SESSION_USER       : '||sys_context('userenv','SESSION_USER'));
  dbms_output.put_line('- CURRENT_USER       : '||sys_context('userenv','CURRENT_USER'));
  dbms_output.put_line('- PROXY_USER         : '||sys_context('userenv','PROXY_USER'));
  dbms_output.put_line('- AUTHENTICATION_TYPE: '||sys_context('userenv','AUTHENTICATION_TYPE'));
  dbms_output.put_line('- NETWORK_PROTOCOL   : '||sys_context('userenv','NETWORK_PROTOCOL'));
  dbms_output.put_line('- EXTERNAL_NAME      : '||sys_context('userenv','EXTERNAL_NAME'));
  dbms_output.put_line('- OS_USER            : '||sys_context('userenv','OS_USER'));
  dbms_output.put_line('-');

  dbms_output.put_line('Other Information');
  dbms_output.put_line('-----------------');
  dbms_output.put_line('- ISDBA              : '||sys_context('userenv','ISDBA'));
  dbms_output.put_line('- CLIENT_INFO        : '||sys_context('userenv','CLIENT_INFO'));
  dbms_output.put_line('- PROGRAM            : '||vSessionRec.program);
  dbms_output.put_line('- MODULE             : '||vSessionRec.module);
  dbms_output.put_line('- IP_ADDRESS         : '||sys_context('userenv','IP_ADDRESS'));
  dbms_output.put_line('- SID                : '||vSessionRec.sid);
  dbms_output.put_line('- SERIAL#            : '||vSessionRec.serial#);
  dbms_output.put_line('- SERVER             : '||vSessionRec.server);
  dbms_output.put_line('- TERMINAL           : '||sys_context('userenv','TERMINAL'));

 

END;
/
