rem -------------------------------------------------------------------------
rem        Trivadis AG, Baden/Basel/Bern/Lausanne/Mellingen/Z�rich
rem                     Frankfurt/Freiburg i.Br./M�nchen/Stuttgart
rem                     Switzerland/Germany Internet: http://www.trivadis.com
rem -------------------------------------------------------------------------
rem   $Header$
rem   **********************************************************************
rem   Group/Privileges.: DBA
rem   Script-Name......: sddep.sql
rem   Developer........: Andri Kisseleff (ank) andri.kisseleff@trivadis.com
rem   Date.............: 07.01.1994
rem   Version..........: Oracle9i - 2.0
rem   Usage............: Shows dependent objects for a given object
rem   Input parameters.:
rem   Output.......... : 
rem   Called by........:
rem   Remarks..........: cscmpdep.sql must be run previousley under SYS (once)
rem -----------------------------------------------------------------------
rem
rem $Log$
rem Revision 1.3  2002/09/09 16:56:24  far
rem 9.2 f�hig checked by ThJ
rem
rem Revision 1.2  2001/07/22 12:59:28  ank
rem - Load initial release Oracle9i 9.0.x
rem
rem
rem
rem Changes:
rem DD.MM.YYYY Consultant Change
rem -----------------------------------------------------------------------
rem 21.09.1997 ank        Oracle8, removed SELECT * FROM DBA_TRIGGERS
rem                       Fixed bug. Not select ideptree, but
rem                       SYS.VCMPDEP$TMP
rem 20.04.1999 AnK        OK for Oracle8i
rem 02.09.2002 ThJ        OK for Oracle9i R2
rem -----------------------------------------------------------------------
rem
rem
SET VERIFY OFF ECHO OFF
ACCEPT OWNER		CHAR	PROMPT 'Owner of table or view: '
ACCEPT TABLE_NAME	CHAR	PROMPT 'Name (table, view)    : '
ACCEPT TABLE_VIEW	CHAR	PROMPT 'Type (TABLE or VIEW)  : '
REM
EXECUTE SYS.cmpdep(UPPER('&TABLE_VIEW'),UPPER('&OWNER'),UPPER('&TABLE_NAME'));
REM
	SELECT	* FROM SYS.VCMPDEP$TMP
	UNION
	SELECT 	' ...SYNONYM '||OWNER||'.'||SYNONYM_NAME
	FROM 	DBA_SYNONYMS
	WHERE	(OWNER = UPPER ('&OWNER') OR OWNER = 'PUBLIC')
	AND 	TABLE_NAME = UPPER('&TABLE_NAME')
	ORDER BY 1 DESC
/
SET VERIFY ON
UNDEFINE OWNER
UNDEFINE TABLE_NAME
UNDEFINE TABLE_VIEW

