rem -------------------------------------------------------------------------
rem        Trivadis AG, Baden/Basel/Bern/Lausanne/Mellingen/Stuttgart/Z�rich
rem                     Switzerland/Germany Internet: http://www.trivadis.com
rem -------------------------------------------------------------------------
rem   $Header$
rem   Group/Privileges.: dba (select privs on V$PARAMETER)
rem   Script-Name......: spindsta.sql
rem   Developer........: Christian Antognini (ChA) christian.antognini@trivadis.com
rem   Date.............: 31.10.2000
rem   DB Version.......: Oracle9i 2.0
rem   Usage............: Shows index statistics for a given table (or many)
rem   Input parameters.:
rem   Output.......... : 
rem   Called by........:
rem   Remarks..........: dba privileges only for v$parameter view needed +
rem                      INIT.ORA parameter DB_FILE_MULTIBLOCK_READ_COUNT and
rem                      OPTIMIZER_INDEX_COST_ADJ must be correctly configured
rem                      to have good RSL and BGES values
rem -----------------------------------------------------------------------
rem
rem HISTORY:
rem =======================================================================
rem
rem $Log$
rem Revision 1.9  2005/03/20 15:06:14  far
rem Aenderung CHA
rem
rem Revision 1.6  2003/06/17 09:25:39  far
rem correction of MBRC / ChA
rem
rem Revision 1.3  2002/09/18 09:46:25  thj
rem OK for Oracle9i R2 (incl. Composite Range-List Partitioning)
rem
rem Revision 1.3  2002/05/12 09:46:25  far
rem merged changes from ChA 8i version
rem
rem Revision 1.5  2001/04/08 15:54:18  urm
rem check in/out
rem
rem Revision 1.2  2001/01/14 13:29:34  urm
rem Script Renaming
rem
rem Revision 1.1  2001/01/14 13:11:45  urm
rem ChA        rename soindsta.sql to spindsta.sql
rem ChA        aligned with publication
rem
rem Revision 1.1  2000/11/27 17:51:56  urm
rem Creation
rem
rem =======================================================================

set echo off
set verify off
set feedback off
set linesize 120
set pause off

column mbrc noprint new_value mbrc
column oica noprint new_value oica

set termout off

select 1.6765*power(value,0.6581) mbrc from v$parameter where name = 'db_file_multiblock_read_count';
select value oica from v$parameter where name = 'optimizer_index_cost_adj';

set termout on

@@fopauon

column table_name              noprint new_value table_name
column index_name              noprint
column index_position          noprint
column partition_name          noprint
column partition_position      noprint
column subpartition_name       noprint
column subpartition_position   noprint
 
column name                 format a34             heading 'IndexName (Part./Sub-Part.)' 
column locality             format a3              heading 'Loc'
column partitioning_type    format a4              heading 'Part'
column uniqueness           format a3              heading 'Uni'
column nn                   format 999             heading '%NN'
column i_num_rows           format 999G999G999     heading 'IndexKeys'
column distinct_keys        format 999G999G999     heading 'DistKeys'
column rsl                  format 99G999G999      heading 'RSL'
column bges                 format 99G999G999      heading 'BGES'
column prfts                format 99G999G999      heading 'PRFTS'

ttitle skip 1 -
       center 'Index Statistics for Table ' table_name skip 2

break on table_name skip page

prompt 
prompt Please enter table name, wildcards allowed
prompt
prompt e.g.: EMP, emp, E%, e% or %
prompt
accept table_name char prompt "Table Name <%>: " default "%"

--
-- top level
--
select  /*+ ordered 
            no_merge(t) 
            no_merge(i)  use_hash(i)
            no_merge(pi) use_hash(pi) */
        t.table_name,
        i.index_name,
        decode(i.uniqueness,'UNIQUE',1,2) index_position,
        null partition_name,
        0 partition_position,
        null subpartition_name,
        0 subpartition_position,
        i.index_name name,
        decode(pi.locality,'LOCAL','LOC','GLOBAL','GLO',null) locality,
        null partitioning_type,
        decode(i.index_type,
               'BITMAP','BIT',
               'CLUSTER','CLU',
               'IOT - TOP','IOT',
               'LOB','LOB', 
               decode(i.uniqueness,'UNIQUE','YES','NONUNIQUE','NO')
              ) uniqueness,
        i.num_rows/decode(t.num_rows,0,null,t.num_rows)*100 nn,
        i.num_rows i_num_rows,
        i.distinct_keys distinct_keys,
        -- the following 3 columns are computed only for b*tree indexes
        decode(substr(i.index_type,1,6),
               'NORMAL',round(i.num_rows*ceil(t.blocks/'&mbrc')/
                              decode(i.clustering_factor,
                                     0,null,
                                     round(i.clustering_factor+i.leaf_blocks+i.blevel)*&oica/100
                                    )
                             )
              ) rsl,
        decode(substr(i.index_type,1,6),
               'NORMAL',round(i.blevel+
                              greatest(1,i.leaf_blocks/decode(i.distinct_keys,
                                                              0,null,
                                                              i.distinct_keys
                                                             )
                                      )+
                              greatest(1,i.clustering_factor/decode(i.distinct_keys,
                                                                    0,null,
                                                                    i.distinct_keys
                                                                   )
                                      )
                             )
              ) bges,
        decode(substr(i.index_type,1,6),
               'NORMAL',ceil(t.blocks/'&mbrc')
              ) prfts
from  user_tables t,
      user_indexes i,
      user_part_indexes pi
where t.table_name = i.table_name
and   i.index_name = pi.index_name (+)
and   t.table_name like upper('&&Table_Name')
union all
--
-- local partition level
--
select  /*+ ordered 
            no_merge(tp)  
            no_merge(i)  use_hash(i)
            no_merge(pi) use_hash(pi)
            no_merge(ip) use_hash(ip) */
        tp.table_name,
        i.index_name,
        decode(i.uniqueness,'UNIQUE',1,2) index_position,
        ip.partition_name partition_name,
        ip.partition_position,
        null subpartition_name,
        0 subpartition_position,
        '  '||ip.partition_name name,
        null locality,
        substr(pi.partitioning_type,1,4) partitioning_type,
        null uniqueness,
        ip.num_rows/decode(tp.num_rows,0,null,tp.num_rows)*100 nn,
        ip.num_rows i_num_rows,
        ip.distinct_keys distinct_keys,
        -- the following 3 columns are computed only for b*tree indexes
        -- the following 3 columns are computed only for range partitioning
        decode(substr(i.index_type,1,6),
               'NORMAL',decode(pi.partitioning_type,
                               'RANGE',round(ip.num_rows*ceil(tp.blocks/'&mbrc')/
                                             decode(ip.clustering_factor,
                                                    0,null,
                                                    round(ip.clustering_factor+
                                                          ip.leaf_blocks+
                                                          ip.blevel
                                                         )*&oica/100
                                                   )
                                            )
                              )
              ) rsl,
        decode(substr(i.index_type,1,6),
               'NORMAL',decode(pi.partitioning_type,
                               'RANGE',round(ip.blevel+
                                             greatest(1,ip.leaf_blocks/decode(ip.distinct_keys,
                                                                              0,null,
                                                                              ip.distinct_keys)
                                                                             )+
                                             greatest(1,ip.clustering_factor/decode(ip.distinct_keys,
                                                                                    0,null,
                                                                                    ip.distinct_keys)
                                                                                   )
                                            )
                              )
              ) bges,
        decode(substr(i.index_type,1,6),
               'NORMAL',decode(pi.partitioning_type,
                               'RANGE',ceil(tp.blocks/'&mbrc')
                              )
              ) prfts
from  user_tab_partitions tp,
      user_indexes i,
      user_part_indexes pi,
      user_ind_partitions ip
where tp.table_name = i.table_name
and   i.index_name = pi.index_name
AND   i.index_name = ip.index_name
and   tp.partition_position = ip.partition_position
and   tp.table_name like upper('&&Table_Name')
and   pi.locality = 'LOCAL'
union all
--
-- global partition level
--
select  /*+ ordered 
            no_merge(i)
            no_merge(pi) use_hash(pi)
            no_merge(ip) use_hash(ip) */
        i.table_name,
        i.index_name,
        decode(i.uniqueness,'UNIQUE',1,2) index_position,
        ip.partition_name partition_name,
        ip.partition_position,
        null subpartition_name,
        0 subpartition_position,
        '  '||ip.partition_name name,
        null locality,
        substr(pi.partitioning_type,1,4) partitioning_type,
        null uniqueness,
        -- the following column is computed only for local partitioning
        to_number(null) nn,
        ip.num_rows i_num_rows,
        ip.distinct_keys distinct_keys,
        -- the following 3 columns are computed only for local partitioning
        to_number(null) rsl,
        to_number(null) rsl,
        to_number(null) rsl
from  user_indexes i,
      user_part_indexes pi,
      user_ind_partitions ip
where i.index_name = pi.index_name
AND   i.index_name = ip.index_name
and   i.table_name like upper('&&Table_Name')
and   pi.locality = 'GLOBAL'
union all
--
-- local sub-partition level
--
select  /*+ ordered 
            no_merge(tp)
            no_merge(tsp) use_hash(tsp) 
            no_merge(i)   use_hash(i) 
            no_merge(pi)  use_hash(pi) 
            no_merge(ip)  use_hash(ip) 
            no_merge(isp) use_hash(isp) */
        tp.table_name,
        i.index_name,
        decode(i.uniqueness,'UNIQUE',1,2) index_position,
        ip.partition_name partition_name,
        ip.partition_position,
        isp.subpartition_name subpartition_name,
        isp.subpartition_position,
        '    '||isp.subpartition_name name,
        null locality,
        substr(pi.subpartitioning_type,1,4) partitioning_type,
        null uniqueness,
        isp.num_rows/decode(tsp.num_rows,0,null,tsp.num_rows)*100 nn,
        isp.num_rows i_num_rows,
        isp.distinct_keys distinct_keys,
        -- the following 3 columns are computed only for range partitioning
        to_number(null) rsl,
        to_number(null) rsl,
        to_number(null) rsl
from  user_tab_partitions tp,
      user_tab_subpartitions tsp,
      user_indexes i,
      user_part_indexes pi,
      user_ind_partitions ip,
      user_ind_subpartitions isp
where tp.table_name = tsp.table_name
and   tp.table_name = i.table_name
and   tp.partition_name = tsp.partition_name
and   i.index_name = pi.index_name
and   i.index_name = ip.index_name
and   i.index_name = isp.index_name
and   ip.partition_name = isp.partition_name
and   tp.partition_position = ip.partition_position
and   tsp.subpartition_position = isp.subpartition_position
and   tp.table_name like upper('&&Table_Name')
and   pi.locality = 'LOCAL'
--
-- order by
--
order by table_name, index_position, index_name, partition_position, subpartition_position;

prompt
prompt
prompt PRFTS = Physical Reads per Full Table Scan
prompt RSL   = Range Scan Limit (max. rows# to be retrieved by this index)
prompt BGES  = Blocks Gets per Equality Search (BGES > PRFTS = bad)
prompt

ttitle off

clear break

column table_name              clear
column index_name              clear
column index_position          clear
column partition_name          clear
column partition_position      clear
column subpartition_name       clear
column subpartition_position   clear

column name                    clear
column locality                clear
column partitioning_type       clear
column uniqueness              clear
column nn                      clear
column i_num_rows              clear
column distinct_keys           clear
column rsl                     clear
column bges                    clear
column prfts                   clear

undefine table_name
undefine oica
undefine mbrc

@@fopauoff

set feedback on
