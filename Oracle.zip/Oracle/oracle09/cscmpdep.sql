rem -------------------------------------------------------------------------
rem        Trivadis AG, Baden/Basel/Bern/Lausanne/Mellingen/Z�rich
rem                     Frankfurt/Freiburg i.Br./M�nchen/Stuttgart
rem                     Switzerland/Germany Internet: http://www.trivadis.com
rem -------------------------------------------------------------------------
rem   $Header$
rem   **********************************************************************
rem   Group/Privileges.: DBA (SYS)
rem   Script-Name......: cscmpdep.sql
rem   Developer........: Andri Kisseleff (ank) andri.kisseleff@trivadis.com
rem   Date.............: 07.01.1994
rem   Version..........: Oracle9i - 1.0
rem   Usage............: creates procdure used for dependency tracking
rem   Input parameters.:
rem   Output.......... : 
rem   Called by........:
rem   Remarks..........: sddep.sql and edcmpdep.sql need this procedure
rem                      Ignore "already exists" errors
rem -----------------------------------------------------------------------
rem $Log$
rem Revision 1.3  2002/08/30 13:16:09  far
rem getestet/angepasst f�r 9.2
rem
rem Revision 1.2  2001/07/22 12:59:28  ank
rem - Load initial release Oracle9i 9.0.x
rem
rem
rem Changes:
rem DD.MM.YYYY Consultant Change
rem -----------------------------------------------------------------------
rem 21.09.1997 ank        Oracle8
rem 20.04.1999 AnK        OK for Oracle8i
rem 27.08.2002 MaW        OK for Oracle9i R2
rem -----------------------------------------------------------------------
rem
Rem      Examples:
Rem        execute cmpdep('procedure', 'scott', 'billing');
Rem        select * from cmpdep1$tmp order by seq#;
Rem
Rem        execute cmpdep('table', 'scott', 'emp');
Rem        select * from cmpdep1$tmp order by seq#;
Rem
Rem        execute cmpdep('package body', 'scott', 'accts_payable');
Rem        select * from cmpdep1$tmp order by seq#;
Rem
Rem        A prettier way to display this information than
Rem		select * from cmpdep1$tmp order by seq#;
Rem	   is
Rem             select * from vcmpdep$tmp;
Rem        This shows the dependency relationship via indenting.  Notice
Rem        that no order by clause is needed with vcmpdep$tmp.
create sequence cmpdep$tmp_seq cache 200 /* cache 200 to make sequence faster */
/
drop table cmpdep$tmp
/
create table cmpdep$tmp
(
  object_id            number,
  referenced_object_id number,
  nest_level           number,
  seq#                 number      
)
/
create or replace procedure cmpdep (type char, schema char, name char) is
  obj_id number;
begin
  delete from cmpdep$tmp;
  commit;
  select object_id into obj_id from DBA_objects
    where owner        = upper(cmpdep.schema)
    and   object_name  = upper(cmpdep.name)
    and   object_type  = upper(cmpdep.type);
  insert into cmpdep$tmp
    values(obj_id, 0, 0, 0);
  insert into cmpdep$tmp
    select object_id, referenced_object_id,
        level, cmpdep$tmp_seq.nextval
      from public_dependency
      connect by prior object_id = referenced_object_id
      start with referenced_object_id = cmpdep.obj_id;
exception
  when no_data_found then
    raise_application_error(-20000, 'ORU-10013: ' ||
      type || ' ' || schema || '.' || name || ' was not found.');
end;
/

drop view cmpdep1$tmp
/

set echo off
create view sys.cmpdep1$tmp
  (nested_level, type, schema, name, seq#)
as
  select d.nest_level, o.object_type, o.owner, o.object_name, d.seq#
  from cmpdep$tmp d, dba_objects o
  where d.object_id = o.object_id (+)
union all
  select d.nest_level+1, 'CURSOR', '<shared>', '"'||c.kglnaobj||'"', d.seq#+.5
  from cmpdep$tmp d, x$kgldp k, x$kglob g, obj$ o, user$ u, x$kglob c,
      x$kglxs a
    where d.object_id = o.obj#
    and   o.name = g.kglnaobj
    and   o.owner# = u.user#
    and   u.name = g.kglnaown
    and   g.kglhdadr = k.kglrfhdl
    and   k.kglhdadr = a.kglhdadr   /* make sure it is not a transitive */
    and   k.kgldepno = a.kglxsdep   /* reference, but a direct one */
    and   k.kglhdadr = c.kglhdadr
    and   c.kglhdnsp = 0 /* a cursor */
/

drop view vcmpdep$tmp
/
create view vcmpdep$tmp (dependencies)
as
  select lpad(' ',3*(max(nested_level))) || max(nvl(type, '<no permission>')
    || ' ' || schema || decode(type, NULL, '', '.') || name)
  from cmpdep1$tmp
  group by seq# /* So user can omit sort-by when selecting from cmpdep$tmp */
/
grant execute on cmpdep to dba
/
