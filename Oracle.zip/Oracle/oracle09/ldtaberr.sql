rem -------------------------------------------------------------------------
rem        Trivadis AG, Baden/Basel/Bern/Lausanne/Mellingen/Z�rich
rem                     Frankfurt/Freiburg i.Br./M�nchen/Stuttgart
rem                     Switzerland/Germany Internet: http://www.trivadis.com
rem -------------------------------------------------------------------------
rem   $Header$
rem   **********************************************************************
rem
rem   Group/Privileges.: DBA
rem   Script-Name......: ldtaberr.sql
rem   Developer........: Andri Kisseleff (ank) andri.kisseleff@trivadis.com
rem   Date.............: 07.1993
rem   Version..........: Oracle9i - 2.0
rem   Usage............: table statistics for tables unable to allocate
rem			 a next extent (filled up already at least 70%)
rem			 because tablespace is full or maxextents is reached
rem   Input parameters.:
rem   Output.......... : ldtaberr.lis
rem   Called by........:
rem   Remarks..........: optimizer statitics *MUST* be available
rem			 *** Important: ***
rem			 7.0 : MAX(F.blocks),  7.1/7.2/7.3 : MAX(F.bytes)
rem	                 to be changed in Sub-Query on DBA_FREE_SPACE
rem
rem			 the number of rows until the allocated space
rem			 will be used up is an estimate based on the
rem			 average row length of the actual rows
rem

rem ----------------------------------------------------------------------------
rem HISTORY:
rem ============================================================================
rem $Log$
rem Revision 1.3  2002/09/09 16:56:24  far
rem 9.2 f�hig checked by ThJ
rem
rem Revision 1.2  2001/07/22 12:59:28  ank
rem - Load initial release Oracle9i 9.0.x
rem
rem
rem
rem DD.MM.YYYY Consultant Change
rem    09.1995 ank	  added MAXEXTENT check
rem 18.06.1996 ank	  title and new header
rem 02.08.1997 ank        Oracle8
rem                       UB4 = 4 bytes
rem                       Block Common Header = 20 bytes
rem                       Transaction Fixed Header = 48 Bytes (incl. 1 INI)
rem                       Transaction Variable Header = 24 bytes
rem                       Data Header = 14 bytes
rem                       Table Directory Entry (in Add. to PCTFREE) = 4 bytes fix.
rem --> Header = 86 bytes incl. INITRANS = 1, for each higher INITRANS add
rem              24 bytes overhead
rem     Each Record overhead of 3 bytes + 2 bytes header
rem     Each Column up to 250 = 1 bytes, longer = 3 bytes overhead
rem 20.04.1999 AnK        Exclude Segments in READ ONLY Tablespaces
rem                       Consider AUTOEXTENSIBLE (Do not show segments
rem                        if AUTOEXTENSIBLE = 'YES')
rem                       OK for Oracle8i
rem 14.12.1999 ClK        Added support for hash and composite partitioned 
rem                       (subpartitioned) tables
rem 
rem 18.01.2000 AnK        Added case, where Tablespace has *no space at all* available actually.
rem                       Combined the 3 SELECTs to 1 (UNION).
rem 
rem                       Fastest execution usually is with Cost-Based Optimizer (ALL_ROWS) and
rem                       Statistics available at schema SYS or RULE if not statistics available.
rem 04.09.2002 ThJ        OK for Oracle9i R2
rem
rem -----------------------------------------------------------------------
rem
rem -----------------------------------------------------------------------
rem
rem
	rem
    ACCEPT user_namen CHAR PROMPT     'Username or Wildcard <%>: ' DEFAULT '%'
    ACCEPT tabellen_namen CHAR PROMPT 'Tablename or Wildcard <%>: ' DEFAULT '%'
    ACCEPT partitionen_namen CHAR PROMPT 'Partitionname or Wildcard <%>: ' DEFAULT '%'
    ACCEPT subpartitionen_namen CHAR PROMPT 'Subpartitionname or Wildcard <%>: ' DEFAULT '%'

	SET ECHO OFF TERMOUT ON


	SET PAGES 48 LINES 130 VERIFY OFF
	COLUMN datum		NEW_VALUE	datum	NOPRINT
	COLUMN extents		FORMAT		999	HEADING EXT
	COLUMN used_blocks	FORMAT		9999999 HEADING USED_BLCK
	COLUMN allo_blocks	FORMAT		9999999 HEADING ALLO_BLCK
	COLUMN space_for_recs	FORMAT 	9999999
	COLUMN next_extent	FORMAT		9999999	HEADING NEXT_EXT
    
	rem
	SET ECHO OFF TERMOUT OFF
    @@foenvtit "Tables, part. tables and subpart. tables unable to allocate a next extent (and already 50% full)"
	SPOOL ldtaberr.lis
        

	SET ECHO OFF TERMOUT OFF

   SELECT /*+ rule */ TO_CHAR(SYSDATE,'DD.MM.YY') datum,
	       RPAD(T.owner,10,'.') OWNER,
	       RPAD(T.table_name,20,'.') TABLE_NAME,
   	       RPAD('.',20,'.') PARTITION_NAME,
	       RPAD(T.tablespace_name,20,'.') TABLESPACE_NAME,
	       extents,
	       T.blocks USED_BLOCKS,
	       S.blocks ALLO_BLOCKS,
               (((( value-86-(ini_trans-1*24))*empty_blocks)*
			(1-pct_free/100))-4)/avg_row_len SPACE_FOR_RECS,
	       S.next_extent
	FROM   sys.dba_tables T, sys.dba_segments S, v$parameter, sys.dba_tablespaces TS
	WHERE  T.owner = S.owner
	AND    T.table_name = S.segment_name
	AND    TS.tablespace_name = T.tablespace_name
    AND    TS.STATUS != 'READ ONLY'
	AND    T.owner LIKE UPPER('&user_namen')
	AND    T.table_name LIKE UPPER('&tabellen_namen')
	AND    name = 'db_block_size'
	AND    avg_row_len > 0
	AND    num_rows > 0
	AND    100/S.blocks*T.blocks >= 50
	AND    ((( S.next_extent > ( SELECT   MAX(F.bytes)
		   	           FROM   sys.dba_free_space F
				   WHERE  F.tablespace_name = T.tablespace_name)
              OR          NOT EXISTS (SELECT  '' 
                               FROM   sys.dba_free_space F
                               WHERE  F.tablespace_name = TS.tablespace_name))
         AND    NOT EXISTS (SELECT ''
                       FROM   sys.dba_data_files F
                       WHERE  F.tablespace_name = TS.tablespace_name
                       AND    F.autoextensible = 'YES'))
       OR          t.max_extents <= s.extents)
 UNION
    SELECT /*+ rule */   TO_CHAR(SYSDATE,'DD.MM.YY') datum,
	       RPAD(T.table_owner,10,'.') OWNER,
   	       RPAD(T.table_name,20,'.') TABLE_NAME,
	       RPAD(T.partition_name,20,'.') PARTITION_NAME,
           RPAD(T.tablespace_name,20,'.') TABLESPACE_NAME,
	       extents,
	       T.blocks USED_BLOCKS,
	       S.blocks ALLO_BLOCKS,
               (((( value-86-(ini_trans-1*24))*empty_blocks)*
			(1-pct_free/100))-4)/avg_row_len SPACE_FOR_RECS,
	       S.next_extent
	FROM   sys.dba_tab_partitions T, sys.dba_segments S, v$parameter, sys.dba_tablespaces TS
	WHERE  T.table_owner = S.owner
	AND    T.table_name = S.segment_name
	AND    T.partition_name = S.partition_name
	AND    TS.tablespace_name = T.tablespace_name
    AND    TS.STATUS != 'READ ONLY'
	AND    T.table_owner LIKE UPPER('&user_namen')
	AND    T.partition_name LIKE UPPER('&partitionen_namen')
	AND    name = 'db_block_size'
	AND    avg_row_len > 0
	AND    num_rows > 0
    AND    100/S.blocks*T.blocks >= 50 
	AND    ((( S.next_extent > ( SELECT   MAX(F.bytes)
		   	           FROM   sys.dba_free_space F
				   WHERE  F.tablespace_name = T.tablespace_name)      
           OR          NOT EXISTS (SELECT  '' 
                               FROM   sys.dba_free_space F
                               WHERE  F.tablespace_name = TS.tablespace_name))
          AND    NOT EXISTS (SELECT ''
                       FROM   sys.dba_data_files F
                       WHERE  F.tablespace_name = TS.tablespace_name
                       AND    F.autoextensible = 'YES'))
         OR          t.max_extent <= s.extents)
 UNION
    SELECT /*+ rule */  TO_CHAR(SYSDATE,'DD.MM.YY') datum,
	       RPAD(SP.table_owner,10,'.') OWNER,
   	       RPAD(SP.table_name,20,'.') TABLE_NAME,
           RPAD(SP.subpartition_name,20,'.') SUBPARTITION_NAME,
           RPAD(SP.tablespace_name,20,'.') TABLESPACE_NAME,
	       extents,
	       SP.blocks USED_BLOCKS,
	       S.blocks ALLO_BLOCKS,
               (((( value-86-(SP.ini_trans-1*24))*SP.empty_blocks)*
			(1-SP.pct_free/100))-4)/SP.avg_row_len SPACE_FOR_RECS,
	       S.next_extent
	FROM   sys.dba_tab_subpartitions SP, sys.dba_tables t, 
               sys.dba_segments S, v$parameter, sys.dba_tablespaces TS
	WHERE  S.segment_name = t.table_name
    AND    S.owner = T.owner
    AND    SP.table_owner = T.owner
    AND    SP.table_name = T.table_name
    AND    S.partition_name = SP.subpartition_name
	AND    TS.tablespace_name = SP.tablespace_name
    AND    TS.STATUS != 'READ ONLY'
	AND    SP.table_owner LIKE UPPER('&user_namen')
	AND    SP.subpartition_name LIKE UPPER('&subpartitionen_namen')
    AND    S.segment_type in 'TABLE SUBPARTITION'
	AND    name = 'db_block_size'
	AND    SP.avg_row_len > 0
	AND    SP.num_rows > 0
	AND    100/S.blocks*SP.blocks >= 50 
	AND    ((( S.next_extent > ( SELECT   MAX(F.bytes)
		   	           FROM   sys.dba_free_space F
				   WHERE  F.tablespace_name = SP.tablespace_name)
           OR          NOT EXISTS (SELECT  '' 
                               FROM   sys.dba_free_space F
                               WHERE  F.tablespace_name = TS.tablespace_name))
         AND    NOT EXISTS (SELECT ''
                       FROM   sys.dba_data_files F
                       WHERE  F.tablespace_name = TS.tablespace_name
                       AND    F.autoextensible = 'YES'))
        OR          SP.max_extent <= s.extents)
    order by 5,2,3,4
/    


	SPOOL OFF
	SET VERIFY ON TERMOUT ON PAGES 24 LINES 80
	TTITLE OFF
	CLEAR COMPUTES BREAKS
	COLUMN datum		clear
	COLUMN extents		clear
	COLUMN used_blocks	clear
	COLUMN allo_blocks	clear
	COLUMN space_for_recs	clear
	COLUMN next_extent	clear

	PROMPT
	PROMPT ldtaberr.lis has been spooled (A4 landscape)
	PROMPT


