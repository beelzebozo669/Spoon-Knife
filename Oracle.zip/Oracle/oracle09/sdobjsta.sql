rem -------------------------------------------------------------------------
rem        Trivadis AG, Baden/Basel/Bern/Lausanne/Mellingen/Z�rich
rem                     Frankfurt/Freiburg i.Br./M�nchen/Stuttgart
rem                     Switzerland/Germany Internet: http://www.trivadis.com
rem -------------------------------------------------------------------------
rem   $Header$
rem   **********************************************************************
rem   Bereich.........: DBA 
rem   Name............: sdobjsta.sql 
rem   Entwickler......: Andri Kisseleff
rem   Datum...........: 12.09.1995
rem   Version.........: Oracle9i - 4.0
rem   Zweck...........: show object of a user or wildcard incl. status
rem                     (choice valid or invalid (default both))
rem   Input Parameter.:
rem   Output..........:
rem   Wird aufgerufen.:
rem   Bemerkung.......:  must be DBA to run this script
set echo off termout on
rem =======================================================================
rem
rem $Log$
rem Revision 1.3  2002/09/09 16:56:24  far
rem 9.2 f�hig checked by ThJ
rem
rem Revision 1.2  2001/07/22 12:59:28  ank
rem - Load initial release Oracle9i 9.0.x
rem
rem
rem
rem   Aenderungen:
rem DD.MM.YYYY Entwickler   Aenderung
rem =======================================================================
rem 19.07.1997 urm Oracle8, added temporary and generated
rem 21.09.1997 ank Better Display for object_type for Partitions
rem                Oracle8-Bug: IOT shows as UNDEFINED (8.0.3)
rem                Added SUBOBJECT_NAME for Partitions
rem                Added COL CLEARs
rem 20.04.1999 AnK OK for Oracle8i (Added DECODE f�r Sub-Partitions)
rem 03.09.2002 ThJ OK for Oracle9i R2
rem =======================================================================
rem
col user_name noprint new_value user_name
col date_time noprint new_value date_time
col owner format a10 trunc
col object_name format a30 WORD_WRAP HEADING "OBJECT_NAME (PART_NAME)"
col object_type format a8 trunc heading OBJ-TYPE
col status format a7 
col last_ddl_time format a17
prompt
prompt User name, wildcard or <RETURN> for all users:
prompt Object name, wildcard or <RETURN> for all objects:
prompt V = valid, I = invalid, <RETURN> = valid and invalid:
prompt
accept user_name 	char prompt "User name  : "
accept object_name 	char prompt "Object name: "
accept status           char prompt "Status     : "
set echo off termout off pause off
select upper(nvl('&&user_name','%')) user_name, 
       to_char(sysdate,'dd.mm.yyyy hh24:mi') date_time
from dual;
set termout on
set pause return... pause on pages 24 verify off lines 80 timing off
ttitle center 'Objects of user 'user_name' at 'date_time - 
       right  sql.pno skip 2
spool sdobjsta.lis
select 	owner, object_name||DECODE(subobject_name,null,null,
                            ' ('||subobject_name||')') object_name, 
        decode(object_type,'PACKAGE','PCK-SPEZ',
                           'PACKAGE BODY','PCK-BODY',
                           'DATABASE LINK','DB-LINK',
                           'TABLE PARTITION','TAB-PART',
                           'INDEX PARTITION','IND-PART',
                           'INDEX SUBPARTITION','IND-SUBP',
                           'TABLE SUBPARTITION','TAB-SUBP',
                                           object_type) object_type, 
        status, to_char(last_ddl_time,'dd.mm.yy hh24:mi:ss') last_ddl_time,
        temporary,
        generated
from 	sys.dba_objects
where   owner like nvl(upper('&user_name'),'%')
and     object_name like nvl(upper('&object_name'),'%')
and     status like decode(upper(substr('&status',1,1)),
                                'V', 'VALID',
                                'I','INVALID',
                                              '%')
order by owner, object_name, subobject_name, object_type
/
spool off
prompt
prompt	sdobjsta.lis has been spooled
prompt
col user_name clear
col date_time clear
col owner clear clear
col object_name clear
col object_type clear
col status clear
col last_ddl_time clear

ttitle off
set pause off verify on
undefine object_name user_name
rem
rem ================================= eof =============================
