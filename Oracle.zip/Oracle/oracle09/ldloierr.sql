rem -------------------------------------------------------------------------
rem        Trivadis AG, Baden/Basel/Bern/Lausanne/Mellingen/Z�rich
rem                     Frankfurt/Freiburg i.Br./M�nchen/Stuttgart
rem                     Switzerland/Germany Internet: http://www.trivadis.com
rem -------------------------------------------------------------------------
rem   $Header$
rem   **********************************************************************
rem   Group/Privileges.: DBA
rem   Script-Name......: ldloierr.sql
rem   Developer........: Andri Kisseleff (ank) andri.kisseleff@trivadis.com
rem   Date.............: Sept.2000
rem   Version..........: Oracle9i (Written with 8.1.6, teseted with 9.0.x,9.2.x)
rem   Usage............: Shows LOB-Indexes which are not able to allocate further 
rem                      extents
REM                      All cases: do not show if TS is READ ONLY
rem                      Case 1: LOB-Indexes of tables
rem                      - Case 1a: LOB Segments where next extent is > then max freespace in TS
rem                      - Case 1b: LOB Segments where TS is 100% full
rem                      - Case 1c: 1a+1b only if NOT a datafile (DF) of the TS has AUTOEXTENT ON
rem                      - Case 1d: LOB Segments where nbr. extents reached max_extents
rem                      Case 2: LOB-Indexes of range part. tables + hash part. tables the same case
rem                      Case 3: LOB-Indexes of composite part. tables
rem                      Case 4 = Case 1 for locally mgmt. TS
rem                      Case 5 = Case 2 for locally mgmt. TS
rem                      Case 6 = Case 3 for locally mgmt. TS
rem                      
rem   Input parameters.:
rem   Output.......... : ldloierr.lis
rem   Called by........:
rem   Remarks..........: 
rem -----------------------------------------------------------------------
rem
rem $Log$
rem Revision 1.3  2002/09/09 16:56:24  far
rem 9.2 f�hig checked by ThJ
rem
rem Revision 1.2  2001/07/22 12:59:28  ank
rem - Load initial release Oracle9i 9.0.x
rem
rem
rem Changes:
rem DD.MM.YYYY Consultant Change
rem 04.09.2002 ThJ        OK for Oracle9i R2
rem
rem -----------------------------------------------------------------------
rem
rem 
	rem
    ACCEPT user_namen CHAR PROMPT     'Username or Wildcard <%>: ' DEFAULT '%'

	SET ECHO OFF TERMOUT ON


	SET PAGES 48 LINES 130 VERIFY OFF
	COLUMN datum		NEW_VALUE	datum	NOPRINT
	COLUMN extents		FORMAT		999	HEADING EXT
	COLUMN used_blocks	FORMAT		9999999 HEADING USED_BLCK
	COLUMN allo_blocks	FORMAT		9999999 HEADING ALLO_BLCK
	COLUMN space_for_recs	FORMAT 	9999999
	COLUMN next_extent	FORMAT		A9	HEADING NEXT_EXT
    
	rem
	SET ECHO OFF TERMOUT OFF
    @@foenvtit "LOB-Indexes unable to allocate a next extent"
	SPOOL ldloierr.lis
        

	SET ECHO OFF TERMOUT ON

    SELECT /*+ RULE */ TO_CHAR(SYSDATE,'DD.MM.YY') datum,   /* Case 1: Lob Segments in Tables */
	       RPAD(L.owner,10,'.') OWNER,
               RPAD(L.table_name,10,'.') TABLE_NAME,
	       RPAD(L.index_name,20,'.') INDEX_NAME,
   	       RPAD('.',30,'.') PARTITION_NAME,
	       RPAD(S.tablespace_name,10,'.') TABLESPACE_NAME,
	       extents,
	       S.blocks ALLO_BLOCKS,
	       TO_CHAR(S.next_extent) NEXT_EXTENT
	FROM   sys.dba_lobs L, sys.dba_segments S, sys.dba_tablespaces TS
	WHERE  L.owner = S.owner
	AND    L.index_name = S.segment_name
	AND    TS.tablespace_name = S.tablespace_name
        AND    TS.status != 'READ ONLY'
        AND    TS.extent_management = 'DICTIONARY'
	AND    L.owner LIKE UPPER('&user_namen')
        AND    S.SEGMENT_TYPE = 'LOBINDEX'
	AND    ((( S.next_extent > ( SELECT   MAX(F.bytes)    /* +Case 1a: not enough free space */
		   	           FROM   sys.dba_free_space F
				   WHERE  F.tablespace_name = S.tablespace_name)
              OR          NOT EXISTS (SELECT  ''            /* +Case 1b: no free space at all */
                               FROM   sys.dba_free_space F
                               WHERE  F.tablespace_name = TS.tablespace_name))
           AND    NOT EXISTS (SELECT '' /* - Case 1c: do not show if DF of TS has AUTOEXTEND ON */
                       FROM   sys.dba_data_files F
                       WHERE  F.tablespace_name = TS.tablespace_name
                       AND    F.autoextensible = 'YES'))
         OR     S.EXTENTS >= S.MAX_EXTENTS) /* +Case 1d: LOB has reached MAXEXTENTS */
 UNION /* LOB Segments in Range Part. Tables + Hash Part. Tables */
      SELECT /*+RULE */ TO_CHAR(SYSDATE,'DD.MM.YY') datum,   /* Case 2: Lob Segments in range + hash part. Tables */
	       RPAD(IP.index_owner,10,'.') OWNER,
               RPAD(I.table_name,10,'.') TABLE_NAME,
	       RPAD(IP.index_name,20,'.') INDEX_NAME,
   	       RPAD(IP.partition_name,30,'.') PARTITION_NAME,
	       RPAD(S.tablespace_name,10,'.') TABLESPACE_NAME,
	       extents,
	       S.blocks ALLO_BLOCKS,
	       TO_CHAR(S.next_extent) NEXT_EXTENT
	FROM   sys.dba_segments S, sys.dba_ind_partitions IP, sys.dba_indexes I, sys.dba_tablespaces TS
        WHERE  S.segment_name = IP.index_name
        AND    S.partition_name = IP.partition_name
        AND    IP.index_owner = S.OWNER
        AND    I.owner = IP.index_owner
        AND    I.index_name = ip.index_name
        AND    S.tablespace_name = TS.tablespace_name
        AND    TS.STATUS != 'READ ONLY'
        AND    TS.extent_management = 'DICTIONARY'
	AND    IP.index_owner LIKE UPPER('&user_namen')
        AND    S.SEGMENT_TYPE = 'INDEX PARTITION'
	AND    ((( S.next_extent > ( SELECT   MAX(F.bytes)    /* +Case 2a: not enough free space */
		   	           FROM   sys.dba_free_space F
				   WHERE  F.tablespace_name = S.tablespace_name)
              OR          NOT EXISTS (SELECT  ''            /* +Case 2b: no free space at all */
                               FROM   sys.dba_free_space F
                               WHERE  F.tablespace_name = TS.tablespace_name))
           AND    NOT EXISTS (SELECT '' /* - Case 2c: do not show if DF of TS has AUTOEXTEND ON */
                       FROM   sys.dba_data_files F
                       WHERE  F.tablespace_name = TS.tablespace_name
                       AND    F.autoextensible = 'YES'))
         OR     S.EXTENTS >= S.MAX_EXTENTS) /* +Case 2d: LOB has reached MAXEXTENTS */
UNION /* LOB Segments Composite part. tables */
     SELECT /*+RULE */ DISTINCT TO_CHAR(SYSDATE,'DD.MM.YY') datum,   /* Case 3: Lob Segments in comp. part. Tables */
	       RPAD(IP.index_owner,10,'.') OWNER,
               RPAD(I.table_name,10,'.') TABLE_NAME,
	       RPAD(IP.index_name,20,'.') INDEX_NAME,
   	       RPAD(IP.partition_name,30,'.') PARTITION_NAME,
	       RPAD(S.tablespace_name,10,'.') TABLESPACE_NAME,
	       extents,
	       S.blocks ALLO_BLOCKS,
	       TO_CHAR(S.next_extent) NEXT_EXTENT
	FROM   sys.dba_segments S, sys.dba_ind_subpartitions IP, sys.dba_indexes I, sys.dba_tablespaces TS
        WHERE  S.segment_name = IP.index_name
        AND    S.partition_name = IP.subpartition_name
        AND    IP.index_owner = S.OWNER
        AND    I.owner = IP.index_owner
        AND    I.index_name = ip.index_name
        AND    S.tablespace_name = TS.tablespace_name
        AND    TS.STATUS != 'READ ONLY'
        AND    TS.extent_management = 'DICTIONARY'
	AND    IP.index_owner LIKE UPPER('&user_namen')
        AND    S.SEGMENT_TYPE = 'INDEX SUBPARTITION'
	AND    ((( S.next_extent > ( SELECT   MAX(F.bytes)    /* +Case 3a: not enough free space */
		   	           FROM   sys.dba_free_space F
				   WHERE  F.tablespace_name = S.tablespace_name)
              OR          NOT EXISTS (SELECT  ''            /* +Case 3b: no free space at all */
                               FROM   sys.dba_free_space F
                               WHERE  F.tablespace_name = TS.tablespace_name))
           AND    NOT EXISTS (SELECT '' /* - Case 3c: do not show if DF of TS has AUTOEXTEND ON */
                       FROM   sys.dba_data_files F
                       WHERE  F.tablespace_name = TS.tablespace_name
                       AND    F.autoextensible = 'YES'))
         OR     S.EXTENTS >= S.MAX_EXTENTS) /* +Case 3d: LOB has reached MAXEXTENTS */
union /* LOB Segment of tables in localy managed tablespaces */
    SELECT /*+ RULE */ TO_CHAR(SYSDATE,'DD.MM.YY') datum,   /* Case 4: Lob Segments in Tables */
	       RPAD(L.owner,10,'.') OWNER,
               RPAD(L.table_name,10,'.') TABLE_NAME,
	       RPAD(L.index_name,20,'.') INDEX_NAME,
   	       RPAD('.',30,'.') PARTITION_NAME,
	       RPAD(S.tablespace_name,10,'.') TABLESPACE_NAME,
	       extents,
	       S.blocks ALLO_BLOCKS,
	       'AUTO' NEXT_EXTENT
	FROM   sys.dba_lobs L, sys.dba_segments S, sys.dba_tablespaces TS
	WHERE  L.owner = S.owner
	AND    L.index_name = S.segment_name
	AND    TS.tablespace_name = S.tablespace_name
        AND    TS.status != 'READ ONLY'
        AND    TS.extent_management = 'LOCAL'
	AND    L.owner LIKE UPPER('&user_namen')
        AND    S.SEGMENT_TYPE = 'LOBINDEX'
	AND    ((NOT EXISTS (SELECT  ''            /* +Case 4b: no free space at all */
                               FROM   sys.dba_free_space F
                               WHERE  F.tablespace_name = TS.tablespace_name)
           AND    NOT EXISTS (SELECT '' /* - Case 1c: do not show if DF of TS has AUTOEXTEND ON */
                       FROM   sys.dba_data_files F
                       WHERE  F.tablespace_name = TS.tablespace_name
                       AND    F.autoextensible = 'YES'))
         OR     S.EXTENTS >= S.MAX_EXTENTS) /* +Case 4d: LOB has reached MAXEXTENTS */
UNION /* LOBs of range und hash part. tables in locally mgmt. TS */
     SELECT /*+RULE */ TO_CHAR(SYSDATE,'DD.MM.YY') datum,   /* Case 5: Lob Segments in range + hash part. Tables */
	       RPAD(IP.index_owner,10,'.') OWNER,
               RPAD(I.table_name,10,'.') TABLE_NAME,
	       RPAD(IP.index_name,20,'.') INDEX_NAME,
   	       RPAD(IP.partition_name,30,'.') PARTITION_NAME,
	       RPAD(S.tablespace_name,10,'.') TABLESPACE_NAME,
	       extents,
	       S.blocks ALLO_BLOCKS,
	       'AUTO' NEXT_EXTENT
	FROM   sys.dba_segments S, sys.dba_ind_partitions IP, sys.dba_indexes I, sys.dba_tablespaces TS
        WHERE  S.segment_name = IP.index_name
        AND    S.partition_name = IP.partition_name
        AND    IP.index_owner = S.OWNER
        AND    I.owner = IP.index_owner
        AND    I.index_name = ip.index_name
        AND    S.tablespace_name = TS.tablespace_name
        AND    TS.STATUS != 'READ ONLY'
        AND    TS.extent_management = 'LOCAL'
	AND    IP.index_owner LIKE UPPER('&user_namen')
        AND    S.SEGMENT_TYPE = 'INDEX PARTITION'
	AND    ((NOT EXISTS (SELECT  ''            /* +Case 5b: no free space at all */
                               FROM   sys.dba_free_space F
                               WHERE  F.tablespace_name = TS.tablespace_name)
           AND    NOT EXISTS (SELECT '' /* - Case 5c: do not show if DF of TS has AUTOEXTEND ON */
                       FROM   sys.dba_data_files F
                       WHERE  F.tablespace_name = TS.tablespace_name
                       AND    F.autoextensible = 'YES'))
         OR     S.EXTENTS >= S.MAX_EXTENTS) /* +Case 5d: LOB has reached MAXEXTENTS */
UNION /* LOB Segment in comp. part. table in locally mgmt. TS */
     SELECT /*+RULE */ DISTINCT TO_CHAR(SYSDATE,'DD.MM.YY') datum,   /* Case 6: Lob Segments in comp. part. Tables */
	       RPAD(IP.index_owner,10,'.') OWNER,
               RPAD(I.table_name,10,'.') TABLE_NAME,
	       RPAD(IP.index_name,20,'.') INDEX_NAME,
   	       RPAD(IP.partition_name,30,'.') PARTITION_NAME,
	       RPAD(S.tablespace_name,10,'.') TABLESPACE_NAME,
	       extents,
	       S.blocks ALLO_BLOCKS,
	       'AUTO' NEXT_EXTENT
	FROM   sys.dba_segments S, sys.dba_ind_subpartitions IP, sys.dba_indexes I, sys.dba_tablespaces TS
        WHERE  S.segment_name = IP.index_name
        AND    S.partition_name = IP.subpartition_name
        AND    IP.index_owner = S.OWNER
        AND    I.owner = IP.index_owner
        AND    I.index_name = ip.index_name
        AND    S.tablespace_name = TS.tablespace_name
        AND    TS.STATUS != 'READ ONLY'
        AND    TS.extent_management = 'LOCAL'
	AND    IP.index_owner LIKE UPPER('&user_namen')
        AND    S.SEGMENT_TYPE = 'INDEX SUBPARTITION'
	AND    ((NOT EXISTS (SELECT  ''            /* +Case 6b: no free space at all */
                               FROM   sys.dba_free_space F
                               WHERE  F.tablespace_name = TS.tablespace_name)
           AND    NOT EXISTS (SELECT '' /* - Case 3c: do not show if DF of TS has AUTOEXTEND ON */
                       FROM   sys.dba_data_files F
                       WHERE  F.tablespace_name = TS.tablespace_name
                       AND    F.autoextensible = 'YES'))
         OR     S.EXTENTS >= S.MAX_EXTENTS) /* +Case 6d: LOB has reached MAXEXTENTS */
order by 1,2,3,4,5
/
	SPOOL OFF
	SET VERIFY ON TERMOUT ON PAGES 24 LINES 80
	TTITLE OFF
	CLEAR COMPUTES BREAKS
	COLUMN datum		clear
	COLUMN extents		clear
	COLUMN used_blocks	clear
	COLUMN allo_blocks	clear
	COLUMN space_for_recs	clear
	COLUMN next_extent	clear

	PROMPT
	PROMPT ldloierr.lis has been spooled (A4 landscape)
	PROMPT
SET TERMOUT ON
