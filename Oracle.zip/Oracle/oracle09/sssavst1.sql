rem -------------------------------------------------------------------------
rem        Trivadis AG, Baden/Basel/Bern/Lausanne/Mellingen/Z�rich
rem                     Frankfurt/Freiburg i.Br./M�nchen/Stuttgart
rem                     Switzerland/Germany Internet: http://www.trivadis.com
rem -------------------------------------------------------------------------
rem   $Header$
rem   **********************************************************************
rem   Privilegien......: SYS
rem   Name.............: cssavsta.sql
rem   Entwickler.......: Sven Vetter (ssv) Sven.Vetter@trivadis.com
rem   Datum............: 22.08.1999
rem   Version..........: Oracle9i - 2.0
rem   Zweck............: Programm zum Abspeichern und Vergleichen von Statistiken
rem                      aus v$sysstat und v$waitstat
rem   Input parameters.:
rem   Output.......... : 
rem   Called by........:
rem   Remarks..........: To be run while connected as SYS
rem -----------------------------------------------------------------------
rem
rem $Log$
rem Revision 1.2  2001/07/22 12:59:28  ank
rem - Load initial release Oracle9i 9.0.x
rem
rem
rem Changes:
rem DD.MM.YYYY Consultant Ver Change
rem 21.04.1999 ssv        1.1 Bessere Formatierung der Ausgabe
rem 22.08.1999 ssv        2.0 ReDesign der Datenspeicherung (2 Tabellen)

rem Description
rem -----------
rem siehe cssavsta.sql

spool sssavst1.lis
set line 250
select substr(p.bezeichnung||decode(a.art,'1',' - Count','2',' - Time',''),1,35) Parameter,
a.wert1 "Wert 1",b.wert1 "Wert 2",c.wert1 "Wert 3",d.wert1 "Wert 4",e.wert1 "Wert 5",
f.wert1 "Wert 6",g.wert1 "Wert 7",h.wert1 "Wert 8",i.wert1 "Wert 9",j.wert1 "Wert 10"
from Sys.css_save_stats_params p,
 Sys.css_save_stats a,Sys.css_save_stats b,Sys.css_save_stats c,Sys.css_save_stats d,Sys.css_save_stats e,
 Sys.css_save_stats f,Sys.css_save_stats g,Sys.css_save_stats h,Sys.css_save_stats i,Sys.css_save_stats j
where a.key=p.key and a.counter=1
and   b.key(+)=a.key and b.counter(+)=2 and a.art=b.art(+)
and   c.key(+)=a.key and c.counter(+)=3 and a.art=c.art(+)
and   d.key(+)=a.key and d.counter(+)=4 and a.art=d.art(+)
and   e.key(+)=a.key and e.counter(+)=5 and a.art=e.art(+)
and   f.key(+)=a.key and f.counter(+)=6 and a.art=f.art(+)
and   g.key(+)=a.key and g.counter(+)=7 and a.art=g.art(+)
and   h.key(+)=a.key and h.counter(+)=8 and a.art=h.art(+)
and   i.key(+)=a.key and i.counter(+)=9 and a.art=i.art(+)
and   j.key(+)=a.key and j.counter(+)=10 and a.art=j.art(+)
order by p.key;
spool off;