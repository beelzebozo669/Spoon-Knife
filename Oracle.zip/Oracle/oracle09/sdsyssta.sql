rem -------------------------------------------------------------------------
rem        Trivadis AG, Baden/Basel/Bern/Lausanne/Mellingen/Z�rich
rem                     Frankfurt/Freiburg i.Br./M�nchen/Stuttgart
rem                     Switzerland/Germany Internet: http://www.trivadis.com
rem -------------------------------------------------------------------------
rem   $Header$
rem   **********************************************************************
rem
rem   Group/Privileges.: DBA
rem   Script-Name......: sdsyssta.sql
rem   Developer........: Andri Kisseleff (ank) andri.kisseleff@trivadis.com
rem   Date.............: 1993
rem   Version..........: Oracle9i - 2.0
rem   Usage............: Systemwide statistics since last instance startup 
rem   Input parameters.:
rem   Output.......... : 
rem   Called by........:
rem   Remarks..........:
rem ----------------------------------------------------------------------------
rem HISTORY:
rem ============================================================================
rem
rem $Log$
rem Revision 1.3  2002/08/30 13:16:09  far
rem getestet/angepasst f�r 9.2
rem
rem Revision 1.2  2001/07/22 12:59:28  ank
rem - Load initial release Oracle9i 9.0.x
rem
rem
rem
rem 18.06.1996 ank title and new header
rem 02.08.1997 ank Oracle8
rem 21.04.1999 AnK OK for Oracle8i
rem 29.09.2000 MaW WHERE clause added, spooling removed
rem 27.08.2002 MaW Ok for Oracle9i R2
rem -----------------------------------------------------------------------
rem
rem

REM
	COLUMN	CLASS		NOPRINT
	COLUMN	NAME		FORMAT A50 TRUNC
	BREAK ON CLASS SKIP PAGE
@@foenvtit "Systemstatistics"
REM
        SET VERIFY OFF
	SET TERMOUT ON PAGES 24 PAUSE ON PAUSE '<return>...'
        PROMPT
        PROMPT Please enter the statistics class name, wildcards allowed
        PROMPT eg.: %redo%
        PROMPT
        accept stat_name char prompt "Statistic name <%>: " default "%"

	SELECT  RPAD(name,50,'.') name, value, class
	FROM 	v$sysstat
        WHERE   name like '&&stat_name'
	ORDER BY class, statistic#;
REM
	SET PAUSE OFF
	TTITLE OFF
	CLEAR BREAKS COMPUTES 
	COLUMN CLASS CLEAR
	COLUMN NAME CLEAR
