rem -------------------------------------------------------------------------
rem        Trivadis AG, Baden/Basel/Bern/Lausanne/Mellingen/Z�rich
rem                     Frankfurt/Freiburg i.Br./M�nchen/Stuttgart
rem                     Switzerland/Germany Internet: http://www.trivadis.com
rem -------------------------------------------------------------------------
rem   $Header$
rem   **********************************************************************
rem   Group/Privileges.: SYS
rem   Script-Name......: lsenqsta.sql
rem   Developer........: Andri Kisseleff (ank) andri.kisseleff@trivadis.com
rem   Date.............: Feb. 2003
rem   Version..........: Oracle9i
rem   Usage............: Shows Number and total time of enqueue waits (Lock waits
rem                      and internal enqueue waits)
rem   Input parameters.: 
rem   Output.......... : 
rem   Called by........:
rem   Remarks..........: As to get the wait-time for the locks, TIMED_STATISTICS
rem                      must be TRUE 
rem -----------------------------------------------------------------------
rem Changes:
rem
rem $Log$
rem Revision 1.1  2003/02/23 17:35:09  far
rem created
rem
rem
rem 
@foenvtit "Enqueue requests/waits sorted by wait time and nbr. requests"
store set "dummy.tmp" replace
set pages 1000 verify off
col enq_name format a30 trunc
col total_req# format 999,999,999 heading "Nbr. Requests"
col total_wait# format 999,999 heading "Nbr. Waits"
col failed_req# format 999,999 heading "Nbr. Fail."
col cum_wait_time format 999,990.000 heading "Wait Time"
accept dummy prompt "Only enqueues with wait time Y/<N> ? " DEFAULT N
spool lsenqsta.lis
select eq_type||' '||DECODE(eq_type,
'BL', 'Buffer Cache Management',
'CF', 'Controlfile Transaction',
'CI', 'Cross-instance Call Invocation',
'CU', 'Bind Enqueue',
'DF', 'Datafile',
'DL', 'Direct Loader Index Creation',
'DM', 'Database Mount',
'DR', 'Distributed Recovery',
'DX', 'Distributed TX',
'FS', 'File Set',
'HW', 'Space management operations on a specific segment',
'IN', 'Instance Number',
'IR', 'Instance Recovery',
'IS', 'Instance State',
'IV', 'Library Cache Invalidation',
'JQ', 'Job Queue',
'KK', 'Redo Log "Kick"',
'MM', 'Mount definition global enqueue',
'MR', 'Media Recovery',
'PF', 'Password File',
'PI', 'Parallel Slaves',
'PR', 'Process Startup',
'PS', 'Parallel Slave Synchronization',
'RT', 'Redo Thread',
'SC', 'System Commit Number',
'SM', 'SMON',
'SN', 'Sequence number instance',
'SQ', 'Sequence Number Enqueue',
'SR', 'Synchronized Replication',
'SS', 'Sort Segment',
'ST', 'Space Management Transaction',
'SV', 'Sequence Number Value',
'TA', 'Transaction RECOVERY',
'TM', 'DML Enqueue',
'TS', 'Temporary Segment (also TableSpace)',
'TT', 'Temporary Table',
'TX', 'Transaction',
'UL', 'User-defined Locks',
'UN', 'User Name',
'US', 'Undo Segment, Serialization',
'WL', 'Being Written Redo Log',
'XA', 'Instance Attribute Lock',
'XI', 'Instance Registration LOCK',
DECODE(
  SUBSTR(eq_type,1,1),
  'N', 'Library Cache Pin',
  'L', 'Library Cache Lock',
  'Q', 'Row Cache',
   eq_type)
) enq_name
, 
total_req#, total_wait#, failed_req#, cum_wait_time/1000 cum_wait_time
from v$enqueue_stat
where cum_wait_time > decode(upper('&dummy'),'Y',0,-1)
order by cum_wait_time desc, total_req# desc, enq_name
/
@dummy.tmp
ttitle off
col total_req# clear
col total_wait# clear
col failed_req# clear
col cum_wait_time clear
col enq_name clear
spool off
prompt
prompt lsenqsta.lis has been spooled...
prompt
prompt Most important for you are the locks of type TX, TM and UL
prompt Wait time is in seconds (27.123 = 27 seconds and 123 milliseconds)
prompt
prompt Please note that statistics are only inserted into v$enqueue_stat
prompt at the moment a locking problem is solved or raises an error.
prompt As long as a user waits for a lock, no insert is done.
prompt
prompt Please also note, that a deadlock (ORA-00060) does not appear in "Nbr. Failures"
prompt

