rem -------------------------------------------------------------------------
rem        Trivadis AG, Baden/Basel/Bern/Lausanne/Mellingen/Z�rich
rem                     Frankfurt/Freiburg i.Br./M�nchen/Stuttgart
rem                     Switzerland/Germany Internet: http://www.trivadis.com
rem -------------------------------------------------------------------------
rem   $Header$
rem   **********************************************************************
rem   Group/Privileges.: Any user with CREATE TABLE priv. and quotas on
rem	                 system/rbs/temp/tools ( or UNLIMITED TABLESPACE)
rem   Script-Name......: cdtabcoa.sql
rem   Developer........: Andri Kisseleff (ank) andri.kisseleff@trivadis.com
rem   Date.............: 1995
rem   Version..........: 1.0 
rem   Usage............: Create and drop fragmented tables to demo
rem			 ALTER TABLESPACE ... COALESCE, sdcoa.sql
rem			 and csprccoa.sql (prccoa procedure)
rem   Input parameters.:
rem   Output.......... : 
rem   Called by........:
rem   Remarks..........: assumes that in demo-database the ts
rem			 rbs, temp and tools exists
rem -----------------------------------------------------------------------
rem Changes:
rem DD.MM.YYYY Consultant Change
rem -----------------------------------------------------------------------
rem 18.06.1996 ank	  title and new header
rem 02.08.1997 ank        Oracle8
rem 20.04.1999 AnK        OK for Oracle8i
rem 27.08.2002 MaW        OK for Oracle9i R2
rem -----------------------------------------------------------------------
rem
rem -----------------------------------------------------------------------
rem
rem
connect system/manager@db2
create table bidon
( a number )
storage (initial 10k next 10k pctincrease 0 minextents 88)
tablespace system;
create table bidon1
( a number )
storage (initial 10k next 10k pctincrease 0 minextents 33)
tablespace rbs;
create table bidon2
( a number )
storage (initial 10k next 10k pctincrease 0 minextents 50)
tablespace tools;
create table bidon3
( a number )
storage (initial 10k next 10k pctincrease 0 minextents 40)
tablespace users;

drop table bidon;
drop table bidon1;
drop table bidon2;
drop table bidon3;


