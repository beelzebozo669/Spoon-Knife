rem -------------------------------------------------------------------------
rem        Trivadis AG, Baden/Basel/Bern/Lausanne/Mellingen/Z�rich
rem                     Frankfurt/Freiburg i.Br./M�nchen/Stuttgart
rem                     Switzerland/Germany Internet: http://www.trivadis.com
rem -------------------------------------------------------------------------
rem   $Header$
rem   **********************************************************************
rem   Group/Privileges.: Utilities
rem   Script-Name......: fopauon.sql
rem   Developer........: Andri Kisseleff andri.kisseleff@trivadis.com
rem   Date.............: 18.02.1996
rem   Version..........: Oracle9i - 1.0
rem   Usage............: 
rem   Input parameters.:
rem   Output.......... : 
rem   Called by........:
rem   Remarks..........:
rem -----------------------------------------------------------------------
rem
rem $Log$
rem Revision 1.3  2002/09/09 16:56:24  far
rem 9.2 f�hig checked by ThJ
rem
rem Revision 1.2  2001/07/22 12:59:28  ank
rem - Load initial release Oracle9i 9.0.x
rem
rem
rem Changes:
rem DD.MM.YYYY Consultant Change
rem -----------------------------------------------------------------------
rem 02.08.1997 ank        Oracle8
rem 20.04.1999 AnK        OK for Oracle8i
rem 04.09.2002 ThJ        OK for Oracle9i R2
rem -----------------------------------------------------------------------
rem
rem
set pages 24 pause on pause "Hit <RETURN>..."


