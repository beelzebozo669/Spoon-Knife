rem -------------------------------------------------------------------------
rem        Trivadis AG, Baden/Basel/Bern/Lausanne/Z�rich
rem                     Frankfurt/Freiburg i.Br./M�nchen/Stuttgart/Hamburg
rem                     Switzerland/Germany Internet: http://www.trivadis.com
rem -------------------------------------------------------------------------
rem   Group/Privileges.: DBA
rem   Script-Name......: lsedfidx.sql
rem   Developer........: Peter Jensch (pej) peter.jensch@trivadis.com
rem   Date.............: December 2004
rem   Version..........: 2.0
rem   Usage............: an export indexfile can be separated into
rem                      serveral files. Files are grouped into
rem                      the basic command types (table, index, alter,
rem                      intermedia)
rem   Input parameters.: index_file.tmp - Index-File from EXPort-Utility
rem   Output.......... : alter.tmp      - all alter comnmands
rem                      index.tmp      - all create unique index
rem                                       and create index commands
rem                      table.tmp      - all create table commands
rem                      intermedia.tmp - all commands for inter media
rem   Called by........:
rem   Remarks..........: use directory to define path
rem
rem                      create or replace directory tmp_idxfile as 'c:\temp';
rem
rem                      set serveroutput on size 1000000 (will be best)
rem                      because of possible errors
rem -----------------------------------------------------------------------
rem   Changes:
rem   DD.MM.YYYY Consultant Change
rem -----------------------------------------------------------------------
rem   22.04.2003 PeJ     intermedia (Test-Version)
rem   16.12.2004 PeJ     use directory instead of utl_file_dir
rem -----------------------------------------------------------------------
rem

set serveroutput on size 1000000
DECLARE

  -- interne Struktur (PL/SQL-Table)
  TYPE t_vLine IS TABLE OF VARCHAR2(255)
    INDEX BY BINARY_INTEGER;
  vtLine                  t_vLine;

  -- File-Definitionen
  vFileIn                 VARCHAR2(80) := 'index_file.tmp';
  vFileHandleIn           utl_file.File_Type;
  vFileOutIndex           VARCHAR2(80) := 'index.tmp';
  vFileHandleOutIndex     utl_file.File_Type;
  vFileOutTable           VARCHAR2(80) := 'table.tmp';
  vFileHandleOutTable     utl_file.File_Type;
  vFileOutAlter           VARCHAR2(80) := 'alter.tmp';
  vFileHandleOutAlter     utl_file.File_Type;
  vFileOutInter           VARCHAR2(80) := 'intermedia.tmp';
  vFileHandleOutInter     utl_file.File_Type;

  vLine                   VARCHAR2(255);

  -- Create-Definitionen
  search_table_def        CONSTANT VARCHAR2(30) := 'CREATE TABLE';
  search_GlobalTabel_def  CONSTANT VARCHAR2(30) := 'CREATE GLOBAL TEMPORARY TABLE';
  search_alter_def        CONSTANT VARCHAR2(30) := 'ALTER TABLE';
  search_index_def        CONSTANT VARCHAR2(30) := 'CREATE INDEX';
  search_unique_index_def CONSTANT VARCHAR2(30) := 'CREATE UNIQUE INDEX';
  search_bitmap_index_def CONSTANT VARCHAR2(30) := 'CREATE BITMAP INDEX';
  search_begin_def        CONSTANT VARCHAR2(30) := 'BEGIN';
  search_end_def          CONSTANT VARCHAR2(30) := 'END;';
  search_commit_def       CONSTANT VARCHAR2(30) := 'COMMIT';

  -- zusaetzliche Suchbedingung
  search_rem_def          CONSTANT VARCHAR2(12) := 'REM  ';

  i_Zeilen                INTEGER;
  file_ende               BOOLEAN;
  verarbeitet             BOOLEAN;

  interMedia_found        BOOLEAN;

BEGIN

  vFileHandleIn           := utl_file.FOpen('TMP_IDXFILE',vFileIn,'r');
  vFileHandleOutIndex     := utl_file.FOpen('TMP_IDXFILE',vFileOutIndex,'w');
  vFileHandleOutTable     := utl_file.FOpen('TMP_IDXFILE',vFileOutTable,'w');
  vFileHandleOutAlter     := utl_file.FOpen('TMP_IDXFILE',vFileOutAlter,'w');
  vFileHandleOutInter     := utl_file.FOpen('TMP_IDXFILE',vFileOutInter,'w');

  interMedia_found := FALSE;

  file_ende := FALSE;
  LOOP

    ----------------------------------------------------------------------
    -- In die interne Struktur einlesen
    -- nur die Intermedia-Abschnitte werden sofort in die InterMedia.tmp
    -- Datei geschrieben.
    i_Zeilen := 0;
    LOOP

      BEGIN

        utl_file.get_line(vFileHandleIn, vLine);
        -- dbms_output.put_line ( vLine );
        IF length (vLine) > 1 THEN

          IF INSTR ( UPPER(vLine), search_begin_def ) > 0 THEN

            interMedia_found := TRUE;

            -- dbms_output.put_line ( 'Begin gefunden' );
            utl_file.put_line (vFileHandleOutInter, vLine );

            -- also muss noch ein commit, COMMIT und END kommen
            -- solange lesen und gleich in den intermedia.tmp - File schreiben

            LOOP
              utl_file.get_line ( vFileHandleIn, vLine );
              utl_file.put_line ( vFileHandleOutInter, vLine );
              IF INSTR ( vLine, search_end_def ) > 0 THEN
                -- dbms_output.put_line ( 'Letzte Zeile aus Intermedia Abschnitt gelesen ' );
                EXIT;
              END IF; 
            END LOOP;
            EXIT;

          ELSE

            -- erst mal die Zeile hinzufuegen
            i_Zeilen := i_Zeilen + 1;
            vtLine(i_zeilen) := vLine;

            -- Ein Abschnitt ist abgeschlossen
            IF INSTR (vLine,';') > 0 THEN
              EXIT;
            END IF;

          END IF;

        END IF;
      EXCEPTION
        WHEN no_data_found THEN
          file_ende           := TRUE;
          EXIT;  -- File-Ende erreicht
      END;
    END LOOP;


    ----------------------------------------------------------------------


    -- dbms_output.put_line ( 'Neue Create-Seq.' );

    -- Hier nur durchlaufen, wenn zuvor kein InterMedia gelesen wurde
    IF NOT interMedia_found THEN

      verarbeitet := FALSE;

        -- REM enthalten, dann kann die Zeile entweder
        -- create table oder alter table entahlten
        IF INSTR ( vtLine(1), search_rem_def ) > 0 THEN
          -- dbms_output.put_line ( 'Kommentar-Zeile, also "create table" oder "alter table"' );
          -- dbms_output.put_line ( '                 oder "create global temporary table"' );
          verarbeitet := TRUE;

          -- Unterscheidung "create table" / "alter table" / "create global temporary tanble"
          IF INSTR ( vtLine(1), search_table_def ) > 0 THEN
            FOR j IN 1 .. i_zeilen
            LOOP
              utl_file.put_line ( vFileHandleOutTable
                                , SUBSTR ( vtLine(j), LENGTH ( search_rem_def) + 1 ) );
            END LOOP;
          ELSIF INSTR ( vtLine(1), search_alter_def ) > 0 THEN
            FOR j IN 1 .. i_zeilen
            LOOP
              utl_file.put_line ( vFileHandleOutAlter
                                , SUBSTR ( vtLine(j), LENGTH ( search_rem_def) + 1 ) );
            END LOOP;
          ELSIF INSTR ( vtLine(1), search_GlobalTabel_def ) > 0 THEN
            FOR j IN 1 .. i_zeilen
            LOOP
              utl_file.put_line ( vFileHandleOutTable
                                , SUBSTR ( vtLine(j), LENGTH ( search_rem_def) + 1 ) );
            END LOOP;
          ELSE
            dbms_output.put_line ( 'Fehler - Zeile nicht verarbeitet' );
            dbms_output.put_line ( '<' || vtLine(1) || '>' );
          END IF;

        END IF;

        -- Index
        IF INSTR ( vtLine(1), search_index_def ) > 0 THEN
          -- dbms_output.put_line ( 'Index"' );
          verarbeitet := TRUE;
          FOR j IN 1 .. i_Zeilen
          LOOP
            utl_file.put_line (vFileHandleOutIndex, vtLine(j) );
          END LOOP;
        END IF;

        -- Bit Map Index
        IF INSTR ( vtLine(1), search_bitmap_index_def ) > 0 THEN
          -- dbms_output.put_line ( 'Bit Map Index"' );
          verarbeitet := TRUE;
          FOR j IN 1 .. i_Zeilen
          LOOP
            utl_file.put_line (vFileHandleOutIndex, vtLine(j) );
          END LOOP;
        END IF;

        -- Unique Index
        IF INSTR ( vtLine(1), search_unique_index_def ) > 0 THEN
          -- dbms_output.put_line ( 'Unique Index"' );
          verarbeitet := TRUE;
          FOR j IN 1 .. i_Zeilen
          LOOP
            utl_file.put_line (vFileHandleOutIndex, vtLine(j) );
          END LOOP;
        END IF;


        -- Wurden Zeilen nicht verarbeitet, dann Meldung ausgeben
        IF NOT verarbeitet THEN
          dbms_output.put_line ( vtLine(1) );
        END IF;

        -- dbms_output.put_line ( vtLine(j) );

    END IF;

    interMedia_found := FALSE;

    -- Ganz am Ende der Datei angekommen?
    IF file_ende THEN
      EXIT;
    END IF;

  END LOOP;

  utl_file.FClose(vFileHandleIn);
  utl_file.FClose(vFileHandleOutIndex);
  utl_file.FClose(vFileHandleOutTable);
  utl_file.FClose(vFileHandleOutAlter);
  utl_file.FClose(vFileHandleOutInter);

END;
/
