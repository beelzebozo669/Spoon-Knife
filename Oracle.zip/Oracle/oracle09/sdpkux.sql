rem -------------------------------------------------------------------------
rem        Trivadis AG, Baden/Basel/Bern/Lausanne/Mellingen/Z�rich
rem                     Frankfurt/Freiburg i.Br./M�nchen/Stuttgart
rem                     Switzerland/Germany Internet: http://www.trivadis.com
rem -------------------------------------------------------------------------
rem   $Header$
rem   **********************************************************************
rem   Group/Privileges.: DBA
rem   Script-Name......: sdpkux.sql
rem   Developer........: Andri Kisseleff (ank) andri.kisseleff@trivadis.com
rem   Date.............: 22.12.1995
rem   Version..........: Oracle9i - 2.1
rem   Usage............: Shows UNIQUE/PK Constraint names which are 
rem                      different to the UNIQUE INDEX Names on the same
rem                      tables (may give problems with EXP/IMP, even
rem                      with Oracle 7.3 and higher)
rem   Input parameters.:
rem   Output.......... : 
rem   Called by........:
rem   Remarks..........: set screenwith best to 132 or so
rem -----------------------------------------------------------------------
rem   Performance:
rem   ------------
rem   InFs Version of the 8i-SELECT is much faster. But it requires ACCESS to
rem   to SYS or O7_DICTIONNARY_ACCESSIBILITY must be set to TRUE. Attached the
rem   SELECT, if someone wants to replace it.
rem   select i.table_owner, i.table_name, o.name "Idx-Name", 
rem          c.name "Constraint-Name"
rem   from
rem          sys.obj$ o, sys.user$ u, sys.cdef$ cd, sys.con$ c, dba_indexes i
rem   where u.user#=o.owner#
rem   and o.obj# = cd.enabled
rem   and cd.enabled is not null
rem   and cd.type# in (2,3)
rem   and u.user#=c.owner#
rem   and cd.con#=c.con#
rem   and o.name!=c.name
rem   and i.index_name=o.name
rem   and i.owner=u.name
rem   order by i.table_owner, i.table_name, o.name;
rem
rem
rem $Log$
rem Revision 1.5  2002/09/09 16:56:24  far
rem 9.2 f�hig checked by ThJ
rem
rem Revision 1.4  2001/09/05 04:16:24  ank
rem - New SELECT (index_name now in dba_constraint)
rem - Read the new remarks about performance
rem
rem
rem Changes:
rem DD.MM.YYYY Consultant Change
rem -----------------------------------------------------------------------
rem 21.09.1997 ank        Oracle8
rem 20.04.1999 AnK        OK for Oracle8i
rem 05.09.2001 InF	  new Colum index_name in dba_constraints used
rem 03.09.2002 ThJ        OK for Oracle9i R2
rem -----------------------------------------------------------------------
rem
rem

col table_owner format a15
col table_name heading "Table-Name"
col index_name heading "Index-Name"
col constraint_name heading "Constraint-Name"

@@foenvtit "UNIQUE-  and PK-Constraints with different UNIQUE INDEX NAMES"
spool sdpkux.lis
set lines 115 pages 10000
set termout on
select i.table_owner, i.table_name, i.index_name, c.constraint_name
from sys.dba_constraints c, sys.dba_indexes i
where i.owner=c.owner
and i.table_name=c.table_name
and c.constraint_type in ('P','U')
and i.uniqueness = 'UNIQUE'
and i.owner!='SYS'
and c.index_name != c.constraint_name
order by i.table_owner, i.table_name, i.index_name;
spool off
prompt
prompt sdpkux.lis has been spooled...
prompt
set pages 24 lines 80
ttitle off
