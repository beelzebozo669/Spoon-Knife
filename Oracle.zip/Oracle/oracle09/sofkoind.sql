rem -------------------------------------------------------------------------
rem        Trivadis AG, Baden/Basel/Bern/Lausanne/Mellingen/Z�rich
rem                     Frankfurt/Freiburg i.Br./M�nchen/Stuttgart
rem                     Switzerland/Germany Internet: http://www.trivadis.com
rem -------------------------------------------------------------------------
rem   $Header$
rem   **********************************************************************
rem   Group/Privileges.: Owner
rem   Script-Name......: sofkoind.sql
rem   Developer........: Peter Nuding (pen) 
rem   Date.............: 11.03.1998
rem   Version..........: Oracle9i - 2.0
rem   Usage............: Shows the foreign keys without appropiate index
rem   Input parameters.:
rem   Output.......... : 
rem   Called by........: Owner
rem   Remarks..........: 
rem -----------------------------------------------------------------------
rem
rem $Log$
rem Revision 1.3  2002/09/09 16:56:24  far
rem 9.2 f�hig checked by ThJ
rem
rem Revision 1.2  2001/07/22 12:59:28  ank
rem - Load initial release Oracle9i 9.0.x
rem
rem
rem
rem Changes:
rem DD.MM.YYYY Consultant Change
rem -----------------------------------------------------------------------
rem 12.10.1998 AnK        Removed Breaks, added @@foenvtit, added Table Name in-line
rem                       Only Clear Cols which are defined in the script
rem                       Changed to linesize 80 output
rem                       Removed DECODE in Constraint-Name
rem 20.04.1999 AnK        OK for Oracle8i	
rem 03.09.2002 ThJ        OK for Oracle9i R2
rem -----------------------------------------------------------------------
rem
rem
set echo off
set verify off

column TABLE_NAME format a24 wrap heading "Table Name"
column CONSTRAINT_NAME format a24 wrap heading "Constraint Name"
column CONSTRAINT_TYPE format a3 heading "Typ"
column COLUMN_NAME format a24 wrap heading "1. Column"

store set temp.tmp replace
set pagesize 80
@@foenvtit 'Unindexed Constraints'

PROMPT 
PROMPT Please enter table name. Wildcards allowed (Default: %)
PROMPT
PROMPT eg.: EMP, E% or %
PROMPT

select c.TABLE_NAME,
       decode(c.CONSTRAINT_TYPE,'P','PK',
                                'U','UK',
                                'R','FK','--') CONSTRAINT_TYPE,
       c.CONSTRAINT_NAME,
       cc.COLUMN_NAME
from   USER_CONSTRAINTS  c,
       USER_CONS_COLUMNS cc
where  c.CONSTRAINT_NAME = cc.CONSTRAINT_NAME
and    c.TABLE_NAME      = cc.TABLE_NAME
and    c.CONSTRAINT_TYPE = 'R'
and    cc.POSITION       = 1
and    c.TABLE_NAME   like nvl(upper('&table'),'%')
and    not exists ( select  'x'
                    from    USER_INDEXES      i,
                            USER_IND_COLUMNS  ic
                    where   i.TABLE_NAME       = c.TABLE_NAME
                    and     i.INDEX_NAME       = ic.INDEX_NAME
                    and     ic.COLUMN_NAME     = cc.COLUMN_NAME
                    and     ic.COLUMN_POSITION = cc.POSITION
                    and     ic.COLUMN_POSITION = 1
                  )
order by c.TABLE_NAME, c.CONSTRAINT_NAME;
ttitle off
set pause off
column TABLE_NAME clear
column CONSTRAINT_NAME clear
column CONSTRAINT_TYPE clear
column COLUMN_NAME clear
@temp.tmp


