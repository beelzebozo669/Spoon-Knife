rem -------------------------------------------------------------------------
rem        Trivadis AG, Baden/Basel/Bern/Lausanne/Mellingen/Z�rich
rem                     Frankfurt/Freiburg i.Br./M�nchen/Stuttgart
rem                     Switzerland/Germany Internet: http://www.trivadis.com
rem -------------------------------------------------------------------------
rem   $Header$
rem   **********************************************************************
rem   Group/Privileges.: SYS 
rem   Script-Name......: ismizjob.sql
rem   Developer........: Urs Meier (urm) urs.meier@trivadis.com
rem   Date.............: 1996
rem   Version..........: Oracle9i - 2.0
rem   Usage............: Creates ANALYZE-Jobs for the CBO (Example)
rem   Input parameters.:
rem   Output.......... : 
rem   Called by........:
rem   Remarks..........:
rem -----------------------------------------------------------------------
rem Changes:
rem DD.MM.YYYY Consultant 	Change
rem -----------------------------------------------------------------------
rem 05.04.1997 urs.meier     	rename
rem 02.08.1997 andri.kisseleff  Oracle8
rem 15.11.1997 urs.meier        All statistics in 1 call
rem 20.04.1999 AnK              OK for Oracle8i
rem 30.06.2001 AnK              Replaced dbms_utility by dbms_stats for Oracle9i
rem 03.09.2002 ThJ              OK for Oracle9i R2       
rem -----------------------------------------------------------------------   
rem
rem

set serveroutput on
DECLARE
  vjob   INTEGER;
BEGIN
  dbms_job.submit(job       => vjob,
                  what      => 'dbms_stats.gather_database_stats(ESTIMATE_PERCENT      => 50, '||
                                                                'BLOCK_SAMPLE => FALSE, '||
                                                                'CASCADE => TRUE ,'||
                                                                'DEGREE => 5,'||
                                                                'METHOD_OPT  => ''FOR TABLE FOR ALL INDEXES FOR ALL COLUMNS'');',
                  next_date => SYSDATE,
                  interval  => 'TRUNC(NEXT_DAY(SYSDATE,''SUNDAY''))+(3*(1/24))');
  dbms_output.put('Gather Database Stats has job#: ');
  dbms_output.put(vjob);
  dbms_output.new_line;

  dbms_job.submit(job       => vjob,
                  what      => 'dbms_stats.delete_schema_stats(ownname => ''SYS'');',
                  next_date => SYSDATE+1/24,
                  interval  => 'TRUNC(NEXT_DAY(SYSDATE,''SUNDAY''))+(4*(1/24))');
  dbms_output.put('Delete SYS-Stats has job#: ');
  dbms_output.put(vjob);
  dbms_output.new_line;


END;
/
set serveroutput off
