rem -------------------------------------------------------------------------
rem        Trivadis AG, Baden/Basel/Bern/Lausanne/Mellingen/Z�rich
rem                     Frankfurt/Freiburg i.Br./M�nchen/Stuttgart
rem                     Switzerland/Germany Internet: http://www.trivadis.com
rem -------------------------------------------------------------------------
rem $Header$
rem -------------------------------------------------------------------------
rem   Group/Privileges.: Utilities (User)
rem   Script-Name......: soxplmv.sql
rem   Developer........: Christian Antognini (ChA)
rem   Date.............: 12.07.2001
rem   Version..........: Oracle9i 2.0
rem   Usage............: Used to list materialized view's capabilities
rem   Input parameters.: 
rem   Output.......... : 
rem   Called by........:
rem   Requirements.....: Oracle9i 9.0.1
rem   Remarks..........: MV_CAPABILITIES_TABLE must exists (can be created
rem                      with the script ?/rdbms/admin/utlxmv.sql)
rem                      Lower/Mixed case object names are not supported.
rem
rem -----------------------------------------------------------------------
rem History:
rem $Log$
rem Revision 1.2  2002/09/09 16:56:24  far
rem 9.2 f�hig checked by ThJ
rem
rem Revision 1.1  2001/08/25 06:38:20  ank
rem - Initial Load into CVS
rem
rem Changes:
rem DD.MM.YYYY Consultant Change
rem -----------------------------------------------------------------------
rem 03.09.2002 ThJ        OK for Oracle9i R2
rem -----------------------------------------------------------------------
rem

@@fopauon
set verify off
set recsep each

col capability_name format A29
col possible format A1
col related_text format A12
col msgtxt format A35


prompt 
prompt Please enter materialized view name, wildcards NOT allowed
prompt
accept mview_name char prompt "Materialized View Name: " 


DELETE mv_capabilities_table
WHERE  UPPER(mvname) = UPPER('&&mview_name')
AND    mvowner = user;


EXEC DBMS_MVIEW.EXPLAIN_MVIEW('&&mview_name')


ttitle center 'Capabilities for materialized view ' mview_name skip 2

SELECT capability_name, possible, related_text, msgtxt
FROM   mv_capabilities_table
WHERE  UPPER(mvname) = UPPER('&&mview_name')
AND    mvowner = user
ORDER BY capability_name, related_text;

ttitle off

undef mview_name


col capability_name clear
col possible clear
col related_text clear
col msgtxt clear

@@fopauoff
set verify on
set recsep off

