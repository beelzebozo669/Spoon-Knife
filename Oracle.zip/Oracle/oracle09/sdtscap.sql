rem -----------------------------------------------------------------------------------
rem        Trivadis AG, Basel/Bern/Lausanne/Zuerich
rem                     Duesseldorf/Frankfurt/Freiburg i.Br./Hamburg/Muenchen/Stuttgart
rem                     Wien
rem                     Switzerland/Germany/Austria Internet: http://www.trivadis.com
rem -----------------------------------------------------------------------------------
rem   Group/Privileges.: DBA
rem   Script-Name......: sdtscap.sql
rem   Developer........: Daniel Steiger (das) daniel.steiger@trivadis.com
rem   Date.............: May 2012
rem   Version..........: Oracle11g
rem   Usage............: Must run as user sys. Lists the tablespace capacities incl. 
rem                      AUTOEXEND.
rem   Input parameters.:
rem   Output.......... :
rem   Called by........:
rem   Remarks..........: 
rem
rem -----------------------------------------------------------------------------------
rem Changes:
rem DD.MM.YYYY Consultant Change
rem -----------------------------------------------------------------------------------



SET pagesize 200 linesize 105

ttitle center "Tablespace statistics"  SKIP 1 -
       center "Sizes in MB" SKIP 2

COLUMN tablespace_name format a25 TRUNC heading "Tablespace Name"
COLUMN status format a3 TRUNC
COLUMN extent_management format a3 TRUNC heading MGMT
COLUMN allocation_type format a4 TRUNC heading ALLO
COLUMN LOGGING format a4 TRUNC heading LOGG
COLUMN df_size format 999,990 heading "DF SIZE"
COLUMN used format 999,990 heading "DF USED"
COLUMN sum_free format 999,990 heading "DF FREE"
COLUMN potential format 999,990 heading POTENTIAL
COLUMN m format 999,990 heading "MAX FREE"
COLUMN pct_free format 990.00 heading "% FREE"

SELECT dt.tablespace_name,
       ROUND(capa.df_size/1024/1024) df_size,
       ROUND((capa.df_size - capa.sum_free)/1024/1024) used,
       ROUND(capa.sum_free/1024/1024) sum_free,
       CASE 
     	 WHEN capa.pct_free <= 100 
     	   THEN capa.pct_free
     	 ELSE 100
       END pct_free,
       ROUND(capa.potential/1024/1024) potential,
       ROUND(capa.m/1024/1024) m,
       SUBSTR(dt.status,1,2)||SUBSTR(CONTENTS,1,1) STATUS,
       dt.extent_management, dt.allocation_type, 
       CASE
         WHEN 'YES' IN 
		   (SELECT autoextensible FROM 
         	  (SELECT autoextensible, tablespace_name FROM dba_data_files
         	   UNION ALL
         	   SELECT autoextensible, tablespace_name FROM dba_temp_files) f
            WHERE f.tablespace_name = dt.tablespace_name)
         THEN 'Y'
         ELSE 'N'
       END AS AUTO,
       dt.LOGGING
FROM   dba_tablespaces dt,
	   -- data files 
       (SELECT a.tablespace_name, 
               df_size, 
               allocated + potential potential, 
               NVL(free,0) sum_free,
               (NVL(f.m,0) + potential) m,
               ROUND(NVL((NVL(free,0) + potential)/(allocated + potential),0),4)*100 pct_free
        FROM   (SELECT tablespace_name, SUM(bytes) free, MAX(bytes) m        
                FROM   dba_free_space  
                GROUP BY tablespace_name) f, 
               (SELECT tablespace_name, 
                       SUM(CASE 
                             WHEN maxbytes <= bytes THEN 0
                             ELSE maxbytes - bytes
                           END) potential, 
                       SUM(user_bytes) allocated,
                       SUM(bytes) df_size
                FROM dba_data_files
                GROUP BY tablespace_name) a
        WHERE a.tablespace_name = f.tablespace_name(+)
        UNION ALL
		-- temp files 
        SELECT t.tablespace_name, 
               df_size,
               potential, 
               allocated - NVL(used,0) sum_free,
               0 m,
               ROUND((potential - NVL(used,0))/potential,4)*100 pct_free
        FROM   (SELECT tablespace_name, SUM(bytes_used) used
                FROM   v$temp_extent_pool
                GROUP BY tablespace_name) e,
               (SELECT tablespace_name, 
                       SUM(bytes) df_size,
                       SUM(CASE 
                             WHEN maxbytes <= bytes THEN user_bytes
                             ELSE maxbytes - bytes + user_bytes
                           END) potential,
                       SUM(user_bytes) allocated
                FROM   dba_temp_files
                GROUP BY tablespace_name) t
        WHERE t.tablespace_name = e.tablespace_name(+)) capa
WHERE dt.tablespace_name = capa.tablespace_name
ORDER BY 1;

ttitle off
prompt
prompt DF SIZE  : currently allocated sizes of datafiles belonging to a tablespace
prompt USED     : used part of currently allocated datafiles
prompt DF FREE  : free part of currently allocated datafiles
prompt % FREE   : % free including the potential maxsize of autoextensible datafiles 
prompt POTENTIAL: potential maxium size of the tablespace based on the potential maxsize of its 
prompt .......... autoextensible datafiles
prompt MAX FREE : maximum chunk of free space taking into account the potential maxsize 
prompt .......... of autoextensible datafiles
prompt Status   : ON=ONLINE OF=OFFLINE P=PERMANENT T=TEMPORARY R=READ ONLY U=UNDO
prompt Mgm      : DIC=DICTIONARY LOC=LOCAL
prompt Alloc    : USER=USER (Dictionary managed)
prompt .......... SYST=SYSTEM (Local Autoallocate) UNIF=UNIFORM (Local Uniform)
prompt A        : Y=Tablespace contains autoextensible files 
prompt .......... N=Tablespace contains no autoextensible files
prompt Logg     : LOGG=LOGGING NOLO=NOLOGGING
prompt
