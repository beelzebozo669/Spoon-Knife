rem -------------------------------------------------------------------------
rem        Trivadis AG, Baden/Basel/Bern/Lausanne/Mellingen/Z�rich
rem                     Frankfurt/Freiburg i.Br./M�nchen/Stuttgart
rem                     Switzerland/Germany Internet: http://www.trivadis.com
rem -------------------------------------------------------------------------
rem   $Header$
rem   **********************************************************************
rem   Group/Privileges.: DBA
rem   Script-Name......: ldblkchn.sql
rem   Developer........: Andri Kisseleff (ank) andri.kisseleff@trivadis.com
rem   Date.............: July 1993
rem   Version..........: Oracle9i - 2.0
rem   Usage............: Statistics on tables with block chaining
rem   Input parameters.:
rem   Output.......... : 
rem   Called by........:
rem   Remarks..........: Analyze the statistics first (use usmizsta.sql or so)
rem -----------------------------------------------------------------------
rem
rem $Log$
rem Revision 1.4  2003/03/17 18:45:56  far
rem Anpassungen Ank f�r 9.2
rem
rem Revision 1.2  2001/07/22 12:59:28  ank
rem - Load initial release Oracle9i 9.0.x
rem
rem
rem
rem Changes:
rem DD.MM.YYYY Consultant Change
rem -----------------------------------------------------------------------
rem 02.08.1997 ank        Oracle8 (partition_name, anylyze_timestamp)
rem 15.03.1998 ank        IOTs not analyzed any longer
rem 20.04.1999 AnK        Added Support for Part-Tables (Range, Hash 
rem                       and Composite). OK for Oracle8i.
rem 04.09.2002 ThJ        OK for Oracle9i R2
rem -----------------------------------------------------------------------
rem
rem
	SET ECHO OFF TERMOUT OFF
	DROP TABLE ldblkchn$tmp;
	SET TERMOUT ON
	CREATE TABLE ldblkchn$tmp
	 (
         owner_name         varchar2(30),
         table_name         varchar2(30),
         cluster_name       varchar2(30),
         partition_name     varchar2(30),
         subpartition_name  varchar2(30),
         head_rowid         rowid,
         analyze_timestamp  date)
/
REM
ACCEPT USER_NAMEN CHAR     PROMPT 'Username or Wildcard <%>  : ' DEFAULT '%'
ACCEPT TABELLEN_NAMEN CHAR PROMPT 'Tablename or Wildcard <%> : ' DEFAULT '%'
	SET FEED OFF ECHO OFF TERMOUT OFF PAGES 0 VERIFY OFF ARRAY 1
	SPOOL ldblkchn.tmp
	SELECT 	'ANALYZE TABLE '||OWNER||'.'||TABLE_NAME,
		' LIST CHAINED ROWS INTO ldblkchn$tmp;',
                NULL
	FROM	sys.dba_tables
	WHERE	owner LIKE UPPER('&user_namen')
	AND	table_name LIKE UPPER('&tabellen_namen')
        AND     IOT_TYPE IS NULL
        AND     OWNER NOT IN ('SYS')
        AND     ASCII(SUBSTR(TABLE_NAME,1,1)) != '95'  /* 95 = _ */
        ORDER BY 1;
SPOOL OFF
	SET FEED ON ECHO ON TERMOUT ON PAGES 66 VERIFY ON
@ldblkchn.tmp
CREATE INDEX ldblkchn$tmp_idx on ldblkchn$tmp(owner_name,table_name,partition_name,subpartition_name);
ANALYZE TABLE ldblkchn$tmp estimate statistics;
	SET ECHO OFF
	COLUMN TABLE_NAME FORMAT A30
	COLUMN OWNER_NAME FORMAT A16 TRUNC
	SPOOL ldblkchn.lis
@@foenvtit "Tables/Partitions with Block-Chaining"
	SELECT /*+ rule */ 	RPAD(owner_name,16,'.') owner_name,
		RPAD(c.table_name||decode(c.partition_name,NULL,NULL,
                             ' ('||c.partition_name||')')||' '||
                                   decode(c.subpartition_name,'N/A',NULL,NULL,NULL,
                                       ' ('||c.subpartition_name||')'),30,'.') 
                                       "TABLE_NAME(PART)(SUBPART)",
		num_rows,
		COUNT(*) ch_rows, decode(to_char(pct_free,'99'),NULL,'P',
                                         to_char(pct_free,'99')) pct_free
	FROM	sys.dba_tables t, ldblkchn$tmp c
	WHERE	t.owner = c.owner_name
	AND	t.table_name = c.table_name
        AND     pct_free IS NOT NULL
	GROUP BY owner_name, 
	RPAD(c.table_name||decode(c.partition_name,NULL,NULL,
                             ' ('||c.partition_name||')')||' '||
                                   decode(c.subpartition_name,'N/A',NULL,NULL,NULL,
                                       ' ('||c.subpartition_name||')'),30,'.'),
                 num_rows,
                 decode(to_char(pct_free,'99'),NULL,'P',
                                         to_char(pct_free,'99'))
        UNION
	SELECT 	/*+ rule */ RPAD(owner_name,16,'.') owner_name,
	RPAD(c.table_name||decode(c.partition_name,NULL,NULL,
                             ' ('||c.partition_name||')'),30,'.') 
                                       "TABLE_NAME(PART)(SUBPART)",
		num_rows,
		COUNT(*) ch_rows, decode(to_char(pct_free,'99'),NULL,'P',
                                         to_char(pct_free,'99')) pct_free
	FROM	sys.dba_tab_partitions t, ldblkchn$tmp c
	WHERE	t.table_owner = c.owner_name
	AND	t.table_name = c.table_name
        AND     t.partition_name = c.partition_name
        AND     c.subpartition_name = 'N/A'
	GROUP BY owner_name, 
	RPAD(c.table_name||decode(c.partition_name,NULL,NULL,
                             ' ('||c.partition_name||')'),30,'.'),
                 num_rows,
                 decode(to_char(pct_free,'99'),NULL,'P',
                                         to_char(pct_free,'99'))
        UNION
	SELECT 	/*+ rule */ RPAD(owner_name,16,'.') owner_name,
	RPAD(c.table_name||decode(c.partition_name,NULL,NULL,
                             ' ('||c.partition_name||')')||' '||
                                   decode(c.subpartition_name,'N/A',NULL,NULL,NULL,
                                       ' ('||c.subpartition_name||')'),30,'.') 
                                       "TABLE_NAME(PART)(SUBPART)",
		num_rows,
		COUNT(*) ch_rows, decode(to_char(pct_free,'99'),NULL,'P',
                                         to_char(pct_free,'99')) pct_free
	FROM	sys.dba_tab_subpartitions t, ldblkchn$tmp c
	WHERE	t.table_owner = c.owner_name
	AND	t.table_name = c.table_name
        AND     t.partition_name = c.partition_name
        AND     t.subpartition_name = c.subpartition_name
        AND     c.subpartition_name != 'N/A'
	GROUP BY owner_name, 
	RPAD(c.table_name||decode(c.partition_name,NULL,NULL,
                             ' ('||c.partition_name||')')||' '||
                                   decode(c.subpartition_name,'N/A',NULL,NULL,NULL,
                                       ' ('||c.subpartition_name||')'),30,'.'),
                 num_rows,
                 decode(to_char(pct_free,'99'),NULL,'P',
                                         to_char(pct_free,'99'))
	UNION
	SELECT 	'No chaining',NULL,0,0,'0'
	FROM 	dual
	WHERE 	0 = ( SELECT 	COUNT(*)
		      FROM	ldblkchn$tmp
		      WHERE	rownum = 1 )
	ORDER BY 1,2;
        TTITLE OFF
        @foenvtit "Number of chained row accesses since last startup"
        SELECT value 
        FROM   v$sysstat
        WHERE  NAME = 'table fetch continued row';
	SPOOL OFF
	SET FEED ON ECHO OFF TERMOUT ON PAGES 24 VERIFY ON
	TTITLE OFF
REM	DROP TABLE ldblkchn$tmp;
prompt
prompt ldblkchn.lis has been spooled...
prompt
