rem -------------------------------------------------------------------------
rem        Trivadis AG, Baden/Basel/Bern/Lausanne/Mellingen/Z�rich
rem                     Frankfurt/Freiburg i.Br./M�nchen/Stuttgart
rem                     Switzerland/Germany Internet: http://www.trivadis.com
rem -------------------------------------------------------------------------
rem   $Header$
rem   **********************************************************************
rem   Group/Privileges.: Utilities
rem   Script-Name......: soobjsrc.sql
rem   Developer........: Urs Meier (urm) urs.meier@trivadis.com
rem   Date.............: 11.08.1992
rem   Version..........: Oracle9i - 2.0
rem   Usage............: Show the source code for a pl/sql object
rem                      Triggers are not supported. They are in
rem                      user_triggers, not in user_source
rem   Input parameters.:
rem   Output.......... : 
rem   Called by........:
rem   Remarks..........:
rem -----------------------------------------------------------------------
rem
rem $Log$
rem Revision 1.3  2002/09/09 16:56:24  far
rem 9.2 f�hig checked by ThJ
rem
rem Revision 1.2  2001/07/22 12:59:28  ank
rem - Load initial release Oracle9i 9.0.x
rem
rem
rem
rem Changes:
rem DD.MM.YYYY Consultant Change
rem -----------------------------------------------------------------------
rem 05.04.1997 urs.meier  rename
rem 21.09.1997 AnK        Oracle8
rem 21.04.1999 AnK        OK for Oracle8i
rem 03.09.2002 ThJ        OK for Oracle9i R2
rem -----------------------------------------------------------------------
rem
rem
	CLEAR column -
	      breaks -
	      computes
	SET echo off -
	    feedback off -
	    pagesize 22 -
	    termout on -
	    verify off

	COLUMN name	NOPRINT		NEW_VALUE name
	COLUMN type	NOPRINT		NEW_VALUE type
	COLUMN status	NOPRINT		NEW_VALUE status

	BREAK ON name SKIP PAGE
@@fopauon
TTITLE CENTER 'Source-Code for 'type ' ' name ' --> ' status skip 2

ACCEPT obj CHAR PROMPT "Show source code for object(s) [%]: " Default "%"

	SELECT src.name, src.type, obj.status, src.text
	  FROM user_source src,
	       user_objects obj
	 WHERE src.name = obj.object_name
	   AND src.type = obj.object_type
	   AND src.name LIKE UPPER('&obj')
	 ORDER BY src.type,src.name,src.line;

@@fopauoff
	TTITLE off
	CLEAR BREAKS COMPUTES
 
	COLUMN name	CLEAR
	COLUMN type	CLEAR
	COLUMN status	CLEAR

