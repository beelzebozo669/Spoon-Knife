CLEAR SCREEN

SET LINESIZE 200
SET PAGESIZE 25
SET VERIFY OFF

COLUMN forenames      FORMAT A30 HEADING "Forename"
COLUMN surname        FORMAT A30 HEADING "Surname"
COLUMN class_user_id  FORMAT A15 HEADING "Class User ID"
COLUMN created_by     FORMAT A15 HEADING "Created By"
COLUMN created        FORMAT A20 HEADING "Created"
COLUMN username       FORMAT A30 HEADING "User name"
COLUMN active_flag    FORMAT A30 HEADING "Active Flag"
COLUMN login          FORMAT A20 HEADING "Login Date"
COLUMN account_status FORMAT A30 HEADING "Status"
COLUMN locked         FORMAT A20 HEADING "Locked"
COLUMN expired        FORMAT A20 HEADING "Expired"
COLUMN created        FORMAT A20 HEADING "Created"
COLUMN grantee        FORMAT A30 HEADING "Grantee"
COLUMN granted_role   FORMAT A30 HEADING "Granted Role(s)"

ACCEPT uid CHAR PROMPT 'Enter user name to be queried : '

TTITLE CENTER 'SLC EMPLOYEE Query Results' SKIP 2

  SELECT forenames,
         surname,
         class_user_id,
         active_flag,
         created_by,
         TO_CHAR(created_date,'DD/MM/YYYY HH24:MI:SS') created
    FROM class.slc_employees
   WHERE class_user_id IN UPPER('&uid')
ORDER BY active_flag, class_user_id;

ALTER SESSION SET nls_date_format = 'DD/MM/YYYY';

TTITLE CENTER 'Logon Audit Query Results' SKIP 2

  SELECT username, to_char(max(timestamp),'DD/MM/YYYY HH24:MI:SS') LOGIN
    FROM logon_audit
   WHERE username IN UPPER('&uid')
GROUP BY username
ORDER BY 2, 1;

TTITLE CENTER 'DBA Users Query Results' SKIP 2

  SELECT username,
         account_status,
         TO_CHAR(lock_date,'DD/MM/YYYY HH24:MI:SS') locked,
         TO_CHAR(expiry_date,'DD/MM/YYYY HH24:MI:SS') expired,
         TO_CHAR(created,'DD/MM/YYYY HH24:MI:SS') created
    FROM dba_users
   WHERE username IN UPPER('&uid')
ORDER BY username;

TTITLE CENTER 'User Privileges Query Results' SKIP 2

  SELECT *
    FROM dba_role_privs
   WHERE grantee IN UPPER('&uid')
ORDER BY grantee, granted_role;

UNDEFINE uid

TTITLE OFF

CLEAR COLUMNS

SET LINESIZE 80
SET PAGESIZE 20
SET VERIFY ON
