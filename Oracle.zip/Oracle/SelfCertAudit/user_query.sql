CLEAR SCREEN

SET LINESIZE 200
SET PAGESIZE 25
SET VERIFY OFF

COLUMN forename      FORMAT A40 HEADING "Forname(s)"
COLUMN surname       FORMAT A40 HEADING "Surname"
COLUMN created_date  FORMAT A20 HEADING "Date Created"
COLUMN class_user_id FORMAT A30 HEADING "Class User ID"

PROMPT Input will be forced into uppercase automatically
PROMPT User Surname and Forname are wild card searches so need not be complete
PROMPT
ACCEPT activeflag CHAR PROMPT 'Do you want Inactive or Active users? N/Y : '
ACCEPT usurname   CHAR PROMPT 'Enter user surname to be queried          : '
ACCEPT uforename  CHAR PROMPT 'Enter user forename to be queried         : '

TTITLE CENTER 'User Query Results' SKIP 2

  SELECT forenames, surname, TO_CHAR(created_date,'DD/MM/YYYY HH24:MI:SS'), class_user_id
    FROM class.slc_employees
   WHERE class_user_id IS NOT NULL
     AND active_flag   LIKE UPPER('&activeflag')
     AND surname       LIKE UPPER('&usurname%')
     AND forenames     LIKE UPPER('&uforename%')
ORDER by surname, forenames;

UNDEFINE activeflag
UNDEFINE usurname
UNDEFINE uforename

TTITLE OFF

CLEAR COLUMNS

SET VERIFY ON
SET LINESIZE 80
SET PAGESIZE 20