COLUMN y NEW_VALUE sid NOPRINT
  SELECT name||'_'||TO_CHAR(SYSDATE, 'ddmonyy_hh24mi') y
    FROM v$database;

	SPOOL checklist_&sid..txt

---alter system checkpoint;

---alter system check datafiles;

SET LINESIZE 300
SET PAGESIZE 300
SET SQLPROMPT 'Sql>'
SET DESC LINENUM ON
SET ARRAYSIZE 1
SET LONG 2000
SET SERVEROUTPUT ON SIZE 1000000 ;
SET HEADING OFF
SET FEEDBACK OFF
SET VERIFY OFF

COLUMN Var_Date NEW_VALUE Var_Date noprint

  SELECT TO_CHAR(Sysdate, 'DD-MM-YYYY HH24:MI') Var_Date
    FROM v$database;

-- PROMPT ---

  SELECT ' ****** &Var_Date ************** Base : ' || Name || ' ************** '
    FROM v$database;

SET HEADING On

COLUMN sid      FORMAT 9999 HEADING "Id"
COLUMN spid     FORMAT A7   HEADING "Unix"
COLUMN username FORMAT A20  HEADING "Utilis."
COLUMN terminal FORMAT A11  HEADING "Terminal"
COLUMN program  FORMAT A27  HEADING "Programme" WORD_WRAPPED

  SELECT s.sid,
         p.spid,
		 SUBSTR(s.username,1,20) username,
		 s.terminal,
		 p.program
    FROM v$session s,
	     v$process p
   WHERE s.paddr = p.addr
     AND s.sid = (
                    SELECT sid
					  FROM v$mystat
					 WHERE rownum = 1
                 );

SET HEADING OFF
SET TERMOUT OFF

COLUMN Var_PROMPT NEW_VALUE Var_PROMPT NOPRINT

  SELECT '''' || RPAD(LPAD(INITCAP(SUBSTR(Name,1,4)),3,'*'),4,'*') || '>''' Var_PROMPT
    FROM v$database;

SET SQLPROMPT &Var_PROMPT

SET TERMOUT ON

PROMPT

-- PROMPT ---

SET HEADING ON
SET FEEDBACK ON

-- PROMPT

PROMPT -- ----------------------------------------------------------------------- ---

PROMPT -- Oracle Instance Information ---

PROMPT -- ----------------------------------------------------------------------- ---

SET HEADING OFF
SET FEEDBACK OFF
SET VERIFY OFF

COLUMN status FORMAT A120 WRAP HEADING "Status"
 
SELECT status_01 || ' | ' || status_02 status
FROM (
        SELECT ' Host_Name ' || LPAD(Host_Name,18) status_02
		  FROM v$instance
     ),
	(
       SELECT ' Cpu_COUNT ' || LPAD(value,8) status_01
         FROM v$parameter
        WHERE name = 'cpu_COUNT'
          AND value IS NOT NULL)
UNION
  SELECT status_01 || ' | ' || status_02 status
    FROM (
            SELECT ' Instance_Name ' || LPAD(instance_name,12) Status_01
              FROM v$instance),
         (
            SELECT ' Database_Status ' || LPAD(database_status,12) Status_02
              FROM v$instance
         )
UNION
  SELECT status_01 || ' | ' || status_02 status
    FROM (
            SELECT ' Startup_Time ' || TO_CHAR(startup_time, 'DD-MM-YYYY HH24:MI') Status_02
              FROM v$instance
         ),
		 (
            SELECT ' Status ' || LPAD(status,12) Status_01
              FROM v$instance
         )
UNION
  SELECT status_01 || ' | ' || status_02 status
    FROM (
            SELECT ' Version ' || LPAD(version,12) Status_01
              FROM v$instance
         ),
         (
            SELECT ' Instance_Role ' || LPAD(instance_role,16) Status_02
              FROM v$instance
         );

  SELECT ' Database log mode ' || log_mode "Parameter"
    FROM v$database
UNION
  SELECT ' Archive destination ' || value
    FROM v$parameter
   WHERE (   name = 'log_archive_dest'
          OR 
             name = 'log_archive_dest_1'
         )
     AND value IS NOT NULL;

  SELECT ' Compatible Version ' || value
    FROM v$parameter
   WHERE name = 'compatible';

  SELECT ' Spfile ' || value
    FROM v$parameter
   WHERE name = 'spfile'
     AND value IS NOT NULL
UNION
  SELECT ' Background Dump Dest ' || value
    FROM v$parameter
   WHERE name = 'background_dump_dest'
     AND value IS NOT NULL;

-- ----------------------------------------------------------------------- ---
-- Check Redo Size ---
-- ----------------------------------------------------------------------- ---

  SELECT DISTINCT ' Redo size (Kb) '|| LPAD(TO_CHAR(ROUND(bytes/1024)),'16') Status
    FROM v$log;

PROMPT

DECLARE
--
 CURSOR Cur_Req IS
  SELECT DISTINCT object_name
    FROM dba_objects
   WHERE object_name = 'DBA_TEMP_FILES';
 --
  CURSOR Cur_SGA IS
  SELECT ' SGA (Mb) ' || LPAD(TO_CHAR(ROUND(SUM(value)/1024/1024)),8) status_02
    FROM v$sga;
--
W_Texte     VARCHAR2(2000);
Curs        INTEGER;
Return_code INTEGER;
W_Temp      VARCHAR2(40);
--
X           VARCHAR2(100);
Nb_Tf       NUMBER(8);
SGA         VARCHAR2(40);
--
BEGIN
--
X := NULL;
--
OPEN  Cur_Req;
FETCH Cur_Req INTO X;
CLOSE Cur_Req;
 --
OPEN  Cur_SGA;
FETCH Cur_SGA INTO SGA;
CLOSE Cur_SGA;
--
 IF X IS NOT NULL THEN
--
W_Texte := 'SELECT ''Database Space (Mb) ''||LPAD(TO_CHAR(ROUND((nb_ctl.nb * ctl_size.the_size) ';
W_Texte := W_texte ||' + (rlf_size.the_size/1024) ';
W_Texte := W_texte ||' + (dtf_size.the_size/1024) ';
W_Texte := W_texte ||' + (NVL(dtft_size.the_size,0)/1024))),8) FROM ';
W_Texte := W_texte ||' (SELECT COUNT(1) nb FROM v$controlfile) nb_ctl ';
W_Texte := W_texte ||' , (SELECT ROUND(SUM(record_size)/1024) the_size FROM v$controlfile_record_section) ctl_size ';
W_Texte := W_texte ||' , (SELECT ROUND(SUM(bytes)/1024) the_size FROM v$log) rlf_size ';
W_Texte := W_texte ||' , (SELECT ROUND(SUM(bytes)/1024) the_size FROM dba_data_files) dtf_size ';
W_Texte := W_texte ||' , (SELECT ROUND(SUM(bytes)/1024) the_size FROM dba_temp_files) dtft_size';
--
ELSE
--
W_Texte := 'SELECT ''Database Space (Mb) ''||LPAD(TO_CHAR(ROUND((nb_ctl.nb * ctl_size.the_size) ';
W_Texte := W_texte ||' + (rlf_size.the_size/1024) ';
W_Texte := W_texte ||' + (dtf_size.the_size/1024) ';
W_Texte := W_texte ||' + (NVL(dtft_size.the_size,0)/1024))),8) FROM ';
W_Texte := W_texte ||' (SELECT COUNT(1) nb FROM v$controlfile) nb_ctl ';
W_Texte := W_texte ||' , (SELECT ROUND(SUM(record_size)/1024) the_size FROM v$controlfile_record_section) ctl_size ';
W_Texte := W_texte ||' , (SELECT ROUND(SUM(bytes)/1024) the_size FROM v$log) rlf_size ';
W_Texte := W_texte ||' , (SELECT ROUND(SUM(bytes)/1024) the_size FROM dba_data_files) dtf_size ';
--
END IF;
--
Curs := DBMS_SQL.OPEN_CURSOR;
--
Dbms_Sql.Parse(Curs, W_texte, Dbms_Sql.Native);
Dbms_Sql.Define_Column(Curs, 1, W_Temp, 40);
--
Return_Code := Dbms_Sql.EXECUTE(Curs);
--
IF dbms_sql.FETCH_ROWS(Curs)> THEN
Dbms_Sql.Column_Value(Curs, 1, W_Temp);
END IF;
 --
DBMS_OUTPUT.PUT_LINE('-- '||W_Temp||' | '||SGA||' --');
--
Dbms_Sql.CLOSE_CURSOR(Curs);
--
END;
/
 
 
 
 
 
DECLARE
--
  CURSOR Cur_Req IS
  SELECT DISTINCT object_name
    FROM dba_objects
   WHERE object_name = 'DBA_TEMP_FILES';
--
  CURSOR Cur_Df IS
  SELECT COUNT(*)
    FROM dba_data_files;
--
W_Texte     VARCHAR2(2000);
Curs        INTEGER;
Return_code INTEGER;
W_Temp      VARCHAR2(20);
--
X           VARCHAR2(100);
Nb_Tf       NUMBER(8);
Nb_Df       NUMBER(8);
--
BEGIN
 --
X := NULL;
--
OPEN  Cur_Req;
FETCH Cur_Req INTO X;
CLOSE Cur_Req;
--
OPEN  Cur_Df;
FETCH Cur_Df INTO Nb_Df;
CLOSE Cur_Df;
 --
IF X IS NOT NULL THEN
--
W_Texte := 'SELECT TO_CHAR(COUNT(*)) FROM dba_temp_files';
--
Curs := Dbms_Sql.OPEN_CURSOR;
--
Dbms_Sql.Parse(Curs, W_texte, Dbms_Sql.Native);
Dbms_Sql.Define_Column(Curs, 1, W_Temp, 20);
--
Return_Code := Dbms_Sql.Execute(Curs);
--
IF dbms_sql.FETCH_ROWS(Curs)> THEN
Dbms_Sql.Column_Value(Curs, 1, W_Temp);
END IF;
 --
DBMS_OUTPUT.PUT_LINE('-- Nb. Datafiles ' || LPAD(TO_CHAR(Nb_Df),5) || ' | Nb. Tempfiles ' || LPAD(W_Temp,5) || ' --' );
--
Dbms_Sql.CLOSE_CURSOR(Curs);
--
ELSE
DBMS_OUTPUT.PUT_LINE('-- Nb. Datafiles ' || LPAD(TO_CHAR(Nb_Df),5));
END IF;
--
END;
/

PROMPT
PROMPT

PROMPT -- ----------------------------------------------------------------------- ---

PROMPT -- Instance CheckList ---

PROMPT -- ----------------------------------------------------------------------- ---

  SELECT status_01 || ' | ' || status_02 status
    FROM (
            SELECT ' Instance Status ' || LPAD('OK',12) Status_01
              FROM v$instance
         ),
         (
            SELECT ' Listener Status ' || LPAD('OK',12) Status_02
              FROM v$instance
		 );

PROMPT
PROMPT

PROMPT -- ----------------------------------------------------------------------- ---

PROMPT -- Performance Memory CheckList ---

PROMPT -- ----------------------------------------------------------------------- ---

PROMPT ---

DECLARE
  CURSOR c1 IS
  SELECT COUNT(*)
    FROM v$session
   WHERE serial# != 1
     AND osuser IS NOT NULL;
 ---
  CURSOR c2 IS
  SELECT COUNT(*)
    FROM v$session
   WHERE SERIAL# != 1
     AND osuser IS NOT NULL
     AND status = 'ACTIVE';
---
  CURSOR c3 IS
  SELECT ((1-a.value/(b.value + c.value))*100)
    FROM v$sysstat a,
         v$sysstat b,
         v$sysstat c
   WHERE a.name = 'physical reads'
    AND b.name = 'db block gets'
    AND c.name = 'consistent gets';
---
  CURSOR c4 IS
  SELECT ((SUM(pins) / (SUM(pins) + SUM(reloads)) * 100))
    FROM v$librarycache;
---
  CURSOR c5 IS
  SELECT ((1-(SUM(getmisses) / SUM(gets))) * 100)
    FROM v$rowcache;
---
  CURSOR c6 IS
  SELECT (COUNT(*) / 24)
    FROM sys.v$log_history
   WHERE first_time > sysdate - 1;
---
  CURSOR c7 IS
  SELECT COUNT(*)
    FROM dba_jobs
   WHERE broken != 'N';
---
  CURSOR c8 IS
  SELECT COUNT(*)
    FROM v$shared_pool_reserved
   WHERE request_failures != 0;
---
  CURSOR c9 IS
  SELECT ROUND(100 * retries.value / entries.value, 4)
    FROM gv$sysstat retries,
         gv$sysstat entries
   WHERE retries.name = 'redo buffer allocation retries'
     AND entries.name = 'redo entries'
     AND entries.inst_id = retries.inst_id;
 
---
  CURSOR c10 IS
  SELECT NVL(total_waits,)
    FROM gv$system_event
   WHERE event LIKE '%log buffer space%';
---
  CURSOR c11 IS
  SELECT ROUND(100 * SUM(getmisses) / SUM(gets), 3)
    FROM gv$rowcache;
---
A NUMBER(8);
B NUMBER(8);
C NUMBER(8);
D NUMBER(8);
E NUMBER(8);
F NUMBER(8);
G NUMBER(8);
H NUMBER(8);
I NUMBER(8,4);
J NUMBER(8);
K NUMBER(8,3);
---
AA VARCHAR2(5);
BB VARCHAR2(5);
CC VARCHAR2(5);
DD VARCHAR2(5);
EE VARCHAR2(5);
FF VARCHAR2(5);
GG VARCHAR2(5);
HH VARCHAR2(5);
II VARCHAR2(5);
JJ VARCHAR2(5);
KK VARCHAR2(5);
---
BEGIN
OPEN  c1;
FETCH c1 INTO A;
CLOSE c1;

OPEN  c2;
FETCH c2 INTO B;
CLOSE c2;

OPEN  c3;
FETCH c3 INTO C;
CLOSE c3;

OPEN  c4;
FETCH c4 INTO D;
CLOSE c4;

OPEN  c5;
FETCH c5 INTO E;
CLOSE c5;

OPEN  c6;
FETCH c6 INTO F;
CLOSE c6;

OPEN  c7;
FETCH c7 INTO G;
CLOSE c7;

OPEN  c8;
FETCH c8 INTO H;
CLOSE c8;

OPEN  c9;
FETCH c9 INTO I;
CLOSE c9;

OPEN  c10;
FETCH c10 INTO J;
CLOSE c10;

OPEN  c11;
FETCH c11 INTO K;
CLOSE c11;

IF A <= 700 THEN
            AA := 'OK';
ELSE
            AA := 'NO';
END IF;

IF B <= 15 THEN
           BB := 'OK';
ELSE
           BB := 'NO';
END IF;

IF C >= 80 THEN
           CC := 'OK';
ELSE
           CC := 'NO';
END IF;

IF D >= 99 THEN
           DD := 'OK';
ELSE
           DD := 'NO';
END IF;

IF E >= 80 THEN
           EE := 'OK';
ELSE
           EE := 'NO';
END IF;

IF F <= 5 THEN
          FF := 'OK';
ELSE
          FF := 'NO';
END IF;

IF G =    THEN
          GG := 'OK';
ELSE
          GG := 'NO';
END IF;

IF H =    THEN
          HH := 'OK';
ELSE
          HH := 'NO';
END IF;

IF I <= 0.0010 THEN
          II := 'OK';
ELSE
          II := 'NO';
END IF;

IF J =    THEN
          JJ := 'OK';
ELSE 
IF J IS NULL THEN
          JJ := 'OK';
           J := ;
ELSE
          JJ := 'NO';
END IF;

IF K <= 0.015 THEN
          KK := 'OK';
ELSE
          KK := 'NO';
END IF;

DBMS_OUTPUT.PUT_LINE('-- '||'Total Sessions < 700 '          || LPAD(AA,5) || ' - ' || LPAD(TO_CHAR(A),5));
DBMS_OUTPUT.PUT_LINE('-- '||'Active sessions NUMBER <15 '    || LPAD(BB,5) || ' - ' || LPAD(TO_CHAR(B),5));
DBMS_OUTPUT.PUT_LINE('-- '||'Data Buffer Hit Ratio > 80 '    || LPAD(CC,5) || ' - ' || LPAD(TO_CHAR(C),5));
DBMS_OUTPUT.PUT_LINE('-- '||'L.Buffer Reload Pin Ratio > 99' || LPAD(DD,5) || ' - ' || LPAD(TO_CHAR(D),5));
DBMS_OUTPUT.PUT_LINE('-- '||'Row Cache Miss Ratio < 0.015 '  || LPAD(KK,5) || ' - ' || LPAD(TO_CHAR(K),5));
DBMS_OUTPUT.PUT_LINE('-- '||'Dict.Buffer Hit Ratio > 80 '    || LPAD(EE,5) || ' - ' || LPAD(TO_CHAR(E),5));
DBMS_OUTPUT.PUT_LINE('-- '||'Log Buffer Waits = 0 '          || LPAD(JJ,5) || ' - ' || LPAD(TO_CHAR(J),5));
DBMS_OUTPUT.PUT_LINE('-- '||'Log Buffer Retries < 0.0010 '   || LPAD(II,5) || ' - ' || LPAD(TO_CHAR(I),5));
DBMS_OUTPUT.PUT_LINE('-- '||'Switch NUMBER (Daily Avg) < 5 ' || LPAD(FF,5) || ' - ' || LPAD(TO_CHAR(F),5));
DBMS_OUTPUT.PUT_LINE('-- '||'Jobs Broken = 0 '               || LPAD(GG,5) || ' - ' || LPAD(TO_CHAR(G),5));
DBMS_OUTPUT.PUT_LINE('-- '||'Shared_Pool Failure = 0 '       || LPAD(HH,5) || ' - ' || LPAD(TO_CHAR(H),5));
END;
/

PROMPT ---

PROMPT -- ----------------------------------------------------------------------- ---

PROMPT -- Storage CheckList ---

PROMPT -- ----------------------------------------------------------------------- ---

PROMPT ---

  SELECT status_01 || ' | ' || status_02 status
    FROM (
	        SELECT DISTINCT DECODE(status, 'ONLINE', ' V$Datafile Status ' || LPAD('OK',12), 'SYSTEM', ' V$Datafile Status ' || LPAD('OK',12) , ' v$datafile Status ' || LPAD('NO',12)) STATUS_01
              FROM v$datafile
         ),
         (
            SELECT DISTINCT DECODE(status, 'ONLINE', ' V$Tempfile Status ' || LPAD('OK',14) , 'SYSTEM', ' V$Tempfile Status ' || LPAD('OK',14), ' v$tempfile Status ' || LPAD('NO',14)) STATUS_02
              FROM v$tempfile
         )
UNION
  SELECT status_01 || ' | ' || status_02 status
    FROM (
            SELECT DISTINCT DECODE(status, 'ONLINE', ' Dba_Tablespaces Status ' || LPAD('OK',7), 'READ ONLY', ' Dba_Tablespaces Status ' || LPAD('OK',7) , ' Dba_Tablespaces Status ' || LPAD('NO',7)) STATUS_01
              FROM dba_tablespaces
         ),
         (
            SELECT DISTINCT DECODE(status, 'CURRENT', ' V$Log Status ' || LPAD('OK',19) , 'ACTIVE', ' V$Log Status ' || LPAD('OK',19), 'INACTIVE', ' V$Log Status ' || LPAD('OK',19), ' V$Log Status ' || LPAD('NO',19)) STATUS_02
              FROM v$log
         )
UNION
  SELECT status_01 || ' | ' || status_02 status
    FROM (
            SELECT DISTINCT DECODE(COUNT(1), , ' V$Recover_File ' || LPAD('OK',15), ' V$Recover_File ' || LPAD('NO',15)) STATUS_01
              FROM v$recover_file),
         (
            SELECT DISTINCT DECODE(COUNT(1), , ' V$Recovery_Log ' || LPAD('OK',17), ' V$Recovery_Log ' || LPAD('NO',17)) STATUS_02
              FROM v$recovery_log
         );

PROMPT

DECLARE
  CURSOR c1 IS
  SELECT COUNT(*)
    FROM v$backup
   WHERE status != 'NOT ACTIVE';

---
  CURSOR c2 IS
  SELECT COUNT(*)
    FROM (
            SELECT SUM (bytes)/1048576 free, max (bytes)/1048576 fragmax, tablespace_name
              FROM sys.dba_free_space
          GROUP BY tablespace_name
         ) fsp,
         (
            SELECT SUM(bytes)/1048576 alloc, tablespace_name
              FROM sys.dba_data_files
          GROUP BY tablespace_name
         ) df,
         dba_tablespaces dt
   WHERE fsp.tablespace_name (+) = df.tablespace_name
     AND df.tablespace_name = dt.tablespace_name
     AND dt.status = 'ONLINE'
     AND (((alloc - NVL(free, )) / alloc) * 100 > 95);

---
  CURSOR c3 IS
  SELECT COUNT(*)
    FROM dba_objects
   WHERE status != 'VALID'
     AND owner NOT IN ('PUBLIC','WKSYS','MDSYS','TSMSYS','CTXSYS','OLAPSYS','EXFSYS','ORDSYS','SYSMAN','SYS','WMSYS','SYSTEM','OUTLN','DBSNMP');
---
  CURSOR c4 IS
  SELECT COUNT(*)
    FROM dba_indexes
    WHERE status = 'UNUSABLE';
---
  CURSOR c5 IS
  SELECT COUNT(*)
    FROM dba_triggers
   WHERE status != 'ENABLED'
     AND owner NOT IN ('PUBLIC','WKSYS','MDSYS','TSMSYS','CTXSYS','OLAPSYS','EXFSYS','ORDSYS','SYSMAN','SYS','WMSYS','SYSTEM','OUTLN','DBSNMP');
---
  CURSOR c6 IS
  SELECT COUNT(*)
    FROM dba_constraints
   WHERE status != 'ENABLED'
     AND owner NOT IN ('PUBLIC','WKSYS','MDSYS','TSMSYS','CTXSYS','OLAPSYS','EXFSYS','ORDSYS','SYSMAN','SYS','WMSYS','SYSTEM','OUTLN','DBSNMP')
     AND constraint_type!='S';
---
A NUMBER(8);
B NUMBER(8);
C NUMBER(8);
D NUMBER(8);
E NUMBER(8);
F NUMBER(8);
 ---
AA VARCHAR2(5);
BB VARCHAR2(5);
CC VARCHAR2(5);
DD VARCHAR2(5);
EE VARCHAR2(5);
FF VARCHAR2(5);
---
BEGIN
OPEN c1;
FETCH c1 INTO A;
CLOSE c1;

OPEN c2;
FETCH c2 INTO B;
CLOSE c2;

OPEN c3;
FETCH c3 INTO C;
CLOSE c3;

OPEN c4;
FETCH c4 INTO D;
CLOSE c4;

OPEN c5;
FETCH c5 INTO E;
CLOSE c5;

OPEN c6;
FETCH c6 INTO F;
CLOSE c6;

IF A =  THEN
        AA := 'OK';
ELSE
        AA := 'NO';
END IF;

IF B =  THEN
        BB := 'OK';
ELSE
        BB := 'NO';
END IF;

IF C =  THEN
        CC := 'OK';
ELSE
        CC := 'NO';
END IF;

IF D =  THEN
        DD := 'OK';
ELSE
        DD := 'NO';
END IF;

IF E =  THEN
        EE := 'OK';
ELSE
        EE := 'NO';
END IF;

IF F =  THEN
        FF := 'OK';
ELSE
        FF := 'NO';
END IF;

DBMS_OUTPUT.PUT_LINE('-- '||'Tablespace in Backup Mode = 0 '||LPAD(AA,5)||' - '||LPAD(TO_CHAR(A),5));
DBMS_OUTPUT.PUT_LINE('-- '||'Tablespace > 95% '             ||LPAD(BB,5)||' - '||LPAD(TO_CHAR(B),5));
DBMS_OUTPUT.PUT_LINE('-- '||'Objects Invalid = 0 '          ||LPAD(CC,5)||' - '||LPAD(TO_CHAR(C),5));
DBMS_OUTPUT.PUT_LINE('-- '||'Indexes unusable = 0 '         ||LPAD(DD,5)||' - '||LPAD(TO_CHAR(D),5));
DBMS_OUTPUT.PUT_LINE('-- '||'Trigger Disabled = 0 '         ||LPAD(EE,5)||' - '||LPAD(TO_CHAR(E),5));
DBMS_OUTPUT.PUT_LINE('-- '||'Constraint Disabled = 0 '      ||LPAD(FF,5)||' - '||LPAD(TO_CHAR(F),5));
END;
/
 
 
 
DECLARE
  CURSOR c1 IS
  SELECT COUNT(*)
    FROM dba_segments
   WHERE max_extents-extents < 10
   AND segment_type <> 'CACHE';
---
  CURSOR c2 IS
  SELECT COUNT(*)
  FROM sys.dba_segments a
  WHERE a.tablespace_name NOT LIKE 'T%MP%'
    AND next_extent * 2 > (
                             SELECT MAX(b.bytes)
                               FROM dba_free_space b
                              WHERE a.tablespace_name = b.tablespace_name
                          );
---
  CURSOR c3 IS
  SELECT COUNT(*)
    FROM sys.dba_segments
   WHERE owner NOT IN ('PUBLIC','WKSYS','MDSYS','TSMSYS','CTXSYS','OLAPSYS','EXFSYS','ORDSYS','SYSMAN','SYS','WMSYS','SYSTEM','OUTLN','DBSNMP')
     AND tablespace_name = 'SYSTEM';
---
  CURSOR c4 IS
  SELECT COUNT(*)
    FROM (
            SELECT SUBSTR(a.table_name,1,30) table_name,
                   SUBSTR(a.constraint_name,1,30) constraint_name,
                   MAX(DECODE(position, 1, SUBSTR(column_name,1,30),NULL))      ||
                   MAX(DECODE(position, 2,', '||SUBSTR(column_name,1,30),NULL)) ||
                   MAX(DECODE(position, 3,', '||SUBSTR(column_name,1,30),NULL)) ||
                   MAX(DECODE(position, 4,', '||SUBSTR(column_name,1,30),NULL)) ||
                   MAX(DECODE(position, 5,', '||SUBSTR(column_name,1,30),NULL)) ||
                   MAX(DECODE(position, 6,', '||SUBSTR(column_name,1,30),NULL)) ||
                   MAX(DECODE(position, 7,', '||SUBSTR(column_name,1,30),NULL)) ||
                   MAX(DECODE(position, 8,', '||SUBSTR(column_name,1,30),NULL)) ||
                   MAX(DECODE(position, 9,', '||SUBSTR(column_name,1,30),NULL)) ||
                   MAX(DECODE(position,10,', '||SUBSTR(column_name,1,30),NULL)) ||
                   MAX(DECODE(position,11,', '||SUBSTR(column_name,1,30),NULL)) ||
                   MAX(DECODE(position,12,', '||SUBSTR(column_name,1,30),NULL)) ||
                   MAX(DECODE(position,13,', '||SUBSTR(column_name,1,30),NULL)) ||
                   MAX(DECODE(position,14,', '||SUBSTR(column_name,1,30),NULL)) ||
                   MAX(DECODE(position,15,', '||SUBSTR(column_name,1,30),NULL)) ||
                   MAX(DECODE(position,16,', '||SUBSTR(column_name,1,30),NULL)) columnsx
              FROM dba_cons_columns a,
                   dba_constraints b
             WHERE a.constraint_name = b.constraint_name
               AND b.constraint_type = 'R'
               AND b.owner NOT IN ('PUBLIC','WKSYS','MDSYS','TSMSYS','CTXSYS','OLAPSYS','EXFSYS','ORDSYS','SYSMAN','SYS','WMSYS','SYSTEM','OUTLN','DBSNMP')
          GROUP BY SUBSTR(a.table_name,1,30), SUBSTR(a.constraint_name,1,30)
         ) a,
         (
            SELECT SUBSTR(table_name,1,30) table_name, SUBSTR(index_name,1,30) index_name,
                   MAX(DECODE(column_position, 1, SUBSTR(column_name,1,30),NULL))      ||
                   MAX(DECODE(column_position, 2,', '||SUBSTR(column_name,1,30),NULL)) ||
                   MAX(DECODE(column_position, 3,', '||SUBSTR(column_name,1,30),NULL)) ||
                   MAX(DECODE(column_position, 4,', '||SUBSTR(column_name,1,30),NULL)) ||
                   MAX(DECODE(column_position, 5,', '||SUBSTR(column_name,1,30),NULL)) ||
                   MAX(DECODE(column_position, 6,', '||SUBSTR(column_name,1,30),NULL)) ||
                   MAX(DECODE(column_position, 7,', '||SUBSTR(column_name,1,30),NULL)) ||
                   MAX(DECODE(column_position, 8,', '||SUBSTR(column_name,1,30),NULL)) ||
                   MAX(DECODE(column_position, 9,', '||SUBSTR(column_name,1,30),NULL)) ||
                   MAX(DECODE(column_position,10,', '||SUBSTR(column_name,1,30),NULL)) ||
                   MAX(DECODE(column_position,11,', '||SUBSTR(column_name,1,30),NULL)) ||
                   MAX(DECODE(column_position,12,', '||SUBSTR(column_name,1,30),NULL)) ||
                   MAX(DECODE(column_position,13,', '||SUBSTR(column_name,1,30),NULL)) ||
                   MAX(DECODE(column_position,14,', '||SUBSTR(column_name,1,30),NULL)) ||
                   MAX(DECODE(column_position,15,', '||SUBSTR(column_name,1,30),NULL)) ||
                   MAX(DECODE(column_position,16,', '||SUBSTR(column_name,1,30),NULL)) columnsx
              FROM dba_ind_columns
          GROUP BY SUBSTR(table_name,1,30), SUBSTR(index_name,1,30)
         ) b
   WHERE a.table_name = b.table_name (+)
     AND b.columnsx (+) LIKE a.columnsx || '%'
     AND b.table_name IS NULL;

A NUMBER(8);
B NUMBER(8);
C NUMBER(8);
D NUMBER(8);
---
AA VARCHAR2(5);
BB VARCHAR2(5);
CC VARCHAR2(5);
DD VARCHAR2(5);
---
BEGIN
OPEN c1;
FETCH c1 INTO A;
CLOSE c1;

OPEN c2;
FETCH c2 INTO B;
CLOSE c2;

OPEN c3;
FETCH c3 INTO C;
CLOSE c3;

OPEN c4;
FETCH c4 INTO D;
CLOSE c4;

IF A =  THEN
        AA := 'OK';
ELSE
        AA := 'NO';
END IF;

IF B =  THEN
        BB := 'OK';
ELSE
        BB := 'NO';
END IF;

IF C =  THEN
        CC := 'OK';
ELSE
        CC := 'NO';
END IF;

IF D =  THEN
        DD := 'OK';
ELSE
        DD := 'NO';
END IF;

DBMS_OUTPUT.PUT_LINE('-- '||'Objects CLOSE max extents = 0 ' ||LPAD(AA,5)||' - '||LPAD(TO_CHAR(A),5));
DBMS_OUTPUT.PUT_LINE('-- '||'Objects can not extent = 0 '    ||LPAD(BB,5)||' - '||LPAD(TO_CHAR(B),5));
DBMS_OUTPUT.PUT_LINE('-- '||'User Objects ON Systems = 0 '   ||LPAD(CC,5)||' - '||LPAD(TO_CHAR(C),5));
DBMS_OUTPUT.PUT_LINE('-- '||'FK Without Index = 0 '          ||LPAD(DD,5)||' - '||LPAD(TO_CHAR(D),5));
END;
/

PROMPT ---

PROMPT -- ----------------------------------------------------------------------- ---

PROMPT -- Datagard CheckList ---

PROMPT -- ----------------------------------------------------------------------- ---

PROMPT ---

DECLARE
  CURSOR c1 IS
  SELECT COUNT(*)
    FROM gv$dataguard_status
   WHERE severity IN ('Error','Fatal');
 ---
  CURSOR c2 IS
  SELECT COUNT(*)
    FROM v$archive_gap;
---
  CURSOR c3 IS
  SELECT MAX(sequence#)
    FROM v$archived_log
   WHERE applied = 'YES';
---
  CURSOR c4 IS
  SELECT MAX(sequence#)
    FROM v$archived_log;
 ---
  CURSOR c5 IS
  SELECT value
    FROM v$parameter
   WHERE name = 'log_archive_dest_1';
---
  CURSOR c6 IS
  SELECT TO_NUMBER(SUBSTR(version,1,3))
    FROM v$instance;
---
A NUMBER(8);
B NUMBER(8);
C NUMBER(10);
D NUMBER(10);
E NUMBER(10);
F NUMBER(8,2);
---
AA VARCHAR2(5);
BB VARCHAR2(5);
CC VARCHAR2(5);
DD VARCHAR2(5);
EE VARCHAR2(500);
---
BEGIN
OPEN c1;
FETCH c1 INTO A;
CLOSE c1;

OPEN c2;
FETCH c2 INTO B;
CLOSE c2;

OPEN c3;
FETCH c3 INTO C;
CLOSE c3;

OPEN c4;
FETCH c4 INTO D;
CLOSE c4;

OPEN c5;
FETCH c5 INTO EE;
CLOSE c5;

OPEN c6;
FETCH c6 INTO F;
CLOSE c6;

IF A =  THEN
        AA := 'OK';
ELSEIF A IS NULL THEN
        AA := 'OK';
         A := ;
ELSE
        AA := 'NO';
END IF;

IF B =  THEN
        BB := 'OK';
ELSEIF B IS NULL THEN
        BB := 'OK';
         B := ;
ELSE
        BB := 'NO';
END IF;

IF D IS NULL THEN
         D := ;
END IF;

IF C IS NULL THEN
         C := ;
END IF;

E := ( D - C);

IF E <= 5 THEN
        CC := 'OK';
ELSE
        CC := 'NO';
END IF;

IF EE IS NOT NULL AND F >= 9 THEN
    DBMS_OUTPUT.PUT_LINE('-- '||'Datagard Errors = 0 '     ||LPAD(AA,5)||' - '||LPAD(TO_CHAR(A),5));
    DBMS_OUTPUT.PUT_LINE('-- '||'Datagard Gap = 0 '        ||LPAD(BB,5)||' - '||LPAD(TO_CHAR(B),5));
    DBMS_OUTPUT.PUT_LINE('-- '||'Archives not Aplied < 5 ' ||LPAD(CC,5)||' - '||LPAD(TO_CHAR(E),5));
    DBMS_OUTPUT.PUT_LINE('-- '||'Last Archive Aplied '     ||TO_CHAR(C));
    DBMS_OUTPUT.PUT_LINE('-- '||'Last Archive Generated '  ||TO_CHAR(D));
ELSE
    DBMS_OUTPUT.PUT_LINE('-- '||'No Dataguard Available or Database version IS not supported for this check!');
END IF;
END;
/

PROMPT

PROMPT -- ---------------------------------------------------------------------- ---

PROMPT -- Oracle Components Status :

PROMPT -- ---------------------------------------------------------------------- ---

COLUMN comp_id   FORMAT A12 HEADING "ID"
COLUMN status    FORMAT A12 HEADING "Status"
COLUMN version   FORMAT A10 HEADING "Version"
COLUMN comp_name FORMAT A40 HEADING "Component"
 
  SELECT SUBSTR(comp_id,1,12) comp_id, status, SUBSTR(version,1,10) version, SUBSTR(comp_name,1,40) comp_name
    FROM dba_registry
ORDER BY 1;

PROMPT

PROMPT -- ---------------------------------------------------------------------- ---

PROMPT -- Installed options :

PROMPT -- ---------------------------------------------------------------------- ---

  SELECT ' - ' || parameter || ' option'
    FROM sys.v$option
   WHERE value = 'TRUE';

SET HEAD ON

PROMPT

SET FEEDBACK ON

-- ----------------------------------------------------------------------- ---
-- V$Recovery_Log Status ---
-- ----------------------------------------------------------------------- ---

COLUMN Thread#      FORMAT 9999999  HEADING "Thread"
COLUMN Sequence#    FORMAT 9999999  HEADING "Sequence"
COLUMN archive_name FORMAT A60 WRAP HEADING "Archive|Name"
COLUMN Time HEADING "Time"
 
  SELECT *
    FROM v$recovery_log
ORDER BY thread#;

-- ----------------------------------------------------------------------- ---
-- V$Recover_File Status ---
-- ----------------------------------------------------------------------- ---

COLUMN file#         FORMAT 9999999  HEADING "File#"
COLUMN online        FORMAT A10      HEADING "Online"
COLUMN online_status FORMAT A10      HEADING "Online|Status"
COLUMN error         FORMAT A20 WRAP HEADING "Error"
COLUMN change        FORMAT 99999    HEADING "Change"
COLUMN Time                          HEADING "Time"
 
  SELECT *
    FROM v$recover_file
ORDER BY file#;

-- ----------------------------------------------------------------------- ---
-- V$Log Status ---
-- ----------------------------------------------------------------------- ---

DECLARE
--
 CURSOR Cur_Req IS
SELECT
'X'
FROM
v$log
 WHERE
status NOT IN ('ACTIVE', 'CURRENT', 'INACTIVE')
;
--
X VARCHAR2(1);
 --
BEGIN
--
X := NULL;
--
 OPEN Cur_Req;
FETCH Cur_Req INTO X;
CLOSE Cur_Req;
--
IF X IS NOT NULL THEN
DBMS_OUTPUT.PUT_LINE('-- ---');
DBMS_OUTPUT.PUT_LINE('-- ----------------------------------------------------------------------- ---');
DBMS_OUTPUT.PUT_LINE('-- V$Log Status ---');
DBMS_OUTPUT.PUT_LINE('-- ----------------------------------------------------------------------- ---');
END IF;
 --
END;
/
 
clear BREAKs
BREAK ON redogroup -
SKIP 1
 
COLUMN redogroup FORMAT 99999 HEADING "Group"
COLUMN redothread FORMAT 99999 HEADING "Thread"
COLUMN redosequence FORMAT 999999 HEADING "Sequence"
COLUMN file_name FORMAT A55 HEADING "RedoLog Name"
COLUMN KB FORMAT 99999999B HEADING "Size|(Kb)"
COLUMN status FORMAT A5 HEADING "Stat." TRUNC
 
SELECT
lf.group# redogroup
, l.thread# redothread
, l.sequence# redosequence
, lf.member file_name
 , l.bytes/1024 Kb
, l.status status
FROM
v$logfile lf
, v$log l
 WHERE
l.group# = lf.group#
and
l.status NOT IN ('ACTIVE', 'CURRENT', 'INACTIVE')
order
 by lf.group#
, l.thread#
, l.sequence#
, lf.member
;
 
clear BREAKs
 
 
-- ----------------------------------------------------------------------- ---
-- V$Tempfile Status ---
-- ----------------------------------------------------------------------- ---
 
DECLARE
--
 CURSOR Cur_Req IS
SELECT
'X'
FROM
v$tempfile
 WHERE
status NOT IN ('ONLINE', 'SYSTEM')
;
--
X VARCHAR2(1);
 --
BEGIN
--
X := NULL;
--
 OPEN Cur_Req;
FETCH Cur_Req INTO X;
CLOSE Cur_Req;
--
IF X IS NOT NULL THEN
DBMS_OUTPUT.PUT_LINE('-- ---');
DBMS_OUTPUT.PUT_LINE('-- ----------------------------------------------------------------------- ---');
DBMS_OUTPUT.PUT_LINE('-- V$Tempfile Status ---');
DBMS_OUTPUT.PUT_LINE('-- ----------------------------------------------------------------------- ---');
END IF;
 --
END;
/
 
clear BREAKs
BREAK ON status SKIP 1
 
 
COLUMN name FORMAT A60 WRAP HEADING "DataFile Name"
 
SELECT
name
, status
FROM
V$tempfile
 WHERE
status NOT IN ('ONLINE', 'SYSTEM')
Order
By Status
, Name
;
 
clear BREAKs
 
 
-- ----------------------------------------------------------------------- ---
-- V$Datafile Status ---
-- ----------------------------------------------------------------------- ---
 
DECLARE
 --
CURSOR Cur_Req IS
SELECT
'X'
FROM
v$datafile
WHERE
status NOT IN ('ONLINE', 'SYSTEM')
;
--
X VARCHAR2(1);
--
BEGIN
--
X := NULL;
 --
OPEN Cur_Req;
FETCH Cur_Req INTO X;
CLOSE Cur_Req;
--
 IF X IS NOT NULL THEN
DBMS_OUTPUT.PUT_LINE('-- ---');
DBMS_OUTPUT.PUT_LINE('-- ----------------------------------------------------------------------- ---');
DBMS_OUTPUT.PUT_LINE('-- V$Datafile Status ---');
DBMS_OUTPUT.PUT_LINE('-- ----------------------------------------------------------------------- ---');
END IF;
--
END;
/
 
clear BREAKs
BREAK ON status SKIP 1
 
 
COLUMN name FORMAT A60 WRAP HEADING "DataFile Name"
 
SELECT
name
, status
FROM
V$datafile
WHERE
status NOT IN ('ONLINE', 'SYSTEM')
Order
By Status
 , Name
;
 
clear BREAKs
 
 
-- ----------------------------------------------------------------------- ---
-- Dba_Tablespaces Status ---
-- ----------------------------------------------------------------------- ---
 
DECLARE
--
CURSOR Cur_Req IS
SELECT
'X'
 FROM
dba_tablespaces
WHERE
status NOT IN ('ONLINE', 'READ ONLY')
;
 --
X VARCHAR2(1);
--
BEGIN
--
X := NULL;
--
OPEN Cur_Req;
FETCH Cur_Req INTO X;
CLOSE Cur_Req;
 --
IF X IS NOT NULL THEN
DBMS_OUTPUT.PUT_LINE('-- ---');
DBMS_OUTPUT.PUT_LINE('-- ----------------------------------------------------------------------- ---');
DBMS_OUTPUT.PUT_LINE('-- Dba_Tablespaces Status ---');
DBMS_OUTPUT.PUT_LINE('-- ----------------------------------------------------------------------- ---');
END IF;
--
END;
/
 
COLUMN tblsp FORMAT A20 WRAP HEADING "Tablespace Name"
COLUMN contents FORMAT A10 HEADING "Content"
 
clear BREAKs
BREAK ON contents -
SKIP 1
 
SELECT
contents
 , tablespace_name tblsp
, status
FROM
dba_tablespaces
WHERE
status NOT IN ('ONLINE', 'READ ONLY')
order
by contents
;
 
 
-- ----------------------------------------------------------------------- ---
-- Tablespaces Backup Mode ---
-- ----------------------------------------------------------------------- ---
 
DECLARE
--
CURSOR Cur_Req IS
SELECT
'X'
 FROM
v$backup bck
, dba_data_files df
WHERE
bck.file# = df.file_id
 and
bck.status != 'NOT ACTIVE'
and
'ARCHIVELOG' = (SELECT log_mode FROM v$database);
--
X VARCHAR2(1);
--
BEGIN
--
X := NULL;
 --
OPEN Cur_Req;
FETCH Cur_Req INTO X;
CLOSE Cur_Req;
--
 IF X IS NOT NULL THEN
DBMS_OUTPUT.PUT_LINE('-- ---');
DBMS_OUTPUT.PUT_LINE('-- ----------------------------------------------------------------------- ---');
DBMS_OUTPUT.PUT_LINE('-- Tablespaces in Backup Mode ---');
DBMS_OUTPUT.PUT_LINE('-- ----------------------------------------------------------------------- ---');
END IF;
--
END;
/
 
COLUMN tablespace_name FORMAT A18 WRAP HEADING "Tablespace Name"
COLUMN file_name FORMAT A50 WRAP HEADING "DataFile Name"
COLUMN status FORMAT A12 WRAP HEADING "Status"
COLUMN change# FORMAT 999999999999 HEADING "Change"
COLUMN time FORMAT A18 WRAP HEADING "Time"
 
SELECT
df.tablespace_name
, df.file_name
, bck.status
 , bck.change#
, TO_CHAR(bck.time,'DD-MM-YYYY HH24:MI') time
FROM
v$backup bck
, dba_data_files df
 WHERE
bck.file# = df.file_id
and
bck.status != 'NOT ACTIVE'
and
 'ARCHIVELOG' = (SELECT log_mode FROM v$database)
order
by df.tablespace_name
, df.file_name
;
 
 
-- ----------------------------------------------------------------------- ---
-- Lock list ---
-- ----------------------------------------------------------------------- ---
 
DECLARE
--
CURSOR Cur_Req IS
SELECT
 'X'
FROM
v$session s
, v$process p
, v$lock l
 , dba_objects o
WHERE
s.paddr = p.addr
And
l.sid=s.sid
 And
l.id1 = o.object_id
And
s.username IS NOT NULL
And
l.ctime > 60
;
--
X VARCHAR2(1);
--
BEGIN
--
X := NULL;
--
OPEN Cur_Req;
 FETCH Cur_Req INTO X;
CLOSE Cur_Req;
--
IF X IS NOT NULL THEN
DBMS_OUTPUT.PUT_LINE('-- ---');
DBMS_OUTPUT.PUT_LINE('-- ----------------------------------------------------------------------- ---');
DBMS_OUTPUT.PUT_LINE('-- Lock list ---');
DBMS_OUTPUT.PUT_LINE('-- ----------------------------------------------------------------------- ---');
END IF;
--
END;
/
 
COLUMN username HEADING "Utilis." FORMAT A15
COLUMN sid HEADING "Id" FORMAT 9999
COLUMN spid HEADING "Unix" FORMAT A7
COLUMN state HEADING "Etat" FORMAT A15
COLUMN Lmode_H HEADING "Lock mode" FORMAT A15
COLUMN terminal HEADING "Terminal" FORMAT A10
COLUMN commAND HEADING "C" FORMAT 99
COLUMN serial# HEADING "Serial#" FORMAT 99999
COLUMN ctime HEADING "Duration" FORMAT 999999
COLUMN logon HEADING "Date Connexion" FORMAT A16
COLUMN object_name HEADING "Object Name" FORMAT A18
 
SELECT
s.sid
, s.serial#
, p.spid
, SUBSTR(s.username,1,15) username
 , s.terminal
, l.type
, TO_CHAR(s.logon_time,'DD-MM-YYYY HH24:MI') logon
, DECODE(l.lmode, 1,'NULL' , 2,'Row share'
, 3,'Row Exclusive' , 4,'Share'
 , 5,'Share Row Excl.' , 6,'Exclusive') Lmode_H
, o.object_name
, ROUND(ctime/60) ctime
FROM
v$session s
 , v$process p
, v$lock l
, dba_objects o
WHERE
s.paddr = p.addr
 And
l.sid=s.sid
And
l.id1 = o.object_id
And
s.username IS NOT NULL
And
l.ctime > 60
;
 
 
PROMPT
 
PROMPT -- ----------------------------------------------------------------------- ---
 
PROMPT -- Tablespaces ---
 
PROMPT -- ----------------------------------------------------------------------- ---
 
 
 
-- SET HEADING Off
-- SET Termout Off
 
-- COLUMN Var_DB_BLOCK_SIZE NEW_VALUE Var_DB_BLOCK_SIZE noprint
 
-- SELECT
-- value Var_DB_BLOCK_SIZE
-- FROM
-- v$parameter
-- WHERE
-- Upper(name) = Upper ('db_block_size')
--;
 
--SET Termout On
--SET HEADING On
 
 
 
--clear BREAKs
--BREAK ON contents -
--SKIP 1
--compute SUM of alloc used free nbfrag ON contents
 
 
--COLUMN tblsp FORMAT A20 WRAP HEADING "Tablespace Name"
--COLUMN Alloc FORMAT 999,999 HEADING "Alloc|(Mb)"
--COLUMN Free FORMAT 999,999 HEADING "Free|(Mb)"
--COLUMN used FORMAT 999,999 HEADING "Used|(Mb)"
--COLUMN pused FORMAT 990.9 HEADING "%|Used|Space"
--COLUMN fragmax FORMAT 99,999.9 HEADING "Largest|Free|Ext.(Mb)"
--COLUMN nbfrag FORMAT 99999 HEADING "Nb|frag"
--COLUMN contents FORMAT A10 HEADING "Content"
--COLUMN pct_ext_coal FORMAT 999 HEADING "% Ext.|Coal."
--COLUMN ext_manage FORMAT A7 WRAP HEADING "Ext.|M."
--COLUMN autoext FORMAT A7 WRAP HEADING "Auto|Ext."
 
 
--SELECT
-- contents
-- , NVL (dt.tablespace_name, NVL (fsp.tablespace_name, 'Unknown')) tblsp
-- , alloc
-- , alloc - NVL (free, ) Used
-- , NVL (free, ) Free
-- , ((alloc - NVL (free, )) / alloc) * 100 pused
-- , nbfrag
-- , fragmax
-- , dfsc.pct_ext_coal pct_ext_coal
-- , dt.ext_manage
-- , df.inc autoext
-- FROM
-- ( SELECT SUM (bytes)/1048576 free
-- , max (bytes)/1048576 fragmax
-- , tablespace_name
-- , COUNT(*) nbfrag
-- FROM sys.dba_free_space
-- GROUP BY tablespace_name
-- ) fsp
-- , ( SELECT SUM(bytes)/1048576 alloc
-- , tablespace_name
-- , DECODE(((inc * &Var_DB_BLOCK_SIZE)/1024), NULL, 'No', 'Yes') inc
-- FROM sys.dba_data_files sddf
-- , sys.filext$ aut
-- WHERE sddf.file_id = aut.file# (+)
-- GROUP BY tablespace_name
-- , DECODE(((inc * &Var_DB_BLOCK_SIZE)/1024), NULL, 'No', 'Yes')
-- UNION
-- SELECT SUM(bytes)/1048576 alloc
-- , tablespace_name
-- , DECODE(((increment_by * &Var_DB_BLOCK_SIZE)/1024), NULL, 'No', 'Yes') inc
-- FROM sys.dba_temp_files sddf
-- GROUP BY tablespace_name
-- , DECODE(((increment_by * &Var_DB_BLOCK_SIZE)/1024), NULL, 'No', 'Yes')
-- ) df
-- , ( SELECT contents
-- , tablespace_name
-- , initial_extent/1024 initial_ext
-- , next_extent/1024 next_ext
-- , pct_increase
-- , max_extents
-- , min_extents
-- , SUBSTR(extent_management,1,5) ext_manage
-- FROM dba_tablespaces
-- ) dt
-- , ( SELECT percent_extents_coalesced pct_ext_coal
-- , tablespace_name
-- FROM dba_free_space_coalesced
-- ) dfsc
-- WHERE
-- fsp.tablespace_name (+) = dt.tablespace_name
-- and
-- df.tablespace_name (+) = dt.tablespace_name
-- and
-- dfsc.tablespace_name (+) = dt.tablespace_name
-- order
-- by contents
-- , pused desc
--;
 
 
PROMPT
 
PROMPT
PROMPT ******************************************** INVALID OBJECTS BY TYPE
 
BREAK ON REPORT
COMPUTE SUM LABEL TOTAL of quantity ON REPORT
 
SELECT object_type, COUNT(*) quantity
FROM dba_objects
WHERE status = 'INVALID'
GROUP BY object_type;
 
CLEAR BREAKS
CLEAR COMPUTES
 
PROMPT
PROMPT ******************************************** INVALID OBJECTS BY TYPE AND OWNER
 
SELECT owner, object_type, COUNT(*) quantity
FROM dba_objects
WHERE status = 'INVALID'
GROUP BY owner, object_type;
 
PROMPT
PROMPT ******************************************** MODIFIED OBJECTS IN THE LAST 7 DAYS
 
SELECT owner||'.'||object_name objet, object_type, created, last_ddl_time modified, ROUND(sysdate - last_ddl_time,2) days
FROM dba_objects
WHERE sysdate - last_ddl_time < 7 AND
subobject_name IS NULL
ORDER BY created DESC;
 
PROMPT
PROMPT ******************************************** UNUSABLE INDEXES
 
SELECT owner||'.'||index_name indice
FROM dba_indexes
WHERE status = 'UNUSABLE'
ORDER BY 1;
 
SELECT index_owner||'.'||index_name||'.'||partition_name partition
FROM dba_ind_partitions
WHERE status = 'UNUSABLE'
ORDER BY 1;
 
PROMPT
PROMPT ******************************************** DISABLED TRIGGERS
 
SELECT owner||'.'||trigger_name "TRIGGER", triggering_event, table_owner||'.'||table_name, status
FROM dba_triggers
WHERE status = 'DISABLED';
 
PROMPT
PROMPT ******************************************** DISABLED CONSTRAINTS
 
SELECT constraint_name constraint, constraint_type, owner||'.'||table_name, status
FROM dba_constraints
WHERE status = 'DISABLED' AND constraint_type<>'S';
 
PROMPT
PROMPT ******************************************** ANALIZED TABLES
 
SELECT owner, NVL(TO_CHAR(TRUNC(last_analyzed),'dd-mm-yyyy'), 'Never Analyzed') last_analyzed, COUNT(*) quantity
FROM dba_tables
GROUP BY owner, TRUNC(last_analyzed)
ORDER BY 1,2;
 
PROMPT
PROMPT ******************************************** ANALYZED INDEXES
 
SELECT owner, NVL(TO_CHAR(TRUNC(last_analyzed),'dd-mm-yyyy'), 'Never Analyzed') last_analyzed, COUNT(*) quantity
FROM dba_indexes
GROUP BY owner, TRUNC(last_analyzed)
ORDER BY 1,2;
 
PROMPT
PROMPT ******************************************** TABLESPACES WITH LESS THAN 15% FREE
 
SELECT a.tblspc tablespace, a.fbytes TOTAL, NVL(u.ebytes,) RESERVED, a.fbytes-NVL(u.ebytes,) FREE, 100*NVL(u.ebytes,)/a.fbytes "% RESERVED"
FROM (SELECT tablespace_name tblspc, SUM(bytes)/1024/1024 ebytes FROM dba_segments GROUP BY tablespace_name) u,
(SELECT tablespace_name tblspc, SUM(bytes)/1024/1024 fbytes FROM dba_data_files GROUP BY tablespace_name) a
WHERE u.tblspc(+) = a.tblspc AND
100*NVL(u.ebytes,)/a.fbytes > 85.00
ORDER BY tablespace;
 
PROMPT
PROMPT ******************************************** OBJECTS CLOSE TO MAX EXTENTS
 
SELECT tablespace_name tablespace, segment_type tipo, owner||'.'||segment_name segment, extents, bytes/1024/1024 mb,
max_extents
FROM dba_segments
WHERE max_extents-extents < 10 AND
segment_type <> 'CACHE'
ORDER BY 1,2,3,4;
 
PROMPT
PROMPT ******************************************** OBJECTS THAT CAN.T EXTENT
 
PROMPT Objects that cannot extend (no space in TS)
 
COLUMN Sname form a40 HEADING 'Object Name'
COLUMN Stype form a15 HEADING 'Type'
COLUMN Size form 9,999 HEADING 'Size'
COLUMN Next form 99,999 HEADING 'Next'
COLUMN Tname form a15 HEADING 'TsName'
 
SELECT a.owner||'.'||a.segment_name "Sname",
a.segment_type "Stype",
a.bytes/1024/1024 "Size",
a.next_extent/1024/1024 "Next",
a.tablespace_name "TName"
FROM sys.dba_segments a
WHERE a.tablespace_name not LIKE 'T%MP%' -- Exclude TEMP tablespaces
AND next_extent * 2 > ( -- Cannot extend 1x, can change to 2x...
 SELECT MAX(b.bytes)
FROM dba_free_space b
WHERE a.tablespace_name = b.tablespace_name)
ORDER BY 3 desc
/
 
PROMPT
PROMPT ******************************************** OBJECTS IN THE SYSTEM TABLESPACE
 
SELECT owner, SUBSTR(segment_name,1,25) segment , SUBSTR(partition_name,1,25) partition, segment_type
FROM sys.dba_segments
WHERE owner NOT IN ('PUBLIC','WKSYS','MDSYS','TSMSYS','CTXSYS','OLAPSYS','EXFSYS','ORDSYS','SYSMAN','SYS','WMSYS','SYSTEM','OUTLN','DBSNMP')
AND tablespace_name = 'SYSTEM';
 
PROMPT
PROMPT ******************************************** FOREIGN KEYS WITHOUT INDEXES
 
COLUMN columns FORMAT A20 word_WRAPped
COLUMN table_name FORMAT A30 word_WRAPped
 
SELECT DECODE( b.table_name, NULL, '****', 'ok' ) Status,
a.table_name table_name, a.columns, b.columns
FROM
( SELECT SUBSTR(a.table_name,1,30) table_name,
SUBSTR(a.constraint_name,1,30) constraint_name,
MAX(DECODE(position, 1, SUBSTR(column_name,1,30),NULL)) ||
MAX(DECODE(position, 2,', '||SUBSTR(column_name,1,30),NULL)) ||
MAX(DECODE(position, 3,', '||SUBSTR(column_name,1,30),NULL)) ||
MAX(DECODE(position, 4,', '||SUBSTR(column_name,1,30),NULL)) ||
MAX(DECODE(position, 5,', '||SUBSTR(column_name,1,30),NULL)) ||
MAX(DECODE(position, 6,', '||SUBSTR(column_name,1,30),NULL)) ||
MAX(DECODE(position, 7,', '||SUBSTR(column_name,1,30),NULL)) ||
MAX(DECODE(position, 8,', '||SUBSTR(column_name,1,30),NULL)) ||
MAX(DECODE(position, 9,', '||SUBSTR(column_name,1,30),NULL)) ||
MAX(DECODE(position,10,', '||SUBSTR(column_name,1,30),NULL)) ||
MAX(DECODE(position,11,', '||SUBSTR(column_name,1,30),NULL)) ||
MAX(DECODE(position,12,', '||SUBSTR(column_name,1,30),NULL)) ||
MAX(DECODE(position,13,', '||SUBSTR(column_name,1,30),NULL)) ||
MAX(DECODE(position,14,', '||SUBSTR(column_name,1,30),NULL)) ||
MAX(DECODE(position,15,', '||SUBSTR(column_name,1,30),NULL)) ||
MAX(DECODE(position,16,', '||SUBSTR(column_name,1,30),NULL)) columns
FROM dba_cons_columns a, dba_constraints b
WHERE a.constraint_name = b.constraint_name
AND b.constraint_type = 'R'
AND b.owner NOT IN ('PUBLIC','WKSYS','MDSYS','TSMSYS','CTXSYS','OLAPSYS','EXFSYS','ORDSYS','SYSMAN','SYS','WMSYS','SYSTEM','OUTLN','DBSNMP')
 GROUP BY SUBSTR(a.table_name,1,30), SUBSTR(a.constraint_name,1,30) ) a,
( SELECT SUBSTR(table_name,1,30) table_name, SUBSTR(index_name,1,30) index_name,
MAX(DECODE(column_position, 1, SUBSTR(column_name,1,30),NULL)) ||
MAX(DECODE(column_position, 2,', '||SUBSTR(column_name,1,30),NULL)) ||
MAX(DECODE(column_position, 3,', '||SUBSTR(column_name,1,30),NULL)) ||
MAX(DECODE(column_position, 4,', '||SUBSTR(column_name,1,30),NULL)) ||
MAX(DECODE(column_position, 5,', '||SUBSTR(column_name,1,30),NULL)) ||
MAX(DECODE(column_position, 6,', '||SUBSTR(column_name,1,30),NULL)) ||
MAX(DECODE(column_position, 7,', '||SUBSTR(column_name,1,30),NULL)) ||
MAX(DECODE(column_position, 8,', '||SUBSTR(column_name,1,30),NULL)) ||
MAX(DECODE(column_position, 9,', '||SUBSTR(column_name,1,30),NULL)) ||
MAX(DECODE(column_position,10,', '||SUBSTR(column_name,1,30),NULL)) ||
MAX(DECODE(column_position,11,', '||SUBSTR(column_name,1,30),NULL)) ||
MAX(DECODE(column_position,12,', '||SUBSTR(column_name,1,30),NULL)) ||
MAX(DECODE(column_position,13,', '||SUBSTR(column_name,1,30),NULL)) ||
MAX(DECODE(column_position,14,', '||SUBSTR(column_name,1,30),NULL)) ||
MAX(DECODE(column_position,15,', '||SUBSTR(column_name,1,30),NULL)) ||
MAX(DECODE(column_position,16,', '||SUBSTR(column_name,1,30),NULL)) columns
FROM dba_ind_columns
GROUP BY SUBSTR(table_name,1,30), SUBSTR(index_name,1,30) ) b
WHERE a.table_name = b.table_name (+)
AND b.columns (+) LIKE a.columns || '%'
AND b.table_name IS NULL
ORDER BY 1 DESC
/
 
PROMPT
PROMPT ******************************************** DATAGUARD STATE (CRITICAL MESSAGES)
 
SELECT inst_id, facility, severity, dest_id, error_code, callout, timestamp, message
FROM gv$dataguard_status
WHERE severity IN ('Error','Fatal')
ORDER BY timestamp;
 
PROMPT
PROMPT ******************************************** NO APLIED ARCHIVELOGS
 
SELECT sequence#,SUBSTR(a.name,1,46) archivelog, a.blocks, a.archived, a.applied, a.status, a.end_of_redo eor, a.standby_dest, a.first_time, a.completion_time completion, SYSDATE time
FROM v$archived_log a
WHERE a.sequence# between (SELECT MAX(b.sequence#) FROM v$archived_log b WHERE b.applied = 'YES') AND (SELECT MAX(c.sequence#) FROM v$archived_log c)
/
 
PROMPT
PROMPT ******************************************** GAP SEQUENCE
 
SELECT * FROM v$archive_gap;
 
PROMPT
PROMPT ******************************************** DIFERENCE ON RECEPTION
 
SELECT thread#, MAX(next_time) next_time, SYSDATE time, ROUND((SYSDATE - MAX(next_time))*24,2) hours, ROUND((SYSDATE - MAX(next_time))*24*60,0) minutes
FROM v$archived_log
GROUP BY thread#;
 
PROMPT
PROMPT ******************************************** DIFERENCE TO APPLY
 
SELECT thread#, MAX(next_time) next_time, SYSDATE time, ROUND((SYSDATE - MAX(next_time))*24,2) hours, ROUND((SYSDATE - MAX(next_time))*24*60,0) minutes
FROM v$archived_log
WHERE applied='YES'
GROUP BY thread#;
 
PROMPT
PROMPT ******************************************** PROCESSES
 
SELECT inst_id, process, pid, status, SUBSTR(TO_CHAR(group#),1,8) group#, thread#, sequence#, block#, blocks, delay_mins, known_agents, active_agents, client_process
FROM gv$managed_standby;
 
PROMPT
 
 
 
SET HEADING ON
SET ECHO OFF
SET LINESIZE 150
SET PAGESIZE 500
COLUMN day FORMAT A16 HEADING 'Day'
COLUMN d_0 FORMAT A3 HEADING '00'
COLUMN d_1 FORMAT A3 HEADING '01'
COLUMN d_2 FORMAT A3 HEADING '02'
COLUMN d_3 FORMAT A3 HEADING '03'
COLUMN d_4 FORMAT A3 HEADING '04'
COLUMN d_5 FORMAT A3 HEADING '05'
COLUMN d_6 FORMAT A3 HEADING '06'
COLUMN d_7 FORMAT A3 HEADING '07'
COLUMN d_8 FORMAT A3 HEADING '08'
COLUMN d_9 FORMAT A3 HEADING '09'
COLUMN d_10 FORMAT A3 HEADING '10'
COLUMN d_11 FORMAT A3 HEADING '11'
COLUMN d_12 FORMAT A3 HEADING '12'
COLUMN d_13 FORMAT A3 HEADING '13'
COLUMN d_14 FORMAT A3 HEADING '14'
COLUMN d_15 FORMAT A3 HEADING '15'
COLUMN d_16 FORMAT A3 HEADING '16'
COLUMN d_17 FORMAT A3 HEADING '17'
COLUMN d_18 FORMAT A3 HEADING '18'
COLUMN d_19 FORMAT A3 HEADING '19'
COLUMN d_20 FORMAT A3 HEADING '20'
COLUMN d_21 FORMAT A3 HEADING '21'
COLUMN d_22 FORMAT A3 HEADING '22'
COLUMN d_23 FORMAT A3 HEADING '23'
COLUMN Total FORMAT 9999
COLUMN status FORMAT A8
COLUMN member FORMAT A40
COLUMN archived HEADING 'Archived' FORMAT A8
COLUMN bytes HEADING 'Bytes|(MB)' FORMAT 9999
TTITLE 'Log Info' SKIP 2
SELECT l.group#,f.member,l.archived,l.bytes/1078576 bytes,l.status,f.type
FROM v$log l, v$logfile f
WHERE l.group# = f.group#
/
TTITLE OFF
PROMPT =========================================================================================================================
TTITLE 'Log Switch ON hour basis' SKIP 2
 
SELECT TO_CHAR(FIRST_TIME,'DY, DD-MON-YYYY') day,
DECODE(SUM(DECODE(SUBSTR(TO_CHAR(FIRST_TIME,'HH24'),1,2),'00',1,)),,'-',SUM(DECODE(SUBSTR(TO_CHAR(FIRST_TIME,'HH24'),1,2),'00',1,))) d_0,
DECODE(SUM(DECODE(SUBSTR(TO_CHAR(FIRST_TIME,'HH24'),1,2),'01',1,)),,'-',SUM(DECODE(SUBSTR(TO_CHAR(FIRST_TIME,'HH24'),1,2),'01',1,))) d_1,
DECODE(SUM(DECODE(SUBSTR(TO_CHAR(FIRST_TIME,'HH24'),1,2),'02',1,)),,'-',SUM(DECODE(SUBSTR(TO_CHAR(FIRST_TIME,'HH24'),1,2),'02',1,))) d_2,
DECODE(SUM(DECODE(SUBSTR(TO_CHAR(FIRST_TIME,'HH24'),1,2),'03',1,)),,'-',SUM(DECODE(SUBSTR(TO_CHAR(FIRST_TIME,'HH24'),1,2),'03',1,))) d_3,
DECODE(SUM(DECODE(SUBSTR(TO_CHAR(FIRST_TIME,'HH24'),1,2),'04',1,)),,'-',SUM(DECODE(SUBSTR(TO_CHAR(FIRST_TIME,'HH24'),1,2),'04',1,))) d_4,
DECODE(SUM(DECODE(SUBSTR(TO_CHAR(FIRST_TIME,'HH24'),1,2),'05',1,)),,'-',SUM(DECODE(SUBSTR(TO_CHAR(FIRST_TIME,'HH24'),1,2),'05',1,))) d_5,
DECODE(SUM(DECODE(SUBSTR(TO_CHAR(FIRST_TIME,'HH24'),1,2),'06',1,)),,'-',SUM(DECODE(SUBSTR(TO_CHAR(FIRST_TIME,'HH24'),1,2),'06',1,))) d_6,
DECODE(SUM(DECODE(SUBSTR(TO_CHAR(FIRST_TIME,'HH24'),1,2),'07',1,)),,'-',SUM(DECODE(SUBSTR(TO_CHAR(FIRST_TIME,'HH24'),1,2),'07',1,))) d_7,
DECODE(SUM(DECODE(SUBSTR(TO_CHAR(FIRST_TIME,'HH24'),1,2),'08',1,)),,'-',SUM(DECODE(SUBSTR(TO_CHAR(FIRST_TIME,'HH24'),1,2),'08',1,))) d_5,
DECODE(SUM(DECODE(SUBSTR(TO_CHAR(FIRST_TIME,'HH24'),1,2),'09',1,)),,'-',SUM(DECODE(SUBSTR(TO_CHAR(FIRST_TIME,'HH24'),1,2),'09',1,))) d_9,
DECODE(SUM(DECODE(SUBSTR(TO_CHAR(FIRST_TIME,'HH24'),1,2),'10',1,)),,'-',SUM(DECODE(SUBSTR(TO_CHAR(FIRST_TIME,'HH24'),1,2),'10',1,))) d_10,
DECODE(SUM(DECODE(SUBSTR(TO_CHAR(FIRST_TIME,'HH24'),1,2),'11',1,)),,'-',SUM(DECODE(SUBSTR(TO_CHAR(FIRST_TIME,'HH24'),1,2),'11',1,))) d_11,
DECODE(SUM(DECODE(SUBSTR(TO_CHAR(FIRST_TIME,'HH24'),1,2),'12',1,)),,'-',SUM(DECODE(SUBSTR(TO_CHAR(FIRST_TIME,'HH24'),1,2),'12',1,))) d_12,
DECODE(SUM(DECODE(SUBSTR(TO_CHAR(FIRST_TIME,'HH24'),1,2),'13',1,)),,'-',SUM(DECODE(SUBSTR(TO_CHAR(FIRST_TIME,'HH24'),1,2),'13',1,))) d_13,
DECODE(SUM(DECODE(SUBSTR(TO_CHAR(FIRST_TIME,'HH24'),1,2),'14',1,)),,'-',SUM(DECODE(SUBSTR(TO_CHAR(FIRST_TIME,'HH24'),1,2),'14',1,))) d_14,
DECODE(SUM(DECODE(SUBSTR(TO_CHAR(FIRST_TIME,'HH24'),1,2),'15',1,)),,'-',SUM(DECODE(SUBSTR(TO_CHAR(FIRST_TIME,'HH24'),1,2),'15',1,))) d_15,
DECODE(SUM(DECODE(SUBSTR(TO_CHAR(FIRST_TIME,'HH24'),1,2),'16',1,)),,'-',SUM(DECODE(SUBSTR(TO_CHAR(FIRST_TIME,'HH24'),1,2),'16',1,))) d_16,
DECODE(SUM(DECODE(SUBSTR(TO_CHAR(FIRST_TIME,'HH24'),1,2),'17',1,)),,'-',SUM(DECODE(SUBSTR(TO_CHAR(FIRST_TIME,'HH24'),1,2),'17',1,))) d_17,
DECODE(SUM(DECODE(SUBSTR(TO_CHAR(FIRST_TIME,'HH24'),1,2),'18',1,)),,'-',SUM(DECODE(SUBSTR(TO_CHAR(FIRST_TIME,'HH24'),1,2),'18',1,))) d_18,
DECODE(SUM(DECODE(SUBSTR(TO_CHAR(FIRST_TIME,'HH24'),1,2),'19',1,)),,'-',SUM(DECODE(SUBSTR(TO_CHAR(FIRST_TIME,'HH24'),1,2),'19',1,))) d_19,
DECODE(SUM(DECODE(SUBSTR(TO_CHAR(FIRST_TIME,'HH24'),1,2),'20',1,)),,'-',SUM(DECODE(SUBSTR(TO_CHAR(FIRST_TIME,'HH24'),1,2),'20',1,))) d_20,
DECODE(SUM(DECODE(SUBSTR(TO_CHAR(FIRST_TIME,'HH24'),1,2),'21',1,)),,'-',SUM(DECODE(SUBSTR(TO_CHAR(FIRST_TIME,'HH24'),1,2),'21',1,))) d_21,
DECODE(SUM(DECODE(SUBSTR(TO_CHAR(FIRST_TIME,'HH24'),1,2),'22',1,)),,'-',SUM(DECODE(SUBSTR(TO_CHAR(FIRST_TIME,'HH24'),1,2),'22',1,))) d_22,
DECODE(SUM(DECODE(SUBSTR(TO_CHAR(FIRST_TIME,'HH24'),1,2),'23',1,)),,'-',SUM(DECODE(SUBSTR(TO_CHAR(FIRST_TIME,'HH24'),1,2),'23',1,))) d_23,
COUNT(TRUNC(FIRST_TIME)) Total
FROM v$log_history
GROUP BY TO_CHAR(FIRST_TIME,'DY, DD-MON-YYYY')
ORDER BY TO_DATE(SUBSTR(TO_CHAR(FIRST_TIME,'DY, DD-MON-YYYY'),5,15) )
/
 
SELECT * FROM v$license;
SELECT banner FROM v$version WHERE BANNER LIKE '%Edition%';
SELECT DECODE(COUNT(*), , 'No', 'Yes') Partitioning
FROM ( SELECT 1
 FROM dba_part_tables
WHERE owner NOT IN ('SYSMAN', 'SH', 'SYS', 'SYSTEM')
AND rownum = 1 );
SELECT DECODE(COUNT(*), , 'No', 'Yes') Spatial
FROM ( SELECT 1
 FROM all_sdo_geom_metadata
WHERE rownum = 1 );
SELECT DECODE(COUNT(*), , 'No', 'Yes') RAC
FROM ( SELECT 1
FROM v$active_instances
 WHERE rownum = 1 );
SET FEEDBACK off
SET LINESIZE 122

COLUMN name FORMAT A45 HEADING "Feature"
COLUMN version FORMAT A10 HEADING "Version"
COLUMN detected_usages FORMAT 999,990 HEADING "Detected|usages"
COLUMN currently_used FORMAT A06 HEADING "Curr.|used?"
COLUMN first_usage_date FORMAT A10 HEADING "First use"
COLUMN last_usage_date FORMAT A10 HEADING "Last use"
COLUMN nop noprint

BREAK ON nop SKIP 1 ON name

  SELECT DECODE(detected_usages,,2,1) nop,
         name,
         version,
         detected_usages,
         currently_used,
         TO_CHAR(first_usage_date,'DD/MM/YYYY') first_usage_date,
         TO_CHAR(last_usage_date,'DD/MM/YYYY') last_usage_date
    FROM dba_feature_usage_statistics
ORDER BY nop, 1, 2;

  SELECT comp_name,status,version
    FROM dba_registry;
	
!cat /proc/version >> checklist_&sid..txt
!cat /proc/cpuinfo >> checklist_&sid..txt
!cat /etc/redhat-release >> checklist_&sid..txt

TTITLE OFF
PROMPT
spool off
---exit