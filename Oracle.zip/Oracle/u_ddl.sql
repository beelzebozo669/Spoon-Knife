--- http://www.oracle-scripts.net/generate-user-ddl/

--- GENERATE USER DDL WITH DBMS_METADATA.GET_DDL USER

CLEAR SCREEN
ACCEPT uname   PROMPT 'Enter User Name : '
ACCEPT outfile PROMPT  ' Output filename : '
 
SPOOL &&outfile..gen
 
SET LONG 20000 LONGCHUNKSIZE 20000 PAGESIZE 0 LINESIZE 1000 FEEDBACK OFF VERIFY OFF TRIMSPOOL ON
 
BEGIN
   DBMS_METADATA.set_transform_param (DBMS_METADATA.session_transform, 'SQLTERMINATOR', true);
   DBMS_METADATA.set_transform_param (DBMS_METADATA.session_transform, 'PRETTY', true);
END;
/
 
SELECT dbms_metadata.get_ddl('USER','&&uname') FROM dual;
SELECT DBMS_METADATA.GET_GRANTED_DDL('SYSTEM_GRANT','&&uname') from dual;
SELECT DBMS_METADATA.GET_GRANTED_DDL('ROLE_GRANT','&&uname') from dual;
SELECT DBMS_METADATA.GET_GRANTED_DDL('OBJECT_GRANT','&&uname') from dual;
 
SPOOL OFF


CLEAR SCREEN
 
ACCEPT uname   PROMPT 'Display the DDL for this specific user: '
ACCEPT outfile PROMPT  ' Output filename : '
 
COLUMN username NOPRINT
COLUMN lne NEWLINE
 
SET LONG 20000 LONGCHUNKSIZE 20000 PAGESIZE 0 LINESIZE 1000 FEEDBACK OFF VERIFY OFF TRIMSPOOL ON
 
SPOOL &&outfile..gen
 
PROMPT  -- generate user ddl
SELECT username, 'CREATE USER '||username||' '||
       DECODE(password, 'EXTERNAL', 'IDENTIFIED EXTERNALLY', 'IDENTIFIED BY VALUES '''||password||''' ') lne,
       'DEFAULT TABLESPACE '||default_tablespace lne,
       'TEMPORARY TABLESPACE '||temporary_tablespace||';' lne
  FROM DBA_USERS
 WHERE USERNAME LIKE UPPER('%&&uname%')
    OR UPPER('&&uname') IS NULL
ORDER BY USERNAME;
 
SELECT username, 'ALTER USER '||username||' QUOTA '||
       DECODE(MAX_BYTES, -1, 'UNLIMITED', TO_CHAR(ROUND(MAX_BYTES/1024))||'K')
       ||' ON '||tablespace_name||';' lne
  FROM DBA_TS_QUOTAS
 WHERE USERNAME LIKE UPPER('%&&uname%')
    OR UPPER('&&uname') IS NULL
ORDER BY USERNAME;
 
COLUMN grantee noprint
 
SELECT grantee, granted_role granted_priv,
       'GRANT '||granted_role||' to '||grantee||
       DECODE(ADMIN_OPTION, 'Y', ' WITH ADMIN OPTION;', ';')
  FROM dba_role_privs
 WHERE grantee LIKE UPPER('%&&uname%')
         UNION
SELECT grantee, privilege granted_priv,
       'GRANT '||privilege||' to '||grantee||
       DECODE(ADMIN_OPTION, 'Y', ' WITH ADMIN OPTION;', ';')
  FROM dba_sys_privs
 WHERE grantee LIKE UPPER('%&&uname%')
ORDER BY 1, 2;
 
SPOOL OFF

--- http://www.oracle-scripts.net/standard-datapump-use/
--- STANDARD DATAPUMP USE
--- How the Oracle DBA can use datapump in consistency mode with “flashback_time” :
–-- Create the export directory
–-- Verify the grantees on the export directory
–-- Execute the datapupmp export with expdp in consistency mode
–-- Execute an example of datapump import

-- Create the datapump directory
SQL> create directory export as '/oracle/export/SID/’;
 
 
-- Verify the grantees on the datapump directory
SQL> SELECT dbms_metadata.get_dependent_ddl('OBJECT_GRANT', 'EXPORT', 'SYS') from dual;
 
-- You should have a result like this as :
-- DBMS_METADATA.GET_DEPENDENT_DDL('OBJECT_GRANT','EXPORT','SYS')
-- --------------------------------------------------------------------------------
--
--  GRANT READ, WRITE ON DIRECTORY "EXPORT" TO "EXP_FULL_DATABASE"
 
 
-- Execute the export datapump with expdp in consistency mode:
$ expdp \'/ as sysdba\' dumpfile=exp_nomBase_02052011_0956.dmp logfile=exp_nomBase_02052011_0956.log full=y flashback_time=\"TO_TIMESTAMP\(TO_CHAR\(SYSDATE, \'YYYY-MM-DD HH24:MI:SS\'\),\'YYYY-MM-DD HH24:MI:SS\'\)\" directory=export 
 
-- Execute the import datapump of one schema. Remap User Scott to Vinc and 2 tablespaces to DATA:
$ impdp \'/ as sysdba\' dumpfile=exp_nomBase_02052011_0956.dmp logfile=imp_nomBase_02052011_0956.log REMAP_SCHEMA=Scott:Vinc SCHEMAS=scott REMAP_TABLESPACE=USER1:DATA  REMAP_TABLESPACE=USER2:DATA directory=export 
 
-- export a single schema
expdp \'/ as sysdba\' SCHEMAS=myschema directory=DATA_PUMP_DIR dumpfile=myschema.dmp logfile=myschema.log VERSION=LATEST
 
-- export a single table of a schema
expdp \'/ as sysdba\' tables=myschema.mytable directory=DATA_PUMP_DIR dumpfile=myschemamytable.dmp logfile=myschemamytable.log VERSION=LATEST
 
-- Import single table
impdp \'/ as sysdba\' tables=myschema.mytable directory=DATA_PUMP_DIR dumpfile=myschemamytable.dmp logfile=impmyschemamytable.log
-- If the table to import exists, use the option: TABLE_EXISTS_ACTION=[SKIP | APPEND | TRUNCATE | REPLACE]
— Optionally you can easily get DDL from dumpfile using the parameter sqlfile=My_file.sql

 

Sometimes, we may get a requirement to delete datapump jobs which are stopped abruptly due to some reason, you can purge data pump jobs.
