rem     ---------------------------------------------------------------------------------------------------
rem     JVC Solutions
rem     Glasgow
rem     United Kingdom
rem     Internet: http://www.jvcsolutions.com
rem     ---------------------------------------------------------------------------------------------------
rem     Group/Privileges.:      SYSDBA
rem     Script Name......:      syn.sql
rem     Developer........:      Jim Campbell (JC)
rem     Date.............:      07/12/2001
rem     Version..........:      Oracle Database 9i
rem     Description......:      Creates view JC_SYNONYMS more obvious than DBA_SYNONYMS
rem     Usage............:      @syn
rem     Input parameters.:      None
rem     Output...........:      Creates view jc_synonyms
rem     Called by........:      N/A
rem     Requirements.....:      Select on the following objects:
rem                             DBA_OBJECTS
rem                             DBA_SYNONYMS
rem
rem     Remarks..........:      Shows object_type, destination and if the synonym points nowhere
rem
rem     ---------------------------------------------------------------------------------------------------
rem     Changes:
rem     Date            Who     Revision        Oracle Version                  Change
rem     ---------------------------------------------------------------------------------------------------
rem     07/12/2001      JC      v1.0            Oracle 9i                       Initial Script
rem     ---------------------------------------------------------------------------------------------------

CREATE OR REPLACE VIEW jc_synonyms
AS
  SELECT vs.owner,
         vs.synonym_name,
         vs.table_owner object_owner,
         vs.table_name object_name,
         nvl(vs.object_type, vs.pub_syn) object_type,
         vs.db_link
    FROM (
            SELECT dbs.owner,
                   dbs.synonym_name,
                   dbs.table_owner,
                   dbs.table_name,
                   dbs.db_link,
                   DECODE(dbo01.object_type, 'SYNONYM', 'PRIVATE SYNONYM', dbo01.object_type) object_type,
                   DECODE(dbo02.object_type, 'SYNONYM', 'PUBLIC SYNONYM',  null, 'n/a', dbo02.object_type) pub_syn
              FROM dba_synonyms dbs,
                   dba_objects dbo01,
                   dba_objects dbo02
             WHERE dbo01.owner(+)       = dbs.table_owner
               AND dbo01.object_name(+) = dbs.table_name
               AND dbo02.object_name(+) = dbs.table_name
               AND dbo02.object_type(+) = 'SYNONYM'
               AND dbo02.owner(+)       = 'PUBLIC'
               AND dbo01.object_type(+) NOT IN ('QUEUE','PACKAGE BODY')
         ) vs;

DROP PUBLIC SYNONYM jc_synonyms;
CREATE PUBLIC SYNONYM jc_synonyms FOR sys.jc_synonyms;
GRANT SELECT ON jc_synonyms TO select_catalog_role;

PROMPT
PROMPT The VIEW jc_synonyms has been created
PROMPT
