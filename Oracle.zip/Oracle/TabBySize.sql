SET LINESIZE 80
SET PAGESIZE 30

COLUMN owner      FORMAT A30
COLUMN table_name FORMAT A30

  SELECT uas.owner,
         uas.table_name,
         TRUNC(SUM(uas.bytes) / 1024 / 1024) MB
    FROM (
            SELECT ds.segment_name table_name,
                   ds.owner,
                   ds.bytes
              FROM dba_segments ds
             WHERE ds.segment_type = 'TABLE'
          UNION ALL
            SELECT di.table_name,
                   di.owner,
                   ds.bytes
              FROM dba_indexes  di,
                   dba_segments ds
             WHERE ds.segment_name = di.index_name
               AND ds.owner        = di.owner
               AND ds.segment_type = 'INDEX'
          UNION ALL
            SELECT dl.table_name,
                   dl.owner,
                   ds.bytes
              FROM dba_lobs dl,
                   dba_segments ds
             WHERE ds.segment_name = dl.segment_name
               AND ds.owner        = dl.owner
               AND ds.segment_type = 'LOBSEGMENT'
          UNION ALL
            SELECT dl.table_name,
                   dl.owner,
                   ds.bytes
              FROM dba_lobs dl,
                   dba_segments ds
             WHERE ds.segment_name = dl.index_name
               AND ds.owner        = dl.owner
               AND ds.segment_type = 'LOBINDEX'
         ) uas
   WHERE uas.owner NOT IN ('SYS', 'SYSTEM')
GROUP BY uas.table_name, uas.owner
HAVING SUM(uas.bytes) / 1024 / 1024 > 30 /* Ignore tables lower than 30 MB */
ORDER BY uas.owner, SUM(uas.bytes) DESC;