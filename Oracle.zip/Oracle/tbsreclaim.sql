SET LINESIZE 500
SET PAGESIZE 1000
SET SERVEROUTPUT ON

DECLARE
        v_tbs_name        char   := null;
        v_hwm             number := 0;
        v_current_size    number := 0;
        v_percent_gain    number := 0;
        v_total_space_rec number := 0;
        v_total_data_size number := 0;

BEGIN

        FOR v_file_info IN (
                              SELECT df.tablespace_name,
                                     df.file_name,
                                     df.file_id,
                                     tbs.block_size
                                FROM dba_tablespaces tbs,
                                     dba_data_files df
                               WHERE tbs.tablespace_name = df.tablespace_name
                           )

        LOOP
              SELECT CEIL( ( NVL( hwm, 1 ) * v_file_info.block_size ) / 1024 / 1024 ),
                     CEIL( blocks * v_file_info.block_size / 1024 / 1024 ) INTO v_hwm,
                     v_current_size
                FROM dba_data_files a,
                     (
                        SELECT file_id,
                               MAX( block_id + blocks - 1 ) hwm
                          FROM dba_extents
                      GROUP BY file_id
                     ) b
               WHERE a.file_id = b.file_id(+)
                 AND a.file_id = v_file_info.file_id;

           v_total_space_rec := v_total_space_rec + ( v_current_size - v_hwm );
           v_total_data_size := v_total_data_size + v_current_size;

                DBMS_OUTPUT.PUT_LINE('Tablespace name                                   : ' || v_file_info.tablespace_name);
                DBMS_OUTPUT.PUT_LINE('File path and name                                : ' || v_file_info.file_name);
                DBMS_OUTPUT.PUT_LINE('Current size                                      : ' || v_current_size || 'MB' );
                DBMS_OUTPUT.PUT_LINE('HWM                                               : ' || v_hwm || 'MB' );
                DBMS_OUTPUT.PUT_LINE('Percentage reclaimable                            : ' || ROUND(( v_current_size - v_hwm ) * 100 / v_current_size,2 ) || '%');
                DBMS_OUTPUT.PUT_LINE('Use following command to resize                   : ALTER DATABASE DATAFILE ''' || v_file_info.file_name || ''' RESIZE ' || v_hwm|| 'M;');
                DBMS_OUTPUT.PUT_LINE(CHR(10));
        END LOOP;

        DBMS_OUTPUT.PUT_LINE('Total database size before shrinking              : ' || ROUND( v_total_data_size, 2 ) || 'M');
        DBMS_OUTPUT.PUT_LINE('Total database size after  shrinking              : ' || ROUND( v_total_data_size - v_total_space_rec, 2) || 'M');
        DBMS_OUTPUT.PUT_LINE('Total datafiles size reclaimable                  : ' || ROUND( v_total_space_rec, 2 ) || 'M');
        DBMS_OUTPUT.PUT_LINE('Percentage of space reclaimable in the datafiles  : ' || ROUND( v_total_space_rec * 100 / v_total_data_size,2) || '%');
END;
/