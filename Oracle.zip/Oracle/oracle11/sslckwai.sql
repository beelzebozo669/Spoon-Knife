rem ---------------------------------------------------------------------------
rem  Trivadis AG, Baden-D�ttwil/Basel/Bern/Lausanne/Z�rich
rem               D�sseldorf/Frankfurt/Freiburg i.Br./Hamburg/M�nchen/Stuttgart
rem               Wien
rem               Switzerland/Germany/Austria Internet: http://www.trivadis.com
rem ---------------------------------------------------------------------------
rem $Id: sslckwai.sql 124 2008-12-01 02:26:28Z cha $
rem ---------------------------------------------------------------------------
rem  Group/Privileges.: SYSDBA
rem  Script Name......: sslckwai.sql
rem  Developer........: Andri Kisseleff (AnK)
rem  Date.............: August 1993
rem  Version..........: Oracle Database 11g
rem  Description......: Shows actual DML-Locks (incl. Table-Name)
rem                     WAIT = YES are users waiting for a lock
rem  Usage............: 
rem  Input parameters.: 
rem  Output...........: 
rem  Called by........:
rem  Requirements.....: 
rem  Remarks..........: 
rem
rem ---------------------------------------------------------------------------
rem Changes:
rem DD.MM.YYYY Developer Change
rem ---------------------------------------------------------------------------
rem 21.09.1997 ank       Oracle8
rem 21.04.1999 AnK       OK for Oracle8i
rem 03.09.2002 ThJ       OK for Oracle9i R2
rem 09.09.2003 Ank       OK for 10.1 (added some hints)
rem 25.04.2004 MnB       performance: changed hint to "rule" !!
rem 07.01.2008 ChA       Removed hint RULE + added new hints + formatting
rem 01.12.2008 ChA       Fixed header + New ORDER BY
rem 01.12.2008 ChA       OK for 11g
rem ---------------------------------------------------------------------------

set logsource "dummy"
store set temp.tmp replace

SET PAGES 24 LINES 100 FEED ON ECHO OFF TERMOUT ON HEAD ON
COLUMN WAIT FORMAT A4
COLUMN PROCESS FORMAT A12
COLUMN LOCKER FORMAT A25 TRUNC
COLUMN T_OWNER FORMAT A25 TRUNC
COLUMN OBJECT_NAME FORMAT A30
COLUMN OSUSER FORMAT A20 TRUNC
COLUMN PROGRAM FORMAT A79 TRUNC
	
@@foenvtit "Actual DML-Locks (TM+TX)"
REM
	select	/*+ ordered use_hash(s) use_nl(o) use_nl(u) */
                decode(L.REQUEST,0,'NO','YES') WAIT,
		S.PROCESS,
		S.USERNAME LOCKER,
		U.NAME T_OWNER,
		O.NAME OBJECT_NAME,
		S.OSUSER,
		S.PROGRAM PROGRAM
	from    V$LOCK L,
		V$SESSION S,
		OBJ$ O,
	        USER$ U
	where   U.USER# = O.OWNER#
	and     S.SID = L.SID
	and     L.ID1 = O.OBJ#
	and     L.TYPE = 'TM'
	 union
	select	decode(L.REQUEST,0,'NO','YES') WAIT,
		S.PROCESS,
		S.USERNAME LOCKER,
		'-',
		'Record(s)',
		S.OSUSER,
		S.PROGRAM PROGRAM
	from    V$LOCK L,
		V$SESSION S
	where   S.SID = L.SID
	and     L.TYPE = 'TX'
	order by 2, 4, 5
/
ttitle off
col program clear
col locker clear
col t_owner clear
col object_name clear
col wait clear
@temp.tmp
