rem ---------------------------------------------------------------------------
rem  Trivadis AG, Baden-D�ttwil/Basel/Bern/Lausanne/Z�rich
rem               D�sseldorf/Frankfurt/Freiburg i.Br./Hamburg/M�nchen/Stuttgart
rem               Wien
rem               Switzerland/Germany/Austria Internet: http://www.trivadis.com
rem ---------------------------------------------------------------------------
rem $Id: sdinvobj.sql 106 2008-11-30 23:41:00Z cha $
rem ---------------------------------------------------------------------------
rem  Group/Privileges.: DBA
rem  Script Name......: sdinvobj.sql
rem  Developer........: Christian Antognini (ChA)
rem  Date.............: November 2008
rem  Version..........: Oracle Database 11g
rem  Description......: Shows a database-wide overview of invalid objects
rem  Usage............: 
rem  Input parameters.: 
rem  Output...........: 
rem  Called by........:
rem  Requirements.....: 
rem  Remarks..........: 
rem
rem ---------------------------------------------------------------------------
rem Changes:
rem DD.MM.YYYY Developer Change
rem ---------------------------------------------------------------------------
rem 28.11.2008 ChA       Created
rem 01.12.2009 ChA       Added "TTITLE OFF"
rem ---------------------------------------------------------------------------

STORE SET temp.tmp REPLACE
SET LINESIZE 70 PAGESIZE 200

BREAK ON owner SKIP 1

COLUMN owner FORMAT A30
COLUMN object_type FORMAT A30
COLUMN count FORMAT 9999999

@@foenvtit.sql "Invalid Objects"

SELECT owner, 
       nvl(object_type,nvl2(owner,'Total for user '||owner,'Total for all users')) AS object_type, 
       count(*) AS count
FROM dba_objects 
WHERE status = 'INVALID'
GROUP BY rollup(owner, object_type);

@temp.tmp

CLEAR BREAKS
TTITLE OFF

PROMPT
PROMPT For addition information you can run sdobjsta.sql
PROMPT
