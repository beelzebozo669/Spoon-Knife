rem ---------------------------------------------------------------------------
rem  Trivadis AG, Baden-D�ttwil/Basel/Bern/Lausanne/Z�rich
rem               D�sseldorf/Frankfurt/Freiburg i.Br./Hamburg/M�nchen/Stuttgart
rem               Wien
rem               Switzerland/Germany/Austria Internet: http://www.trivadis.com
rem ---------------------------------------------------------------------------
rem $Id: somizsta.sql 71 2008-11-29 14:50:14Z cha $
rem ---------------------------------------------------------------------------
rem  Group/Privileges.: User
rem  Script Name......: somizsta.sql
rem  Developer........: Urs Meier (UrM)
rem  Date.............: 12.08.1992
rem  Version..........: Oracle Database 11g
rem  Description......: Show object statistics (table, columns and indexes)
rem  Usage............: 
rem  Input parameters.: 
rem  Output...........: 
rem  Called by........:
rem  Requirements.....: 
rem  Remarks..........: 
rem
rem ---------------------------------------------------------------------------
rem Changes:
rem DD.MM.YYYY Developer Change
rem ---------------------------------------------------------------------------
rem 07.04.1996 UrM       upgrade to V73
rem 05.04.1997 UrM       rename
rem 02.08.1997 AnK       upgrade to Oracle8
rem 15.11.1997 UrM       Include sample size/date and go for all_tables
rem 21.04.1999 AnK       OK for Oracle8i (col. ambig. defined part. ind. stat query)
rem                      Tested for Hash-Part. Tables. 
rem                      Added support for Composite Partitioning
rem 08.27.2002 ChA       OK for Oracle9i R2
rem 15.09.2003 AnK       OK for 10.1
rem 29.11.2008 ChA       Fixed header + Formatting
rem 29.11.2008 ChA       OK for 11g
rem ---------------------------------------------------------------------------

set logsource "dummy"
store set temp.tmp replace

ACCEPT pTable_Name CHAR -
PROMPT "Show Statistics for Table: "

COLUMN num_rows                HEADING '#rows'              FORMAT 9G999G999G990
COLUMN blocks                  HEADING '#blks'              FORMAT 9G999G990
COLUMN empty_blocks            HEADING '#empty|blks'        FORMAT 9G999G990
COLUMN avg_space               HEADING 'AVG|space'          FORMAT 9G990
COLUMN chain_cnt               HEADING '#chain'             FORMAT 999G999G990
COLUMN avg_row_len             HEADING 'AVG row|length'     FORMAT 9G999G990
COLUMN sample_size             HEADING 'Sampled'            FORMAT 9G999G999G990
COLUMN last_analyzed           HEADING 'Last|Analyzed'      FORMAT A11

COLUMN column_name             HEADING 'Column Name' 	    FORMAT A30
COLUMN num_distinct            HEADING 'Distinct'           FORMAT 9G999G999G990
COLUMN num_nulls               HEADING 'Nulls'              FORMAT 9G999G999G990
COLUMN num_buckets             HEADING 'Buckets'            FORMAT 990
COLUMN indexed                 HEADING 'Ind'

COLUMN index_name              HEADING 'Index'              FORMAT A30
COLUMN uniqueness              HEADING 'Unique'             FORMAT A3
COLUMN blevel                  HEADING 'LEV'                FORMAT 90
COLUMN leaf_blocks             HEADING '#leaf|blk'          FORMAT 9G999G990
COLUMN distinct_keys           HEADING '#dist.|keys'        FORMAT 9G999G999G990
COLUMN avg_leaf_blocks_per_key HEADING 'AVG|LF/key'         FORMAT 9G999G990
COLUMN avg_data_blocks_per_key HEADING 'AVG|Data/key'       FORMAT 9G999G990
COLUMN clustering_factor       HEADING 'Clust.'             FORMAT 9G999G999G990

COLUMN partition_name          HEADING 'Partition Name'     FORMAT A30
COLUMN subpartition_name       HEADING 'Sub-Partition Name' FORMAT A30
COLUMN locality                HEADING 'Loc'                FORMAT A3
COLUMN alignment               HEADING 'Ali'                FORMAT A3

SET VERIFY OFF
SPOOL somizsta.lis

ALTER SESSION SET nls_date_format = 'DD.MM HH24:MI' nls_numeric_characters = '.''';

SET LINESIZE 94

@@foenvtit "Table Statistics for &pTable_Name"
@@fopauon
SELECT num_rows, blocks, empty_blocks, avg_space, chain_cnt, avg_row_len, sample_size, last_analyzed
FROM user_all_tables
WHERE table_name = UPPER('&pTable_Name');

SET LINESIZE 125

@@foenvtit "Partition Statistics for &pTable_Name"
@@fopauon
SELECT partition_name, num_rows, blocks, empty_blocks, avg_space, chain_cnt, avg_row_len, sample_size, last_analyzed
FROM user_tab_partitions
WHERE table_name = UPPER('&pTable_Name')
ORDER BY partition_name;

SET LINESIZE 125

@@foenvtit "Sub-Partition Statistics for &pTable_Name"
@@fopauon
SELECT subpartition_name, num_rows, blocks, empty_blocks, avg_space, chain_cnt, avg_row_len, sample_size, last_analyzed
FROM user_tab_subpartitions
WHERE table_name = UPPER('&pTable_Name')
ORDER BY subpartition_name;

SET LINESIZE 97

@@foenvtit "Column Statistics for &pTable_Name"
@@fopauon
SELECT utc.column_name, utc.num_distinct, utc.num_nulls, utc.num_buckets, decode(uic.column_position,1,'Y','N') indexed, utc.sample_size, utc.last_analyzed
FROM user_tab_columns utc,
     (SELECT uic.table_name, uic.column_name, MIN(uic.column_position) column_position
      FROM user_ind_columns uic
      GROUP BY uic.table_name, uic.column_name) uic
WHERE utc.table_name = uic.table_name(+)
AND utc.column_name = uic.column_name(+)
AND utc.table_name = UPPER('&pTable_Name')
ORDER BY utc.column_id;

BREAK ON COLUMN_NAME SKIP 1
SET LINESIZE 126

@@foenvtit "Partition Column Statistics for &pTable_Name"
@@fopauon
SELECT utc.column_name, utc.partition_name, utc.num_distinct, utc.num_nulls, utc.num_buckets, utc.sample_size, utc.last_analyzed
FROM user_part_col_statistics utc,
     user_tab_columns col,
     (SELECT  uic.table_name, uic.column_name, MIN(uic.column_position) column_position
      FROM user_ind_columns uic
      GROUP BY uic.table_name, uic.column_name) uic
WHERE utc.table_name = uic.table_name(+)
AND utc.column_name = uic.column_name(+)
AND utc.table_name = col.table_name
AND utc.column_name = col.column_name
AND utc.table_name = UPPER('&pTable_Name')
ORDER BY column_id, partition_name;

CLEAR BREAK
BREAK ON COLUMN_NAME SKIP 1
SET LINESIZE 126

@@foenvtit "Sub-Partition Column Statistics for &pTable_Name"
@@fopauon
SELECT utc.column_name, utc.subpartition_name, utc.num_distinct, utc.num_nulls, utc.num_buckets, utc.sample_size, utc.last_analyzed
FROM user_subpart_col_statistics utc,
     user_tab_columns col,
     (SELECT  uic.table_name, uic.column_name, MIN(uic.column_position) column_position
      FROM user_ind_columns uic
      GROUP BY uic.table_name, uic.column_name) uic
WHERE utc.table_name = uic.table_name(+)
AND utc.column_name = uic.column_name(+)
AND utc.table_name = col.table_name
AND utc.column_name = col.column_name
AND utc.table_name = UPPER('&pTable_Name')
ORDER BY column_id, subpartition_name;

CLEAR BREAK
SET LINESIZE 101

@@foenvtit "Index Statistics for &pTable_Name"
@@fopauon
SELECT index_name, substr(uniqueness,1,3), blevel, leaf_blocks, distinct_keys, avg_leaf_blocks_per_key, avg_data_blocks_per_key, clustering_factor
FROM user_indexes
WHERE table_name = UPPER('&pTable_Name');

BREAK ON index_name SKIP 1
SET LINESIZE 140

@@foenvtit "Partition Indexes Statistics for &pTable_Name"
@@fopauon
SELECT ui.index_name, uip.partition_name, substr(ui.uniqueness,1,3) uniqueness, substr(upi.locality,1,3) locality,
       substr(upi.alignment,1,3) alignment, uip.blevel, uip.leaf_blocks, uip.distinct_keys, uip.avg_leaf_blocks_per_key, 
       uip.avg_data_blocks_per_key, uip.clustering_factor
FROM user_ind_partitions uip, user_part_indexes upi, user_indexes ui
WHERE ui.table_name = UPPER('&pTable_Name')
AND uip.index_name = upi.index_name
AND uip.index_name = ui.index_name 
ORDER BY ui.index_name, partition_name;

CLEAR BREAK
BREAK ON index_name SKIP 1
SET LINESIZE 140

@@foenvtit "Sub-Partition Indexes Statistics for &pTable_Name"
@@fopauon
SELECT ui.index_name, uip.subpartition_name, substr(ui.uniqueness,1,3) uniqueness, substr(upi.locality,1,3) locality,
       substr(upi.alignment,1,3) alignment, uip.blevel, uip.leaf_blocks, uip.distinct_keys, uip.avg_leaf_blocks_per_key, 
       uip.avg_data_blocks_per_key, uip.clustering_factor
FROM user_ind_subpartitions uip, user_part_indexes upi, user_indexes ui
WHERE ui.table_name = UPPER('&pTable_Name')
AND uip.index_name = upi.index_name
AND uip.index_name = ui.index_name 
ORDER BY ui.index_name, subpartition_name;

SPOOL OFF
CLEAR BREAK

ttitle off
COLUMN num_rows	CLEAR
COLUMN blocks CLEAR
COLUMN empty_blocks CLEAR
COLUMN avg_space CLEAR
COLUMN chain_cnt CLEAR
COLUMN avg_row_len CLEAR

COLUMN column_name CLEAR
COLUMN num_distinct CLEAR
COLUMN num_nulls CLEAR
COLUMN num_buckets CLEAR
COLUMN last_analyzed CLEAR
COLUMN sample_size CLEAR
COLUMN indexed	 CLEAR

COLUMN index_name CLEAR
COLUMN uniqueness CLEAR
COLUMN blevel CLEAR
COLUMN leaf_blocks CLEAR
COLUMN distinct_keys CLEAR
COLUMN avg_leaf_blocks_per_key CLEAR
COLUMN avg_data_blocks_per_key CLEAR
COLUMN clustering_factor CLEAR
COLUMN partition_name CLEAR
COLUMN locality CLEAR
COLUMN alignment CLEAR
COLUMN subpartition_name CLEAR
@@fopauoff
prompt
prompt somizsta.lis has been spooled
prompt (format landscape together with partitions)
prompt
@temp.tmp
