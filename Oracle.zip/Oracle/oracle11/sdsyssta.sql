rem ---------------------------------------------------------------------------
rem  Trivadis AG, Baden-D�ttwil/Basel/Bern/Lausanne/Z�rich
rem               D�sseldorf/Frankfurt/Freiburg i.Br./Hamburg/M�nchen/Stuttgart
rem               Wien
rem               Switzerland/Germany/Austria Internet: http://www.trivadis.com
rem ---------------------------------------------------------------------------
rem $Id: sdsyssta.sql 102 2008-11-30 22:49:52Z cha $
rem ---------------------------------------------------------------------------
rem  Group/Privileges.: DBA
rem  Script Name......: sdsyssta.sql
rem  Developer........: Andri Kisseleff (AnK)
rem  Date.............: 1993
rem  Version..........: Oracle Database 11g
rem  Description......: System-wide statistics since last instance startup 
rem  Usage............: 
rem  Input parameters.: 
rem  Output...........: 
rem  Called by........:
rem  Requirements.....: 
rem  Remarks..........: 
rem
rem ---------------------------------------------------------------------------
rem Changes:
rem DD.MM.YYYY Developer Change
rem ---------------------------------------------------------------------------
rem 18.06.1996 AnK       title and new header
rem 02.08.1997 AnK       Oracle8
rem 21.04.1999 AnK       OK for Oracle8i
rem 29.09.2000 MaW       WHERE clause added, spooling removed
rem 27.08.2002 MaW       Ok for Oracle9i R2
rem 09.09.2003 AnK       OK for 10.1
rem 30.11.2008 ChA       Fixed header + Formatting
rem 30.11.2008 ChA       OK for 11g
rem ---------------------------------------------------------------------------

store set temp.tmp replace

COLUMN CLASS NOPRINT
COLUMN NAME FORMAT A50 TRUNC
COLUMN VALUE FORMAT 9G999G999G999G999G999G999
BREAK ON CLASS SKIP PAGE
@@foenvtit "System statistics"

SET VERIFY OFF
SET TERMOUT ON PAGES 24 LINES 80 PAUSE ON PAUSE '<return>...'
PROMPT
PROMPT Please enter the statistics class name, wildcards allowed
PROMPT eg.: %redo%
PROMPT
accept stat_name char prompt "Statistic name <%>: " default "%"

SELECT  rpad(name,60,'.') name, value, class
FROM 	v$sysstat
WHERE   name like '&&stat_name'
ORDER BY class, statistic#;

SET PAUSE OFF
TTITLE OFF
CLEAR BREAKS COMPUTES 
COLUMN CLASS CLEAR
COLUMN NAME CLEAR

@temp.tmp
