rem ---------------------------------------------------------------------------
rem  Trivadis AG, Baden-D�ttwil/Basel/Bern/Lausanne/Z�rich
rem               D�sseldorf/Frankfurt/Freiburg i.Br./Hamburg/M�nchen/Stuttgart
rem               Wien
rem               Switzerland/Germany/Austria Internet: http://www.trivadis.com
rem ---------------------------------------------------------------------------
rem $Id: sovietxt.sql 37 2008-11-21 13:40:11Z cha $
rem ---------------------------------------------------------------------------
rem  Group/Privileges.: User
rem  Script Name......: sovietxt.sql
rem  Developer........: Urs Meier (UrM)
rem  Date.............: 1994
rem  Version..........: Oracle Database 11g
rem  Description......: Show the text for a views
rem  Usage............: 
rem  Input parameters.: 
rem  Output...........: 
rem  Called by........:
rem  Requirements.....: 
rem  Remarks..........: 
rem
rem ---------------------------------------------------------------------------
rem Changes:
rem DD.MM.YYYY Developer Change
rem ---------------------------------------------------------------------------
rem 05.04.1997 UrM       rename
rem 02.08.1997 AnK       Oracle8
rem 21.04.1999 AnK       OK for Oracle8i
rem 03.09.2002 ThJ       OK for Oracle9i R2
rem 15.09.2003 AnK       added store set as to reset the SQL*Plus settings
rem 15.09.2003 AnK       OK for 10.1
rem 21.11.2008 ChA       Fixed header + OK for 11g + Formatting
rem ---------------------------------------------------------------------------

store set temp.tmp replace
ACCEPT vname CHAR PROMPT "Text for View(s) [%]: " Default "%"

SET PAUSE OFF -
    ECHO OFF -
    TERMOUT OFF -
    LINESIZE 100
CLEAR COLUMNS -
      BREAKS -
      COMPUTES
COLUMN text FORMAT A100 WRAP
COLUMN maxlong  NOPRINT NEW_VALUE maxlong
COLUMN viewname NOPRINT NEW_VALUE viewname

SELECT MAX(text_length) maxlong
 FROM user_views
WHERE view_name LIKE UPPER('&&vname');

SET LONG &maxlong

SET TERMOUT ON -
    FEEDBACK ON -
    VERIFY OFF 
   
@@fopauon

BREAK ON viewname SKIP PAGE

TTITLE CENTER "View description for "viewname

SELECT view_name viewname, text
 FROM user_views
WHERE view_name LIKE UPPER('&&vname')
ORDER BY view_name;

TTITLE OFF
col maxlong clear
col viewname clear
@@fopauoff
set echo off
@temp.tmp

