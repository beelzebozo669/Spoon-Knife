rem ---------------------------------------------------------------------------
rem  Trivadis AG, Baden-D�ttwil/Basel/Bern/Lausanne/Z�rich
rem               D�sseldorf/Frankfurt/Freiburg i.Br./Hamburg/M�nchen/Stuttgart
rem               Wien
rem               Switzerland/Germany/Austria Internet: http://www.trivadis.com
rem ---------------------------------------------------------------------------
rem $Id: sotabind.sql 33 2008-11-20 15:26:57Z cha $
rem ---------------------------------------------------------------------------
rem  Group/Privileges.: User
rem  Script Name......: sotabind.sql
rem  Developer........: Urs Meier (UrM)
rem  Date.............: 03.01.1990
rem  Version..........: Oracle Database 11g
rem  Description......: Shows the indexes for a given table (or many)
rem  Usage............: 
rem  Input parameters.: 
rem  Output...........: 
rem  Called by........:
rem  Requirements.....: 
rem  Remarks..........: 
rem
rem ---------------------------------------------------------------------------
rem Changes:
rem DD.MM.YYYY Developer Change
rem ---------------------------------------------------------------------------
rem 14.07.1994 AnK       Lauffaehig fuer ORACLE7
rem                      Anzeige DISTINCT KEYS	
rem 05.04.1997 UrM       rename
rem 21.09.1997 AnK       Oracle8, added Partitions, IOTs, etc.
rem 21.04.1999 AnK       OK for Oracle8i. Tested hash partitions.
rem                      Added support for composite partitions.
rem                      P=part.Index. SP=Sub.part.Index
rem                      Scipt runs much faster with ALL_ROWS Optimizer-Hint
rem 03.01.2001 ChA       Added some hints for better performances
rem 27.08.2002 ChA       OK for Oracle9i R2
rem 30.08.2002 FaR       getestet/angepasst f�r 9.2
rem 09.09.2003 AnK       OK for 10.1 (Bitmap idx. on IOTs, List part. IOT)
rem 20.11.2008 ChA       Fixed header + OK for 11g + Formatting
rem ---------------------------------------------------------------------------

store set temp.tmp replace
set echo off
set verify off
set linesize 100
@@fopauon
column index_name	format a40 word_wrap	heading 'Index Name (Partition)' 
column type		format a3		heading 'Typ'
column uni		format a3		heading 'Uni'
column tablespace_name	format a10 wrap		heading 'Tablespace'
column table_name	noprint			new_value tab
column column_name	format a25 wrap		heading 'Column Name'
column distinct_keys	format 9G999G999G999	heading 'Distinct Keys'
column column_position  noprint
ttitle center 'Indexes for table 'tab skip 2
break on table_name skip page -
      on index_name skip 2 -
      on type -
      on uni -
      on distinct_keys  -
      on tablespace_name
PROMPT 
PROMPT Please enter table name, wildcards allowed
PROMPT
PROMPT eg.: EMP, E% or %
PROMPT
accept table_name char prompt "Table Name <%>: " default "%"
select 	/*+ ordered 
            no_merge(i) 
            no_merge(c) use_hash(c) */ 
        /* first non-partitioned indexes */
                i.index_name,i.table_name,c.column_name,
		decode(i.table_type,'TABLE','TAB','CLUSTER','CLU','???') type,
                decode(i.index_type,'BITMAP','BIT',
                                    'CLUSTER','CLU',
                                    'IOT - TOP','IOT',
                                    'LOB','LOB',
		                     decode(i.uniqueness,'UNIQUE','YES',
                                                         'NONUNIQUE','NO')) UNI,
		i.tablespace_name, i.distinct_keys, c.column_position 
   	from  user_indexes i, user_ind_columns c
  	where i.table_name = c.table_name
    	and i.index_name = c.index_name
    	and i.table_name like upper('&&Table_Name')
        and i.partitioned = 'NO'
 union
select  /*+ ordered 
            no_merge(i) 
            no_merge(ip) use_hash(ip)
            no_merge(c) use_hash(c) 
            no_merge(p) use_hash(p) */ 
        /* and now partitioned indexes */ 
        i.index_name||' ('||ip.partition_name||') '||
                    ' (P:'||p.locality||' '||p.alignment||')' index_name,
        c.table_name,c.column_name,
                decode(i.table_type,'TABLE','TAB','CLUSTER','CLU','???') type,
                decode(i.index_type,'BITMAP','BIT',
                                    'CLUSTER','CLU',
                                    'IOT - TOP','IOT',
                                    'LOB','LOB',
                                     decode(i.uniqueness,'UNIQUE','YES',
                                                         'NONUNIQUE','NO')) UNI,
                ip.tablespace_name, i.distinct_keys, c.column_position
        from  user_indexes i, user_ind_partitions ip,
              user_ind_columns c, user_part_indexes p
        where i.table_name = c.table_name
        and p.index_name = ip.index_name
        and i.index_name = ip.index_name
        and ip.index_name = c.index_name
        and i.table_name like upper('&&Table_Name')
        and ip.tablespace_name is not null /* Comp. part. Indexes */
 union
select  /*+ ordered 
            no_merge(i) 
            no_merge(ip) use_hash(ip)
            no_merge(c) use_hash(c) 
            no_merge(p) use_hash(p) */ 
        /* and now sub-partitioned indexes */ 
        i.index_name||' ('||ip.subpartition_name||') '||
                    ' (SP:'||p.locality||' '||p.alignment||')' index_name,
        c.table_name,c.column_name,
                decode(i.table_type,'TABLE','TAB','CLUSTER','CLU','???') type,
                decode(i.index_type,'BITMAP','BIT',
                                    'CLUSTER','CLU',
                                    'IOT - TOP','IOT',
                                    'LOB','LOB',
                                     decode(i.uniqueness,'UNIQUE','YES',
                                                         'NONUNIQUE','NO')) UNI,
                ip.tablespace_name, i.distinct_keys, c.column_position
        from  user_indexes i, user_ind_subpartitions ip,
              user_ind_columns c, user_part_indexes p
        where i.table_name = c.table_name
        and p.index_name = ip.index_name
        and i.index_name = ip.index_name
        and ip.index_name = c.index_name
        and i.table_name like upper('&&Table_Name')
 union
select /*+ ordered 
            no_merge(i) 
            no_merge(l) use_hash(l) */ 
       /* and now the LOB-Indexes */
       l.index_name, l.table_name, l.column_name,'LOB' TYPE,
       'LOB' UNI, i.tablespace_name,
       -1,1
       from user_indexes i, user_lobs l
       where l.index_name = i.index_name
       and   l.table_name = i.table_name
       and   l.table_name like upper('&&Table_Name')
order by 2, 5 desc, 1, 8;

ttitle off
clear break compute     
column index_name	CLEAR
column type		CLEAR
column uni              CLEAR
column tablespace_name	CLEAR
column table_name	CLEAR
column column_name	CLEAR
column distinct_keys	CLEAR
column column_position  CLEAR
undefine table_name
@temp.tmp
