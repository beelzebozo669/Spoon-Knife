rem ---------------------------------------------------------------------------
rem  Trivadis AG, Baden-D�ttwil/Basel/Bern/Lausanne/Z�rich
rem               D�sseldorf/Frankfurt/Freiburg i.Br./Hamburg/M�nchen/Stuttgart
rem               Wien
rem               Switzerland/Germany/Austria Internet: http://www.trivadis.com
rem ---------------------------------------------------------------------------
rem $Id: soxplmv.sql 39 2008-11-21 16:20:44Z cha $
rem ---------------------------------------------------------------------------
rem  Group/Privileges.: User
rem  Script Name......: soxplmv.sql
rem  Developer........: Christian Antognini (ChA)
rem  Date.............: 12.07.2001
rem  Version..........: Oracle Database 11g
rem  Description......: Shows materialized view's capabilities
rem  Usage............: 
rem  Input parameters.: 
rem  Output...........: 
rem  Called by........:
rem  Requirements.....: 
rem  Remarks..........: MV_CAPABILITIES_TABLE must exists (can be created
rem                     with the script ?/rdbms/admin/utlxmv.sql)
rem                     Lower/Mixed case object names are not supported.
rem
rem ---------------------------------------------------------------------------
rem Changes:
rem DD.MM.YYYY Developer Change
rem ---------------------------------------------------------------------------
rem 03.09.2002 ThJ       OK for Oracle9i R2
rem 15.09.2003 AnK       OK for 10.1
rem 21.11.2008 ChA       Fixed header + OK for 11g + Formatting
rem ---------------------------------------------------------------------------

store set temp.tmp replace
@@fopauon
set verify off
set recsep each
set linesize 100

col capability_name format A29
col possible format A1
col related_text format A20
col msgtxt format A47


prompt 
prompt Please enter materialized view name, wildcards NOT allowed
prompt
accept mview_name char prompt "Materialized View Name: " 


DELETE mv_capabilities_table
WHERE  UPPER(mvname) = UPPER('&&mview_name')
AND    mvowner = user;


EXEC DBMS_MVIEW.EXPLAIN_MVIEW('&&mview_name')


ttitle center 'Capabilities for materialized view ' mview_name skip 2

SELECT capability_name, possible, related_text, msgtxt
FROM   mv_capabilities_table
WHERE  UPPER(mvname) = UPPER('&&mview_name')
AND    mvowner = user
ORDER BY capability_name, related_text;

ttitle off

undef mview_name


col capability_name clear
col possible clear
col related_text clear
col msgtxt clear

@@fopauoff
@temp.tmp
