rem ---------------------------------------------------------------------------
rem  Trivadis AG, Baden-D�ttwil/Basel/Bern/Lausanne/Z�rich
rem               D�sseldorf/Frankfurt/Freiburg i.Br./Hamburg/M�nchen/Stuttgart
rem               Wien
rem               Switzerland/Germany/Austria Internet: http://www.trivadis.com
rem ---------------------------------------------------------------------------
rem $Id: sddep.sql 79 2008-11-30 14:04:39Z cha $
rem ---------------------------------------------------------------------------
rem  Group/Privileges.: DBA
rem  Script Name......: sddep.sql
rem  Developer........: Andri Kisseleff (AnK)
rem  Date.............: 07.01.1994
rem  Version..........: Oracle Database 11g
rem  Description......: Show dependent objects for a given object
rem  Usage............: 
rem  Input parameters.: 
rem  Output...........: 
rem  Called by........:
rem  Requirements.....: 
rem  Remarks..........: cscmpdep.sql must be run previousley under SYS (once)
rem
rem ---------------------------------------------------------------------------
rem Changes:
rem DD.MM.YYYY Developer Change
rem ---------------------------------------------------------------------------
rem 21.09.1997 AnK       Oracle8, removed SELECT * FROM DBA_TRIGGERS
rem                      Fixed bug. Not select ideptree, but
rem                      SYS.VCMPDEP$TMP
rem 20.04.1999 AnK       OK for Oracle8i
rem 02.09.2002 ThJ       OK for Oracle9i R2
rem 10.09.2003 AnK       OK for 10.1
rem                      Removed special treatment for SYNONYMS/PUBLIC SYNONYMS
rem                      Added COMPILE for above, as now they are dependent
rem 30.11.2008 ChA       Fixed header
rem 30.11.2008 ChA       OK for 11g + Display error if cscmpdep.sql was not run
rem ---------------------------------------------------------------------------

SET VERIFY OFF ECHO OFF SERVEROUTPUT ON

DECLARE
  l_count PLS_INTEGER;
BEGIN
  SELECT count(*) INTO l_count
  FROM all_objects
  WHERE object_name = 'CMPDEP'
  AND owner = 'SYS';
  IF l_count = 0
  THEN
    dbms_output.put_line('****************************************************************');
    dbms_output.put_line('* ERROR: cscmpdep.sql must be run previousley under SYS (once) *');
    dbms_output.put_line('****************************************************************');
  END IF;
END;
/

ACCEPT OWNER		CHAR	PROMPT 'Owner of table or view: '
ACCEPT TABLE_NAME	CHAR	PROMPT 'Name (table, view)    : '
ACCEPT TABLE_VIEW	CHAR	PROMPT 'Type (TABLE or VIEW)  : '

EXECUTE SYS.cmpdep(UPPER('&TABLE_VIEW'),UPPER('&OWNER'),UPPER('&TABLE_NAME'));

SELECT	* FROM SYS.VCMPDEP$TMP
ORDER BY 1 DESC
/

SET VERIFY ON SERVEROUTPUT OFF
UNDEFINE OWNER
UNDEFINE TABLE_NAME
UNDEFINE TABLE_VIEW

