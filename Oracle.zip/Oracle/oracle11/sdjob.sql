rem ---------------------------------------------------------------------------
rem  Trivadis AG, Baden-D�ttwil/Basel/Bern/Lausanne/Z�rich
rem               D�sseldorf/Frankfurt/Freiburg i.Br./Hamburg/M�nchen/Stuttgart
rem               Wien
rem               Switzerland/Germany/Austria Internet: http://www.trivadis.com
rem ---------------------------------------------------------------------------
rem $Id: sdjob.sql 115 2008-12-01 01:14:29Z cha $
rem ---------------------------------------------------------------------------
rem  Group/Privileges.: DBA
rem  Script Name......: sdjob.sql
rem  Developer........: Andri Kisseleff (AnK)
rem  Date.............: 12.09.1995
rem  Version..........: Oracle Database 11g
rem  Description......: Show jobs scheduled with DBMS_JOB
rem  Usage............: 
rem  Input parameters.: 
rem  Output...........: 
rem  Called by........:
rem  Requirements.....: 
rem  Remarks..........: 
rem
rem ---------------------------------------------------------------------------
rem Changes:
rem DD.MM.YYYY Developer Change
rem ---------------------------------------------------------------------------
rem 02.08.1997 AnK       Oracle8
rem 20.04.1999 AnK       OK for Oracle8i
rem 03.09.2002 ThJ       OK for Oracle9i R2
rem 15.09.2003 AnK       OK for 10.1
rem 01.12.2008 ChA       Fixed header + Formatting + Added info about instance
rem 01.12.2008 ChA       OK for 11g
rem ---------------------------------------------------------------------------

store set temp.tmp replace

col job format 999999
col log_user format a30
col priv_user format a30
col schema_user format a30
col instance format a16
col broken format a6
col failures format 9G999G999G999
col total_time format 9G999G999G999
col this_sec format 9G999G999G999
col last_date format a9
col last_sec format a8
col next_date format a9
col next_sec format a8
col interval format a100
col what format a100

set echo off termout off pause off array 1

@@foenvtit "All jobs scheduled with DBMS_JOB"
set termout on
set pages 1000 verify off lines 100 timing off
spool sdjob.lis

select job, log_user, priv_user, schema_user, 
       nvl(instance_name,'DEFAULT') instance, broken, failures, total_time, this_sec, 
       last_date, last_sec, next_date, next_sec, 
       interval, what 
from dba_jobs, gv$instance
where instance = instance_number (+)
order by next_date, next_sec, log_user;

spool off
prompt
prompt	sdjob.lis has been spooled
prompt

col job clear
col log_user clear
col priv_user clear
col schema_user clear
col instance clear
col broken clear
col failures clear
col total_time clear
col this_sec clear
col last_date clear
col last_sec clear
col next_date clear
col next_sec clear
col interval clear
col what clear

ttitle off
@temp.tmp
