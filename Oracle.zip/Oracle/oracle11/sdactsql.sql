rem ---------------------------------------------------------------------------
rem  Trivadis AG, Baden-D�ttwil/Basel/Bern/Lausanne/Z�rich
rem               D�sseldorf/Frankfurt/Freiburg i.Br./Hamburg/M�nchen/Stuttgart
rem               Wien
rem               Switzerland/Germany/Austria Internet: http://www.trivadis.com
rem ---------------------------------------------------------------------------
rem $Id: sdactsql.sql 105 2008-11-30 23:19:33Z cha $
rem ---------------------------------------------------------------------------
rem  Group/Privileges.: DBA
rem  Script Name......: sdactsql.sql
rem  Developer........: Urs Meier (UrM)
rem  Date.............: 1995
rem  Version..........: Oracle Database 11g
rem  Description......: Show SQL statements in execution
rem  Usage............: 
rem  Input parameters.: 
rem  Output...........: 
rem  Called by........:
rem  Requirements.....: 
rem  Remarks..........: 
rem
rem ---------------------------------------------------------------------------
rem Changes:
rem DD.MM.YYYY Developer Change
rem ---------------------------------------------------------------------------
rem 05.04.1997 urs.meier  rename
rem 02.08.1997 AnK        Oracle8
rem 21.04.1999 AnK        OK for Oracle8i 
rem 16.06.2000 UrM        Shows only "users executing > 0" (actually running SQL-Commands)
rem 03.09.2002 ThJ        OK for Oracle9i R2
rem 09.09.2002 AnK        OK for 10.1
rem 30.11.2008 ChA        Fixed header + Formatting
rem 30.11.2008 ChA        OK for 11g
rem 30.11.2008 ChA        Renamed sdsqltxt.sql to sdactsql.sql
rem ---------------------------------------------------------------------------

@@foenvtit "SQL statements in execution"
@@fopauon
set linesize 120
column sid format 999999
column username format a30
column sql_text format a70 word_wrap
column executions format 9G999G999
break on sql_text skip 1

select sid, nvl(username,type) username, sql_text, executions
  from v$session, v$sqlarea
 where sql_hash_value = hash_value
 and users_executing > 0
 order by sql_text;
clear breaks
column sql_text clear
column username clear
column executions clear
ttitle off
@@fopauoff
