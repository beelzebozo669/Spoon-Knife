rem ---------------------------------------------------------------------------
rem  Trivadis AG, Baden-D�ttwil/Basel/Bern/Lausanne/Z�rich
rem               D�sseldorf/Frankfurt/Freiburg i.Br./Hamburg/M�nchen/Stuttgart
rem               Wien
rem               Switzerland/Germany/Austria Internet: http://www.trivadis.com
rem ---------------------------------------------------------------------------
rem $Id: sdpkux.sql 92 2008-11-30 21:46:44Z cha $
rem ---------------------------------------------------------------------------
rem  Group/Privileges.: DBA
rem  Script Name......: sdpkux.sql
rem  Developer........: Andri Kisseleff (AnK)
rem  Date.............: 22.12.1995
rem  Version..........: Oracle Database 11g
rem  Description......: Shows unique and PK constraint names which are 
rem                     different from the unique index name on the same
rem                     tables (might give problems with EXP/IMP)
rem  Usage............: 
rem  Input parameters.: 
rem  Output...........: 
rem  Called by........:
rem  Requirements.....: 
rem  Remarks..........: 
rem
rem   Performance:
rem   ------------
rem   InFs Version of the 8i-SELECT is much faster. But it requires ACCESS to
rem   to SYS or O7_DICTIONNARY_ACCESSIBILITY must be set to TRUE. Attached the
rem   SELECT, if someone wants to replace it.
rem   select i.table_owner, i.table_name, o.name "Idx-Name", 
rem          c.name "Constraint-Name"
rem   from
rem          sys.obj$ o, sys.user$ u, sys.cdef$ cd, sys.con$ c, dba_indexes i
rem   where u.user#=o.owner#
rem   and o.obj# = cd.enabled
rem   and cd.enabled is not null
rem   and cd.type# in (2,3)
rem   and u.user#=c.owner#
rem   and cd.con#=c.con#
rem   and o.name!=c.name
rem   and i.index_name=o.name
rem   and i.owner=u.name
rem   order by i.table_owner, i.table_name, o.name;
rem ---------------------------------------------------------------------------
rem Changes:
rem DD.MM.YYYY Developer Change
rem ---------------------------------------------------------------------------
rem 21.09.1997 AnK       Oracle8
rem 20.04.1999 AnK       OK for Oracle8i
rem 05.09.2001 InF	 new colum index_name in dba_constraints used
rem                      Read the new remarks about performance
rem 03.09.2002 ThJ       OK for Oracle9i R2
rem 10.09.2003 AnK       Removed display of LOB-Indexes and Indexes on Tables
rem                      in the Recycle bin
rem 10.09.2003 AnK       OK for 10.1
rem 25.04.2004 MnB       Exclude indexes in recycle bin (DROPPED='YES' instead 
rem                      of like 'RB$%')
rem 30.11.2008 ChA       Fixed header + Formatting
rem 30.11.2008 ChA       OK for 11g
rem ---------------------------------------------------------------------------

col table_owner format a27 heading "Table Owner"
col table_name format a30 heading "Table Name"
col index_name format a30 heading "Index Name"
col constraint_name format a30 heading "Constraint Name"

store set temp.tmp replace

@@foenvtit "Unique and PK constraints with different unique index name"
spool sdpkux.lis
set lines 120 pages 10000
set termout on
select i.table_owner, i.table_name, i.index_name, c.constraint_name
from sys.dba_constraints c, sys.dba_indexes i
where i.owner=c.owner
and i.table_name=c.table_name
and c.constraint_type in ('P','U')
and i.uniqueness = 'UNIQUE'
and i.owner!='SYS'
and c.index_name != c.constraint_name
and i.dropped != 'YES' -- Recycle bin
and i.index_name not like 'SYS_IL%' -- LOB-Index
order by i.table_owner, i.table_name, i.index_name;
spool off
prompt
prompt sdpkux.lis has been spooled...
prompt
@temp.tmp
ttitle off
