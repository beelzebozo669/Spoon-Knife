rem ---------------------------------------------------------------------------
rem  Trivadis AG, Baden-D�ttwil/Basel/Bern/Lausanne/Z�rich
rem               D�sseldorf/Frankfurt/Freiburg i.Br./Hamburg/M�nchen/Stuttgart
rem               Wien
rem               Switzerland/Germany/Austria Internet: http://www.trivadis.com
rem ---------------------------------------------------------------------------
rem $Id: soprv.sql 84 2008-11-30 15:16:47Z cha $
rem ---------------------------------------------------------------------------
rem  Group/Privileges.: User
rem  Script Name......: soprv.sql
rem  Developer........: Andri Kisseleff (AnK)
rem  Date.............: 07.01.1994
rem  Version..........: Oracle Database 11g
rem  Description......: Show all privileges of connected user
rem  Usage............: 
rem  Input parameters.: 
rem  Output...........: 
rem  Called by........:
rem  Requirements.....: 
rem  Remarks..........: Direct privileges, through roles, sub-roles, etc.
rem                     System-Privs, Table/View/Stored-Object Privs.
rem                     Column-Privs, etc.
rem			Excluding public privs. on objects owned by
rem                     CTXSYS,DMSYS,EXFSYS,LBACSYS,MDSYS, etc. (see below)
rem
rem ---------------------------------------------------------------------------
rem Changes:
rem DD.MM.YYYY Developer Change
rem ---------------------------------------------------------------------------
rem 03.11.1997 ank       Oracle8 (changes for object privs with roles)
rem 22.04.1999 AnK       OK for Oracle8i
rem 05.09.2000 SvV       show public Object and Column-Privileges
rem 30.10.2001 AnK       Work-arround for problem with 0 = SELECT COUNT('x') implemented
rem 27.08.2002 MaW       Ok for Oracle9i R2
rem 09.09.2003 AnK       OK for 10.1 
rem                      (Excluded public grants from DTXSYS,DMSYS,MDSYS,.etc)
rem 20.11.2003 AnK       added exclusion of additional public grants (OLAPSYS, etc.)
rem 30.11.2008 ChA       Fixed header + updated list of excluded users
rem 30.11.2008 ChA       OK for 11g (updated list of excluded users)
rem ---------------------------------------------------------------------------

CLEAR BREAKS COLUMNS
SET PAUSE OFF
SPOOL soprv.lis
SHOW USER
ACCEPT DUMMY prompt '<<<RETURN>>> for roles actually set...'
ttitle "Roles actually set"
	SELECT	ROLE, DEFAULT_ROLE, ADMIN_OPTION
	FROM 	SESSION_ROLES, USER_ROLE_PRIVS
	WHERE	GRANTED_ROLE = ROLE
	ORDER BY ROLE
/
ACCEPT DUMMY prompt '<<<RETURN>>> for roles not actually set...'
TTITLE "Roles not actually set"
	SELECT 	GRANTED_ROLE, DEFAULT_ROLE, ADMIN_OPTION
	FROM 	USER_ROLE_PRIVS
	WHERE	NOT EXISTS ( SELECT 	'X'
			     FROM  	SESSION_ROLES
			     WHERE	ROLE = GRANTED_ROLE )
	UNION
	SELECT 'All roles are set','',''
	FROM	DUAL
	WHERE	0 = ( SELECT 	COUNT('X')
		      FROM 	USER_ROLE_PRIVS
		      WHERE 	NOT EXISTS ( SELECT 	'X'
					     FROM	SESSION_ROLES
					     WHERE	ROLE = GRANTED_ROLE))
	ORDER BY 1
/
ACCEPT DUMMY prompt '<<<RETURN>>> for sub-roles...'
ttitle "Sub-Roles"
	SELECT 	ROLE, GRANTED_ROLE
	FROM	ROLE_ROLE_PRIVS
	UNION	
	SELECT  'No Sub-Roles',''
	FROM	DUAL 
        WHERE	0 = ( SELECT 	COUNT(*)
		      FROM   	ROLE_ROLE_PRIVS ) 
/
ACCEPT DUMMY prompt '<<<RETURN>>> for System-Privileges...'
SET PAGES 24 PAUSE ON PAUSE <<<RETURN>>>
BREAK ON ROLE SKIP 1
TTITLE "System-Privileges (roles or directly)"
	SELECT	ROLE, PRIVILEGE, ADMIN_OPTION
	FROM 	ROLE_SYS_PRIVS
	UNION
	SELECT	'direct' ROLE, PRIVILEGE, ADMIN_OPTION
	FROM 	USER_SYS_PRIVS
	ORDER BY 1,2
/
ACCEPT DUMMY prompt '<<<RETURN>>> for Object-Privileges...'
PROMPT
PROMPT Y, A = Granted
PROMPT S = Granted, but only on column level (see next section)
PROMPT G = Granted with GRANT OPTION
PROMPT N = Not Granted
PROMPT
TTITLE "Object-Privileges (roles, directly or public)"
COLUMN ROLE FORMAT A23 TRUNC
COLUMN OWNER FORMAT A12 TRUNC
COLUMN OBJECT_NAME FORMAT A28 TRUNC
COLUMN PRIVILEGE FORMAT A3 TRUNC
SET PAGES 24
SET PAUSE <<<RETURN>>> PAUSE ON
	SELECT	GRANTEE ROLE, OWNER, TABLE_NAME object_name, 
                SELECT_PRIV, INSERT_PRIV, DELETE_PRIV, UPDATE_PRIV,
                REFERENCES_PRIV, ALTER_PRIV, INDEX_PRIV
	FROM	TABLE_PRIVILEGES
	WHERE	GRANTEE IN ( SELECT ROLE
			  FROM 	 SESSION_ROLES )
        AND     OWNER != USER
	UNION
	SELECT	'public' ROLE, OWNER, TABLE_NAME object_name, 
                SELECT_PRIV, INSERT_PRIV, DELETE_PRIV, UPDATE_PRIV,
                REFERENCES_PRIV, ALTER_PRIV, INDEX_PRIV
	FROM	TABLE_PRIVILEGES
	WHERE	GRANTEE = 'PUBLIC'
        AND     OWNER NOT IN (user,'ANONYMOUS','APEX_PUBLIC_USER','CTXSYS','DBSNMP','DIP','EXFSYS',
                              'FLOWS_030000','FLOWS_FILES','LBACSYS','MDDATA','MDSYS','MGMT_VIEW',
                              'OLAPSYS','ORACLE_OCM','ORDPLUGINS','ORDSYS','OUTLN','OWBSYS',
                              'SI_INFORMTN_SCHEMA','SPATIAL_CSW_ADMIN_USR','SPATIAL_WFS_ADMIN_USR',
                              'SYS','SYSMAN','SYSTEM','TSMSYS','WKPROXY','WKSYS','WK_TEST','WMSYS',
                              'XDB')
	UNION
	SELECT 	'direct' ROLE, OWNER, TABLE_NAME object_name,
                SELECT_PRIV, INSERT_PRIV, DELETE_PRIV, UPDATE_PRIV,
                REFERENCES_PRIV, ALTER_PRIV, INDEX_PRIV
	FROM 	TABLE_PRIVILEGES
        WHERE   GRANTEE = USER
        AND     OWNER != USER
	ORDER BY 1,2,3,4
/
ACCEPT DUMMY prompt '<<<RETURN>>> for Column-Privileges...'
TTITLE "Column-Privileges (roles, directly or public)"
COLUMN ROLE FORMAT A16 TRUNC
COLUMN OWNER FORMAT A10 TRUNC
COLUMN OBJECT_NAME FORMAT A20 TRUNC
COLUMN COLUMN_NAME FORMAT A22 TRUNC
COLUMN PRIVILEGE FORMAT A3 TRUNC
SET PAGES 24
SET PAUSE <<<RETURN>>> PAUSE ON
	SELECT	GRANTEE ROLE, OWNER, TABLE_NAME object_name, COLUMN_NAME, 
	        INSERT_PRIV, UPDATE_PRIV,
                REFERENCES_PRIV
	FROM	COLUMN_PRIVILEGES
	WHERE	GRANTEE IN ( SELECT ROLE
			  FROM 	 SESSION_ROLES )
	AND	COLUMN_NAME IS NOT NULL
	UNION
	SELECT	'public' ROLE, OWNER, TABLE_NAME object_name, COLUMN_NAME, 
	        INSERT_PRIV, UPDATE_PRIV,
                REFERENCES_PRIV
	FROM	COLUMN_PRIVILEGES
	WHERE	GRANTEE = 'PUBLIC'
	AND	COLUMN_NAME IS NOT NULL
	UNION
	SELECT 	'direct' ROLE, OWNER, TABLE_NAME object_name, COLUMN_NAME, 
	        INSERT_PRIV, UPDATE_PRIV,
                REFERENCES_PRIV
	FROM 	COLUMN_PRIVILEGES
        WHERE   GRANTEE = USER
        AND     OWNER != USER
	ORDER BY 1,2,3,4
/
SPOOL OFF
CLEAR BREAKS 
COL ROLE CLEAR
COL OWNER CLEAR
COL OBJECT_NAME CLEAR
COL COLUMN_NAME CLEAR
COL PRIVILEGE CLEAR
TTITLE OFF
SET PAUSE OFF
PROMPT
PROMPT ed soprv.lis for the listing of your privileges...
PROMPT


