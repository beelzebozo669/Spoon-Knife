rem ---------------------------------------------------------------------------
rem  Trivadis AG, Baden-D�ttwil/Basel/Bern/Lausanne/Z�rich
rem               D�sseldorf/Frankfurt/Freiburg i.Br./Hamburg/M�nchen/Stuttgart
rem               Wien
rem               Switzerland/Germany/Austria Internet: http://www.trivadis.com
rem ---------------------------------------------------------------------------
rem $Id: ssasmfil.sql 42 2008-11-25 10:35:53Z cha $
rem ---------------------------------------------------------------------------
rem  Group/Privileges.: SYSDBA
rem  Script Name......: ssasmfil.sql
rem  Developer........: Peter Hulm (PHu)
rem  Date.............: January 2005
rem  Version..........: Oracle Database 11g
rem  Description......: Shows, for each database, the files stored in ASM
rem  Usage............: 
rem  Input parameters.: 
rem  Output...........: 
rem  Called by........:
rem  Requirements.....: 
rem  Remark...........: Run this script while connected to the +ASM instance. 
rem                     Otherwise, no information is displayed.
rem
rem ---------------------------------------------------------------------------
rem Changes:
rem DD.MM.YYYY Developer Change
rem ---------------------------------------------------------------------------
rem 18.10.2007 ChA       Added information about database and diskgroup
rem 25.11.2008 ChA       Fixed header + OK for 11g
rem ---------------------------------------------------------------------------

set linesize 120 pagesize 100

column database noprint new_value database
column path format a80
column file_type format a13
column redundancy format a6
column striped format a6
column used_mb format 9,999,990

break on database skip page
ttitle center "Database " ''database'' skip 2

SELECT a.database, '+'||g.name||a.path path, f.type file_type, f.redundancy, f.striped,
       round(f.bytes/1024/1024) size_mb
FROM v$asm_diskgroup g, v$asm_file f, 
     (SELECT connect_by_root name database, group_number, file_number, sys_connect_by_path(name,'/') path
      FROM v$asm_alias
      WHERE alias_directory = 'N'
      START WITH parent_index IN (SELECT parent_index FROM v$asm_alias
                                  MINUS
                                  SELECT reference_index FROM v$asm_alias)
      CONNECT BY PRIOR reference_index = parent_index) a
WHERE a.file_number = f.file_number(+)
AND a.group_number = f.group_number(+)
AND g.group_number = a.group_number
ORDER BY a.database, g.name, a.path
/

clear break
ttitle off

column database clear
column path clear
column file_type clear
column redundancy clear
column striped clear
column used_mb clear
