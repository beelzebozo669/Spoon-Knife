rem ---------------------------------------------------------------------------
rem  Trivadis AG, Baden-D�ttwil/Basel/Bern/Lausanne/Z�rich
rem               D�sseldorf/Frankfurt/Freiburg i.Br./Hamburg/M�nchen/Stuttgart
rem               Wien
rem               Switzerland/Germany/Austria Internet: http://www.trivadis.com
rem ---------------------------------------------------------------------------
rem $Id: soascii.sql 31 2008-11-20 13:24:10Z cha $
rem ---------------------------------------------------------------------------
rem  Group/Privileges.: User
rem  Script Name......: soascii.sql
rem  Developer........: Stephan Borsodi (SBo)
rem  Date.............: December 2000
rem  Version..........: Oracle Database 11g
rem  Description......: Creates an ascii coding list (ascii_nr: value) valid
rem                     for the instance on which the script is executed.
rem  Usage............: 
rem  Input parameters.: 
rem  Output...........: 
rem  Called by........:
rem  Requirements.....: 
rem  Remarks..........: 
rem
rem ---------------------------------------------------------------------------
rem Changes:
rem DD.MM.YYYY Developer Change
rem ---------------------------------------------------------------------------
rem 22.12.2000 SBo       Initial version created
rem 03.09.2002 ThJ       OK for Oracle9i R2
rem 15.09.2003 AnK       OK for 10.1
rem 20.09.2008 ChA       Fixed header + OK for 11g
rem ---------------------------------------------------------------------------

set serverout on size 100000

begin
	dbms_output.put_line('ASCII codings on this database');
	dbms_output.put_line('=============================='||CHR(10));
	dbms_output.put_line('Ascii   Character');
	dbms_output.put_line('------- ---------');
	for i in 1 .. 256 loop
		dbms_output.put_line(rpad(to_char(i, '099'), 7, '.')||': '||CHR(i));
	end loop;
end;
/


