rem ---------------------------------------------------------------------------
rem  Trivadis AG, Baden-D�ttwil/Basel/Bern/Lausanne/Z�rich
rem               D�sseldorf/Frankfurt/Freiburg i.Br./Hamburg/M�nchen/Stuttgart
rem               Wien
rem               Switzerland/Germany/Austria Internet: http://www.trivadis.com
rem ---------------------------------------------------------------------------
rem $Id: ssasmgrp.sql 141 2011-05-03 14:48:34Z mbg $
rem ---------------------------------------------------------------------------
rem  Group/Privileges.: SYSDBA
rem  Script-Name......: ssasmgrp.sql
rem  Developer........: Peter Hulm (peter.hulm@trivadis.com)
rem  Date.............: January 2005
rem  Version..........: Oracle Database 10g
rem  Description......: Shows available ASM disk groups
rem  Usage............: 
rem  Input parameters.: 
rem  Output...........: 
rem  Called by........:
rem  Requirements.....: 
rem  Remarks..........: In Oracle Database 10g Release 1 some information is 
rem                     only displayed when connected to the +ASM instance. 
rem ---------------------------------------------------------------------------
rem Changes:
rem DD.MM.YYYY Developer Change
rem ---------------------------------------------------------------------------
rem 18.10.2007 ChA       Changed formatting and fixed problem with dismounted
rem                      disk groups
rem 03.05.2011 DaH       rised fthe format of TOTAL_MB, FREE_MB and USED_MB
rem                      to display 9 digits
rem ---------------------------------------------------------------------------

set linesize 100 pagesize 100

column diskgroup_name format a30
column state format a10
column type format a6
column total_mb format 999,999,990
column free_mb format 999,999,990
column used_mb format 999,999,990
column free_percent format 990.0

select name diskgroup_name, state, type, total_mb, free_mb, 
       (total_mb-free_mb) used_mb, round(((free_mb*100)/nullif(total_mb,0)),2) free_percent
from v$asm_diskgroup
order by name
/

column diskgroup_name clear
column state clear
column type clear
column total_mb clear
column free_mb clear
column used_mb clear
column free_percent clear
