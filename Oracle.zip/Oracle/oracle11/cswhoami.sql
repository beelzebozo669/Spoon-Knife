rem ---------------------------------------------------------------------------
rem  Trivadis AG, Baden-D�ttwil/Basel/Bern/Lausanne/Z�rich
rem               D�sseldorf/Frankfurt/Freiburg i.Br./Hamburg/M�nchen/Stuttgart
rem               Wien
rem               Switzerland/Germany/Austria Internet: http://www.trivadis.com
rem ---------------------------------------------------------------------------
rem $Id: cswhoami.sql 62 2008-11-28 22:50:02Z cha $
rem ---------------------------------------------------------------------------
rem  Group/Privileges.: DBA
rem  Script-Name......: cswhoami.sql
rem  Developer........: Urs Meier (urm)/Andri Kisseleff (ank) 
rem                     andri.kisseleff@trivadis.com
rem  Date.............: January 1995
rem  Version..........: Oracle Database 11g
rem  Usage............: Creates view whoami and grants select to public
rem                     Shows PID of foreground and shadow/Server-Process
rem                     as well as the server type (SHARED/DEDICATED)
rem  Input parameters.:
rem  Output.......... : 
rem  Called by........:
rem  Remarks..........: To be run while connected as SYS
rem                     To automatically show the information at login,
rem                     add the following lines at the end of
rem                     $ORACLE_HOME/sqlplus/admin/glogin.sql :
rem                     COLUMN "WHO (OSUSER DBUSER GLOBALNAME)" FORMAT A49 TRUNCATE
rem                     COLUMN frontend FORMAT a9
rem                     COLUMN backend FORMAT a9
rem                     COLUMN servertype FORMAT a10
rem                     SELECT * FROM whoami;
rem -----------------------------------------------------------------------
rem Changes:
rem DD.MM.YYYY Consultant Change
rem -----------------------------------------------------------------------
rem 05.04.1997 UrM        Rename
rem 02.08.1997 ank        Oracle8
rem 20.04.1999 AnK        OK for Oracle8i 
rem 08.07.2002 ChA        OK for Oracle9i R2
rem 10.12.2002 AnK        Added (and sid in select sid from v$mystat)
rem                       as the user SYS has always AUDSID=O (so SYS is shown
rem                       as many times as he is connected, not only the current session
rem                       OK for 9.0 and 9.2
rem 09.09.2003 AnK        OK for 10.1 + WHO now more meaningful
rem 25.04.2004 MnB        Added comment about glogin.sql
rem 10.06.2008 ChA        Formatting (removed SUBSTR from SELECT clause)
rem                       Removed restriction on AUDSID
rem                       Replaced subquery on v$mystat with context
rem 28.11.2008 ChA        Fixed header + OK for 11g
rem -----------------------------------------------------------------------

CREATE OR REPLACE VIEW whoami 
	(
 	"WHO (OSUSER DBUSER GLOBALNAME)",
	frontend,
	backend,
	servertype
	)
AS SELECT
	p.username||' as '||s.username||' at '||g.global_name,
	s.process,
	p.spid,
	s.server
FROM	v$session s,
        v$process p,
        global_name g
WHERE	s.paddr = p.addr
AND     s.sid = sys_context('userenv','sid')
/
DROP PUBLIC SYNONYM whoami;
CREATE PUBLIC SYNONYM whoami FOR sys.whoami
/
GRANT SELECT ON whoami TO PUBLIC
/
SELECT * FROM whoami;
