rem ---------------------------------------------------------------------------
rem  Trivadis AG, Baden-D�ttwil/Basel/Bern/Lausanne/Z�rich
rem               D�sseldorf/Frankfurt/Freiburg i.Br./Hamburg/M�nchen/Stuttgart
rem               Wien
rem               Switzerland/Germany/Austria Internet: http://www.trivadis.com
rem ---------------------------------------------------------------------------
rem $Id: cssyn.sql 86 2008-11-30 17:00:42Z cha $
rem ---------------------------------------------------------------------------
rem  Group/Privileges.: SYSDBA
rem  Script Name......: cssyn.sql
rem  Developer........: Ingo Frost (InF)
rem  Date.............: 01.10.2001
rem  Version..........: Oracle Database 11g
rem  Description......: Creates view TVD_SYNONYMS (better than DBA_SYNONYMS...)
rem  Usage............: 
rem  Input parameters.: 
rem  Output...........: 
rem  Called by........: sdsyn.sql and sdsynerr.sql
rem  Requirements.....: 
rem  Remarks..........: shows object_type of destination 
rem                     and if the synonym points to nowhere
rem
rem ---------------------------------------------------------------------------
rem Changes:
rem DD.MM.YYYY Developer Change
rem ---------------------------------------------------------------------------
rem 27.08.2002 MaW       Ok for Oracle9i R2
rem 30.08.2002 FaR       getestet/angepasst f�r 9.2
rem 10.09.2003 AnK       OK for 10.1
rem 30.11.2008 ChA       Fixed header
rem 30.11.2008 ChA       OK for 11g
rem ---------------------------------------------------------------------------

create or replace view tvd_synonyms 
as
select  m.owner, m.SYNONYM_NAME, m.TABLE_OWNER object_owner, 
        m.table_name object_name, 
        nvl(m.object_type,m.pub_syn) object_type
from ( select s.owner, s.SYNONYM_NAME, s.TABLE_OWNER, s.table_name,
        decode(o.object_type ,
                'SYNONYM','PRIVATE SYNONYM',
                o.object_type) object_type,
        decode(o1.object_type,
                'SYNONYM','PUBLIC SYNONYM',
                null,'n/a',
                o1.object_type) pub_syn
        from dba_objects o , dba_synonyms s , dba_objects o1
        where o.owner(+)=s.table_owner
        and o.object_name(+)=s.table_name
        and o.object_type(+) not in ('QUEUE','PACKAGE BODY')
        and o1.object_name(+)=s.table_name
        and o1.object_type(+) ='SYNONYM'
        and o1.owner(+) ='PUBLIC' ) m ;

drop public synonym tvd_synonyms;
create public synonym tvd_synonyms for sys.tvd_synonyms;
grant select on tvd_synonyms to select_catalog_role;

prompt 
prompt The view tvd_synonyms has been created
prompt

