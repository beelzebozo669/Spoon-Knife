rem ---------------------------------------------------------------------------
rem  Trivadis AG, Baden-D�ttwil/Basel/Bern/Lausanne/Z�rich
rem               D�sseldorf/Frankfurt/Freiburg i.Br./Hamburg/M�nchen/Stuttgart
rem               Wien
rem               Switzerland/Germany/Austria Internet: http://www.trivadis.com
rem ---------------------------------------------------------------------------
rem $Id: ssprv.sql 83 2008-11-30 15:16:20Z cha $
rem ---------------------------------------------------------------------------
rem  Group/Privileges.: SYSDBA
rem  Script Name......: ssprv.sql
rem  Developer........: Andri Kisseleff (AnK)
rem  Date.............: 21.07.1994
rem  Version..........: Oracle Database 11g
rem  Description......: Show privileges of any user
rem  Usage............: 
rem  Input parameters.: 
rem  Output...........: 
rem  Called by........:
rem  Requirements.....: 
rem  Remarks..........: 
rem
rem ---------------------------------------------------------------------------
rem Changes:
rem DD.MM.YYYY Developer Change
rem ---------------------------------------------------------------------------
rem 02.08.1997 AnK       Oracle8
rem 20.04.1999 AnK       OK for Oracle8i
rem 30.10.2001 AnK       Work-arround for problem with 0 = SELECT COUNT('x') implemented
rem 28.08.2002 MaW       OK for Oracle9i R2
rem 30.08.2002 FaR       getestet/angepasst f�r 9.2
rem 09.09.2003 AnK       added roles granted to public (only the roles, not
rem                      their privs. incl. privs it would be too much...)
rem 09.09.2003           OK for 10.1
rem 03.04.2005 FaR       Group by entfernt
rem 30.11.2008 ChA       X$KZDOS_DBA no loger required +
rem                      Renamed (sdprv.sql -> ssprv.sql) +  
rem                      Fixed header
rem 30.11.2008 ChA       OK for 11g
rem ---------------------------------------------------------------------------

CLEAR BREAKS
COLUMN NAMEVAR NOPRINT NEW_VALUE NAMEVAR
COLUMN DATUM NOPRINT NEW_VALUE DATEVAR
SET PAUSE OFF TIMING OFF VERIFY OFF ECHO OFF TERMOUT ON
ACCEPT grantee PROMPT "Username (no wildcards)...: "
SET TERMOUT OFF 
	SELECT NAME NAMEVAR,
               TO_CHAR(SYSDATE,'DD.MM.YYYY HH24:MI') DATUM
	FROM   SYS.USER$
        WHERE  NAME=UPPER('&grantee')
/
SET TERMOUT ON
SPOOL sdprv.lis
ACCEPT DUMMY prompt '<<<RETURN>>> for all Roles...'
TTITLE LEFT "All roles of the user" -
       RIGHT NAMEVAR SKIP RIGHT DATEVAR
	SELECT 	'Direct grant to user...' GRANTED, GRANTED_ROLE, DEFAULT_ROLE, ADMIN_OPTION
	FROM 	DBA_ROLE_PRIVS
        WHERE   GRANTEE=upper('&grantee')
         UNION
        SELECT 	'Grant to Public........' GRANTED, GRANTED_ROLE, DEFAULT_ROLE, ADMIN_OPTION
	FROM 	DBA_ROLE_PRIVS
        WHERE   GRANTEE=upper('PUBLIC')
	ORDER BY 1,2
/
ACCEPT DUMMY prompt '<<<RETURN>>> for Sub-Rolles...'
TTITLE LEFT "Sub-Roles of the User" -
       RIGHT NAMEVAR SKIP RIGHT DATEVAR
        SELECT U1.NAME ROLE,U2.NAME "SUB-ROLE"
        FROM  SYS.USER$ U1, SYS.USER$ U2, SYS.SYSAUTH$ SA
        WHERE GRANTEE# IN
           (SELECT DISTINCT(PRIVILEGE#)
            FROM SYS.SYSAUTH$ SA
            WHERE PRIVILEGE# > 0
            CONNECT BY PRIOR SA.PRIVILEGE# = SA.GRANTEE#
            START WITH GRANTEE#=(SELECT USER#
                                 FROM SYS.USER$
                                 WHERE NAME=UPPER('&grantee'))
                         OR GRANTEE#=1 OR GRANTEE# IN
              (SELECT KZDOSROL FROM SYS.X$KZDOS))
           AND U1.USER#=SA.GRANTEE# AND U2.USER#=SA.PRIVILEGE#
        GROUP BY U1.NAME,U2.NAME
        UNION
        select 
          'No Sub-Roles',''
        FROM  DUAL
        WHERE	to_number(0) = ( SELECT COUNT(*)
        FROM  SYS.USER$ U1, SYS.USER$ U2, SYS.SYSAUTH$ SA
        WHERE GRANTEE# IN
           (SELECT DISTINCT(PRIVILEGE#)
            FROM SYS.SYSAUTH$ SA
            WHERE PRIVILEGE# > 0
            CONNECT BY PRIOR SA.PRIVILEGE# = SA.GRANTEE#
            START WITH GRANTEE#=(SELECT USER#
                                 FROM SYS.USER$
                                 WHERE NAME=UPPER('&grantee'))
                         OR GRANTEE#=1 OR GRANTEE# IN
              (SELECT KZDOSROL FROM SYS.X$KZDOS))
           AND U1.USER#=SA.GRANTEE# AND U2.USER#=SA.PRIVILEGE#)
/
ACCEPT DUMMY prompt '<<<RETURN>>> for System-Privileges...'
SET PAGES 66 PAUSE ON PAUSE <<<RETURN>>>
BREAK ON ROLE SKIP 1
TTITLE LEFT "System-Privileges (roles and directly)" -
       RIGHT NAMEVAR SKIP RIGHT DATEVAR
        SELECT U.NAME ROLE,SPM.NAME PRIVILEGE,
               DECODE(MIN(OPTION$),1,'YES','NO') ADM
        FROM  SYS.USER$ U, SYS.SYSTEM_PRIVILEGE_MAP SPM, SYS.SYSAUTH$ SA
        WHERE GRANTEE# IN
           (SELECT DISTINCT(PRIVILEGE#)
            FROM SYS.SYSAUTH$ SA
            WHERE PRIVILEGE# > 0
            CONNECT BY PRIOR SA.PRIVILEGE# = SA.GRANTEE#
            START WITH GRANTEE#=(SELECT USER#
                                 FROM   SYS.USER$
                                 WHERE  NAME=UPPER('&grantee'))
               OR GRANTEE#=1 OR GRANTEE# IN
              (SELECT KZDOSROL FROM SYS.X$KZDOS))
          AND U.USER#=SA.GRANTEE# AND SA.PRIVILEGE#=SPM.PRIVILEGE
        GROUP BY U.NAME, SPM.NAME
	UNION
	SELECT	'direct' ROLE, PRIVILEGE, ADMIN_OPTION
	FROM    SYS.DBA_SYS_PRIVS
        WHERE   GRANTEE = UPPER('&grantee')
	ORDER BY 1,2
/
ACCEPT DUMMY prompt '<<<RETURN>>> for Object-Privileges...'
TTITLE LEFT "Objekt-Privileges (roles and direclty)" -
       RIGHT NAMEVAR SKIP RIGHT DATEVAR
COLUMN ROLE FORMAT A25 TRUNC
COLUMN OWNER FORMAT A15 TRUNC
COLUMN OBJECT_NAME FORMAT A30 TRUNC
COLUMN PRIVILEGE FORMAT A3 TRUNC
SET PAGES 66
SET PAUSE <<<RETURN>>> PAUSE OFF
        SELECT U1.NAME ROLE,U2.NAME OWNER,O.NAME object_name,
	       TPM.NAME PRIVILEGE,
               DECODE(MAX(OA.OPTION$), 1, 'YES', 'NO') GRANTABLE
        FROM  SYS.USER$ U1,SYS.USER$ U2,SYS.TABLE_PRIVILEGE_MAP TPM,
              SYS.OBJAUTH$ OA,SYS.OBJ$ O,SYS.COL$
        WHERE GRANTEE# IN
           (SELECT DISTINCT(PRIVILEGE#)
            FROM SYS.SYSAUTH$ SA
            WHERE PRIVILEGE# > 0
            CONNECT BY PRIOR SA.PRIVILEGE# = SA.GRANTEE#
            START WITH GRANTEE#=(SELECT USER#
                                 FROM   SYS.USER$
                                 WHERE  NAME=UPPER('&grantee'))
                  OR GRANTEE#=1 OR GRANTEE# IN
              (SELECT KZDOSROL FROM SYS.X$KZDOS))
           AND U1.USER#=OA.GRANTEE# AND OA.PRIVILEGE#=TPM.PRIVILEGE
           AND OA.OBJ#=O.OBJ# AND OA.OBJ#=COL$.OBJ#(+) AND OA.COL#=COL$.COL#(+)
           AND U2.USER#=O.OWNER#
           AND COL$.COL# IS NULL
        GROUP BY U1.NAME,U2.NAME,O.NAME,COL$.NAME,TPM.NAME
	UNION
	SELECT 	'direct' ROLE, OWNER, TABLE_NAME object_name, 
		PRIVILEGE, GRANTABLE
	FROM 	SYS.DBA_TAB_PRIVS
        WHERE   GRANTEE=UPPER('&grantee')
	ORDER BY 1,2,3,4
/
ACCEPT DUMMY prompt '<<<RETURN>>> for Column-Privileges...'
TTITLE LEFT "Column-Privileges (roles and directly)" -
       RIGHT NAMEVAR SKIP RIGHT DATEVAR
COLUMN ROLE FORMAT A16 TRUNC
COLUMN OWNER FORMAT A10 TRUNC
COLUMN OBJECT_NAME FORMAT A20 TRUNC
COLUMN COLUMN_NAME FORMAT A22 TRUNC
COLUMN PRIVILEGE FORMAT A3 TRUNC
SET PAGES 66
SET PAUSE <<<RETURN>>> PAUSE OFF
        SELECT U1.NAME ROLE,U2.NAME OWNER,O.NAME object_name,
               COL$.NAME COLUMN_NAME, TPM.NAME PRIVILEGE,
               DECODE(MAX(OA.OPTION$), 1, 'YES', 'NO') GRANTABLE
        FROM  SYS.USER$ U1,SYS.USER$ U2,SYS.TABLE_PRIVILEGE_MAP TPM,
              SYS.OBJAUTH$ OA,SYS.OBJ$ O,SYS.COL$
        WHERE GRANTEE# IN
           (SELECT DISTINCT(PRIVILEGE#)
            FROM SYS.SYSAUTH$ SA
            WHERE PRIVILEGE# > 0
            CONNECT BY PRIOR SA.PRIVILEGE# = SA.GRANTEE#
            START WITH GRANTEE#=(SELECT USER#
                                 FROM   SYS.USER$
                                 WHERE  NAME=UPPER('&grantee'))
                  OR GRANTEE#=1 OR GRANTEE# IN
              (SELECT KZDOSROL FROM SYS.X$KZDOS))
           AND U1.USER#=OA.GRANTEE# AND OA.PRIVILEGE#=TPM.PRIVILEGE
           AND OA.OBJ#=O.OBJ# AND OA.OBJ#=COL$.OBJ#(+) AND OA.COL#=COL$.COL#(+)
           AND U2.USER#=O.OWNER#
           AND COL$.COL# IS NOT NULL
        GROUP BY U1.NAME,U2.NAME,O.NAME,COL$.NAME,TPM.NAME
	UNION
	SELECT 	'direct' ROLE, OWNER, TABLE_NAME object_name, COLUMN_NAME, 
		PRIVILEGE, GRANTABLE
	FROM 	SYS.DBA_COL_PRIVS
        WHERE   GRANTEE=UPPER('&grantee')
	ORDER BY 1,2,3,4
/
SPOOL OFF
CLEAR BREAKS 
COL NAMEVAR CLEAR
COL DATUM CLEAR
COL ROLE CLEAR
COL OWNER CLEAR
COL OBJECT_NAME CLEAR
COL COLUMN_NAME CLEAR
COL PRIVILEGE CLEAR
TTITLE OFF
PROMPT
PROMPT ed sdprv.lis for the listing of the privileges...
PROMPT
