rem ---------------------------------------------------------------------------
rem  Trivadis AG, Baden-D�ttwil/Basel/Bern/Lausanne/Z�rich
rem               D�sseldorf/Frankfurt/Freiburg i.Br./Hamburg/M�nchen/Stuttgart
rem               Wien
rem               Switzerland/Germany/Austria Internet: http://www.trivadis.com
rem ---------------------------------------------------------------------------
rem $Id: foenvtit.sql 25 2008-11-19 19:40:33Z cha $
rem ---------------------------------------------------------------------------
rem  Group/Privileges.: Utilities
rem  Script Name......: foenvtit.sql
rem  Developer........: Andri Kisseleff
rem  Date.............: 27.03.1996
rem  Version..........: Oracle Database 11g
rem  Description......: Display open time and current time of instance and a
rem                     title 
rem  Usage............: 
rem  Input parameters.: P1 = Title
rem  Output...........: 
rem  Called by........:
rem  Requirements.....: select priv on v$thread and global_name
rem  Remarks..........: 
rem
rem ---------------------------------------------------------------------------
rem Changes:
rem DD.MM.YYYY Developer Change
rem ---------------------------------------------------------------------------
rem 02.08.1997 ank       Oracle8
rem 20.04.1999 AnK       OK for Oracle8i
rem 27.08.2002 MaW       OK for Oracle9i R2
rem 09.09.2003 AnK       OK for 10.1
rem 19.11.2008 ChA       Fixed header + OK for 11g
rem ---------------------------------------------------------------------------

	COLUMN	TIME_RUNNING	NEW_VALUE TIME_RUNNING
	COLUMN 	GLOBAL_NAME 	NEW_VALUE GLOBAL_NAME
	SET ECHO OFF TERMOUT OFF PAUSE OFF
	SELECT 	TO_CHAR(open_time,'DD.MM.YYYY HH24:MI')||' - '|| 
		TO_CHAR(SYSDATE,'DD.MM.YYYY HH24:MI')||
                ' ('||TO_CHAR(ROUND((SYSDATE-OPEN_TIME)*24,1))||' h)'
                TIME_RUNNING
	FROM 	v$thread;
	SELECT 	global_name
	FROM 	global_name;
REM
	SET TERMOUT ON
	TTITLE  CENTER '&1' SKIP 1 -
		CENTER ''GLOBAL_NAME'' SKIP 1 -
		CENTER ''TIME_RUNNING''  SKIP 2 
	COLUMN GLOBAL_NAME CLEAR
	COLUMN TIME_RUNNING CLEAR
	UNDEFINE 1
