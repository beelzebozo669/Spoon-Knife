rem ---------------------------------------------------------------------------
rem  Trivadis AG, Baden-D�ttwil/Basel/Bern/Lausanne/Z�rich
rem               D�sseldorf/Frankfurt/Freiburg i.Br./Hamburg/M�nchen/Stuttgart
rem               Wien
rem               Switzerland/Germany/Austria Internet: http://www.trivadis.com
rem ---------------------------------------------------------------------------
rem $Id: ssseqval.sql 51 2008-11-28 11:18:50Z cha $
rem ---------------------------------------------------------------------------
rem  Group/Privileges.: SYSDBA
rem  Script Name......: ssseqval.sql
rem  Developer........: Andri Kisseleff (AnK)
rem  Date.............: 04.1997
rem  Version..........: Oracle Database 11g
rem  Description......: Shows next sequence number of any sequence (cached or not)
rem			This without incrementing the sequence with nextval
rem  Usage............: 
rem  Input parameters.: 
rem  Output...........: 
rem  Called by........:
rem  Requirements.....: 
rem  Remarks..........: 
rem
rem ---------------------------------------------------------------------------
rem Changes:
rem DD.MM.YYYY Developer Change
rem ---------------------------------------------------------------------------
rem 18.06.1996 AnK       title and new header
rem 02.08.1997 AnK 	 Oracle8
rem 21.04.1999 AnK       OK for Oracle8i
rem 04.08.2002 ThJ       OK for Oracle9i R2
rem 09.09.2003 AnK       OK for 10.1
rem 28.11.2008 ChA       Fixed header + Formatting + OK for 11g
rem ---------------------------------------------------------------------------

accept sequence_owner char prompt "Sequence Owner <%> : " default %
accept sequence_name char prompt "Sequence Name  <%> : " default %
col sequence_owner format a22 trunc
col sequence_name format a30
select sequence_owner, sequence_name, next_seq, cache 
from (select sequence_owner, sequence_name, 
       nextvalue next_seq, 'in cache' cache
      from v$_sequences
      where nextvalue is not null
       union
      select sequence_owner, sequence_name, 
       highwater next_seq, 'created NOCACHE' cache
      from v$_sequences
      where nextvalue is null
       union
      select sequence_owner, sequence_name, 
       last_number next_seq, 'not in cache' cache
      from dba_sequences s
      where not exists (select  sequence_owner, sequence_name
                        from v$_sequences v
                        where v.sequence_name = s.sequence_name
                        and   v.sequence_owner = s.sequence_owner))
where   sequence_owner like upper('&sequence_owner')
and     sequence_name like upper('&sequence_name')
order by sequence_owner, sequence_name
/
undefine sequence_owner
undefine sequence_name
col sequence_owner clear
col sequence_name clear
set verify on

