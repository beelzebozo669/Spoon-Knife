rem ---------------------------------------------------------------------------
rem  Trivadis AG, Baden-D�ttwil/Basel/Bern/Lausanne/Z�rich
rem               D�sseldorf/Frankfurt/Freiburg i.Br./Hamburg/M�nchen/Stuttgart
rem               Wien
rem               Switzerland/Germany/Austria Internet: http://www.trivadis.com
rem ---------------------------------------------------------------------------
rem $Id: sofkoind.sql 100 2008-11-30 22:37:36Z cha $
rem ---------------------------------------------------------------------------
rem  Group/Privileges.: User
rem  Script Name......: sofkoind.sql
rem  Developer........: Peter Nuding (PeN) 
rem  Date.............: 11.03.1998
rem  Version..........: Oracle Database 11g
rem  Description......: Show unindexed foreign keys of the current user
rem  Usage............: 
rem  Input parameters.: 
rem  Output...........: 
rem  Called by........:
rem  Requirements.....: 
rem  Remarks..........: 
rem
rem ---------------------------------------------------------------------------
rem Changes:
rem DD.MM.YYYY Developer Change
rem ---------------------------------------------------------------------------
rem 12.10.1998 AnK        Removed Breaks, added @@foenvtit, added Table Name in-line
rem                       Only Clear Cols which are defined in the script
rem                       Changed to linesize 80 output
rem                       Removed DECODE in Constraint-Name
rem 20.04.1999 AnK        OK for Oracle8i	
rem 03.09.2002 ThJ        OK for Oracle9i R2
rem 09.09.2003 AnK        OK for 10.1
rem 30.11.2008 ChA        Fixed header + Formatting
rem 30.11.2008 ChA        OK for 11g
rem ---------------------------------------------------------------------------

store SET temp.tmp REPLACE
SET echo off
SET verify off
SET linesize 92
SET pages 80 pause ON pause "Hit <RETURN>..."
SET PAUSE OFF

COLUMN TABLE_NAME format a30 heading "Table Name"
COLUMN CONSTRAINT_NAME format a30 heading "Constraint Name"
COLUMN COLUMN_NAME format a30 heading "1. Column"

store set temp.tmp replace
set pagesize 80
@@foenvtit 'Unindexed foreign keys'

PROMPT 
PROMPT Please enter table name. Wildcards allowed (Default: %)
PROMPT
PROMPT eg.: EMP, E% or %
PROMPT

ACCEPT vTable prompt "Tables <%>: " DEFAULT %

select c.TABLE_NAME,
       c.CONSTRAINT_NAME,
       cc.COLUMN_NAME
from   USER_CONSTRAINTS  c,
       USER_CONS_COLUMNS cc
where  c.CONSTRAINT_NAME = cc.CONSTRAINT_NAME
and    c.TABLE_NAME      = cc.TABLE_NAME
and    c.CONSTRAINT_TYPE = 'R'
and    cc.POSITION       = 1
and    c.TABLE_NAME   like nvl(upper('&vTable'),'%')
and    not exists ( select  'x'
                    from    USER_INDEXES      i,
                            USER_IND_COLUMNS  ic
                    where   i.TABLE_NAME       = c.TABLE_NAME
                    and     i.INDEX_NAME       = ic.INDEX_NAME
                    and     ic.COLUMN_NAME     = cc.COLUMN_NAME
                    and     ic.COLUMN_POSITION = cc.POSITION
                    and     ic.COLUMN_POSITION = 1
                  )
order by c.TABLE_NAME, c.CONSTRAINT_NAME;
ttitle off
column TABLE_NAME clear
column CONSTRAINT_NAME clear
column COLUMN_NAME clear
@temp.tmp


