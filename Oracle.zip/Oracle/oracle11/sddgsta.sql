rem ---------------------------------------------------------------------------
rem  Trivadis AG, Baden-D�ttwil/Basel/Bern/Lausanne/Z�rich
rem               D�sseldorf/Frankfurt/Freiburg i.Br./Hamburg/M�nchen/Stuttgart
rem               Wien
rem               Switzerland/Germany/Austria Internet: http://www.trivadis.com
rem ---------------------------------------------------------------------------
rem $Id: sddgsta.sql 79 2009-09-09 14:04:39Z gha $
rem ---------------------------------------------------------------------------
rem  Group/Privileges.: DBA
rem  Script Name......: sddgsta.sql
rem  Developer........: Daniel Rey Daniel.Rey@trivadis.com
rem  Date.............: 09.09.2009
rem  Version..........: Oracle Database 11g
rem  Description......: Display statistic for Data Guard Configuration
rem  Usage............: 
rem  Input parameters.: 
rem  Output...........: 
rem  Called by........:
rem  Requirements.....: 
rem  Remarks..........: 
rem
rem ---------------------------------------------------------------------------
rem Changes:
rem DD.MM.YYYY Developer Change
rem ---------------------------------------------------------------------------
rem ---------------------------------------------------------------------------
rem
set logsource "Dummy"
store set temp.tmp replace
clear	columns -
	breaks -
	computes 
set pagesize 100 linesize 120

@@foenvtit "Data Guard statistics"
COLUMN Database format a50 TRUNC heading "Database"

select 'Database Name    : '||d.name               ||chr(10)||
       'Database Role    : '||d.database_role      ||chr(10)||
       'DB Unique Name   : '||d.db_unique_name     ||chr(10)||
       'Open Mode        : '||d.open_mode          ||chr(10)||
       'Force Logging    : '||d.force_logging      ||chr(10)||
       '         ' ||chr(10)||
       'Instance ' ||chr(10)||
       '-------------------------------------------------' ||chr(10)||
       'Name             : '||i.instance_name      ||chr(10)||
       'Status           : '||i.status             ||chr(10)||
       'Host Name        : '||i.host_name          ||chr(10)||
       'Flashback        : '||d.flashback_on       ||chr(10)||
       '         ' ||chr(10)||
       'Dataguard Protection ' ||chr(10)||
       '-------------------------------------------------' ||chr(10)||
       'Protection Mode  : '||D.PROTECTION_MODE    ||chr(10)||
       'Protection Level : '||D.PROTECTION_LEVEL   ||chr(10)||
       '         ' ||chr(10)||
       'Fast-Start Failover ' ||chr(10)||
       '-------------------------------------------------' ||chr(10)||
       'Status           : '||D.FS_FAILOVER_STATUS            ||chr(10)||
       'Obserser Present : '||D.FS_FAILOVER_OBSERVER_PRESENT  ||chr(10)||
       'Observer Host    : '||D.FS_FAILOVER_OBSERVER_HOST     ||chr(10)||
       'Threshold Time(s): '||D.FS_FAILOVER_THRESHOLD         ||chr(10)||
       'Current target   : '||D.FS_FAILOVER_CURRENT_TARGET    ||chr(10) "Database "
from 
   v$database d,
   v$instance i
order by
   d.name, 
   i.instance_name
/

COLUMN Database clear
ttitle off
prompt
@temp.tmp

