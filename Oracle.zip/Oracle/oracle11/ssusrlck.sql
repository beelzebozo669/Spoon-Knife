rem ---------------------------------------------------------------------------
rem  Trivadis AG, Baden-D�ttwil/Basel/Bern/Lausanne/Z�rich
rem               D�sseldorf/Frankfurt/Freiburg i.Br./Hamburg/M�nchen/Stuttgart
rem               Wien
rem               Switzerland/Germany/Austria Internet: http://www.trivadis.com
rem ---------------------------------------------------------------------------
rem $Id: ssusrlck.sql 69 2008-11-29 13:24:18Z cha $
rem ---------------------------------------------------------------------------
rem  Group/Privileges.: SYSDBA
rem  Script Name......: ssusrlck.sql
rem  Developer........: Sven Vetter (SvV)
rem  Date.............: Juli 2001
rem  Version..........: Oracle Database 11g
rem  Description......: Show user locks (from package DBMS_LOCK)
rem  Usage............: 
rem  Input parameters.: 
rem  Output...........: 
rem  Called by........:
rem  Requirements.....: 
rem  Remarks..........: Column B/W = Blk  - Blocker
rem                                = Wait - Wait for a lock
rem
rem ---------------------------------------------------------------------------
rem Changes:
rem DD.MM.YYYY Developer Change
rem ---------------------------------------------------------------------------
rem 13.08.2001 AnK       Added information if User waits for an UL-Lock
rem 04.09.2002 ThJ       OK for Oracle9i R2
rem 10.09.2003 AnK       OK for 10.1
rem 29.11.2008 ChA       Fixed header
rem 29.11.2008 ChA       OK for 11g
rem ---------------------------------------------------------------------------

SET PAGES 24 LINES 100 FEED ON ECHO OFF TERMOUT ON HEAD ON
COLUMN sid        format 99999
COLUMN username   format a20
COLUMN oseruser   format a20
COLUMN duration   format 99999999
COLUMN lockname   format a20
COLUMN DATABASE   NOPRINT NEW_VALUE DATABASE
COLUMN DATUM_ZEIT NOPRINT NEW_VALUE DATUM_ZEIT

SET TERMOUT OFF ECHO OFF FEED OFF
SELECT NAME DATABASE,
 TO_CHAR(SYSDATE,'DD.MM.YYYY HH24:MI') DATUM_ZEIT
FROM V$DATABASE;
SET TERMOUT ON
TTITLE CENTER 'Current User Locks - DB: 'DATABASE' ('datum_zeit) SKIP 2

SELECT l.sid, s.username, s.osuser,a.name LockName,l.ctime duration,
 DECODE(l.lmode,0,'Wait',DECODE(l.block,0,NULL,'Blk')) "B/W"
FROM v$lock l, v$session s, sys.dbms_lock_allocated a
WHERE
 l.TYPE='UL' AND
 l.sid=s.sid AND
 l.id1=a.lockid
/
TTITLE OFF
COLUMN sid        clear
COLUMN username   clear
COLUMN oseruser   clear
COLUMN duration   clear
COLUMN lockname   clear
COLUMN DATABASE   clear
COLUMN DATUM_ZEIT clear
