rem ---------------------------------------------------------------------------
rem  Trivadis AG, Baden-D�ttwil/Basel/Bern/Lausanne/Z�rich
rem               D�sseldorf/Frankfurt/Freiburg i.Br./Hamburg/M�nchen/Stuttgart
rem               Wien
rem               Switzerland/Germany/Austria Internet: http://www.trivadis.com
rem ---------------------------------------------------------------------------
rem $Id: sdsyn.sql 127 2009-01-29 12:33:32Z cha $
rem ---------------------------------------------------------------------------
rem  Group/Privileges.: DBA
rem  Script Name......: sdsyn.sql
rem  Developer........: Ingo Frost (InF)
rem  Date.............: 01.10.2001
rem  Version..........: Oracle Database 11g
rem  Description......: Show information about synonyms
rem  Usage............: 
rem  Input parameters.: 
rem  Output...........: 
rem  Called by........:
rem  Requirements.....: 
rem  Remarks..........: cssyn.sql must have been run before as to 
rem                     create the required view
rem
rem ---------------------------------------------------------------------------
rem Changes:
rem DD.MM.YYYY Developer Change
rem ---------------------------------------------------------------------------
rem 27.08.2002 MaW       Ok for Oracle9i R2
rem 30.08.2002 FaR       getestet/angepasst f�r 9.2
rem 09.09.2003 AnK       OK for 10.1
rem 25.04.2004 MnB       performance: added "rule" hint!
rem 30.11.2008 ChA       Fixed header + Formatting
rem 30.11.2008 ChA       OK for 11g
rem 29.01.2008 ChA       Removed comment about hint "rule"
rem ---------------------------------------------------------------------------

set echo off
set verify off
set logsource "Dummy"
store set temp.tmp replace
clear   columns -
        breaks -
        computes
set pagesize 24 linesize 130

PROMPT
PROMPT Please enter Synonym Owner and/or Destination-Object Owner, wildcards allowed
PROMPT
PROMPT eg.: SCOTT, S% , % or PUBLIC
PROMPT
accept v_owner      char prompt "Synonym Owner <PUBLIC>    : " default "PUBLIC"
accept v_dest_owner char prompt "Destination Owner <%>     : " default "%"

@@foenvtit "Synonym Report"

col owner        format a20 heading "Synonym Owner"
col synonym_name format a30 heading "Synonym Name"
col object_owner format a20 heading "Dest-Obj Owner"
col object_name  format a30 heading "Dest-Obj Name"
col object_type  format a18 heading "Type"

select owner, synonym_name, object_owner, object_name, object_type
from tvd_synonyms
where owner like upper('&v_owner')
and object_owner like upper('&v_dest_owner')
order by 1,2,3,4 ;

ttitle off
prompt  Type "n/a": the synonym points to nowhere, and probably could be dropped 
prompt
undefine v_owner
undefine v_dest_owner
@temp.tmp
