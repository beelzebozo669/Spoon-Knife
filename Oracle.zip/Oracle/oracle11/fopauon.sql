rem ---------------------------------------------------------------------------
rem  Trivadis AG, Baden-D�ttwil/Basel/Bern/Lausanne/Z�rich
rem               D�sseldorf/Frankfurt/Freiburg i.Br./Hamburg/M�nchen/Stuttgart
rem               Wien
rem               Switzerland/Germany/Austria Internet: http://www.trivadis.com
rem ---------------------------------------------------------------------------
rem $Id: fopauon.sql 25 2008-11-19 19:40:33Z cha $
rem ---------------------------------------------------------------------------
rem  Group/Privileges.: Utilities
rem  Script Name......: fopauon.sql
rem  Developer........: Andri Kisseleff
rem  Date.............: 18.02.1996
rem  Version..........: Oracle Database 11g
rem  Description......: 
rem  Usage............: 
rem  Input parameters.: 
rem  Output...........: 
rem  Called by........:
rem  Requirements.....: 
rem  Remarks..........: 
rem
rem ---------------------------------------------------------------------------
rem Changes:
rem DD.MM.YYYY Developer Change
rem ---------------------------------------------------------------------------
rem 02.08.1997 AnK       Oracle8 
rem 20.04.1999 AnK       OK for Oracle8i
rem 04.09.2002 ThJ       OK for Oracle9i R2
rem 09.09.2003 AnK       OK for 10.1
rem 19.11.2008 ChA       Fixed header + OK for 11g
rem ---------------------------------------------------------------------------

set pages 24 pause on pause "Hit <RETURN>..."


