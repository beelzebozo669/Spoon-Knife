rem ---------------------------------------------------------------------------
rem  Trivadis AG, Baden-D�ttwil/Basel/Bern/Lausanne/Z�rich
rem               D�sseldorf/Frankfurt/Freiburg i.Br./Hamburg/M�nchen/Stuttgart
rem               Wien
rem               Switzerland/Germany/Austria Internet: http://www.trivadis.com
rem ---------------------------------------------------------------------------
rem $Id: ssinipar.sql 25 2008-11-19 19:40:33Z cha $
rem ---------------------------------------------------------------------------
rem  Group/Privileges.: SYSDBA
rem  Script Name......: ssinipar.sql
rem  Developer........: Andri Kisseleff
rem  Date.............: July 1996
rem  Version..........: Oracle Database 11g
rem  Description......: Show Instance and Session Values of Parameters
rem  Usage............: 
rem  Input parameters.: 
rem  Output...........: 
rem  Called by........:
rem  Requirements.....: 
rem  Remarks..........: 
rem
rem ---------------------------------------------------------------------------
rem Changes:
rem DD.MM.YYYY Developer Change
rem ---------------------------------------------------------------------------
rem 02.08.1997 AnK       Oracle8 + added SESSION Modifiable + INSTANCE Mod.
rem                      Session Value only shown if modifyable
rem 21.04.1999 AnK       OK for Oracle8i
rem 27.08.2002 ChA       OK for Oracle9i R2
rem 30.08.2002 FaR       getestet/angepasst f�r 9.2
rem 20.11.2003 AnK       Enhanced display (Wrap, etc.)
rem 09.09.2003 AnK       OK for 10.1
rem 19.11.2008 ChA       Fixed header + OK for 11g + formatting of output
rem ---------------------------------------------------------------------------

set logsource "dummy"
store set temp.tmp replace
set pages 100 lines 100 verify off recsep off
col "Parameter" format a46 wrap
col "Session" format a20 wrap
col "Instance" format a20 wrap
col "S-Mod" format a5 trunc
col "I-Mod" format a5 trunc
@@foenvtit "INIT.ORA Parameter"
  select  a.ksppinm  "Parameter",
  decode(p.isses_modifiable,'FALSE',NULL,NULL,NULL,b.ksppstvl) "Session",
  c.ksppstvl "Instance",
  p.isses_modifiable "S-Mod",
  p.issys_modifiable "I-Mod"
     from x$ksppi a, x$ksppcv b, x$ksppsv c, v$parameter p
    where a.indx = b.indx and a.indx = c.indx
      and p.name(+) = a.ksppinm
      and upper(a.ksppinm) like upper('%&Parameter%')
  order by a.ksppinm
/
ttitle off
col "Parameter" clear
col "Session" clear
col "Instance" clear
col "S-Mod" clear
col "I-Mod" clear
undefine parameter
@temp.tmp

