rem ---------------------------------------------------------------------------
rem  Trivadis AG, Baden-D�ttwil/Basel/Bern/Lausanne/Z�rich
rem               D�sseldorf/Frankfurt/Freiburg i.Br./Hamburg/M�nchen/Stuttgart
rem               Wien
rem               Switzerland/Germany/Austria Internet: http://www.trivadis.com
rem ---------------------------------------------------------------------------
rem $Id: sdpkfk.sql 90 2008-11-30 19:01:31Z cha $
rem ---------------------------------------------------------------------------
rem  Group/Privileges.: DBA
rem  Script Name......: sdpkfk.sql
rem  Developer........: Andri Kisseleff (AnK)
rem  Date.............: 11.06.1995
rem  Version..........: Oracle Database 11g
rem  Description......: Show all FK of a given PK or vice verca
rem  Usage............: 
rem  Input parameters.: 
rem  Output...........: 
rem  Called by........:
rem  Requirements.....: 
rem  Remarks..........: Enter either a PK table *or* a FK table
rem
rem ---------------------------------------------------------------------------
rem Changes:
rem DD.MM.YYYY Developer Change
rem ---------------------------------------------------------------------------
rem 20.04.1999 AnK       OK for Oracle8i
rem 03.09.2002 ThJ       OK for Oracle9i R2
rem 15.09.2003 AnK       OK for 10.1 (excluded tables in the recycle bin)
rem 25.04.2004 MnB       Name of objects in recycle bin is 'BIN$%' (instead of
rem                      'RB$%' in 10g beta)
rem 30.11.2008 ChA       Fixed header
rem 30.11.2008 ChA       OK for 11g
rem ---------------------------------------------------------------------------

accept pk_owner char prompt "Owner of PK or Wildcard <%> : "
accept pk_table char prompt "Table of PK or Wildcard <%> : "
accept fk_owner char prompt "Owner of FK or Wildcard <%> : "
accept fk_table char prompt "Table of FK or Wildcard <%> : "
@@foenvtit "PK-FK Relationships"
col pk_owner format a10 trunc heading "PK Owner"
col fk_owner format a10 trunc heading "FK Owner"
col pk_table format a28 trunc heading "PK Table"
col fk_table format a28 trunc heading "FK Table"
col pk_col   format a30 trunc heading "PK Columns"
col pos      format 999       heading "Pos"
break on pk_owner skip 1 on pk_table skip 1 on fk_owner skip 1 on fk_table skip 1
set lines 116 pages 10000 head on feed on echo off termout on verify off
spool sdpkfk.lis
select distinct P.OWNER pk_owner, P.TABLE_NAME pk_table,
       F.OWNER fk_owner, F.TABLE_NAME fk_table,
       PC.POSITION pos,
       PC.COLUMN_NAME pk_col 
from   SYS.DBA_CONSTRAINTS P,
       SYS.DBA_CONSTRAINTS F,
       SYS.DBA_CONS_COLUMNS PC,
       SYS.DBA_CONS_COLUMNS FC
where  P.CONSTRAINT_NAME = F.R_CONSTRAINT_NAME
and    P.OWNER = F.R_OWNER
and    P.CONSTRAINT_TYPE = 'P'
and    F.CONSTRAINT_TYPE = 'R'
and    P.CONSTRAINT_NAME = PC.CONSTRAINT_NAME
and    F.CONSTRAINT_NAME = FC.CONSTRAINT_NAME
and    P.TABLE_NAME = PC.TABLE_NAME
and    F.TABLE_NAME = FC.TABLE_NAME
and    P.OWNER = PC.OWNER 
and    F.OWNER = FC.OWNER
and    P.OWNER like upper(nvl('&pk_owner','%'))
and    F.OWNER like upper(nvl('&fk_owner','%'))
and    P.TABLE_NAME like upper(nvl('&pk_table','%'))
and    F.TABLE_NAME like upper(nvl('&fk_table','%'))
and    P.TABLE_NAME NOT LIKE 'BIN$%' -- recycle bin
and    F.TABLE_NAME NOT LIKE 'BIN$%' -- recycle bin
order by P.OWNER, P.TABLE_NAME, F.OWNER, F.TABLE_NAME, PC.POSITION
/
spool off
ttitle off
col pk_owner clear
col fk_owner clear
col pk_table clear
col fk_table clear
col pk_col clear
col pos clear
set lines 80 pages 24 verify on
prompt
prompt sdpkfk.lis has been spooled...
prompt
rem
