rem ---------------------------------------------------------------------------
rem  Trivadis AG, Baden-D�ttwil/Basel/Bern/Lausanne/Z�rich
rem               D�sseldorf/Frankfurt/Freiburg i.Br./Hamburg/M�nchen/Stuttgart
rem               Wien
rem               Switzerland/Germany/Austria Internet: http://www.trivadis.com
rem ---------------------------------------------------------------------------
rem $Id: lstsres.sql 67 2008-11-29 10:39:11Z cha $
rem ---------------------------------------------------------------------------
rem  Group/Privileges.: SYSDBA
rem  Script Name......: lstsres.sql
rem  Developer........: Martin Bracher (MnB)
rem  Date.............: 16.02.2003
rem  Version..........: Oracle Database 11g
rem  Description......: Show minimal size in KB for shrinking a datafile
rem  Usage............: 
rem  Input parameters.: 
rem  Output...........: 
rem  Called by........:
rem  Requirements.....: 
rem  Remarks..........: 
rem
rem ---------------------------------------------------------------------------
rem Changes:
rem DD.MM.YYYY Developer Change
rem ---------------------------------------------------------------------------
rem 16.02.2003 MnB       initial version
rem 10.08.2003 MnB       Correction: when file# <> relfile#, no result
rem 12.08.2003 MnB       New Version with correct file ID
rem 09.09.2003 AnK       OK for 10.1
rem 25.04.2004 MnB       Handling of locally managed bigfile tablespaces
rem 16.08.2005 MnB       dba_lmt_used_extents hides objects in recycle-bin
rem                      --> using x$ktfbue
rem 29.11.2008 ChA       Fixed header + Formatting
rem 29.11.2008 ChA       OK for 11g
rem ---------------------------------------------------------------------------

set logsource "dummy"
store set temp.tmp replace
set pages 1000 lines 120
column tablespace format a30 heading "Tablespace"
column file_name  format a55 word_wrap heading "Filename"
column actual     format a14 heading "Actual KB"
column shrink_to  format a14 heading "Shrink KB"
@@foenvtit "Resize of datafiles"
spool lstsres.lis

select tablespace_name tablespace
     , file_name 
     , decode(actual_size,-1,'n/a (offline)',to_char(actual_size,'9,999,999,999')) actual
     , decode(shrink_to,-1,'n/a',null,'cannot shrink',actual_size,'cannot shrink', to_char(shrink_to,'9,999,999,999')) shrink_to
from (
 select -- locally managed files that can be resized (last used block < last free block)
        d.tablespace_name
      , d.file_id 
      , d.file_name
      , d.bytes/1024 actual_size --MB
      , nvl((m.maxblock-1)*t.blocksize/1024, (64*1024+t.bitmapped*t.blocksize)/1024) shrink_to
   from dba_data_files d
      , sys.ts$ t
      , (select u.ktfbuefno file_id, max(u.ktfbuebno /*block*/ +u.ktfbueblks /*length*/) maxblock --last used block +1
         from sys.x$ktfbue u group by u.ktfbuefno ) m --dba_lmt_used_extents hides objects in recycle-bin
   where m.file_id(+)=d.file_id 
     and d.tablespace_name =t.name
     and t.bitmapped > 0
     and d.bytes is not null --online
     and bitand(t.flags,256) != 256
 union all -- bigfile TBS
 select -- locally managed files that can be resized (last used block < last free block)
        d.tablespace_name
      , d.file_id 
      , d.file_name
      , d.bytes/1024 actual_size --MB
      , nvl((m.maxblock-1)*t.blocksize/1024, (64*1024+t.bitmapped*t.blocksize)/1024) shrink_to
   from dba_data_files d
      , sys.ts$ t
      , (select u.tablespace_id file_id, max(u.block+u.length) maxblock --last used block +1
         from dba_lmt_used_extents u group by tablespace_id ) m
   where m.file_id(+)=t.TS#
     and d.tablespace_name =t.name
     and t.bitmapped > 0
     and d.bytes is not null --online
     and bitand(t.flags,256) = 256
 union  -- Offline LMT (Offline DMT info is still available in datadict.)
 select d.tablespace_name, d.file_id, d.file_name, -1, -1  /* -1 => n/a, null => cannot be resized */
   from dba_data_files d 
   where bytes is null  -- Offline LMT: Size is unknown
 union -- dictionary managed (online + offline)
 select ts.name, a.file#, df.name, ts.blocksize*f.blocks/1024
      , case when nvl(min(a.bl-1),f.blocks) > 2  --nvl: no free space
             then nvl(min(a.bl-1),f.blocks)*(ts.blocksize)/1024
             else 2*(ts.blocksize)/1024 end
   from (select f.ts#, f.file#, block# bl
         from sys.fet$ f 
         start with block#=(select d.blocks-f.length+1 m from sys.file$ d where f.file#=d.relfile#)
           --end of free space area = end of datafile
         connect by prior block#=length+block#  --if area before is also free space
         ) a
       , v$dbfile df
       , sys.file$ f 
       , sys.ts$ ts 
   where f.relfile# = a.file# (+) -- a no rows -> no free space
     and f.ts# = ts.ts#
     and f.file# = df.file#
     and ts.bitmapped=0 --0=dictionary managed, else=locally managed
   group by ts.name, a.file#, df.name, f.blocks , ts.blocksize
)
order by tablespace_name, file_name
;

spool off
@temp.tmp
column tablespace clear
column file_name  clear
column actual     clear
column shrink_to  clear
ttitle off
prompt
prompt lstsres.lis has been spooled...
prompt
