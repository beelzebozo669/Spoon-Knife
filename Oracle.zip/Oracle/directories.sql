SET LINESIZE 150
SET PAGESIZE 30

COLUMN owner          FORMAT A20    HEADING "Owner"
COLUMN directory_name FORMAT A25    HEADING "Directory Name"
COLUMN directory_path FORMAT A80    HEADING "Directory Path"
COLUMN origin_con_id  FORMAT 999999 HEADING "Origin|Con Id"

  SELECT *
    FROM dba_directories
ORDER BY owner, directory_name;

  SELECT directory_path
    FROM dba_directories
   WHERE UPPER(directory_name) = '&OBJ';

  SELECT owner, table_name, grantor, privilege, grantee, grantable, hierarchy, common, type
    FROM dba_tab_privs
   WHERE table_name IN (
                        SELECT directory_name 
                          FROM dba_directories
                       )
ORDER BY owner, table_name, grantor, privilege;


  SELECT 'Grant ' || privilege || ' on directory ' || owner || '.' || table_name || ' to ' || grantee 
    FROM dba_tab_privs 
   WHERE table_name IN (
                          SELECT directory_name
                            FROM dba_directories
                       )
     AND privilege = 'EXECUTE'
ORDER BY owner, table_name;

COLUMN name  FORMAT A30 HEADING "Directory Name"
COLUMN path  FORMAT A60 HEADING "Directory Path"
COLUMN read  FORMAT A5  HEADING "Read"
COLUMN write FORMAT A5  HEADING "Write"

  SELECT *
    FROM datapump_dir_objs;

					   
					   
SET LINESIZE 200
SET PAGESIZE 30

COLUMN grantee    FORMAT A15 HEADING "Grantee"
COLUMN owner      FORMAT A15 HEADING "Owner"
COLUMN table_name FORMAT A30 HEADING "Object Name"
COLUMN grantor    FORMAT A15 HEADING "Grantor"
COLUMN privilege  FORMAT A15 HEADING "Privilege"
COLUMN grantable  FORMAT A15 HEADING "Grantable"
COLUMN hierarchy  FORMAT A15 HEADING "Hierarchy"
COLUMN common     FORMAT A15 HEADING "Common"
COLUMN type       FORMAT A15 HEADING "Type"
   
   
  SELECT owner, table_name, grantor, privilege, grantee, grantable, hierarchy, common, type
    FROM dba_tab_privs
   WHERE table_name = UPPER('&OBJ')
ORDER BY grantee, privilege;