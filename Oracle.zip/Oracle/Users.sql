Creating users
==============
find /u02 -name create_authorised_users.sh -ls 2>/dev/null

clear; cd /u02/app/oracle/admin/$ORACLE_SID/create; pwd; ls

egrep -i 'COUGHLJO|DARLILA|DOCHMARK|ERCKOZS|HAMILTGR|WHYTEDAN' create_authorised_users.sh

cp -p create_authorised_users.sh create_authorised_users.sh_old; ls -lrt create_authorised_users.*

vi create_authorised_users.sh

repeat egrep to get create command

vi /u02/app/SLC/DBA/src/lock_master.sh  -------- add users to the DEVELOPERS_LIST of authorised users CLASS_R only

cd ~/jc; clear; pwd; vi active.sql logon.sql real.sql logging.sql; sqlplus '/ as sysdba'

show user

select open_mode from v$database;

@active.sql
@logon.sql
@real.sql
@logging.sql

Add entry for user(s), copy and execute relevant lines from shell script and execute in SQL Plus.

run active.sql, logon.sql and real.sql from SQL Plus, first having inserted the user ids into the scripts. 
 IN ('GILCHRISC','LENNONST','ROSSGRA')
Email request, dba team and support desk, email user separately.
=================================================================================================
active.sql
=================================================================================================
SET LINESIZE 200
SET PAGESIZE 25

COLUMN forenames     FORMAT A30
COLUMN surname       FORMAT A30
COLUMN created_by    FORMAT A15
COLUMN class_user_id FORMAT A15

  SELECT forenames,
         surname,
         class_user_id,
         active_flag,
         created_by,
         TO_CHAR(created_date,'DD/MM/YYYY HH24:MI:SS')
    FROM class.slc_employees
   WHERE class_user_id IN ('DHIMANKO')
ORDER BY class_user_id
/

SET LINESIZE 80
SET PAGESIZE 20

CLEAR COLUMNS

=================================================================================================
logon.sql
=================================================================================================
SET LINES 132
SET PAGESIZE 25

COLUMN username FORMAT A30

  SELECT username, to_char(max(timestamp),'DD/MM/YYYY HH24:MI:SS') LOGIN
    FROM logon_audit
   WHERE username IN ('DHIMANKO')
GROUP BY username
ORDER BY username;

SET LINESIZE 80
SET PAGESIZE 20

CLEAR COLUMNS

=================================================================================================
real.sql
=================================================================================================
SET LINESIZE 200
SET PAGESIZE 25

COLUMN username FORMAT A30

  SELECT username,
         account_status,
         TO_CHAR(lock_date,'DD/MM/YYYY HH24:MI:SS'),
         TO_CHAR(expiry_date,'DD/MM/YYYY HH24:MI:SS'),
         TO_CHAR(created,'DD/MM/YYYY HH24:MI:SS')
    FROM dba_users
   WHERE username IN ('DHIMANKO')
ORDER BY username
/

SET LINESIZE 80
SET PAGESIZE 20

CLEAR COLUMNS