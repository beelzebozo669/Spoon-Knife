---Create new UNDO tablespace
---Summary
---If you want to create a new UNDO tablespace or move datafiles of UNDO tablespace to other filesystems the solution is to:
---Create a new UNDO tablespace (put the datafiles where you want), set it as default UNDO tablespace, change init parameter and drop the OLD UNDO tablespace.

---How to
---Query database to determine if spfile is in use
SET LINESIZE 80
SET PAGESIZE 10

CLEAR COLUMNS
CLEAR COMPUTES
CLEAR SCREEN

COLUMN ift FORMAT A14 HEADING "Init File Type"
COLUMN dv  FORMAT A60 HEADING "Init File Location and Name"

SET TERMOUT OFF

ALTER SESSION SET NLS_DATE_FORMAT = 'DD/MM/YYYY HH24:MI';

SET TERMOUT ON

REPHEADER LEFT   'Report Date: '              _DATE -
          RIGHT  'Page: ' FORMAT 999 SQL.PNO SKIP 2 -
          CENTER 'Init File Type Report'     SKIP 2

  SELECT DECODE(value, NULL, 'PFILE', 'SPFILE') ift,
         display_value dv
    FROM sys.v_$parameter
   WHERE name = 'spfile';

CLEAR COLUMNS
CLEAR COMPUTES

REPHEADER OFF
REPFOOTER OFF

SET LINESIZE 80
SET PAGESIZE 25

or

show parameter spfile;

---Query database to determine current UNDO tablespace information
SET LINESIZE 120
SET PAGESIZE 10

CLEAR COLUMNS
CLEAR COMPUTES
CLEAR SCREEN

COLUMN stat  FORMAT A15          HEADING "Status"
COLUMN tsn   FORMAT A30          HEADING "Tablespace Name"
COLUMN fn    FORMAT A50          HEADING "Path and File Name"
COLUMN fsize FORMAT 999999999999 HEADING "File Size (Mb)"

SET TERMOUT OFF

ALTER SESSION SET NLS_DATE_FORMAT = 'DD/MM/YYYY HH24:MI';

SET TERMOUT ON

REPHEADER LEFT   'Report Date: '              _DATE -
          RIGHT  'Page: ' FORMAT 999 SQL.PNO SKIP 2 -
          CENTER 'Undo Tablespace Report'    SKIP 2

  SELECT dts.status stat, ddf.tablespace_name tsn, ddf.file_name fn, ddf.bytes/1024/1024 fsize
    FROM dba_tablespaces dts,
         dba_data_files ddf
   WHERE dts.contents = 'UNDO'
     AND dts.tablespace_name = ddf.tablespace_name;

CLEAR COLUMNS
CLEAR COMPUTES

REPHEADER OFF
REPFOOTER OFF

SET LINESIZE 80
SET PAGESIZE 25

---Create a new UNDO tablespace
---Check the OS to ensure there is enough disk space to accommodate the new UNDO tablespace file
SET LINESIZE 120
SET PAGESIZE 10

CLEAR COLUMNS
CLEAR COMPUTES
CLEAR SCREEN

SET TERMOUT OFF

ALTER SESSION SET NLS_DATE_FORMAT = 'DD/MM/YYYY HH24:MI';

SET TERMOUT ON

COLUMN statement FORMAT A110 HEADING "Run the statement listed below to create the new UNDO tablespace"

REPHEADER LEFT   'Report Date: '              _DATE -
          RIGHT  'Page: ' FORMAT 999 SQL.PNO SKIP 2 -
          CENTER 'Create New Undo Tablespace Report'    SKIP 2

ACCEPT tname FORMAT A30    PROMPT 'Enter the unique tablespace name           : '
ACCEPT pname FORMAT A50    PROMPT 'Enter the directory path to locate file in : '
ACCEPT fname FORMAT A30    PROMPT 'Enter the file name to be used             : '
ACCEPT fsize FORMAT 999999 PROMPT 'Enter the size for the new file in Mb      : '

  SELECT 'CREATE UNDO TABLESPACE '||UPPER('&tname')||' DATAFILE '||''''||'&pname'||'&fname'||'.dbf'||''''||' SIZE '||&fsize||'M AUTOEXTEND OFF;' statement
    FROM dual;

CLEAR COLUMNS
CLEAR COMPUTES

REPHEADER OFF
REPFOOTER OFF

SET LINESIZE 80
SET PAGESIZE 25

UNDEFINE tname
UNDEFINE pname
UNDEFINE fname
UNDEFINE fsize

Report Date: 19/03/2019 15:18                                                                                 Page:    1

                                            Create New Undo Tablespace Report

Run the statement listed below to create the new UNDO tablespace
--------------------------------------------------------------------------------------------------------------
CREATE UNDO TABLESPACE UNDOTBS999 DATAFILE '/xyz/abc/pqr/undotbs999.dbf' SIZE 1580M AUTOEXTEND OFF;

1 row selected.


---Set it as the default undo tablespace of the database

ALTER SYSTEM SET UNDO_TABLESPACE = UNDOTBS;

---Drop old undo tablespace. If uncommited transactions exists, leave it for later(after a restart maybe)

DROP TABLESPACE OLD_UNDOTBS INCLUDING CONTENTS AND DATAFILES;

---Trying to drop the current UNDO tablespace will propably get you an:

---ORA-30013: undo tablespace 'OLD_UNDOTBS' is currently in use

---You have to restart the instance to be able to drop the tablespace.
---In case you don't want to restart the database you must find the processes which are using rollback segments of the current UNDO tablespace and kill them.
---To find the sessions use the following script:

  SELECT a.sid,
         a.username,
         b.used_urec,
         b.used_ublk
    FROM v$session a,
         v$transaction b
   WHERE a.saddr = b.ses_addr
ORDER BY b.used_ublk DESC;

---Change the init parameter at spfile and memmory before restart!

ALTER SYSTEM SET undo_tablespace=UNDOTBS1 SCOPE=BOTH;
