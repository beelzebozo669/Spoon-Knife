rem     ---------------------------------------------------------------------------------------------------
rem     JVC Solutions
rem     Glasgow
rem     United Kingdom
rem     Internet: http://www.jvcsolutions.com
rem     ---------------------------------------------------------------------------------------------------
rem     Group/Privileges.:      SYSDBA
rem     Script Name......:      tbsrep.sql
rem     Developer........:      Jim Campbell (JC)
rem     Date.............:      21/01/2013
rem     Version..........:      Oracle Database 12c
rem     Description......:      Tablespace report will list the tablespaces including tablespace status, type,
rem                             counts of files, segments per tablespace and display correct tablespace sizes.
rem     Usage............:      @tbsrep
rem     Input parameters.:      None
rem     Output...........:      Spools to screen
rem     Called by........:      N/A
rem     Requirements.....:      Select on the following objects:
rem                             DBA_DATA_FILES
rem                             DBA_FREE_SPACE
rem                             DBA_SEGMENTS
rem                             DBA_TABLESPACES
rem                             DBA_TABLESPACE_USAGE_METRICS
rem                             DBA_TEMP_FILES
rem                             DBA_UNDO_EXTENTS
rem                             GV$SORT_SEGMENT
rem
rem     Remarks..........:      tbsrep.sql
rem
rem     Examples:
rem             @tbsrep
rem                                                                        Tablespace Report                                                         Page    1
rem
rem                                                                                  Allocated Size   Used Space    Free Space  Used    Max Size     Max Used
rem     Tablespace             Status                 TS Type         Files Segments      (MB)           (MB)          (MB)      %        (MB)         (%)
rem     ---------------------- ---------------------- --------------- ----- -------- -------------- -------------- ------------ ---- --------------- --------
rem     CLASS_RPT              ONLINE                 LM-SYS-ASSM         1        4      2,048.000          3.313    2,044.688    0       2,048.000        0
rem     SYSAUX                 ONLINE                 LM-SYS-ASSM         4     5060      7,120.000      4,556.938    2,563.063   64       7,120.000       64
rem                                                                            .......
rem     XXSLINDEX5M            ONLINE                 LM-SYS-MSSM         1      176     20,480.000      9,862.563   10,617.438   48      20,480.000       48
rem     TEMP                   ONLINE                 TEMP-UNI-MSSM       4        0    102,400.000         27.000  102,373.000    0     102,400.000        0
rem     UNDOTBS1               ONLINE                 UNDO-SYS-MSSM       3      112     92,160.000     48,839.188   43,320.813   53      92,160.000        0
rem                                                                   ----- -------- -------------- -------------- ------------      ---------------
rem     AVERAGE   ==========>                                             3      245     77,140.884     69,192.928    7,947.957           77,421.442
rem     TOTAL SUM ==========>                                           139    10527  3,317,058.000  2,975,295.885  341,762.135        3,329,122.000
rem
rem                                                                          SLC
rem
rem     ---------------------------------------------------------------------------------------------------
rem     Changes:
rem     Date            Who     Revision        Oracle Version                  Change
rem     ---------------------------------------------------------------------------------------------------
rem     21/01/2016      JC      v1.0            Oracle 12cR1 12.2.0.1           Initial Script
rem     03/03/2017      JC      v1.1            Oracle 12cR2 12.1.0.2.0         Format change for display
rem     ---------------------------------------------------------------------------------------------------

/*
http://www.dadbm.com/oracle-database-tablespace-report-sql-script/
The SQL will show Oracle database tablespace information.
Many Oracle DBAs and developers use GUI tools nowadays and me also, but sometimes you need to see some extras.
This SQL script will list Oracle database tablespaces including tablespace status and type, counts of files and segments per tablespace and the most important - display proper tablespace sizes.
UPDATE [Jun-2016]: the script is entirely rewritten to version 2.0
- New [2.0]: Tablespace (TS) type is extended to display UNIFORM / System Extend Management and ASSM
- New [2.0]: Display actual used space in UNDO and TEMP tablespaces (not HWM as before)
- New [2.0]: Runtime is considerably reduced
- New [2.0]: Compatible with OEM CC 12c/13c output
- Tested on Oracle database 10g, 11g, 12c
- Column: "Max Size" - maximum possible size of a tablespace as a result of Autoextention of database files
- Column: "TS Type" (Tablespace type):
-> LM/DM     - Local/Dictionary Managed
-> SYS/UNI   - SYStem/UNIform Extent Management (LM only)
-> ASSM/MSSM - Automatic/Manual Segment Space Management (ASSM -> LM only)
*/

CLEAR COLUMNS
CLEAR COMPUTES
CLEAR SCREEN

SET PAGESIZE 35
SET LINESIZE 150
SET TAB OFF

COLUMN  tablespace_name         FORMAT  A22             HEADING "Tablespace"
COLUMN  status                  FORMAT  A22             HEADING "Status"
COLUMN  ts_type                 FORMAT  A15             HEADING "TS Type"
COLUMN  segments                FORMAT  999999          HEADING "Segments"
COLUMN  files                   FORMAT  9999            HEADING "Files"
COLUMN  allocated_mb            FORMAT  9,999,990.000   HEADING "Allocated Size|(Mb)"   JUSTIFY CENTER
COLUMN  used_mb                 FORMAT  9,999,990.000   HEADING "Used Space|(Mb)"       JUSTIFY CENTER
COLUMN  Free_mb                 FORMAT  999,990.000     HEADING "Free Space|(Mb)"       JUSTIFY CENTER
COLUMN  used_pct                FORMAT  999             HEADING "Used|%"                JUSTIFY CENTER
COLUMN  max_ext_mb              FORMAT  99,999,990.000  HEADING "Max Size|(Mb)"         JUSTIFY CENTER
COLUMN  max_free_mb             FORMAT  9,999,990.000   HEADING "Max Free|(Mb)"         JUSTIFY CENTER
COLUMN  max_used_pct            FORMAT  999             HEADING "Max Used|(%)"          JUSTIFY CENTER

SET TERMOUT OFF

ALTER SESSION SET NLS_DATE_FORMAT = 'DD/MM/YYYY HH24:MI';

SET TERMOUT ON

BREAK ON REPORT

COMPUTE SUM LABEL "TOTAL SUM ==========>" AVG LABEL "AVERAGE   ==========>" OF segments files allocated_mb used_mb Free_MB max_ext_mb ON REPORT

REPHEADER LEFT   'Report Date: ' _DATE -
          RIGHT  'Page: ' FORMAT 999 SQL.PNO SKIP 2 -
          CENTER 'Tablespace Usage Report' SKIP 2
REPFOOTER SKIP 2 CENTER 'SLC'

WITH df AS (  SELECT tablespace_name, SUM(bytes) bytes, COUNT(*) cnt, DECODE(SUM(DECODE(autoextensible,'NO',0,1)), 0, 'NO', 'YES') autoext, SUM(DECODE(maxbytes,0,bytes,maxbytes)) maxbytes
                FROM dba_data_files
            GROUP BY tablespace_name
           ),
     tf AS (  SELECT tablespace_name, SUM(bytes) bytes, COUNT(*) cnt, DECODE(SUM(DECODE(autoextensible,'NO',0,1)), 0, 'NO', 'YES') autoext, SUM(DECODE(maxbytes,0,bytes,maxbytes)) maxbytes
                FROM dba_temp_files
            GROUP BY tablespace_name
           ),
     tm AS (  SELECT tablespace_name, used_percent
                FROM dba_tablespace_usage_metrics
           ),
     ts AS (  SELECT tablespace_name, COUNT(*) segcnt
                FROM dba_segments
            GROUP BY tablespace_name
           )
  -- Regular Tablespace(s)
  SELECT d.tablespace_name,
          d.status                                                      Status,
          DECODE(d.contents,'PERMANENT',DECODE(d.extent_management,'LOCAL','LM','DM'),'TEMPORARY','TEMP',d.contents)||'-'||DECODE(d.allocation_type,'UNIFORM','UNI','SYS')||'-'||DECODE(d.segment_space_management,'AUTO','ASSM','MSSM') ts_type,
          a.cnt                                                         Files,
          NVL(s.segcnt,0)                                               Segments,
          ROUND(NVL(a.bytes / 1024 / 1024, 0), 3)                       Allocated_MB,
          ROUND(NVL(a.bytes - NVL(f.bytes, 0), 0)/1024/1024,3)          Used_MB,
          ROUND(NVL(f.bytes, 0) / 1024 / 1024, 3)                       Free_MB,
          ROUND(NVL((a.bytes - NVL(f.bytes, 0)) / a.bytes * 100, 0), 2) Used_pct,
          ROUND(a.maxbytes / 1024 / 1024, 3)                            Max_ext_mb,
          ROUND(NVL(m.used_percent,0), 2)                               Max_used_pct
     FROM dba_tablespaces d,
          df a,
          tm m,
          ts s,
          (  SELECT tablespace_name, SUM(bytes) bytes
               FROM dba_free_space
           GROUP BY tablespace_name
          ) f
    WHERE d.tablespace_name = a.tablespace_name(+)
      AND d.tablespace_name = f.tablespace_name(+)
      AND d.tablespace_name = m.tablespace_name(+)
      AND d.tablespace_name = s.tablespace_name(+)
      AND NOT d.contents    = 'UNDO'
      AND NOT ( d.extent_management = 'LOCAL' AND d.contents = 'TEMPORARY' )
  UNION ALL
  -- Temp  Tablespace(s)
  SELECT d.tablespace_name,
         d.status,
         DECODE(d.contents,'PERMANENT',DECODE(d.extent_management,'LOCAL','LM','DM'),'TEMPORARY','TEMP',d.contents)||'-'||DECODE(d.allocation_type,'UNIFORM','UNI','SYS')||'-'||DECODE(d.segment_space_management,'AUTO','ASSM','MSSM') ts_type,
         a.cnt                                                                         Status,
         0,
         ROUND(NVL(a.bytes / 1024 / 1024, 0), 3)                                       Allocated_MB,
         ROUND(NVL(t.ub*d.block_size, 0)/1024/1024, 3)                                 Used_MB,
         ROUND((NVL(a.bytes ,0)/1024/1024 - NVL((t.ub*d.block_size), 0)/1024/1024), 3) Free_MB,
         ROUND(NVL((t.ub*d.block_size) / a.bytes * 100, 0), 2)                         Used_pct,
         ROUND(a.maxbytes / 1024 / 1024, 3)                                            Max_size_mb,
         ROUND(NVL(m.used_percent,0), 2)                                               Max_used_pct
    FROM dba_tablespaces d,
             tf a,
                 tm m,
                 (  SELECT ss.tablespace_name , SUM(ss.used_blocks) ub
                      FROM gv$sort_segment ss
          GROUP BY ss.tablespace_name
                 ) t
   WHERE d.tablespace_name   = a.tablespace_name(+)
     AND d.tablespace_name   = t.tablespace_name(+)
     AND d.tablespace_name   = m.tablespace_name(+)
     AND d.extent_management = 'LOCAL'
     AND d.contents          = 'TEMPORARY'
  UNION ALL
  -- Undo  Tablespace(s)
  SELECT d.tablespace_name,
         d.status                                              Status,
         DECODE(d.contents,'PERMANENT',DECODE(d.extent_management,'LOCAL','LM','DM'),'TEMPORARY','TEMP',d.contents)||'-'||DECODE(d.allocation_type,'UNIFORM','UNI','SYS')||'-'||DECODE(d.segment_space_management,'AUTO','ASSM','MSSM') ts_type,
         a.cnt,
         NVL(s.segcnt,0)                                       Segments,
         ROUND(NVL(a.bytes / 1024 / 1024, 0), 3)               Allocated_MB,
         ROUND(NVL(u.bytes, 0) / 1024 / 1024, 3)               Used_MB,
         ROUND(NVL(a.bytes - NVL(u.bytes, 0), 0)/1024/1024, 3) Free_MB,
         ROUND(NVL(u.bytes / a.bytes * 100, 0), 2)             Used_pct,
         ROUND(a.maxbytes / 1024 / 1024, 3)                    Max_size_mb,
         ROUND(NVL(m.used_percent,0), 2)                       Max_used_pct
    FROM dba_tablespaces d,
             df a,
                 tm m,
                 ts s,
                 (  SELECT tablespace_name, SUM(bytes) bytes
                      FROM dba_undo_extents
             WHERE status IN ('ACTIVE','UNEXPIRED')
          GROUP BY tablespace_name
                 ) u
   WHERE d.tablespace_name = a.tablespace_name(+)
     AND d.tablespace_name = u.tablespace_name(+)
     AND d.tablespace_name = m.tablespace_name(+)
     AND d.tablespace_name = s.tablespace_name(+)
     AND d.contents        = 'UNDO'
ORDER BY 3, 1
---ORDER BY 1
/

REPHEADER OFF
REPFOOTER OFF

SET LINESIZE 80
SET PAGESIZE 25

PROMPT Tablespace (TS) types:
PROMPT LM/DM     - Local/Dictionary Managed
PROMPT SYS/UNI   - SYStem/UNIform Extent Management (LM only)
PROMPT ASSM/MSSM - Automatic/Manual Segment Space Management (ASSM -> LM only)