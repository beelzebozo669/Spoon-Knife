Generating create scripts through dbms_metadata package

Execute the following to get the create script of existing database objects

SET LINESIZE 300
SET PAGESIZE 50000
SET LONG     1000000

SELECT DBMS_METADATA.GET_DDL('<object_type','<object_name>','<object owner>') FROM DUAL;

Following example to get table structure

SELECT DBMS_METADATA.GET_DDL('TABLE','EMP','SCOTT') FROM DUAL;

Following example to get index structure

SELECT DBMS_METADATA.GET_DDL('INDEX','PK_EMP','SCOTT') FROM DUAL;

Following example to get Package Specification

SELECT DBMS_METADATA.GET_DDL('PACKAGE','EMP_PKG','SCOTT') FROM DUAL;

Following example to get Package Body

SELECT DBMS_METADATA.GET_DDL('PACKAGE_BODY','EMP_PKG','SCOTT') FROM DUAL;

Get ddl for tablespace

SELECT DBMS_METADATA.GET_DDL('TABLESPACE','USERS') FROM dual;

Get the defination of the foreign key constraints.

SELECT DBMS_METADATA.GET_DEPENDENT_DDL('REF_CONSTRAINT','<table_name>','<schema>') FROM dual;

Get the System privileges grants for a schema.

SELECT DBMS_METADATA.GET_GRANTED_DDL('SYSTEM_GRANT','<schema>') FROM dual;

Get the Role grant for a schema,

SELECT DBMS_METADATA.GET_GRANTED_DDL('ROLE_GRANT','<schema>') FROM dual;

Get the object grants for a schema

SELECT DBMS_METADATA.GET_GRANTED_DDL('OBJECT_GRANT','<schema>') FROM dual;

Following query to get the create scripts of all  tables of  a particular schema

SQL> SPOOL tables.sql
SQL> SELECT 'SELECT DBMS_METADATA.GET_DDL(''TABLE'', '''||TABLE_NAME||''',''<schema>'') FROM dual;' FROM DBA_TABLES;
SQL> SPOOL OFF

======================================================================================================================
set long 1000000 longchunksize 20000 pagesize 50000 linesize 1000 feedback off verify off trimspool on
column ddl format a1000

begin
   dbms_metadata.set_transform_param (dbms_metadata.session_transform, 'SQLTERMINATOR', true);
   dbms_metadata.set_transform_param (dbms_metadata.session_transform, 'PRETTY', true);
end;
/
 
variable v_role VARCHAR2(30);

exec :v_role := upper('&1');

select dbms_metadata.get_ddl('ROLE', r.role) AS ddl
from   dba_roles r
where  r.role = :v_role
union all
select dbms_metadata.get_granted_ddl('ROLE_GRANT', rp.grantee) AS ddl
from   dba_role_privs rp
where  rp.grantee = :v_role
and    rownum = 1
union all
select dbms_metadata.get_granted_ddl('SYSTEM_GRANT', sp.grantee) AS ddl
from   dba_sys_privs sp
where  sp.grantee = :v_role
and    rownum = 1
union all
select dbms_metadata.get_granted_ddl('OBJECT_GRANT', tp.grantee) AS ddl
from   dba_tab_privs tp
where  tp.grantee = :v_role
and    rownum = 1
/

set linesize 80 pagesize 14 feedback on verify on