SET DEFINE OFF
DECLARE
    v_fileHandle            utl_file.FILE_TYPE;
    tab_columns             xml_spreadsheet.t_tab_columns;
    tab_caption             xml_spreadsheet.t_tab_caption;
    tab_conditionalFormats  xml_spreadsheet.t_tab_conditionalFormats;

	r_border 				xml_spreadsheet.t_rec_border;
	tab_border 				xml_spreadsheet.t_tab_border;
	r_font 					xml_spreadsheet.t_rec_font;
	r_background 			xml_spreadsheet.t_rec_background;
	r_alignment				xml_spreadsheet.t_rec_alignment;

	r_customStyles			xml_spreadsheet.t_rec_customStyles;
	tab_customStyles		xml_spreadsheet.t_tab_customStyles;

BEGIN
	r_customStyles.id			:= 's50';
	r_customStyles.type			:= 'Text';

	r_alignment.vertical		:= 'Top';
	r_alignment.horizontal		:= 'Right';
	r_alignment.textRotate		:= 10;
	r_customStyles.alignment	:= r_alignment;

	r_border.bPosition			:= 'Left, Right';
	r_border.bLineStyle			:= 'Double';
	r_border.bWeight				:= 2;
	r_border.bColor				:= xml_spreadsheet.c_blue;
	tab_border(1) 				:= r_border;
	r_border.bPosition			:= 'Top, Bottom';
	r_border.bLineStyle			:= 'Continuous';
	r_border.bWeight				:= 2;
	r_border.bColor				:= xml_spreadsheet.c_red;
	tab_border(2) 				:= r_border;
	r_customStyles.border		:= tab_border;

	r_font.fName				:= 'Times New Roman';
	r_font.fSize				:= 14;
	r_font.fColor				:= xml_spreadsheet.c_blue;
	r_font.fBold				:= TRUE;
	r_font.fUnderline			:= 's';
	r_font.fPosition			:= 'Subscript';
	r_customStyles.font			:= r_font;

	r_background.bColor			:= xml_spreadsheet.c_brightYellow;
	r_background.bPattern		:= xml_spreadsheet.c_bgpThinHorzStripe;
	r_background.bPatternColor	:= xml_spreadsheet.c_white;
	r_customStyles.background	:= r_background;

	tab_customStyles(1)			:= r_customStyles;

	tab_customStyles(2).id		:= 's51';
	tab_customStyles(2).protection	:= TRUE;

    tab_columns(1).cWidth       := 91;
    tab_columns(2).cWidth       := 182;
    tab_columns(3).cAutowidth   := TRUE;
    tab_columns(4).cAutowidth   := TRUE;
    -- Fill caption
    tab_caption(1).title       := 'caption left';
    -- The first two columns get a combined caption
    tab_caption(1).topTitle    := 'topCaption left';
    tab_caption(1).span        := 2;
    tab_caption(1).comment     := 'My Comment with '||CHR(10)||'linebreak';

    tab_caption(2).title       := 'caption center';

    -- the third column gets its own topCaption
    tab_caption(3).title       := 'caption right';
    tab_caption(3).topTitle    := 'topCaption right';

    -- the forth column gets no topCaption
    tab_caption(4).title       := 'caption without top caption';
    tab_caption(4).topTitle    := '';

    -- New File
    v_fileHandle   := xml_spreadsheet.createNewFile('DOC','Exceltest.xml',tab_customStyles);
    -- open first worksheet
    xml_spreadsheet.newWorksheet(
             v_fileHandle
            ,'test_1'
            ,tab_caption
            ,tab_columns
            );

    -- Write a data row
    -- Date with time
    xml_spreadsheet.writeData(v_fileHandle,SYSDATE,xml_spreadsheet.c_dateTime);
    -- simple text
    xml_spreadsheet.writeData(v_fileHandle,'Sample Text');
    -- Number with two digits
    xml_spreadsheet.writeData(v_fileHandle,100/39,xml_spreadsheet.c_number2decimal);

    -- New data row
    xml_spreadsheet.newDatarow(v_fileHandle);

    -- Date without time
    xml_spreadsheet.writeData(v_fileHandle,SYSDATE,xml_spreadsheet.c_date);
    -- Text with special characters
    xml_spreadsheet.writeData(
             v_fileHandle
            ,'another text < kjnh " ">&'
            );
    -- number as percent
    xml_spreadsheet.writeData(v_fileHandle,39/100,xml_spreadsheet.c_prozent);
    -- number as integer
    xml_spreadsheet.writeData(v_fileHandle,100/39,xml_spreadsheet.c_integer);
    -- Text with comment
    xml_spreadsheet.writeData(v_fileHandle,'Comment',xml_spreadsheet.c_textDefault,'My Comment with '||CHR(10)||'linebreak');
    -- New data row
    xml_spreadsheet.newDatarow(v_fileHandle);
    -- Formula
    xml_spreadsheet.writeData(v_fileHandle,'Summand 1 bold underlined',xml_spreadsheet.c_textBoldUnderline);
    xml_spreadsheet.writeData(v_fileHandle,-100/39,xml_spreadsheet.c_currency);
    xml_spreadsheet.writeData(v_fileHandle,'Summand 2');
    xml_spreadsheet.writeData(v_fileHandle,39/19,xml_spreadsheet.c_accounting);
    xml_spreadsheet.newDatarow(v_fileHandle);
    xml_spreadsheet.writeData(v_fileHandle,'Sum');
    xml_spreadsheet.writeData(
             v_fileHandle
            ,TO_NUMBER(NULL)
            ,xml_spreadsheet.c_number2decimal
            ,NULL
            ,'=SUM(R[-1]C,R[-1]C[2])'
            );
    --Conditional format for value in D4
    tab_conditionalFormats(1).range          := 'R4C4';
    tab_conditionalFormats(1).qualifier      := 'Greater';
    tab_conditionalFormats(1).value1         := '0';
    tab_conditionalFormats(1).value2         := NULL;
    tab_conditionalFormats(1).formatColor    := xml_spreadsheet.c_red;
    tab_conditionalFormats(1).formatEmphasis := xml_spreadsheet.c_emphasisBoldItalic;
    tab_conditionalFormats(1).formatMarkup   := xml_spreadsheet.c_markupUnderlinedD;
    tab_conditionalFormats(1).formatBgColor  := xml_spreadsheet.c_silver;

    -- close worksheet
    xml_spreadsheet.closeWorksheet(
             v_fileHandle
            ,2 -- fix first 2 rows in first worksheet when scrolling
            ,0 -- fix no columns in first worksheet when scrolling
            ,tab_caption
            ,TRUE
            ,tab_conditionalFormats
           );

    -- open second worksheet
    xml_spreadsheet.newWorksheet(
             v_fileHandle
            ,'new sheet'
    		,xml_spreadsheet.g_tab_caption
    		,xml_spreadsheet.g_tab_columns
    		,NULL
    		,NULL
    		,TRUE -- protect cells
            );

    xml_spreadsheet.writeData(v_fileHandle,'Data on second sheet');
    xml_spreadsheet.writeData(v_fileHandle,'My format','s50');
    xml_spreadsheet.writeData(v_fileHandle,'Protected','s51');
    -- close worksheet
    xml_spreadsheet.closeWorksheet(
             v_fileHandle
            ,0 -- fix no rows in second worksheet when scrolling
            ,0 -- fix no columns in second worksheet when scrolling
            );
    -- Close file
    xml_spreadsheet.closeFile(v_fileHandle);

END;
/
/*
DECLARE
    l_cursor number := dbms_sql.open_cursor;
BEGIN

    dbms_sql.parse( l_cursor,
        'SELECT   username, user_id, created ' ||
        'FROM     all_users ' ||
        'WHERE    UPPER(username) = ''RVS_FE'' ',
        dbms_sql.native );

    xml_spreadsheet.abfrage(
         p_cursor =>  l_cursor
        ,p_path => 'PFAD_REPORTS'
        ,p_sumColumns => xml_spreadsheet.t_tab_abfrage( 'N', 'Y', 'N')
        ,p_titles => xml_spreadsheet.t_tab_abfrage( 'Username', 'ID', 'Created')
        );
END;
/
DECLARE
    v_fileHandle            utl_file.FILE_TYPE;
BEGIN

    v_fileHandle := xml_spreadsheet.abfrage(
         p_query => 'SELECT   username, user_id, created ' ||
                    'FROM     all_users ' ||
                    'WHERE    UPPER(username) = ''RVS_TE'''
        ,p_path => 'PFAD_REPORTS'
        ,p_filename => 'test2.xml'
        ,p_sheetname => 'sheet1'
        ,p_sumColumns => xml_spreadsheet.t_tab_abfrage( 'N', 'Y', 'N')
        ,p_titles => xml_spreadsheet.t_tab_abfrage( 'Username', 'ID', 'Created')
        ,p_close => FALSE
        );

    xml_spreadsheet.abfrage(
         p_query => 'SELECT TO_DATE(''01.01.1899'',''dd.mm.yyyy'') d FROM dual'
        ,p_fileHandle => v_fileHandle
        ,p_sheetname => 'sheet2'
        );

END;
/
*/
