DECLARE
    --Stile f�r �berschriften
    -- zentriert, soweit nicht anders angegeben
    c_stilFettHdgRru        CONSTANT VARCHAR2 (5) := 's50'; --Fett,Hintergrund dunkelgrau, Rand rechts und unten
    c_stilFettHdgRo         CONSTANT VARCHAR2 (5) := 's51'; --Fett,Hintergrund dunkelgrau, Rand ohne
    c_stilFettHdgRoAl       CONSTANT VARCHAR2 (5) := 's51a'; --Fett,Hintergrund dunkelgrau, Rand ohne, Ausrichtung links
    c_stilFettHhgRo         CONSTANT VARCHAR2 (5) := 's52'; --Fett,Hintergrund hellgrau, Rand ohne
    c_stilFettHhgRoAl       CONSTANT VARCHAR2 (5) := 's52b'; --Fett,Hintergrund hellgrau, Rand ohne, Ausrichtung links
    c_stilFettHdgRr         CONSTANT VARCHAR2 (5) := 's53'; --Fett,Hintergrund dunkelgrau, Rand rechts
    c_stilFettHdgRu         CONSTANT VARCHAR2 (5) := 's54'; --Fett,Hintergrund dunkelgrau, Rand unten
    c_stilFettHhgRu         CONSTANT VARCHAR2 (5) := 's55'; --Fett,Hintergrund hellgrau, Rand unten

    --Stile f�r Ergebnisse
    c_stilHhgRo             CONSTANT VARCHAR2 (5) := 's56'; --Hintergrund hellgrau, Rand ohne
    c_stilHhgRr             CONSTANT VARCHAR2 (5) := 's57'; --Hintergrund hellgrau, Rand rechts
    c_stilHhgRrAr           CONSTANT VARCHAR2 (5) := 's57a'; --Hintergrund hellgrau, Rand rechts, Ausrichtung rechts
    c_stilHhgRoZahl         CONSTANT VARCHAR2 (5) := 's58'; --Hintergrund hellgrau, Rand ohne
    c_stilHhgRrZahl         CONSTANT VARCHAR2 (5) := 's59'; --Hintergrund hellgrau, Rand rechts
    c_stilHhgRoProzent      CONSTANT VARCHAR2 (5) := 's60'; --Hintergrund hellgrau, Rand ohne
    c_stilHdgRo             CONSTANT VARCHAR2 (5) := 's61'; --Hintergrund hellgrau, Rand ohne
    c_stilHdgRr             CONSTANT VARCHAR2 (5) := 's62'; --Hintergrund hellgrau, Rand rechts
    c_stilHdgRrAr           CONSTANT VARCHAR2 (5) := 's62a'; --Hintergrund hellgrau, Rand rechts, Ausrichtung rechts
    c_stilHwRoZahl          CONSTANT VARCHAR2 (5) := 's63'; --Hintergrund hellgrau, Rand ohne
    c_stilHwRrZahl          CONSTANT VARCHAR2 (5) := 's64'; --Hintergrund hellgrau, Rand rechts
    c_stilHwRoProzent       CONSTANT VARCHAR2 (5) := 's65'; --Hintergrund hellgrau, Rand ohne
    --Stile f�r Summenzeile
    c_stilFettHviRo         CONSTANT VARCHAR2 (5) := 's66'; --Hintergrund violett, Rand ohne
    c_stilFettHviRr         CONSTANT VARCHAR2 (5) := 's67'; --Hintergrund violett, Rand rechts
    c_stilFettHviRrAr       CONSTANT VARCHAR2 (5) := 's67a'; --Hintergrund violett, Rand rechts, Ausrichtung rechts
    c_stilFettHviRoZahl     CONSTANT VARCHAR2 (5) := 's68'; --Hintergrund violett, Rand ohne
    c_stilFettHviRrZahl     CONSTANT VARCHAR2 (5) := 's69'; --Hintergrund violett, Rand rechts
    c_stilFettHviRoProzent  CONSTANT VARCHAR2 (5) := 's70'; --Hintergrund violett, Rand ohne

    v_fileHandle            utl_file.FILE_TYPE;
    v_styleFlag             PLS_INTEGER;
    v_first                 BOOLEAN := TRUE;

    tab_columnsAl           xml_spreadsheet.t_tab_columns;

    tab_caption             xml_spreadsheet.t_tab_caption;
    tab_conditionalFormats  xml_spreadsheet.t_tab_conditionalFormats;

    r_customStyles          xml_spreadsheet.t_rec_customStyles;
    tab_customStyles        xml_spreadsheet.t_tab_customStyles;

    r_printSetup            xml_spreadsheet.t_rec_printSetup;
    r_autofilter            xml_spreadsheet.t_rec_autofilter;

    CURSOR cur_liste IS
        SELECT 'AB' vta_cd,'Alle' pgr_cd,1 altgrp_nr ,'0 - 30 Tage' altgrp_text,89.5 pr_sumf,7237909.28 sumf,65.9 pr_sumf00,5327048.17 sumf00,23.6 pr_sumf10,1907452.49 sumf10,0 pr_sumf02,3408.62 sumf02,19.4 pr_sumv,1417421.27 sumv FROM dual UNION ALL
        SELECT 'AB','Alle',2,'31 - 60 Tage',1.3,101537.04,0.5,43944.77,0.3,25564.16,0.4,32028.10,5.6,405828.07 FROM dual UNION ALL
        SELECT 'AB','Alle',3,'61 - 90 Tage',1.2,97481.51,0.2,15247.99,0.4,33470.75,0.6,48762.76,3.3,241315.00 FROM dual UNION ALL
        SELECT 'AB','Alle',4,'4 - 6 Monate',2.1,168732.28,0.8,61059.84,0.7,55342.83,0.6,52329.61,13.3,971554.41 FROM dual UNION ALL
        SELECT 'AB','Alle',5,'7 - 9 Monate',0.6,50328.04,0.3,23660.17,0.2,17373.95,0.1,9293.92,6.3,458325.82 FROM dual UNION ALL
        SELECT 'AB','Alle',6,'10 - 12 Monate',0.4,33750.70,0.2,18677.51,0.1,9277.43,0.1,5795.77,3.3,242583.92 FROM dual UNION ALL
        SELECT 'AB','Alle',7,'13 - 24 Monate',1.1,89924.36,0.4,30634.86,0.6,51691.49,0.1,7598.01,11.9,866694.44 FROM dual UNION ALL
        SELECT 'AB','Alle',8,'> 24 Monate',0.5,39622.06,0.2,13228.63,0.3,21022.23,0.1,5371.19,10,728883.89 FROM dual UNION ALL
        SELECT 'AB','Alle',9,'> 36 Monate',3.3,267183.40,0.9,73938.33,1,83451.09,1.4,109793.98,26.9,1960038.89 FROM dual UNION ALL
        SELECT 'AB','Alle',NULL,'Summe',100,8086468.67,69.3,5607440.27,27.3,2204646.42,3.4,274381.98,100,7292645.72 FROM dual UNION ALL
        SELECT 'AB','Mno',1,'0 - 30 Tage',29.9,50251.79,17.4,29359.60,12.2,20455.20,0.3,436.99,28.5,56182.09 FROM dual UNION ALL
        SELECT 'AB','Mno',2,'31 - 60 Tage',7.2,12122.91,1.8,2973.21,3,5131.69,2.4,4018.00,4,7937.35 FROM dual UNION ALL
        SELECT 'AB','Mno',3,'61 - 90 Tage',13.6,22876.96,0.9,1560.08,10.5,17679.67,2.2,3637.21,4.4,8733.96 FROM dual UNION ALL
        SELECT 'AB','Mno',4,'4 - 6 Monate',15,25229.15,6.4,10742.23,3,5080.42,5.6,9406.51,6.9,13589.75 FROM dual UNION ALL
        SELECT 'AB','Mno',5,'7 - 9 Monate',2.4,4087.50,0.4,682.01,1.1,1857.48,0.9,1548.01,7.8,15336.38 FROM dual UNION ALL
        SELECT 'AB','Mno',6,'10 - 12 Monate',1.3,2134.27,0,39.99,1,1727.45,0.2,366.82,4.2,8324.27 FROM dual UNION ALL
        SELECT 'AB','Mno',7,'13 - 24 Monate',8,13500.58,3.9,6551.75,1.3,2269.00,2.8,4679.83,13.4,26416.61 FROM dual UNION ALL
        SELECT 'AB','Mno',8,'> 24 Monate',3.6,6113.23,1.7,2865.19,0.3,524.38,1.6,2723.65,7.4,14583.53 FROM dual UNION ALL
        SELECT 'AB','Mno',9,'> 36 Monate',19,31941.02,3.1,5223.29,7.5,12602.53,8.4,14115.20,23.3,45941.51 FROM dual UNION ALL
        SELECT 'AB','Mno',NULL,'Summe',100,168257.40,35.7,59997.35,40,67327.83,24.3,40932.21,100,197045.44 FROM dual UNION ALL
        SELECT 'AB','Pqr',1,'0 - 30 Tage',93.9,4893420.28,65.9,3433739.34,28,1458036.48,0,1644.46,16,749972.45 FROM dual UNION ALL
        SELECT 'AB','Pqr',2,'31 - 60 Tage',0.4,22147.93,0.1,5111.56,0.1,6640.64,0.2,10395.73,5.4,254629.87 FROM dual UNION ALL
        SELECT 'AB','Pqr',3,'61 - 90 Tage',0.6,32904.28,0.1,3425.85,0.1,2756.61,0.5,26721.83,2.1,100734.76 FROM dual UNION ALL
        SELECT 'AB','Pqr',4,'4 - 6 Monate',1.4,73952.45,0.8,42972.58,0.3,16685.43,0.3,14294.44,12.9,604132.86 FROM dual UNION ALL
        SELECT 'AB','Pqr',5,'7 - 9 Monate',0.4,19973.29,0.3,13534.15,0.1,5330.49,0,1108.65,7.6,355674.54 FROM dual UNION ALL
        SELECT 'AB','Pqr',6,'10 - 12 Monate',0.1,7580.19,0,1601.13,0.1,3159.01,0.1,2820.05,3.2,150946.66 FROM dual UNION ALL
        SELECT 'AB','Pqr',7,'13 - 24 Monate',1,53406.40,0.2,7886.08,0.9,44787.34,0,732.98,11.9,557444.00 FROM dual UNION ALL
        SELECT 'AB','Pqr',8,'> 24 Monate',0.3,16679.93,0.1,4941.71,0.2,11738.22,0,0.00,7.1,334333.03 FROM dual UNION ALL
        SELECT 'AB','Pqr',9,'> 36 Monate',1.7,90033.89,0.4,21619.54,1,49750.40,0.4,18663.95,33.7,1580651.70 FROM dual UNION ALL
        SELECT 'AB','Pqr',NULL,'Summe',100,5210098.67,67.8,3534831.94,30.7,1598884.64,1.5,76382.10,100,4688519.86 FROM dual UNION ALL
        SELECT 'AB','Hij',1,'0 - 30 Tage',84.8,2102742.17,69.3,1718973.67,15.4,383153.76,0,614.74,25.6,597254.42 FROM dual UNION ALL
        SELECT 'AB','Hij',2,'31 - 60 Tage',2.4,58488.80,1.4,35251.95,0.5,13082.38,0.4,10154.46,6,138979.17 FROM dual UNION ALL
        SELECT 'AB','Hij',3,'61 - 90 Tage',1.4,35757.04,0.4,10128.81,0.5,11549.55,0.6,14078.68,5.6,129567.98 FROM dual UNION ALL
        SELECT 'AB','Hij',4,'4 - 6 Monate',2.5,63165.17,0.3,7230.48,1.1,27810.30,1.1,28124.39,14.9,346281.23 FROM dual UNION ALL
        SELECT 'AB','Hij',5,'7 - 9 Monate',0.9,23470.26,0.4,9332.45,0.4,9136.49,0.2,5001.32,3.5,82523.15 FROM dual UNION ALL
        SELECT 'AB','Hij',6,'10 - 12 Monate',0.9,21997.82,0.7,16817.32,0.1,2851.84,0.1,2328.66,3,69863.67 FROM dual UNION ALL
        SELECT 'AB','Hij',7,'13 - 24 Monate',0.8,20557.42,0.6,15686.18,0.1,2795.66,0.1,2075.58,11.9,276843.54 FROM dual UNION ALL
        SELECT 'AB','Hij',8,'> 24 Monate',0.6,14937.80,0.2,4601.63,0.3,8455.40,0.1,1880.77,16,372068.39 FROM dual UNION ALL
        SELECT 'AB','Hij',9,'> 36 Monate',5.6,139463.21,1.9,46794.38,0.7,16783.91,3.1,75884.93,13.6,315989.08 FROM dual UNION ALL
        SELECT 'AB','Hij',NULL,'Summe',100,2480579.68,75.2,1864816.86,19.2,475619.28,5.6,140143.54,100,2329370.63 FROM dual UNION ALL
        SELECT 'AB','Str',1,'0 - 30 Tage',84.2,191495.03,63.7,144975.56,20.1,45807.04,0.3,712.43,18,14012.32 FROM dual UNION ALL
        SELECT 'AB','Str',2,'31 - 60 Tage',3.9,8777.40,0.3,608.04,0.3,709.45,3.3,7459.91,5.5,4281.69 FROM dual UNION ALL
        SELECT 'AB','Str',3,'61 - 90 Tage',2.6,5943.24,0.1,133.26,0.7,1484.93,1.9,4325.05,2.9,2278.31 FROM dual UNION ALL
        SELECT 'AB','Str',4,'4 - 6 Monate',2.8,6385.50,0.1,114.56,2.5,5766.68,0.2,504.26,9.7,7550.57 FROM dual UNION ALL
        SELECT 'AB','Str',5,'7 - 9 Monate',1.2,2796.99,0,111.56,0.5,1049.49,0.7,1635.95,6.2,4791.74 FROM dual UNION ALL
        SELECT 'AB','Str',6,'10 - 12 Monate',0.9,2038.42,0.1,219.07,0.7,1539.13,0.1,280.23,17.3,13449.32 FROM dual UNION ALL
        SELECT 'AB','Str',7,'13 - 24 Monate',1.1,2459.95,0.2,510.85,0.8,1839.48,0,109.63,7.7,5990.29 FROM dual UNION ALL
        SELECT 'AB','Str',8,'> 24 Monate',0.8,1891.10,0.4,820.11,0.1,304.23,0.3,766.77,10.2,7898.94 FROM dual UNION ALL
        SELECT 'AB','Str',9,'> 36 Monate',2.5,5745.28,0.1,301.13,1.9,4314.25,0.5,1129.90,22.5,17456.61 FROM dual UNION ALL
        SELECT 'AB','Str',NULL,'Summe',100,227532.93,65,147794.13,27.6,62814.67,7.4,16924.13,100,77709.79 FROM dual UNION ALL
        SELECT 'KAB','Alle',1,'0 - 30 Tage',96.9,501256.63,96.9,501256.63,0,0.00,0,0.00,22.5,440434.13 FROM dual UNION ALL
        SELECT 'KAB','Alle',2,'31 - 60 Tage',1,5251.73,1,5210.19,0,41.54,0,0.00,5.5,107748.47 FROM dual UNION ALL
        SELECT 'KAB','Alle',3,'61 - 90 Tage',0,111.43,0,111.43,0,0.00,0,0.00,4.9,94797.11 FROM dual UNION ALL
        SELECT 'KAB','Alle',4,'4 - 6 Monate',0.5,2400.44,0.5,2400.44,0,0.00,0,0.00,9.7,188556.50 FROM dual UNION ALL
        SELECT 'KAB','Alle',5,'7 - 9 Monate',0.1,702.03,0.1,702.03,0,0.00,0,0.00,8.2,159833.08 FROM dual UNION ALL
        SELECT 'KAB','Alle',6,'10 - 12 Monate',0.1,598.01,0.1,598.01,0,0.00,0,0.00,4.7,90918.44 FROM dual UNION ALL
        SELECT 'KAB','Alle',7,'13 - 24 Monate',0.3,1407.84,0.3,1407.84,0,0.00,0,0.00,11.4,223322.76 FROM dual UNION ALL
        SELECT 'KAB','Alle',8,'> 24 Monate',0.2,1132.46,0.2,1102.46,0,30.00,0,0.00,13,253204.19 FROM dual UNION ALL
        SELECT 'KAB','Alle',9,'> 36 Monate',0.8,4231.78,0.8,4231.78,0,0.00,0,0.00,20.2,394947.00 FROM dual UNION ALL
        SELECT 'KAB','Alle',NULL,'Summe',100,517092.33,100,517020.79,0,71.54,0,0.00,100,1953761.68 FROM dual UNION ALL
        SELECT 'KAB','Pqr',1,'0 - 30 Tage',98.7,339543.89,98.7,339543.89,0,0.00,0,0.00,35.2,347198.35 FROM dual UNION ALL
        SELECT 'KAB','Pqr',2,'31 - 60 Tage',0,0.00,0,0.00,0,0.00,0,0.00,6.3,61800.62 FROM dual UNION ALL
        SELECT 'KAB','Pqr',3,'61 - 90 Tage',0,0.00,0,0.00,0,0.00,0,0.00,3.1,30338.76 FROM dual UNION ALL
        SELECT 'KAB','Pqr',4,'4 - 6 Monate',0,77.12,0,77.12,0,0.00,0,0.00,9.7,95529.86 FROM dual UNION ALL
        SELECT 'KAB','Pqr',5,'7 - 9 Monate',0.1,513.61,0.1,513.61,0,0.00,0,0.00,12.3,121849.45 FROM dual UNION ALL
        SELECT 'KAB','Pqr',6,'10 - 12 Monate',0,0.00,0,0.00,0,0.00,0,0.00,3.7,36832.91 FROM dual UNION ALL
        SELECT 'KAB','Pqr',7,'13 - 24 Monate',0.1,212.09,0.1,212.09,0,0.00,0,0.00,6.4,63051.38 FROM dual UNION ALL
        SELECT 'KAB','Pqr',8,'> 24 Monate',0.2,852.62,0.2,822.62,0,30.00,0,0.00,9.3,91770.98 FROM dual UNION ALL
        SELECT 'KAB','Pqr',9,'> 36 Monate',0.8,2764.35,0.8,2764.35,0,0.00,0,0.00,14,138403.41 FROM dual UNION ALL
        SELECT 'KAB','Pqr',NULL,'Summe',100,343963.68,100,343933.68,0,30.00,0,0.00,100,986775.73 FROM dual UNION ALL
        SELECT 'KAB','Hij',1,'0 - 30 Tage',93.4,160870.23,93.4,160870.23,0,0.00,0,0.00,9.5,89290.92 FROM dual UNION ALL
        SELECT 'KAB','Hij',2,'31 - 60 Tage',3,5251.73,3,5210.19,0,41.54,0,0.00,4.3,40301.75 FROM dual UNION ALL
        SELECT 'KAB','Hij',3,'61 - 90 Tage',0.1,111.43,0.1,111.43,0,0.00,0,0.00,6.5,61479.99 FROM dual UNION ALL
        SELECT 'KAB','Hij',4,'4 - 6 Monate',1.3,2323.32,1.3,2323.32,0,0.00,0,0.00,9.8,92152.72 FROM dual UNION ALL
        SELECT 'KAB','Hij',5,'7 - 9 Monate',0.1,188.42,0.1,188.42,0,0.00,0,0.00,4,37690.95 FROM dual UNION ALL
        SELECT 'KAB','Hij',6,'10 - 12 Monate',0.3,598.01,0.3,598.01,0,0.00,0,0.00,5.7,54017.27 FROM dual UNION ALL
        SELECT 'KAB','Hij',7,'13 - 24 Monate',0.7,1195.75,0.7,1195.75,0,0.00,0,0.00,16.6,157022.12 FROM dual UNION ALL
        SELECT 'KAB','Hij',8,'> 24 Monate',0.2,279.84,0.2,279.84,0,0.00,0,0.00,16.8,158434.50 FROM dual UNION ALL
        SELECT 'KAB','Hij',9,'> 36 Monate',0.9,1467.43,0.9,1467.43,0,0.00,0,0.00,26.8,252874.37 FROM dual UNION ALL
        SELECT 'KAB','Hij',NULL,'Summe',100,172286.15,100,172244.61,0,41.54,0,0.00,100,943264.59 FROM dual UNION ALL
        SELECT 'KAB','Str',1,'0 - 30 Tage',100,842.50,100,842.50,0,0.00,0,0.00,16.6,3944.86 FROM dual UNION ALL
        SELECT 'KAB','Str',2,'31 - 60 Tage',0,0.00,0,0.00,0,0.00,0,0.00,23.8,5646.10 FROM dual UNION ALL
        SELECT 'KAB','Str',3,'61 - 90 Tage',0,0.00,0,0.00,0,0.00,0,0.00,12.6,2978.36 FROM dual UNION ALL
        SELECT 'KAB','Str',4,'4 - 6 Monate',0,0.00,0,0.00,0,0.00,0,0.00,3.7,873.92 FROM dual UNION ALL
        SELECT 'KAB','Str',5,'7 - 9 Monate',0,0.00,0,0.00,0,0.00,0,0.00,1.2,292.69 FROM dual UNION ALL
        SELECT 'KAB','Str',6,'10 - 12 Monate',0,0.00,0,0.00,0,0.00,0,0.00,0.3,68.25 FROM dual UNION ALL
        SELECT 'KAB','Str',7,'13 - 24 Monate',0,0.00,0,0.00,0,0.00,0,0.00,13.7,3249.27 FROM dual UNION ALL
        SELECT 'KAB','Str',8,'> 24 Monate',0,0.00,0,0.00,0,0.00,0,0.00,12.6,2998.71 FROM dual UNION ALL
        SELECT 'KAB','Str',9,'> 36 Monate',0,0.00,0,0.00,0,0.00,0,0.00,15.5,3669.22 FROM dual UNION ALL
        SELECT 'KAB','Str',NULL,'Summe',100,842.50,100,842.50,0,0.00,0,0.00,100,23721.37 FROM dual;


   /**
   * PROCEDURE declarePrintSetupAltersliste:
   * setzte Drucklayout der Ausgabedatei Alterslisten
   * Seitenr�nder, Kopf- und Fu�zeile
   **/
PROCEDURE declarePrintSetupAltersliste
IS
BEGIN
      r_printSetup.landscape := TRUE;
      r_printSetup.headerLeft :=
            CHR (10)
         || xml_spreadsheet.c_mtFontBold
         || 'Altersliste - '
         || CHR (10)
         || xml_spreadsheet.c_mtFontStandard
         || 'Stichtag: '
         || '01.01.2014';
      r_printSetup.headerCenter :=
            'My Company'
         || CHR (10)
         || 'Konto: 12345678'
         || CHR (10)
         || 'Abschlusstag: '
         || '22.12.2013';
      r_printSetup.headerRight :=
            CHR (10)
         || 'System'
         || CHR (10)
         || 'erstellt am: '
         || TO_CHAR (SYSDATE, 'dd.mm.yyyy hh24:mi:ss');
      r_printSetup.headerMargin := 0.3; -- Angabe in gespeicherter Datei * 2,54

      r_printSetup.footerLeft := NULL;
      r_printSetup.footerCenter := xml_spreadsheet.c_mtName;
      r_printSetup.footerRight :=
            'Seite '
         || xml_spreadsheet.c_mtPage
         || '/'
         || xml_spreadsheet.c_mtPageTotal;
      r_printSetup.footerMargin := 0.8;

      r_printSetup.pageMarginTop := 2.5;
      r_printSetup.pageMarginBottom := 2;
      r_printSetup.pageMarginLeft := 1.1;
      r_printSetup.pageMarginRight := 1.1;

      r_printSetup.printTitle := 'R1:R4';
   END declarePrintSetupAltersliste;

   /**
   * Definition der Spalten-Breite f�r Altersliste
   **/

   PROCEDURE declareColumnsAltersliste
   IS
   BEGIN
      tab_columnsAl (1).cWidth := 35;
      tab_columnsAl (2).cWidth := 42;
      tab_columnsAl (3).cWidth := 76;
      tab_columnsAl (4).cWidth := 29;
      tab_columnsAl (5).cWidth := 76;
      tab_columnsAl (6).cWidth := 29;
      tab_columnsAl (7).cWidth := 76;
      tab_columnsAl (8).cWidth := 29;
      tab_columnsAl (9).cWidth := 76;
      tab_columnsAl (10).cWidth := 29;
      tab_columnsAl (11).cWidth := 76;
      tab_columnsAl (12).cWidth := 29;
      tab_columnsAl (13).cWidth := 87;
      tab_columnsAl (1).cAutowidth := FALSE;
      tab_columnsAl (2).cAutowidth := FALSE;
      tab_columnsAl (3).cAutowidth := FALSE;
      tab_columnsAl (4).cAutowidth := FALSE;
      tab_columnsAl (5).cAutowidth := FALSE;
      tab_columnsAl (6).cAutowidth := FALSE;
      tab_columnsAl (7).cAutowidth := FALSE;
      tab_columnsAl (8).cAutowidth := FALSE;
      tab_columnsAl (9).cAutowidth := FALSE;
      tab_columnsAl (10).cAutowidth := FALSE;
      tab_columnsAl (11).cAutowidth := FALSE;
      tab_columnsAl (12).cAutowidth := FALSE;
      tab_columnsAl (13).cAutowidth := FALSE;
   END declareColumnsAltersliste;

   /**
      * PROCEDURE declareCustomStyles
      **/

   PROCEDURE declareCustomStyles
   IS
       r_border                 xml_spreadsheet.t_rec_border;
       tab_borderO              xml_spreadsheet.t_tab_border;-- ohne Rand
       tab_borderU              xml_spreadsheet.t_tab_border;-- Rand unten
       tab_borderR              xml_spreadsheet.t_tab_border;-- Rand rechts
       tab_borderRU             xml_spreadsheet.t_tab_border;-- Rand rechts und unten
       r_fontB                  xml_spreadsheet.t_rec_font;-- Fett
       r_fontN                  xml_spreadsheet.t_rec_font;-- Normal
       r_backgroundDg           xml_spreadsheet.t_rec_background;--Dunkelgrau
       r_backgroundHg           xml_spreadsheet.t_rec_background;--Hellgrau
       r_backgroundVi           xml_spreadsheet.t_rec_background;--Violett
       r_backgroundW            xml_spreadsheet.t_rec_background;--Wei�
       r_alignmentL             xml_spreadsheet.t_rec_alignment;-- Linksb�ndig
       r_alignmentC             xml_spreadsheet.t_rec_alignment;-- Zentriert
       r_alignmentR             xml_spreadsheet.t_rec_alignment;-- Rechtsb�ndig

       i                        PLS_INTEGER := 1;

   BEGIN
      -- Vorbereiten Textausrichtung
      -- immer oben, immer mit Zeilenumbruch erlaubt
      r_alignmentC.vertical := 'Top';
      r_alignmentC.wrapText := TRUE;
      r_alignmentC.horizontal := 'Center';
      r_alignmentL := r_alignmentC;
      r_alignmentL.horizontal := 'Left';
      r_alignmentR := r_alignmentC;
      r_alignmentR.horizontal := 'Right';

      -- Vorbereiten Rahmen
      -- immer durchgehend, schwarz, Strichst�rke 1
      tab_borderO(1)    := r_border;
      r_border.bLineStyle := 'Continuous';
      r_border.bWeight  := 1;
      r_border.bColor   := '#000000';
      r_border.bPosition := 'Bottom';
      tab_borderU(1)    := r_border;
      r_border.bPosition := 'Right';
      tab_borderR(1)    := r_border;
      r_border.bPosition := 'Right,Bottom';
      tab_borderRU(1)   := r_border;

      -- Vorbereiten Hintergrund
      -- immer ausgef�llt
      r_backgroundDg.bPattern := 'Solid';
      r_backgroundDg.bColor := '#AAAAAA';
      r_backgroundHg.bPattern := 'Solid';
      r_backgroundHg.bColor := '#C8C8C8';
      r_backgroundVi.bPattern := 'Solid';
      r_backgroundVi.bColor := '#D9A4AF';
      r_backgroundW.bPattern := 'Solid';
      r_backgroundW.bColor := xml_spreadsheet.c_white;

      -- Vorbereiten Schriften
      r_fontB.fName := 'Calibri';
      r_fontB.fSize := 11;
      r_fontB.fBold := TRUE;
      r_fontN       := r_fontB;
      r_fontN.fBold := FALSE;

      --dunkelgrau fett Rand rechts und unten
      r_customStyles.id := c_stilFettHdgRru;
      r_customStyles.TYPE := 'Text';
      r_customStyles.format := NULL;
      r_customStyles.alignment := r_alignmentC;
      r_customStyles.border := tab_borderRU;
      r_customStyles.background := r_backgroundDg;
      r_customStyles.font := r_fontB;
      tab_customStyles (i) := r_customStyles;
      i := i + 1;

      --dunkelgrau fett ohne Rand
      r_customStyles.id := c_stilFettHdgRo;
      r_customStyles.TYPE := 'Text';
      r_customStyles.format := NULL;
      r_customStyles.alignment := r_alignmentC;
      r_customStyles.border := tab_borderO;
      r_customStyles.background := r_backgroundDg;
      r_customStyles.font := r_fontB;
      tab_customStyles (i) := r_customStyles;
      i := i + 1;

      --dunkelgrau fett ohne Rand linksb�ndig
      r_customStyles.id := c_stilFettHdgRoAl;
      r_customStyles.TYPE := 'Text';
      r_customStyles.format := NULL;
      r_customStyles.alignment := r_alignmentL;
      r_customStyles.border := tab_borderO;
      r_customStyles.background := r_backgroundDg;
      r_customStyles.font := r_fontB;
      tab_customStyles (i) := r_customStyles;
      i := i + 1;

      --hellgrau fett ohne Rand
      r_customStyles.id := c_stilFettHhgRo;
      r_customStyles.TYPE := 'Text';
      r_customStyles.format := NULL;
      r_customStyles.alignment := r_alignmentC;
      r_customStyles.border := tab_borderO;
      r_customStyles.background := r_backgroundHg;
      r_customStyles.font := r_fontB;
      tab_customStyles (i) := r_customStyles;
      i := i + 1;

      --hellgrau fett ohne Rand linksb�ndig
      r_customStyles.id := c_stilFettHhgRoAl;
      r_customStyles.TYPE := 'Text';
      r_customStyles.format := NULL;
      r_customStyles.alignment := r_alignmentL;
      r_customStyles.border := tab_borderO;
      r_customStyles.background := r_backgroundHg;
      r_customStyles.font := r_fontB;
      tab_customStyles (i) := r_customStyles;
      i := i + 1;

      --dunkelgrau fett Rand rechts
      r_customStyles.id := c_stilFettHdgRr;
      r_customStyles.TYPE := 'Text';
      r_customStyles.format := NULL;
      r_customStyles.alignment := r_alignmentC;
      r_customStyles.border := tab_borderR;
      r_customStyles.background := r_backgroundDg;
      r_customStyles.font := r_fontB;
      tab_customStyles (i) := r_customStyles;
      i := i + 1;

      --Fett,Hintergrund dunkelgrau, Rand unten
      r_customStyles.id := c_stilFettHdgRu;
      r_customStyles.TYPE := 'Text';
      r_customStyles.format := NULL;
      r_customStyles.alignment := r_alignmentC;
      r_customStyles.border := tab_borderU;
      r_customStyles.background := r_backgroundDg;
      r_customStyles.font := r_fontB;
      tab_customStyles (i) := r_customStyles;
      i := i + 1;

      --Fett,Hintergrund hellgrau, Rand unten
      r_customStyles.id := c_stilFettHhgRu;
      r_customStyles.TYPE := 'Text';
      r_customStyles.format := NULL;
      r_customStyles.alignment := r_alignmentC;
      r_customStyles.border := tab_borderU;
      r_customStyles.background := r_backgroundHg;
      r_customStyles.font := r_fontB;
      tab_customStyles (i) := r_customStyles;
      i := i + 1;

      --Hintergrund hellgrau, Rand ohne
      r_customStyles.id := c_stilHhgRo;
      r_customStyles.TYPE := 'Text';
      r_customStyles.format := NULL;
      r_customStyles.alignment := r_alignmentL;
      r_customStyles.border := tab_borderO;
      r_customStyles.background := r_backgroundHg;
      r_customStyles.font := r_fontN;
      tab_customStyles (i) := r_customStyles;
      i := i + 1;

      --Hintergrund hellgrau, Rand ohne, Zahl
      r_customStyles.id := c_stilHhgRoZahl;
      r_customStyles.TYPE := 'Number';
      r_customStyles.format := xml_spreadsheet.c_nf2decimalGroupSep;
      r_customStyles.alignment := r_alignmentR;
      r_customStyles.border := tab_borderO;
      r_customStyles.background := r_backgroundHg;
      r_customStyles.font := r_fontN;
      tab_customStyles (i) := r_customStyles;
      i := i + 1;

      --Hintergrund hellgrau, Rand ohne, Prozent
      r_customStyles.id := c_stilHhgRoProzent;
      r_customStyles.TYPE := 'Number';
      r_customStyles.format := '0.0';
      r_customStyles.alignment := r_alignmentR;
      r_customStyles.border := tab_borderO;
      r_customStyles.background := r_backgroundHg;
      r_customStyles.font := r_fontN;
      tab_customStyles (i) := r_customStyles;
      i := i + 1;

      --Hintergrund hellgrau, Rand rechts
      r_customStyles.id := c_stilHhgRr;
      r_customStyles.TYPE := 'Text';
      r_customStyles.format := NULL;
      r_customStyles.alignment := r_alignmentL;
      r_customStyles.border := tab_borderR;
      r_customStyles.background := r_backgroundHg;
      r_customStyles.font := r_fontN;
      tab_customStyles (i) := r_customStyles;
      i := i + 1;

      --Hintergrund hellgrau, Rand rechts, Ausrichtung rechts
      r_customStyles.id := c_stilHhgRrAr;
      r_customStyles.TYPE := 'Text';
      r_customStyles.format := NULL;
      r_customStyles.alignment := r_alignmentR;
      r_customStyles.border := tab_borderR;
      r_customStyles.background := r_backgroundHg;
      r_customStyles.font := r_fontN;
      tab_customStyles (i) := r_customStyles;
      i := i + 1;

      --Hintergrund hellgrau, Rand rechts
      r_customStyles.id := c_stilHhgRrZahl;
      r_customStyles.TYPE := 'Number';
      r_customStyles.format := xml_spreadsheet.c_nf2decimalGroupSep;
      r_customStyles.alignment := r_alignmentR;
      r_customStyles.border := tab_borderR;
      r_customStyles.background := r_backgroundHg;
      r_customStyles.font := r_fontN;
      tab_customStyles (i) := r_customStyles;
      i := i + 1;

      --Hintergrund dunkelgrau, Rand ohne
      r_customStyles.id := c_stilHdgRo;
      r_customStyles.TYPE := 'Text';
      r_customStyles.format := NULL;
      r_customStyles.alignment := r_alignmentL;
      r_customStyles.border := tab_borderO;
      r_customStyles.background := r_backgroundDg;
      r_customStyles.font := r_fontN;
      tab_customStyles (i) := r_customStyles;
      i := i + 1;

      --Hintergrund dunkelgrau, Rand rechts
      r_customStyles.id := c_stilHdgRr;
      r_customStyles.TYPE := 'Text';
      r_customStyles.format := NULL;
      r_customStyles.alignment := r_alignmentL;
      r_customStyles.border := tab_borderR;
      r_customStyles.background := r_backgroundDg;
      r_customStyles.font := r_fontN;
      tab_customStyles (i) := r_customStyles;
      i := i + 1;

      --Hintergrund dunkelgrau, Rand rechts, Ausrichtung rechts
      r_customStyles.id := c_stilHdgRrAr;
      r_customStyles.TYPE := 'Text';
      r_customStyles.format := NULL;
      r_customStyles.alignment := r_alignmentR;
      r_customStyles.border := tab_borderR;
      r_customStyles.background := r_backgroundDg;
      r_customStyles.font := r_fontN;
      tab_customStyles (i) := r_customStyles;
      i := i + 1;

      --Hintergrund wei�, Rand ohne, Zahl
      r_customStyles.id := c_stilHwRoZahl;
      r_customStyles.TYPE := 'Number';
      r_customStyles.format := xml_spreadsheet.c_nf2decimalGroupSep;
      r_customStyles.alignment := r_alignmentR;
      r_customStyles.border := tab_borderO;
      r_customStyles.background := r_backgroundW;
      r_customStyles.font := r_fontN;
      tab_customStyles (i) := r_customStyles;
      i := i + 1;

      --Hintergrund wei�, Rand ohne, Prozent
      r_customStyles.id := c_stilHwRoProzent;
      r_customStyles.TYPE := 'Number';
      r_customStyles.format := '0.0';
      r_customStyles.alignment := r_alignmentR;
      r_customStyles.border := tab_borderO;
      r_customStyles.background := r_backgroundW;
      r_customStyles.font := r_fontN;
      tab_customStyles (i) := r_customStyles;
      i := i + 1;

      --Hintergrund wei�, Rand rechts
      r_customStyles.id := c_stilHwRrZahl;
      r_customStyles.TYPE := 'Number';
      r_customStyles.format := xml_spreadsheet.c_nf2decimalGroupSep;
      r_customStyles.alignment := r_alignmentR;
      r_customStyles.border := tab_borderR;
      r_customStyles.background := r_backgroundW;
      r_customStyles.font := r_fontN;
      tab_customStyles (i) := r_customStyles;
      i := i + 1;

      --Fett, Hintergrund violett, Rand ohne
      r_customStyles.id := c_stilFettHviRo;
      r_customStyles.TYPE := 'Text';
      r_customStyles.format := NULL;
      r_customStyles.alignment := r_alignmentL;
      r_customStyles.border := tab_borderO;
      r_customStyles.background := r_backgroundVi;
      r_customStyles.font := r_fontB;
      tab_customStyles (i) := r_customStyles;
      i := i + 1;

      --Fett, Hintergrund violett, Rand rechts
      r_customStyles.id := c_stilFettHviRr;
      r_customStyles.TYPE := 'Text';
      r_customStyles.format := NULL;
      r_customStyles.alignment := r_alignmentL;
      r_customStyles.border := tab_borderR;
      r_customStyles.background := r_backgroundVi;
      r_customStyles.font := r_fontB;
      tab_customStyles (i) := r_customStyles;
      i := i + 1;

      --Fett, Hintergrund violett, Rand rechts, Ausrichtung rechts
      r_customStyles.id := c_stilFettHviRrAr;
      r_customStyles.TYPE := 'Text';
      r_customStyles.format := NULL;
      r_customStyles.alignment := r_alignmentR;
      r_customStyles.border := tab_borderR;
      r_customStyles.background := r_backgroundVi;
      r_customStyles.font := r_fontB;
      tab_customStyles (i) := r_customStyles;
      i := i + 1;

      --Fett, Hintergrund violett, Rand ohne
      r_customStyles.id := c_stilFettHviRoZahl;
      r_customStyles.TYPE := 'Number';
      r_customStyles.format := xml_spreadsheet.c_nf2decimalGroupSep;
      r_customStyles.alignment := r_alignmentR;
      r_customStyles.border := tab_borderO;
      r_customStyles.background := r_backgroundVi;
      r_customStyles.font := r_fontB;
      tab_customStyles (i) := r_customStyles;
      i := i + 1;

      --Fett, Hintergrund violett, Rand rechts
      r_customStyles.id := c_stilFettHviRrZahl;
      r_customStyles.TYPE := 'Number';
      r_customStyles.format := xml_spreadsheet.c_nf2decimalGroupSep;
      r_customStyles.alignment := r_alignmentR;
      r_customStyles.border := tab_borderR;
      r_customStyles.background := r_backgroundVi;
      r_customStyles.font := r_fontB;
      tab_customStyles (i) := r_customStyles;
      i := i + 1;

      --Fett, Hintergrund violett, Rand ohne
      r_customStyles.id := c_stilFettHviRoProzent;
      r_customStyles.TYPE := 'Number';
      r_customStyles.format := '0.0';
      r_customStyles.alignment := r_alignmentR;
      r_customStyles.border := tab_borderO;
      r_customStyles.background := r_backgroundVi;
      r_customStyles.font := r_fontB;
      tab_customStyles (i) := r_customStyles;
      i := i + 1;

   END declareCustomStyles;

PROCEDURE anlegenDatei
IS
BEGIN

    declarePrintSetupAltersliste();
    declareColumnsAltersliste();
    declareCustomStyles();
    v_fileHandle := xml_spreadsheet.createNewFile (
                        'LISTEN_DAT',
                        'Altersliste_Konto_12345678.xml',
                        tab_customStyles);
    -- Arbeitsblatt �ffnen
    xml_spreadsheet.newWorksheet (
        v_fileHandle,
        'Altersliste_FUV',
        xml_spreadsheet.g_tab_caption,     -- leer
        tab_columnsAl,
        NULL,
        NULL,
        NULL,
        TRUE,
        r_printSetup
        );
    --Zeile 1
    xml_spreadsheet.writeData (
        v_fileHandle,
        TO_CHAR (NULL),
        c_stilFettHdgRru,
        NULL,
        NULL,
        2);
    xml_spreadsheet.writeData (
        v_fileHandle,
        'Forderungen an VN',
        c_stilFettHdgRru,
        NULL,
        NULL,
        7);
    xml_spreadsheet.writeData (
        v_fileHandle,
        'Verbindlichkeiten an VN',
        c_stilFettHdgRu,
        NULL,
        NULL,
        1);
    --Zeile 2
    xml_spreadsheet.newDatarow (v_fileHandle, NULL, 30);
    xml_spreadsheet.writeData (v_fileHandle,TO_CHAR (NULL),c_stilFettHdgRo);
    xml_spreadsheet.writeData (v_fileHandle,TO_CHAR (NULL),c_stilFettHhgRo);
    xml_spreadsheet.writeData (v_fileHandle,TO_CHAR (NULL),c_stilFettHdgRr);
    xml_spreadsheet.writeData (
        v_fileHandle,
        'gesamt',
        c_stilFettHhgRo,
        NULL,
        NULL,
        1);
    xml_spreadsheet.writeData (
        v_fileHandle,
        'ohne Flag 1' || CHR (10) || 'ohne Flag2',
        c_stilFettHdgRo,
        NULL,
        NULL,
        1);
    xml_spreadsheet.writeData (
        v_fileHandle,
        'mit Flag 1',
        c_stilFettHhgRo,
        NULL,
        NULL,
        1);
    xml_spreadsheet.writeData (
        v_fileHandle,
        'mit Flag 2' || CHR (10) || 'ohne Flag 1',
        c_stilFettHdgRr,
        NULL,
        NULL,
        1);
    xml_spreadsheet.writeData (
        v_fileHandle,
        'gesamt',
        c_stilFettHhgRo,
        NULL,
        NULL,
        1);
    -- Zeile 3
    xml_spreadsheet.newDatarow (v_fileHandle, NULL, 30);
    xml_spreadsheet.writeData (v_fileHandle, 'Vertr. art', c_stilFettHdgRoAl);
    xml_spreadsheet.writeData (v_fileHandle,'Produkt- gruppe',c_stilFettHhgRoAl);
    xml_spreadsheet.writeData (v_fileHandle, 'Alter', c_stilFettHdgRr);
    xml_spreadsheet.writeData (v_fileHandle, '%', c_stilFettHhgRo);
    xml_spreadsheet.writeData (v_fileHandle,'Betrag' || CHR (10) || 'EUR',c_stilFettHhgRo);
    xml_spreadsheet.writeData (v_fileHandle, '%', c_stilFettHdgRo);
    xml_spreadsheet.writeData (v_fileHandle,'Betrag' || CHR (10) || 'EUR',c_stilFettHdgRo);
    xml_spreadsheet.writeData (v_fileHandle, '%', c_stilFettHhgRo);
    xml_spreadsheet.writeData (v_fileHandle,'Betrag' || CHR (10) || 'EUR',c_stilFettHhgRo);
    xml_spreadsheet.writeData (v_fileHandle, '%', c_stilFettHdgRo);
    xml_spreadsheet.writeData (v_fileHandle,'Betrag' || CHR (10) || 'EUR',c_stilFettHdgRr);
    xml_spreadsheet.writeData (v_fileHandle, '%', c_stilFettHhgRo);
    xml_spreadsheet.writeData (v_fileHandle,'Betrag' || CHR (10) || 'EUR',c_stilFettHhgRo);
    -- Zeile 4
    xml_spreadsheet.newDatarow (v_fileHandle);
    xml_spreadsheet.writeData (v_fileHandle,TO_CHAR (NULL),c_stilFettHdgRu);
    xml_spreadsheet.writeData (v_fileHandle,TO_CHAR (NULL),c_stilFettHhgRu);
    xml_spreadsheet.writeData (v_fileHandle,TO_CHAR (NULL),c_stilFettHdgRru);
    xml_spreadsheet.writeData (v_fileHandle,TO_CHAR (NULL),c_stilFettHhgRu);
    xml_spreadsheet.writeData (v_fileHandle,TO_CHAR (NULL),c_stilFettHhgRu);
    xml_spreadsheet.writeData (v_fileHandle,TO_CHAR (NULL),c_stilFettHdgRu);
    xml_spreadsheet.writeData (v_fileHandle,TO_CHAR (NULL),c_stilFettHdgRu);
    xml_spreadsheet.writeData (v_fileHandle,TO_CHAR (NULL),c_stilFettHhgRu);
    xml_spreadsheet.writeData (v_fileHandle,TO_CHAR (NULL),c_stilFettHhgRu);
    xml_spreadsheet.writeData (v_fileHandle,TO_CHAR (NULL),c_stilFettHdgRu);
    xml_spreadsheet.writeData (v_fileHandle,TO_CHAR (NULL),c_stilFettHdgRru);
    xml_spreadsheet.writeData (v_fileHandle,TO_CHAR (NULL),c_stilFettHhgRu);
    xml_spreadsheet.writeData (v_fileHandle,TO_CHAR (NULL),c_stilFettHhgRu);

END anlegenDatei;

BEGIN

    -- Ab jetzt Datenzeilen
    FOR rec_liste IN cur_liste LOOP
        IF v_first THEN
            anlegenDatei();
            v_first := FALSE;
        END IF;

        v_styleFlag := MOD (rec_liste.altgrp_nr, 2);

        xml_spreadsheet.newDatarow (v_fileHandle);
        xml_spreadsheet.writeData (
            v_fileHandle,
            rec_liste.vta_cd,
            CASE v_styleFlag WHEN 1 THEN c_stilHhgRo WHEN 0 THEN c_stilHdgRo ELSE c_stilFettHviRo END
            );
        xml_spreadsheet.writeData (
            v_fileHandle,
            rec_liste.pgr_cd,
            CASE v_styleFlag WHEN 1 THEN c_stilHhgRo WHEN 0 THEN c_stilHdgRo ELSE c_stilFettHviRo END
            );
        xml_spreadsheet.writeData (
            v_fileHandle,
            rec_liste.altgrp_text,
            CASE v_styleFlag WHEN 1 THEN c_stilHhgRr WHEN 0 THEN c_stilHdgRr ELSE c_stilFettHviRr END
            );
        xml_spreadsheet.writeData (
            v_fileHandle,
            rec_liste.pr_sumf,
            CASE v_styleFlag WHEN 1 THEN c_stilHhgRoProzent WHEN 0 THEN c_stilHwRoProzent ELSE c_stilFettHviRoProzent END
            );
        xml_spreadsheet.writeData (
            v_fileHandle,
            rec_liste.sumf,
            CASE v_styleFlag WHEN 1 THEN c_stilHhgRoZahl WHEN 0 THEN c_stilHwRoZahl ELSE c_stilFettHviRoZahl END
            );
        xml_spreadsheet.writeData (
            v_fileHandle,
            rec_liste.pr_sumf00,
            CASE v_styleFlag WHEN 1 THEN c_stilHhgRoProzent WHEN 0 THEN c_stilHwRoProzent ELSE c_stilFettHviRoProzent END
            );
        xml_spreadsheet.writeData (
            v_fileHandle,
            rec_liste.sumf00,
            CASE v_styleFlag WHEN 1 THEN c_stilHhgRoZahl WHEN 0 THEN c_stilHwRoZahl ELSE c_stilFettHviRoZahl END
            );
        xml_spreadsheet.writeData (
            v_fileHandle,
            rec_liste.pr_sumf10,
            CASE v_styleFlag WHEN 1 THEN c_stilHhgRoProzent WHEN 0 THEN c_stilHwRoProzent ELSE c_stilFettHviRoProzent END
            );
        xml_spreadsheet.writeData (
            v_fileHandle,
            rec_liste.sumf10,
            CASE v_styleFlag WHEN 1 THEN c_stilHhgRoZahl WHEN 0 THEN c_stilHwRoZahl ELSE c_stilFettHviRoZahl END
            );
        xml_spreadsheet.writeData (
            v_fileHandle,
            rec_liste.pr_sumf02,
            CASE v_styleFlag WHEN 1 THEN c_stilHhgRoProzent WHEN 0 THEN c_stilHwRoProzent ELSE c_stilFettHviRoProzent END
            );
        xml_spreadsheet.writeData (
            v_fileHandle,
            rec_liste.sumf02,
            CASE v_styleFlag WHEN 1 THEN c_stilHhgRrZahl WHEN 0 THEN c_stilHwRrZahl ELSE c_stilFettHviRrZahl END
            );
        xml_spreadsheet.writeData (
            v_fileHandle,
            rec_liste.pr_sumv,
            CASE v_styleFlag WHEN 1 THEN c_stilHhgRoProzent WHEN 0 THEN c_stilHwRoProzent ELSE c_stilFettHviRoProzent END
            );
        xml_spreadsheet.writeData (
            v_fileHandle,
            rec_liste.sumv,
            CASE v_styleFlag WHEN 1 THEN c_stilHhgRoZahl WHEN 0 THEN c_stilHwRoZahl ELSE c_stilFettHviRoZahl END
            );
    END LOOP;

    IF NOT v_first THEN
        r_autofilter.row := 4;
        r_autofilter.colFrom := 1;
        r_autofilter.colTo := 3;

        -- Arbeitsblatt schlie�en
        xml_spreadsheet.closeWorksheet (
            v_fileHandle,
            4,                          -- fix 4 rows in worksheet when scrolling
            0,                      -- fix no columns in worksheet when scrolling
            tab_caption,
            TRUE,
            xml_spreadsheet.g_tab_conditionalFormats,
            r_printSetup,
            r_autofilter);
        -- Datei schlie�en
        xml_spreadsheet.closeFile (v_fileHandle);
    END IF;

END aufl_dateien_fuv_xml;
/


