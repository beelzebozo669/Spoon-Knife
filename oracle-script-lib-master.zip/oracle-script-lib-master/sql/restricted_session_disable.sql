alter system disable restricted session; 
