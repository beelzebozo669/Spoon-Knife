
-- change statspack to level 0

exec statspack.modify_statspack_parameter( i_snap_level => 0 )

