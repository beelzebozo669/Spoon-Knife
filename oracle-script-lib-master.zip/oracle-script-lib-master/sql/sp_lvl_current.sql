select snap_level
from perfstat.STATS$STATSPACK_PARAMETER
/
