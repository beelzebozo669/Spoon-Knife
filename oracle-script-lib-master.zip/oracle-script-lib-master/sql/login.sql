
set sqlprompt "_USER'@'_CONNECT_IDENTIFIER _PRIVILEGE> "

define _editor=vi

set tab off



