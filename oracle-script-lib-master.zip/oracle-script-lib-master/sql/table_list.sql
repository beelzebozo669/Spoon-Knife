
v_tables(1) := 'CONTACTGROUPS';
v_tables(2) := 'CUSTOM_FIELDS_VAL';
v_tables(3) := 'CUSTOM_FIELDS_DATE_VAL';

v_tables(4) := 'CONTACTS';
v_tables(5) := 'MESSAGE_CONTACTS_BASE';

