
-- simplified prompt for copy and paste to blog and articles

set sqlprompt 'SQL# '
set timing off
set time off


