
@@set_dbid
@@set_date_format

