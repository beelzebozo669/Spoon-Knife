@@autotask_sql_setup

select client_name, status from dba_autotask_client
/
