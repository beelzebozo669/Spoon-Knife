select * from  v$sqlcommand
/
