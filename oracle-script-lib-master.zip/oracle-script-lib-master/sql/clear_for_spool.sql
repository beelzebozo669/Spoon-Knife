

@@clears

set pages 0 lines 200 term on feed off 

