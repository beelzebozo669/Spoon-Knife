---https://www.oradba.ch/2013/07/query-alert-log-from-sqlplus/
A simple query to get the alert log messages and timestamp would look like.

SET linesize 200 pagesize 200
col RECORD_ID FOR 9999999 head ID
col ORIGINATING_TIMESTAMP FOR a20 head DATE
col MESSAGE_TEXT FOR a120 head Message

SELECT 
    record_id,
    to_char(originating_timestamp,'DD.MM.YYYY HH24:MI:SS'),
    message_text 
FROM 
    x$dbgalertext;
For daily use I’ve put together two scripts.

 tal.sql list all or some alert log messages. Messages will be filtered by the parameter
 taln.sql list the last n numbers of rows in an alert log.
Write into the alertlog

The procedure kdswrt in dbms_system package allows us to write own messages in the alert log / trace files or both. It receives two parameters:

A number that indicates where do we want to write our message
Writing to a TRACE file
Writing to the Alert.log file
Writing to both of them
A text string (the message itself).
EXEC dbms_system.ksdwrt(2, 'ORA-00042: Test message in alert log.');


EXEC dbms_system.ksdwrt(2, 'JC marker on 09/01/2019 to alert log.');

Query the Alertlog

List the last 10 lines in the alert log.

SQL> @taln 10


SQL> @taln 10

      ID DATE                 Message
-------- -------------------- ----------------------------------------------------------------------
    4333 23.07.2013 22:00:47  Thread 1 advanced TO log SEQUENCE 94 (LGWR switch)
    4334 23.07.2013 22:00:47    CURRENT log# 1 seq# 94 mem# 0: /u00/oradata/TDB01/redog1m1TDB01.dbf
    4335 23.07.2013 22:00:47    CURRENT log# 1 seq# 94 mem# 1: /u01/oradata/TDB01/redog1m2TDB01.dbf
    4336 23.07.2013 22:00:47  Archived Log entry 111 added FOR thread 1 SEQUENCE 93 ID 0xa3d43dfa...
    4337 24.07.2013 02:00:00  Closing scheduler window
    4338 24.07.2013 02:00:00  Closing Resource Manager plan via scheduler window
    4339 24.07.2013 02:00:00  Clearing Resource Manager plan via parameter
    4340 24.07.2013 03:38:21  VKTM detected a TIME drift. Please CHECK trace file FOR more details.
    4341 24.07.2013 09:18:38  VKTM detected a TIME drift. Please CHECK trace file FOR more details.
    4342 24.07.2013 14:50:05  ORA-00042: Test Message IN alert log

10 ROWS selected.
Query the alert log string ORA-00042.

SQL> @tal ORA-00042

      ID DATE                 Message
-------- -------------------- -------------------------------------------
    4342 24.07.2013 14:50:05  ORA-00042: Test Message IN alert log


FILTER ON alert log message => ORA-00042
Other fixed tables

There are bunch of other X$ Fixed Tables. At lease the following are somehow related to the ADR

X$DBGDIREXT list all file and directory names under diagnostic_dest/diag directory. Will be quite a lot on a shared DB server
X$DBGRICX list of ADR Incidents
References

Some links related to this post.

 tal.sql list all or some alert log messages. Messages will be filtered by the parameter
 taln.sql list the last n numbers of rows in an alert log.
How To Edit, Read, and Query the Alert.Log [1072547.1]
How To Test The Generic Alert Log Error Metric on 10g [850320.1]
Tanel Poder Oracle 11g: Reading alert log via SQL (https://blog.tanelpoder.com/2009/03/21/oracle-11g-reading-alert-log-via-sql/)
http://www.dba-oracle.com/t_11g_dbgalertext_alert_log_sql.htm
https://dbaprakash.wordpress.com/2015/03/10/how-to-check-alert-log-in-oracle-11g/
http://www.adp-gmbh.ch/ora/concepts/alert_log.html
http://www.adp-gmbh.ch/ora/admin/scripts/read_alert_log.html
http://www.adp-gmbh.ch/ora/admin/read_alert/index.html
http://www.adp-gmbh.ch/blog/2006/02/05.php
http://www.adp-gmbh.ch/ora/sql/create_directory.html
http://www.adp-gmbh.ch/ora/admin/read_alert/index.html

ADRCI
========================================
https://www.databasejournal.com/features/oracle/article.php/3879896/Oracle-Databases-ADRCI--Reading-the-Old-Alert-Log-and-Listener-Log.htm

========================================
Search
google -> oracle script to give alert log location


https://www.bbc.co.uk/news/entertainment-arts-46746353
https://www.bbc.co.uk/news/technology-46785490
https://spicemountain.co.uk/
https://herbalveda.co.uk/product/ratanjot-alkanet-root-bark-onosma-echioides-linn/
https://herbalveda.co.uk/product/malabar-imli-or-vilayati-imli-garcinia-cambogia/
https://steenbergs.co.uk/
https://nikibakes.uk/
https://nikibakes.uk/2019/01/07/nikis-buffalo-cauliflower-wings/
https://www.spicekitchenuk.com/
https://www.spicesofindia.co.uk/index.html
https://www.theasiancookshop.co.uk/


https://travelling-foodies.com/tag/indonesian-black-nut/
https://www.wingyipstore.co.uk/food/soup-snacks-nuts/nuts-seeds?p=3
https://www.finedininglovers.com/stories/indonesia-food-ingredients/
http://www.feasttotheworld.com/2012/09/tales-of-elusive-black-nut-ayam-buah.html
http://www.feasttotheworld.com/
https://www.youtube.com/watch?v=IHeKPRfYegk
https://www.amazon.co.uk/Siddhratan-RATANJOT-Alkanna-tinctoria-ALKANET/dp/B07438LS85
https://mangalorespice.com/products/ratan-jot-alkanet
https://mangalorespice.com/
https://www.thespiceworks.co.uk/
http://www.natoora.co.uk/
https://www.souschef.co.uk/
https://www.thespicery.com/
https://bart-ingredients.co.uk/
https://www.jalpurmillers.co.uk/
https://ottolenghi.co.uk/pantry
https://www.wildmeat.co.uk/
https://www.playfulcooking.com
https://www.playfulcooking.com/index/recipe/bengali-cuisine/




















========================================
NIKI’S BUFFALO CAULIFLOWER WINGS

Baked golden nuggets of deliciousness, my buffalo cauliflower wings have a lovely meaty texture to them. I love how simple they are and also that they are not fried, meaning you won’t be feeling sluggish afterwards and you can still enjoy the benefits of cauliflower as they still retain some nutrients when cooked this way. All you need is:

Ingredients:

1 large or 2 medium sized head of cauliflower, chopped into smallish chunky florets
½ cup of almond milk 
½ cup of tapioca flour and gluten free flour
½ teaspoon of garlic powder @steenbergsltd
½ teaspoon of onion powder @steenbergsltd
½ teaspoon of ground turmeric @steenbergsltd
1 teaspoon of smoked paprika @steenbergsltd
1 tablespoon of Niki’s Korean Blend @steenbergsltd
½ teaspoon of sea salt and pepper to taste @steenbergsltd
½ cup of sriracha mayo
3 tablespoons of melted coconut oil or olive oil

Instructions:

Preheat the oven to 450 F and line a baking sheet with parchment paper.
In a large bowl, whisk together the tapioca and gluten free flour, onion powder, garlic powder, paprika powder, ground turmeric, sea salt, and pepper.
Slowly add the milk and whisk to make a lump free batter. The batter should be a thick coating consistency. Add more tapioca flour if the batter is too thin.
Dip each cauliflower floret into the batter. Coat evenly. Shake off the excess and place on the parchment covered baking tray.
Bake for 20 minutes, until the florets are fragrant and tender and the batter has ‘gelled on’. Once the cauliflower florets are done baking, let them cool for a bit, about 5 minutes.
Toss the baked florets in the sriracha mayo taking care to coat every floret with the sauce.
Transfer it back to the baking sheet and bake for 10 more minutes.
Serve the Buffalo Cauliflower Wings with an extra drizzle of the sriracha mayo and sprinkle over Niki’s Korean Blend, lush!
