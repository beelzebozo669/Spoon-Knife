Standards
=========================================================================================================
PL SQL Standards
	Layout
	Commenting
	Naming Conventions
	SQL Statements
	PL/SQL Control Structures
	Defining Variables and Data Structures
	Exceptions
	Cursors and Transaction Management
	Application Design
	Appendix

DDL Standards
	Logical Data Modelling
	Physical Data Modelling
	Script templates and file extensions

Module Naming Conventions

Strategic Data Warehouse Mirrorred Tables
 
4 Child Pages
	DDL Standards
	Module Naming Conventions
	PL SQL Standards
	Strategic Data Warehouse Mirrorred Tables
=========================================================================================================
PL SQL Standards
Coding Standards and Guidelines

These pages details the set of PL/SQL and SQL coding standards and guidelines to be checked during the code review process. Adherence to the identified set will determine whether an item of code is allowed to progress through this review stage to the next stage in the development lifecycle.
 
Standards list against which the code will be checked
	Layout - layout of the PL/SQL and SQL for readability.
	Commenting - documenting of the code for maintainability.
	Naming Conventions - naming of components within the code.
	SQL Statements - SQL statements both standalone and embedded within PL/SQL, i.e. selects, updates, inserts and deletes.
	PL/SQL Control Structures - conditional and iterative processing within PL/SQL blocks.
	Defining Variables and Data Structures - declaring a variable, constant or any other data structure within a PL/SQL block or subprogram.
	Exceptions - exception handling within PL/SQL.
	Cursors and Transaction Management - SQL and PL/SQL integration.
	Application Design - designing a PL/SQL or SQL module.
 
 
Each category above has been presented as a sub-section within this section. Each will detail the set of applicable standards and guidelines

Standard - where this appears, adherence is mandatory and non-compliance should require rework before the code can progress through this stage in the development lifecycle.
Guideline - where this appears, adherence is optional. A guideline should be viewed as a best practice suggestion. These guidelines are generally to do with a particular aspect of coding style. Non-compliance would not necessarily result in a failed code review unless the chosen style either compromised readability, maintainability, or efficiency.
In addition to the above categorisation, each standard and guideline will have an associated unique reference. This reference will be used to flag non-compliance with that particular standard or guideline when completing a Code Review template. For example, G1.1c identifies the third guideline in category 1 subsection 1. Likewise, S3.2a identifies the first standard in category 3 subsection 2.
There is also helpful information contained in the Appendices


10 Child Pages
	Appendix
	Application Design
	Commenting
	Cursors and Transaction Management
	Defining Variables and Data Structures
	Exceptions
	Layout
	Naming Conventions
	PL/SQL Control Structures
	SQL Statements
=========================================================================================================
Layout
Category 1 - Layout

This section introduces a set of layout guidelines to make PL/SQL and SQL code more readable and maintainable.
1.1 Indentation
Indentation is one of the most common and effective techniques used to display a program's logic via format.
Guideline (G1.1a) - use a two-space indentation technique to highlight logic.
 
Example:
if (length(p_answer) < g_min_answer_length or
    length(p_answer) > g_max_answer_length) then
  l_msg_text := f_validation_message (99);
  l_msg_code := 99;
end if;
 
Notice also the alignment of the continuous line. In this case the statement continues on the second line after a three space indent to align the conditional expressions within the previous if statement.
1.2 Vertical Alignment
Vertical Alignment is the technique of aligning elements of a statement vertically to highlight a relationship between the elements.
Standard (S1.2a) - use vertical alignment to highlight relationships between elements of a statement.
 
Example - Parameters
 
 
 
In the above example, the vertical alignment of the parameters allows you to easily see the different parameter modes and data types.
 
 
Example - Query
select csr.id,
       csr.surname,
       cor.request_date
from customers csr,
     correspondence_requests cor
where csr.active_ind = 'Y'
  and csr.correspondence_ind = 'H'
  and csr.id = cor.csr_id
  and (cor.printed_date is null or
       cor.requested_date = trunc(sysdate))
  and exists
      (select 1
       from support_applications sap
       where sap.csr_id = csr.id)
order by csr.id,
         csr.surname,
         cor.request_date;
 
In the above example the vertical alignment of the SQL statement groups the components for clarity. Notice also the vertical alignment of the sub-query. It is also worth noting that the reserved words (i.e. select, from, where, and, order by etc) can be left aligned.
 
 
Example - Update
update borrowings brw
   set brw.borrow_date = trunc(sysdate),
       brw.borrow_id = user
 where brw.isbn = p_isbn;
 
In the above example the vertical alignment of the SQL statement groups the components for clarity.
 
 
Example - Delete
delete from support_applications sap
 where sap.acy_id = 2004
   and sap.lea_id = '850';
 
In the above example the vertical alignment of the SQL statement groups the components for clarity.
 
 
Example - Type
type reason_r_type is record (
  reason_id          app_pend_reasons.id%type,
  reason_type_id     app_pend_reasons.prt_id%type,
  reason_description pend_reason_types.short_description%type,
  start_date         app_pend_reasons.start_date_time%type,
  end_date           app_pend_reasons.end_date_time%type,
  note               app_pend_reasons.note%type,
  raised_by          app_pend_reasons.created_by%type,
  creation_date      app_pend_reasons.creation_date_time%type);
 
In the above example the vertical alignment of the components of the record enhances readability.
Standard (S1.2b) - Organize and align like items together.
For example, declare record variables together in the same section. Declare all constants together in another section, separated from the previous section by white-space.
 
Example - Declarations
cursor c_ipw (p_pwd invalid_passwords.password_string%type) is
  select ipw.password_string
    from invalid_passwords ipw
   where ipw.password_string = p_pwd;
r_ipw c_ipw%rowtype;
l_password          invalid_passwords.password_string%type;
l_password_reversed invalid_passwords.password_string%type;
l_max_password_len  constant number := 10;
type reason_r_type is record (
  id    reason_types.id%type,
  name  reason_types.name%type);
type reason_rc_type is ref cursor return reason_r_type;
g_module constant varchar2(10) := 'SAPPK001' ;
e_ldap_timeout exception;
pragma exception_init(e_ldap_timeout, -31202);
 
In the above example the whole declare statement is NOT vertically aligned. However, there are vertically aligned groupings to highlight relationships between components of a statement and for reasons of readability. Notice also in the above example, the cursor row declaration follows the cursor declaration that it is associated with.
1.3 Case
There are various options available when considering adopting a case standard to make code more readable and maintainable, i.e. upper, lower or a mixture of both. These centre around highlighting the difference between the various constructs within the code, e.g. reserved words and application-specific names or identifiers.
Standard (S1.3a) - use lowercase exclusively.
It is not felt that a mix of upper and lower case would increase the readability of the code. In addition, two identical pieces of SQL with a single character in a different case will both have to be parsed from scratch.
 
Example
if (length(p_sq_answer) < g_min_sqa_length and
    p_sq_answer != 'DEFAULT') then
  p_return_msg := f_get_content_message (1211);
  p_return_code := 1211;
  return false;
end if;
 
Notice - the above example highlights that there will be instances where uppercase text will be required, e.g. string literals.
1.4 PL/SQL Statements per Line
A single PL/SQL statement is terminated by a semicolon. This allows for multiple statements on a line, however...
Standard (S1.4a) - Use at most one statement per line.
 
Example
p_return_msg := f_get_content_message (1211);
p_return_code := 1211;
 
 
1.5 Complex Expressions
The rules of SQL and PL/SQL operator precedence follow the commonly accepted precedence of algebraic operators. Where operators have the same precedence level, the rules of evaluation specify left-to-right evaluation. However, this can easily be overlooked when checking for correctness.
Guideline (G1.5a) - Express complex expressions unambiguously using parenthesis
regardless of the simplicity of the expression.
 
Example
if l_account_balance < 100 then ...
if (l_account_balance < 100 and
    l_status != 'A') then ...
l_checksum := 5 + ((l_weight**3) mod 10);
 
 
1.6 Named Notation
Named notation is the technique of specifying the name of a parameter along with its value in a procedure or function parameter list. The syntax of this notation is:
  parameter value => value
Standard (S1.6a) - use named notation whenever you make a call to a procedure/function.
This will make the parameter list more readable and will also clarify an overloaded procedure/function call. In addition, this notation allows greater flexibility in how the parameter list is constructed.
 
Example - Parameters
if not f_emp_group(p_user_id     => l_user_id,
                   p_employee_id => l_emp_id,
                   p_group_id    => l_owner_id) then
  ...
end if;

=========================================================================================================
Commenting
Category 2 - Comments

This section introduces a set of guidelines to commenting SQL and PL/SQL code.
2.1 Headers
Icon
The following constructs within a PL/SQL package require an appropriate header for the reasons stipulated:
- Package Specification - to summarise the package functionality and version details
- Package Body - to summarise version details
- Procedure(s) and Function(s) - to summarise their functionality and parameters
In addition, Data Update scripts should also contain similar headers - see SupportingTemplates.

Standard (S2.1a) - Complete a standard header comment at the top of each package specification and body
- immediately before the package specification statement. This code will NOT be included in the compiled code base within the database. The template for package headers is provided in the Supporting Templates section.
 
Example
--##########################################################
--#
--# name : SAPPK001
--#
--# author : Keith Hill
--#
--# description : Procedures to retrieve and update application 
--# data
--#
--# pvcs : $Revision: 1.114 $
--# $Modtime: 26 Nov 2004 16:45:10 $
--# $Author: tilston $
--#
--##########################################################
--# modification history
--#
--# $Log: X:/PVCS/Archives/Protocol/Packages/SCUPK001.svl $
--#
--# Rev 1.114 26 Nov 2004 17:09:40 tilston
--# 2568 - fix to change merged from branch.
--# 3162 - Update to NINO not allowed due to IR restrictions.
--#
--# Rev 1.113 27 Sep 2004 16:50:26 skinners
--# CRMDBA5A.169 merged from branch.--# $Log: $
--#
--##########################################################
create or replace package sappk001 is
 
Note - the version details are NOT populated manually. They are automatically maintained upon upload into PVCS.
Standard (S2.1b) - Complete a standard header comment at the top of each package specification
- immediately after the create package statement. This code will be included in the compiled code base within the database. The template for package headers is provided in the Supporting Templates section.
 
Example
create or replace package scupk001 is
--##########################################################
--#
--# package specification for SCUPK001 $Revision:   1.14  $
--#
--##########################################################
 
Note - the version details are NOT populated manually. They are automatically maintained upon upload into PVCS.
Standard (S2.1c) - Complete a standard header comment at the top of each package body
- immediately after the package body statement. This code will be included in the compiled code base within the database. The template for package headers is provided in the Supporting Templates section.
 
Example
create or replace package body scupk001 is
--##########################################################
--#
--# package body for SCUPK001 $Revision:   1.14  $
--#
--##########################################################
 

Standard (S2.1d) - complete a standard header comment at the top of each procedure/function
- immediately before the procedure/function definition. The template for procedure/function headers is provided in the Supporting Templates section.
 
Example - Procedure
--##########################################################
--#
--# procedure : p_validate_nino
--#
--# description : validates a NINO and NINO status pairing
--#
--# parameter(s): p_csr_id - customer internal identifier
--# p_nino - national insurance number
--# p_status - new nino status
--# p_valid_nino - is nino format valid
--# p_reason - missing nino reason
--#
--##########################################################
procedure p_validate_nino (p_csr_id in customers.id%type,
p_nino in customers.nino%type,
p_status in customers.status%type,
p_valid_nino out boolean,
p_reason out varchar2) is
 
 
Example - Function
--##########################################################
--#
--# function    : f_valid_password
--#
--# description : determines whether a password is valid in
--#               accordance pre-specified rules
--#
--# parameter(s): p_username - user for which password is being 
--#                 checked
--#               p_password - password to be checked
--#               p_invalid_reason - reason why password is not 
--#                 valid
--#
--# return value: boolean identifying whether password is valid
--#
--##########################################################
function f_valid_password (p_username       in  varchar2,
                           p_password       in  varchar2,
                           p_invalid_reason out varchar2) 
  return boolean is
 
2.2. Declaration Comments

It is important that the variables, constants, cursors and type declarations local to a package, procedure or function are all understood before they are used throughout the body of the PL/SQL block.
Standard (S2.2a)- Always comment a cursor or a custom type.
Use the double-dash commenting technique, always using an extra one above and below to improve readability. Align the dashes with the statement start position.
 
Example
--
-- get current deceased and nino details for 
-- specified customer
--
cursor c_csr (p_csr_id customers.id%type) is
select csr.ir_matching_status, 
par.attribute12 as deceased_ind, 
par.attribute16 as nino_status,
par.jgzz_fiscal_code as nino,
par.party_id
from customers csr,
hz_parties par
where par.party_id = csr.party_id
and csr.id = p_csr_id;
r_csr c_csr%rowtype;
--
-- record representing an application pend reason
--
type reason_r_type is record ( 
id reason_types.id%type,
name reason_types.name%type);
type reason_rc_type is ref cursor return reason_r_type;
Standard (S2.2b) - Where a variable or constant does not have a name which effectively describes its purpose then use an appropriate trailing double-dash comment.
Example
l_female_match_enabled boolean := false;
l_succeeded boolean := false; -- matching success flag
 
2.3 Commenting Program Logic

It is important that PL/SQL code is appropriately documented to ensure that it can be easily understood and maintained. This is especially important where there is complex or opaque logic.

Standard (S2.3a) - Rely as much as possible on the structure and layout of the code itself to express the meaning of the program.
Reserve your comments to explain the Why of your code:
- What business rule is it meant to implement?
- Why implement a certain requirement in a certain way?
In addition, use comments to translate internal, computer-language terminology into something meaningful for the application

Standard (S2.3b) - Use the double-dash commenting technique to describe procedural logic,
always using an extra one above and below to improve readability.

Guideline (G2.3a) - Align the dashes with the statement start position.
 
Example
--
-- When the password has been fully reversed check if it 
-- matches the username
--
if ((g_chk_pwd_for_username_rvsd = 'Y') and
    (l_pwd_char_position = l_pwd_length) and
    (l_password_reversed = l_username)) then
p_return_msg := f_get_content_message (1208);
p_return_code := 1208; -- invalid password
--
-- password has failed the validation rules
--
return false;
end if;
 
Notice also the use of the trailing double-dash comment to describe the assignment of the return code.
Standard (S2.3c) - Do not comment-out redundant code. It should be removed from the module.
PVCS can be used to refer back to previous revisions with the now redundant code.
=========================================================================================================
Naming Conventions
	
Category 3 - Naming Conventions

This section introduces a set of guidelines to standardise the names of PL/SQL code constructs to make them more readable and maintainable and also potentially more re-useable.
3.1 PL/SQL Data Structures

It is important that standard naming conventions are used when naming structures, constants and variables. Not only should it make the code more readable and maintainable, but it should also highlight scope and the difference in construct types.

Standard (S3.1a) - Use meaningful names for declared structures, constants and variables.
Include the appropriate naming pre-fix for the declared item. Note, there is a 30 character maximum for PL/SQL variable names.
 
Item
Prefix
Global Variable	g_
Local Variable	l_
Global Constant	g_
Local Constant	l_
Cursor	c_
Record (of type cursor row)	r_
Record (of a user-defined type)	r_
User-defined PL/SQL table	t_
Reference Cursor	rc_
Varray	v_
Parameter (of any type)	p_
Exception	e_
 
Standard (S3.1b) - Use meaningful names for user-defined types.
Include the appropriate type naming suffix for the declared item. Note, there is a 30 character maximum for PL/SQL type names.
 
Item
Suffix
Record Type 

_r_type
Reference Cursor Type 

_rc_type
PL/SQL Table Type 

_t_type
Varray Type	_v_type
 
 
Example
cursor c_rty (p_reason_code reason_types.code%type) is
  select rty.code,
         rty.name
  from reason_types rty
  where rty.code = p_reason_code;
r_rty c_rty%rowtype;
l_reason_code reason_types.code%type;
l_reason_name reason_types.name%type;
l_max_reason_len constant number := 30;
type reason_r_type is record ( 
  id reason_types.id%type,
  name reason_types.name%type);
type reason_rc_type is ref cursor return reason_r_type;
r_reason reason_r_type;
rc_reason reason_rc_type;
type reason_code_v_type is varray (7) of reason_types.code%type;
type reason_t_type is table of reason_r_type
index by binary_integer;
v_reason_types reason_code_v_type;
t_reason_types reason_t_type;
g_module constant varchar2(10) := 'SAPPK001' ;
e_ldap_timeout exception;
pragma exception_init(e_ldap_timeout, -31202);
 
Notice also in the above example:
• Cursors should be named based on the standard alias associated with the driving table within the query. These aliases will be documented within Designer. Where an existing cursor within the same scope has the same name, the cursor name should be suffixed with a sequence number, e.g. c_csr1.
• Use of abbreviations within variables and constants to avoid excessively long names. These abbreviations should be meaningful.
3.2 Packages

Package naming conventions are detailed within the standard Module Naming Conventions document.
Standard (S3.2a) - Adopt module naming conventions.
3.3 Procedures and Functions
Standards should be adopted to give procedures and functions meaningful names.
Standard (S3.3a) - Include the appropriate naming pre-fix for procedures and functions.
 
Item
Prefix
Procedure	p_
Function	f_
 
Guideline (G3.3a) - Name procedures with verb phrases
- adopting meaning abbreviations where appropriate. The name of the procedure should reflect the net effect of its procedural logic.
 
Example
procedure p_match_customers (...);
procedure p_set_profile (...);
 

Guideline (G3.3b) - Name functions with noun phrases
- adopting meaningful abbreviations where appropriate. The name of the function should describe what is being returned.
 
Example
function f_valid_check_digit (...) return boolean;
function f_current_lea (...) return award_authorities.code%type;
=========================================================================================================
SQL Statements
Category 4 - SQL Statements

This section introduces a set of guidelines to consider when writing SQL statements - both standalone and embedded within PL/SQL.
4.1 SQL
Standard (S4.1a) - Always alias tables within a query with their short code as recorded within designer.
Where the table appears within the query multiple times then the alias name should be suffixed with a sequence number.
Standard (S4.1b) - Adopt the layout and commenting strategies as proposed in the previous Code Layout section.

Standard (S4.1c) - Avoid implicit type conversions.
For example, character to number conversions which occur implicitly within an equi-join predicate. Compare like types or cast appropriately - thus ensuring that you fully understand the indexing strategy that will be adopted.
Standard (S4.1d) - Beware of writing a view for one purpose and then using it for other purposes to which it might be ill-suited.
Querying from a view requires all tables from the view to be accessed for the data to be returned. Before reusing a view, determine whether all tables in the view need to be accessed to return the data. If not, then do not use the view. Instead, use the base table(s), or if necessary define a new view. The goal is to refer to the minimum number of tables and views necessary to return the required data.

Standard (S4.1e) - Use bind variables whenever possible.
If the bind variable references within a SQL statement are the same, the parsed forms of the statement are considered to be the same. Consequently, the statements share the same parsed form in the shared pool area in memory.
 
Example
select csr.ir_matching_status,
       pty.attribute12 as deceased_ind, 
       pty.attribute16 as nino_status,
       pty.jgzz_fiscal_code as nino,
       pty.party_id
from xxsl_customers csr,
     hz_parties pty
where pty.party_id = csr.party_id
and csr.id = p_customer_id;
 

Standard (S4.1f) - For an insert statement include the column list even if all of the columns are being populated
i.e. do not just specify the values clause.
Standard (S4.1g) - Ensure that the SQL statement performs its desired function efficiently.
The data access path - hinted or otherwise - should be the most appropriate based upon on an understanding of the application.
Standard (S4.1h) - A SQL statement should only be hinted where the desired data access path is not identified automatically by the optimizer.
Imposing hints upon a statement restricts the flexibility of the statement to adapt to changes in data organisation or underlying database optimization. Therefore any hinting strategy should be carefully considered on a statement-by-statement basis and should provide the desired access path with the least restrictions on the optimizer.
Standard (S4.1i) - Do not use the truncate table command.
This causes unrecoverable problems within the standby and copy database.

Standard (S4.1j) - Do not perform select * queries within a module.
Each column required within the program logic should be explicitly listed within the select statement. This ensures that the developer knows exactly what is being processed within the code.
Guideline (G4.1a) - Avoid using DDL within PL/SQL.
Such operations can invalidate dependent objects. There are generally very few situations where there is a requirement to create or amend the definition of a database object within application code. However, this might be required within a data warehouse type upload or a one off data fix script. In such situation the design should be discussed with the TDL's and DBA.
Guideline (G4.1b) - Where possible avoid hinting views.
A view should be hinted in accordance with the desired access path of a particular query. This can be done using a global hint on the driving query.
 
Example
select /*+ index (abc.def.ghi ghi_ui) */
       xyz.column1,
       abc.column1 
from xyz_table xyz,
     abc_view abc
where xyz.column2 = abc.column2;
 
where the view ABC_VIEW is as follows:
 
select def.column2
from uvw_table uvw,
     def_view def
where uvw.column3 = def.column3;
 
where the view DEF_VIEW is as follows:
 
select ghi.column3
from rst_table rst,
     ghi_table ghi
where rst.column5 = ghi.column5;
 
where table GHI_TABLE has the index GHI_U1 on COLUMN3.
 
4.2 Temporary Tables
In addition to permanent tables, Oracle can create temporary tables to hold session-private data that exists only for the duration of a transaction or session.
The create global temporary table statement creates a temporary table that can be transaction-specific or session-specific. For transaction-specific temporary tables, data exists for the duration of the transaction. For session-specific temporary tables, data exists for the duration of the session. Data in a temporary table is private to the session.
You specify whether the data is session- or transaction-specific with the on commit keywords, i.e. delete rows or preserve rows.
Guideline (G4.2a) - A temporary table should only be used where no other appropriate alternative technical solution exists to provide the desired functionality.
Excessive usage of temporary tables may make impact other users of the database, e.g. disk sorts use the same temporary area within the database. Any temporary table solution should therefore be discussed with the TDL's and DBA.
Guideline (G4.2b) - Within a Web-based application that is adopting a connection pooling mechanism for database session allocation, temporary tables should be transaction-specific because sessions are re-used.
=========================================================================================================
PL/SQL Control Structures
Category 5 - Control Structures

This section introduces a set of rules and suggestions to consider when writing PL/SQL control structures.
5.1 if Statements
There are several different flavours of the if construct which can be used:
 
if-then
if-then-else
if-then-elsif
Standard (S5.1a) - Adopt the generic layout and commenting strategies as proposed previously.
 
Example
if (length(p_sq_answer) < g_min_sqa_length and
    p_sq_answer != 'DEFAULT') then
  p_return_msg := f_get_content_message (1211);
  p_return_code := 1211;
  l_success := false;
elsif length(p_sq_answer) = g_min_sqa_length then
  p_return_msg := f_get_content_message (10);
  p_return_code := 10;
  l_success := false;
else
  p_return_msg := null;
  p_return_code := 0;
  l_success := true;
end if;
return l_success;
 
Standard (S5.1b) - Avoid if statements which are used solely to assign a Boolean.
A direct assignment to a Boolean variable is more readable and efficient.
 
Example
--
-- replace the following if ...
--
if l_new_balance < l_minimum_balance then
  l_overdrawn := true;
else
  l_overdrawn := false;
end if;
--
-- with the following assignment ...
--
l_overdrawn := l_new_balance < l_minimum_balance;
 

Standard (S5.1c) - Avoid nesting if statements when an elsif clause can be used.
This will make code more readable.
5.2 null in PL/SQL
When a variable, column, or constant has a value of NULL, its value is unknown - indeterminate. 'Unknown' is very different from a blank or a zero or the Boolean value FALSE. 'Unknown' means that the variable has no value at all and so cannot be compared directly with other variables.

Standard (S5.2a) - Always use the is null and is not null operators or the nvl function when you wish to incorporate the possibility of null values in comparison operations.
 
Example
l_my_string := '';
...
if l_my_string is not null then ...
 
Note - PL/SQL treats a string of zero-length as a null. A zero-length string is two single quotes without any characters in between.

5.3 case Statements

A case statement is similar to an if statement in that there is a conditional execution of logic. case, like decode, works from left to right: it evaluates the when-conditions in order, and as soon as it finds one that is true, it returns the corresponding then-value and quits.
Standard (S5.3a) - Adopt the generic layout and commenting strategies as proposed previously.
 
Example
case l_grade
  when 'A' then ... 
  when 'B' then ... 
  else ...
end case;
...
case
  when l_current_char_ascii between 65 and 90 then -- A->Z
    l_pwd_character_count := l_pwd_character_count + 1;
  when l_current_char_ascii between 48 and 57 then -- 0->9
    l_pwd_number_count := l_pwd_number_count + 1;
  else
    p_return_msg := f_get_content_message (1202); -- Invalid
    p_return_code := 1202;
    return false;
end case;
 
Note - if the else clause was omitted in either of the above examples, then the following implicit else clause takes effect:
else raise case_not_found;
Standard (S5.3b) - Consider the use of a case statement over an if statement if you are comparing a single expression to multiple values
- it simplifies the logic and is more readable.
Guideline (G5.3a) - Consider the use of a case statement over a decode statement.
Anything you can do with case can be done in decode, but it's likely to be more complicated. case is almost always easier to read and understand, and therefore it's easier to debug and maintain.
5.4 loop Statements
A loop statement lets you execute a sequence of statements multiple times. There are three forms of loop statements:
- loop
- while-loop
- for-loop
Standard (S5.4a) - Adopt the generic layout and commenting strategies as proposed previously.
 
Example
loop
--
-- If we've got a match, set the send method and exit the loop
--
  if f_bit_match(l_send_dests, power(2, l_channel - 1)) then
    p_send_channel_id := l_channel;
    exit;
  end if;
--
-- Go in reverse order since this is the order of send fallbacks
--
  l_index := l_index - 1;
  exit when l_index < g_channel_post;
end loop;
--
-- loop through elements
--
for l_index in 0..l_length-1 loop
  l_node := xmldom.item(l_node_list, l_index);
end loop;
for r_csr in c_csr(p_id) loop
  l_surname := r_csr.surname;
...
end loop;
--
-- loop through elements IN REVERSE
--
for l_index reverse in 0..l_length-1 loop
  l_node := xmldom.item(l_node_list, l_index);
end loop;
--
-- loop through elements
--
while l_index <= l_length loop
  l_node := xmldom.item(l_node_list, l_index);
  l_index := l_index + 1;
end loop;
 
Standard (S5.4b) - Do NOT use the goto statement to simulate looping or branching within logic. It is unnecessary and suggests poor structure.
=========================================================================================================
Defining Variables and Data Structures
Category 6 - Defining Variables and Data Structures

This section introduces a set of guidelines to consider when declaring a variable, constant or any other data structure within a PL/SQL block.
6.1 Variables
Consider the following points when defining variables for use within a PL/SQL block.
Standard (S6.1a) - Consider the scope of a variable carefully before deciding upon on local or a global definition.
Global variables are generally only used for package wide constants. They should not be seen are methods of communication between functions and procedures within a package.
Standard (S6.1b) - Where appropriate use %type and %rowtype when defining variables, constants, etc,
i.e. where the declaration applies to a specific column on a table. When you declare a variable using %type or %rowtype, you 'anchor' the type of that data to another previously defined element. This also helps in the readability and maintainability of that piece of code.
 
Example
type customer_r_type is record (
  csr_id             customers.id%type,
  acy_id             academic_years.id%type,
  art_id             hz_parties.party_number%type,
  person_first_name  hz_parties.person_first_name%type,
  person_middle_name hz_parties.person_middle_name%type,
  person_last_name   hz_parties.person_last_name%type,
  relationship       assessment_addresses.relationship%type);
 
type customer_rc_type is ref cursor return customer_r_type;
 
cursor c_par (p_nino hz_parties.jgzz_fiscal_code%type,
              p_party_id hz_parties.party_id%type) is
select par.jgzz_fiscal_code as nino
from hz_parties par
where par.jgzz_fiscal_code like substr(p_nino,1,8)||'%'
and par.party_id <> p_party_id;
r_par c_par%rowtype;
 
Standard (S6.1c) - Ensure variables are initialized in cursor loops
Variables that are assigned values within a cursor loop should be initialized in each iteration of the loop to ensure that null values are handled correctly.
 
Example
for r_csr in c_csr loop
 
    l_balance_total := 0;
    l_name := ' '; 
 
 
6.2 Constants
If you know that the value of a variable is NOT going to change, then it should be considered a constant.
Standard (S6.2a) - Use the reserved word constant within the definition of the item.
This will enhance the readability of the code and prevent subsequent misuse, e.g. attempts to update the value programmatically.
 
g_app_closed_status constant app_work_stages.id%type := 9;
l_threshold_date constant date := 
to_date('01/01/1970','dd/mm/yyyy');
 
6.3 Implicit Datatype Conversions
Where there is a mismatch of datatypes across an assignment or condition, the PL/SQL runtime engine will, in certain circumstances, perform an automatic conversion.
Standard (S6.3a) - Avoid implicit datatype conversion
Explicitly convert the item using an appropriate built-in function, i.e. to_date, to_char, and to_number. This makes code more consistent and predictable.
 
Example
l_start_date date := to_date('01/04/2004','DD/MM/YYYY');
 
6.4 Parameters
Parameters to procedures and functions can be passed by value or by reference. Parameter passing in PL/SQL by default follows these rules:
- in arguments are passed by reference
- out and in out arguments are passed by value
Guideline (G6.4a) - Consider the use of the nocopy parameter hint where an out or in out parameter is being used to pass a large data structure.
This hint allows the compiler to decide whether the parameter can be passed by reference. It should be noted that this will have an impact on the ability of the subprogram to in effect 'roll back' in the event of an exception, i.e. the data structure could already have been partially or fully updated by reference.
 
Example
procedure p_analyze_results (p_date in date,
                             p_results in out nocopy results_v_type,
                             p_decision in out boolean );
=========================================================================================================
Exceptions
Category 7 - Exceptions

In PL/SQL a warning or error condition is called an exception. Exceptions can be internally defined (e.g. division by zero) or user defined. This section introduces a set of rules and standards to be adopted when coding for exceptions within PL/SQL.
When an error occurs, an exception is raised and control transfers to the exception handlers within the PL/SQL block or subprogram. Internal exceptions are raised implicitly (automatically) by the run-time system whenever a piece of code violates an Oracle rule or exceeds a system-dependent limit. User-defined exceptions must be raised explicitly by raise statements, which can also raise predefined exceptions.
The others exception handler catches all exceptions that the block does not name specifically. The functions sqlcode and sqlerrm are especially useful in the others handlers because they return the Oracle error code and message text.
7.1 Defining and Raising Exceptions
Exceptions can be declared only in the declarative part of a PL/SQL block, subprogram, or package. The same scope rules apply to variables and exceptions. To handle error conditions (typically ORA- messages) that have no predefined name, you must use the others handler or the pragma exception_init. A pragma is a compiler directive, i.e. is processed at compile time as opposed to run time. The syntax is as follows:
 
Syntax
exception name exception;
pragma exception_init (exception name, -oracle error message);
 
The procedure raise_application_error provides a mechanism by which to issue user-defined ORA- error messages from stored subprograms. When called, raise_application_error ends the subprogram and returns a user-defined error number and message to the application. The syntax is as follows:
 
Syntax
raise_application_error (error no, message, [true|false]);
 
where error no is a negative integer in the range -20000 to -20999. The optional trailing boolean parameter identifies whether the error is placed on the stack of previous errors or replaces all previous errors.
Standard (S7.1a) - Use the exception_init pragma to name system exceptions that might be raised within the subprogram and have to be handled in a specific way.
 
Example
e_cursor_already_open exception;
pragma exception_init(e_cursor_already_open,-6511);
 
Standard (S7.1b) - Only raise exceptions for errors, not to branch execution, i.e. to control normal program flow.
This suggests poorly structured code. Exceptions should therefore describe errors rather than actions, e.g. invalid_password as opposed to exit_function.
7.2 Handling Exceptions
When an exception is raised, if PL/SQL cannot find a handler for it in the current block or subprogram, the exception propagates. That is, the exception reproduces itself in successive enclosing blocks until a handler is found or there are no more blocks to search - in which case an unhandled exception will be returned.
Standard (S7.2a) - Avoid the possibility of unhandled exceptions by handling specific exceptions conditions via user-defined exceptions with associated exception handlers -
including exception handlers for internal exceptions if relevant. A generic others exception handler should be included to ensure that unexpected errors are handled gracefully.
Standard (S7.2b) - if a subprogram fails with an unhandled exception, PL/SQL does NOT roll back uncommitted transactions.
Ensure that error situations where a rollback is required are handled.
 
Example
exception
when e_validation_error then
...
when others then
rollback;
...
 
Standard (S7.2c) - In a when others exception handler, use the built-in functions sqlcode and sqlerrm to find out which error occurred and to get the associated error message.
 For internal exceptions, sqlcode returns the number of the Oracle error. The number that sqlcode returns is negative unless the Oracle error is no data found, in which case sqlcode returns 100. The corresponding error message is returned by sqlerrm. The message begins with the Oracle error code.
 For user-defined exceptions, sqlcode returns 1 and sqlerrm returns the message: User-Defined Exception. Where a pragma (i.e. exception_init) is used to associate an exception name with an Oracle error code, the sqlcode and sqlerrm functions will return the Oracle error and associated message.
If no exception has been raised, sqlcode returns 0 and sqlerrm returns the message: ORA-0000: normal, successful completion.
The functions sqlcode and sqlerrm cannot be used directly in a SQL statement.
7.3 Generic Logging Routines
A suite of PL/SQL logging routines has been created to structure error handling within packages and their subprograms. These routines are implemented within package HELPK002. There is also an associated package HELPK003 which contains the relevant routines for use within CLASS. Both packages have associated module specifications (within PVCS) which detail their purpose and their content. This section highlights the generic approach to including the required functionality effectively within PL/SQL developments.
Standard (S7.3a) – each package should define its module name within a global constant, i.e. within the package specification. This global constant is used by the generic PL/SQL logging routines.
 
Example
g_module constant varchar2(10) := 'SAPPK001';
 
Standard (S7.3b) - where a subprogram is called directly from the end user application (e.g. from Java or Oracle Forms) then the application user should be passed in for audit purposes.
Such subprograms should also include a call to the generic logging initialisation routine at the start of the subprogram logic.
 
Example
procedure p_get_assessment (
  p_user_id in varchar2,
  p_sap_id in applications.id%type,
  p_rc_assessment_summary out rc_assessment_summary)
is
...
begin
   helpk002.p_initialise (p_app_user => p_user_id);
...
end p_get_assessment;
 
Standard (S7.3c) - each subprogram should set its module and subprogram context at the start of the subprogram logic
After the initialisation routine if applicable. This context is also placed on to a generic execution stack which identifies the subprogram execution hierarchy.
 
Example
helpk002.p_set_routine(g_module, 'p_get_assessment');
 
Guideline (G7.3a) - at significant points throughout the logic within a subprogram the section context should be marked to help with error resolution.
Significant points might be seen as before and after a complex section of processing or DML processing.
 
Example
helpk002.p_set_section('Creating an Application');
insert into support_applications ( ... );
helpk002.p_set_section('Creating an Assessment');
 
Standard (S7.3d) - at each location within a subprogram where control passes back to the calling subprogram or application (i.e. all exit points), the subprogram context should be removed from the execution stack.
 
Example
helpk002.p_exit_routine;
 
Standard (S7.3e) - each subprogram should define a message variable to be used locally to hold error or warning text which has to be raised to the calling routine or application.
When an application error has been identified (i.e. a non-oracle error) then the standard PL/SQL assignment operator should be used to assign the error text to the local message variable.
 
Example
l_message varchar2(2000) := null;
...
begin
...
if l_lea_code is null and p_sap_id is null then
l_message := 'Cannot determine LEA details for generic search';
raise e_error;
end if;
...
end;
 
Standard (S7.3f) - When an application error has been identified (i.e. a non-oracle error) within a subprogram then appropriate exception handling logic should be defined using the generic PL/SQL logging routines.
 
Example
exception
when e_error then
  l_message := helpk002.f_raise_message (
                 p_type => helpk002.g_business_event,
                 p_level => helpk002.g_level_error,
                 p_message => l_message );
  helpk002.p_exit_routine;
  raise_application_error(helpk001.g_err_bespoke_routine,
                          l_message);
...
end;
 
Notes
It is important to note that the HELPK002 function f_raise_message does not raise the error to the calling routine – it builds up the error message.
The message type can be set to one of two values depending upon how the message should be interpreted by the calling application:
g_system_event (i.e. 'System') - to signify a non-business logic type failure, e.g. an oracle error.
g_business_event (i.e. 'Business') - to signify a business logic type failure
The message level can be set to any of the following values, once again this is based upon how the calling application will interpret the event:
g_level_critical (i.e. 'Critical Error')
g_level_error (i.e. 'Error')
g_level_warn ('i.e. Warning')
g_level_info (i.e. 'Information')
g_level_debug (i.e. 'Debug')
 The application error helpk001.g_err_bespoke_routine is raised to signify to the calling application that an error occurred within the PL/SQL routine.
Standard (S7.3g) - When an oracle error occurs within a subprogram then appropriate 'others' exception handling logic should be defined using the generic PL/SQL logging routines.
 
Example
exception
when others then
  l_message := helpk002.f_raise_message (
                 p_type => helpk002.g_system_event,
                 p_level => helpk002.g_level_error,
                 p_message => sqlcode||':'||sqlerrm );
helpk002.p_exit_routine;
raise_application_error(helpk001.g_err_bespoke_routine,
                        l_message);
end;
 
Notes
The message type is set to g_system_event – signifying that it was not as a result of failed business rules.
Notice the direct assignment of the message text to the SQL functions sqlcode and sqlerrm.
Standard (S7.3h) - Where an additional data item context has to be added to a system or business logic error, then the generic PL/SQL logging routines should be used.
The data item text should be in the form of name and value pairing with ':' and ',' separators.
 
Example
exception
when e_error then
  l_message := helpk002.f_raise_message (
                 p_type => helpk002.g_business_event,
                 p_level => helpk002.g_level_error,
                 p_message => l_message,
                 p_data_items => 'Csr Id: '||p_csr_id||', Year: '||p_acy_id);
helpk002.p_exit_routine;
raise_application_error(helpk001.g_err_bespoke_routine,
                        l_message);
...
end;
 
Standard (S7.3i) - When developing an integration module there is an additional set of guidelines that should be followed with regards error handling.
These are detailed in the document 'Event Handling Standards' (see the Appendix).
=========================================================================================================
Cursors and Transaction Management
Category 8 - Cursors and Transaction Management

This section introduces a set of guidelines for consideration in the area of SQL and PL/SQL integration.
8.1 Transaction Control

Oracle is transaction oriented; that is, Oracle uses transactions to ensure integrity. A transaction is a series of SQL data manipulation statements that does a logical unit of work. Simultaneously, Oracle makes permanent or undoes all database changes made by a transaction. You use the following commands to control transactions:
commit - to make permanent any database changes made during the current transaction. Until you commit the changes, other users cannot access the changed data.
rollback - ends the current transaction and undoes any changes made since the transaction began.
savepoint - names and marks the current point in the processing of a transaction - used with the rollback command savepoint undoes part of a transaction.
set transaction - sets transaction properties such as read/write access and isolation level.
Standard (S8.1a) - Do not perform a commit or rollback operation within a PL/SQL subprogram which is called from another routine which is itself attempting to control the transaction.
The only exception to this is in the circumstances where an autonomous transaction has been identified.
8.2 Locking
By default Oracle locks data structures for you automatically at update or delete time. However, you can request specific data locks on rows or tables when it is to your advantage to override default locking. Explicit locking lets you share or deny access to a table for the duration of a transaction.
Standard (G8.2a) - In an online web-based application it is important that an optimistic locking strategy is adopted.
The generic strategy for optimistic locking is presented with the Design Strategies Appendix. It is important to ensure that developed PL/SQL complies with this strategy.
Standard (S8.2b) - Where a pessimistic locking strategy is required the select for update clause should be used.
The select for update statement requests that locks are placed on all rows identified by the query. Where appropriate specify the columns to be updated (i.e. using for update of clause) so that: (a) anyone reading the code knows the intentions of the update; and (b) if the query contains a join to more than one table, Oracle will lock only the rows in those tables that contain any of the specified columns.
Standard (S8.2c) - Where a pessimistic locking strategy is required consider the use of the nowait clause when selecting for update to return control back to the PL/SQL rather than Oracle waiting for the rows to become available,
i.e. allows of for exception processing or controlled subsequent attempts.
8.3 Autonomous Transactions
An autonomous transaction provides a mechanism by which to make and save (or roll back) changes within a single PL/SQL block - without affecting the outer or main transaction. Once started, an autonomous transaction shares no locks, resources, or commit-dependencies with the main transaction.
To make a PL/SQL block an autonomous transaction, include the following declaration:

pragma autonomous_transaction;

Use an autonomous transaction to isolate the effect of commits and rollbacks.
Standard (S8.3a) - Avoid deadlock situations by ensuring that any resources held by the main transaction are not required by the autonomous transaction.
Standard (S8.3b) - Ensure that autonomous transactions are committed or rolled back before exiting the transaction and returning back to the main transaction.
8.4 Managing Cursors
PL/SQL uses two types of cursors: implicit and explicit.
There are three commands to control an explicitly declared cursor:
open - executes the query and identifies the result set, which consists of all rows that meet the query search criteria. For a cursor declared using the for update clause, the open statement also locks those rows.
fetch - used to retrieve the rows into a PL/SQL construct for processing - each fetch retrieves a single row and then advances the cursor to the next row in the result set. The bulk collect clause can also be included used to fetch multiple rows at once into an appropriate PL/SQL collection.
close - used to release the cursor.
Oracle implicitly opens a cursor to process each SQL data manipulation statements not associated with an explicitly declared cursor. You can refer to the most recent cursor as the SQL cursor. Although you cannot use the open, fetch, and close statements to control the SQL cursor, you can use cursor attributes to get information about the most recently executed SQL statement.
There are four cursor attributes:
%found – has a row been fetched in the latest fetch operation
%isopen – is the cursor open. Note – this is always false for implicit cursors.
%notfound – logical opposite of %found
%rowcount – when a cursor (or cursor variable) is opened, this attribute is zeroed. The number is incremented if the last fetch returned a row.
Standard (S8.4a) - In general an explicit cursor should be used. In the majority of situations explicit cursors provide for a more readable code structure than implicit cursors.
The previous claim of performance benefits over implicit cursors no longer holds in recent versions of Oracle. It is now widely accepted that implicit cursors provide a performance improvement in certain situations. This performance gain is in general not thought to be sufficient to merit a rethink of coding standards. However, the situation described below has been identified as one in which it would be reasonable to adopt an implicit cursor in preference to an explicit one.
A select has been identified which will return one or no rows, i.e. there is no requirement to handle a too_many_rows exception. Such a query is generally testing for the existence of data, counting a number of rows, or getting a single row. Where a result of no_data_found should not terminate the subprogram then the implicit cursor should be placed within a PL/SQL block and the exception handled locally.
 
Example - Implicit Cursor
l_no_applications := false;
begin
  select sap.acy_id,
         sap.lea_code
  into l_acy_id,
       l_lea_code
  from support_applications sap
  where sap.csr_id = l_csr_id
  and rownum = 1;
exception
  when no_data_found then
    l_no_applications := true;
end;
if l_no_applications then ...
 
Note - if in the above example the exception handler was not declared then it would raise an exception at the subprogram level, i.e. subprogram processing would terminate. The localised 'no data found' exception handler is an acceptable exception to the generic standard S7.1a.
Standard (S8.4b) - When declaring an explicit cursor with bind variables, always pass associated parameters into the cursor.
Note - parameters can only be in parameters.
 
Example
cursor c_ipw (p_pwd invalid_passwords.password_string%type) is
  select ipw.password_string
  from invalid_passwords ipw
  where ipw.password_string = p_pwd;
 
Standard (S8.4c) - when opening an explicit cursor with parameters, declare the parameters in accordance with the naming conventions discussed previously.
This will generally avoid confusion and will distinguish between the formal cursor parameters and the PL/SQL variables referred to in the cursor open statement.
 
Example
cursor c_ipw (p_pwd invalid_passwords.password_string%type) is
  select ipw.password_string
  from invalid_passwords ipw
  where ipw.password_string = p_pwd;
 
open c_ipw(l_user_pwd);
 
Standard (S8.4d) - Use the cursor attribute %found or %notfound to detect the failure of a cursor fetch to return a row.
 
Example
fetch c_ipw into r_ipw;
if c_ipw%notfound then ...
 

Standard (S8.4e) - when fetching data from a cursor it should be fetched into a record defined from that cursor with %rowtype,
i.e. it should not be into a hard-coded list of variables.There are a few exceptions to the above, e.g. a fetch into a single variable to determine the existence of a record or to retrieve a sequence number.
Standard (S8.4f) - Where cursor bulk processing is not appropriate, use the cursor for loop construct to control row-by-row processing of a cursor where there are multiple rows being returned.
It simplifies the coding required, i.e. it replaces the need for the open, fetch, and close statements, and implicitly declares its loop index as a %rowtype record. Note - the record is defined only inside the loop.
 
Example
declare
  cursor c_asa (p_sap_id support_applications.id%type) is
    select asa.id,
           asa.aty_id,
           asa.relationship
    from assessment_addresses asa
    where asa.sap_id = p_sap_id
    and asa.aty_id in (4,5);
begin
  for r_asa in c_asa(p_sap_id) loop
    if lower(r_asa.relationship) = lower(p_relationship) then
    ...
    else
    ...
    end if;
  end loop;
end;
 
Note - if the for loop is exited prematurely or by exception, then the cursor also is closed automatically
Standard (S8.4g) - Use aliases for expressions within a cursor to allow for ease of reference to a corresponding cursor record.
 
Example
declare
  cursor c_asa (p_sap_id support_applications.id%type) is
    select asa.id,
           asa.aty_id,
           asa.relationship,
           nvl(asa.address_matched_flag,'N') matched_flag
    from assessment_addresses asa
    where asa.sap_id = p_sap_id
      and asa.aty_id in (4,5);
begin
  if r_asa.matched_flag = 'Y' then ...
end;
 
Standard (S8.4h) - If a value is required from the result of an insert then use the returning clause within update, delete and insert statements to retrieve information about modified rows.
 
Example
insert into customers 
  (id,
   surname,
   forenames)
values
  (csr_id_seq.nextval,
   'CUSTOMER',
   'FIRST')
returning id into l_csr_id;
 
Guideline (G8.4a) - Where the result set of a query has to be processed within a PL/SQL block, consider the use the bulk collect clause within the select to deposit multiple rows of data to pre-defined collections in a single request to the RDBMS.
This executes a single fetch and therefore cuts down on the number of SQL to PL/SQL context switches.
 
Example
open c_emp;
fetch c_emp bulk collect into t_empnos,t_enames,t_hire_dates;
 
Standard (S8.4i) - Ensure that a cursor is closed as soon as processing of that result set has complete.
Each cursor uses memory so closing it allows Oracle to recover it.
8.5 Cursor Variables (ref cursor)
Cursor variables are used to pass query result sets between PL/SQL stored subprograms and various clients. Basically the cursor variable is a pointer to the query work area in which the result set is stored. There are three statements used to control a cursor variable:
open-for - associates a cursor variable with a multi-row query, executes the query, and identifies the result set.
fetch - retrieve a row from the result set
close - close the cursor variable.
Standard (S8.5a) - Adopt the generic layout and commenting strategies and the naming conventions as proposed previously.
 
Example
type ccare_exception_r_type is record ( 
  id ccare_est_exceptions.id%type,
  start_date ccare_est_exceptions.start_date%type);
 
type ccare_exception_rc_type is ref cursor return
  ccare_exception_r_type;
 
type appln_rc_type is ref cursor return applications%rowtype;
 
rc_ccare_exceptions ccare_exception_rc_type;
...
--
-- retrieve the list of childcare exceptions for the
-- specified support application
--
open rc_ccare_exceptions for
  select cee.id,
  cee.start_date
from ccare_est_exceptions cee,
     ccare_app_child_estimates ccc
where cee.ccc_id = ccc.id
  and ccc.sap_id = l_sap_id;
...
--
-- retrieve the list of customers based on the
-- dynamically constructed customer filter
--
open rc_customers for l_sql_statement 
  using l_users_lea_code, p_art_id;
...
fetch rc_customers into r_customers;
...
fetch rc_customers bulk collect into t_customers;
...
close rc_customers;
 
Notice in the above examples:
The ref cursor type is declared and then the cursor variable associated with that type.
The cursor variable can be used to open a SQL statement which has been defined dynamically and written to a string variable.
The fetch operation can return into a collection using the bulk collect mechanism
Standard (S8.5b) - Where possible use strong reference cursor types, i.e. those which specify a return type.
Strongly typed cursor variables can only be associated with type-compatible queries and so although they are less flexible, they are less error prone. An exception to this would be the association of a cursor variable with a dynamic SQL string.
Standard (S8.5c) - Ensure that a cursor variable is closed as soon as processing of that result set has complete. Each cursor uses memory so closing it allows Oracle to recover it.
8.6 Dynamic SQL

Dynamic SQL is basically the building and processing of SQL statements at run time. Dynamic SQL statements or PL/SQL blocks are stored in character strings built at run time. The strings can also contain placeholders for bind arguments (each prefixed by a colon).
Standard (S8.6a) - Consider the use of dynamic SQL in the following situations:
A single query would involve overly complicated OR conditions to provide for the query permutations suggested within the PL/SQL business logic
Coding individual cursors for each query permutation suggested within the business logic would prove excessive.
Standard (S8.6b) - Do not hardcode the value of variables within the SQL text - continue to use bind variable placeholders.
 
Example - Execute Immediate
l_sql_stmt := 'update support_applications ';
l_sql_stmt := l_sql_stmt || 'set lea_code = :p_lea_code ';
l_sql_stmt := l_sql_stmt || 'returning id into :p_sap_id';
 
execute immediate l_sql_stmt using l_lea_code 
returning into l_sap_id;
 
Note - The execute immediate statement prepares (parses) and immediately executes a dynamic SQL statement or an anonymous PL/SQL block.
 
Example - Open -for
declare
  type sap_rc_type is ref cursor; 
  rc_sap sap_rc_type;
  l_csr_id number := 123456;
  l_sql_stmt varchar2(500);
begin
  l_sql_stmt := 'select sap.id, ';
  l_sql_stmt := l_sql_stmt || 'lea_code ';
  l_sql_stmt := l_sql_stmt || 'from support_applications sap ';
  l_sql_stmt := l_sql_stmt || 'where sap.csr_id = :p_csr_id';
  ...
  open rc_sap for l_sql_stmt using l_csr_id;
  ...
  fetch rc_sap into l_sap_id, l_lea_code;
  ...
  close rc_sap;
end;
=========================================================================================================
Application Design
Category 9 - Application Design

This section introduces a set of guidelines to consider when creating a code base to provide the necessary PL/SQL and SQL support for an application.
9.1 Packages
The following points should be considered when designing a package.
Guideline (G9.1a) - A package should group components which provide similar functionality, i.e. types, variables, constants, cursors, exceptions, procedures and functions.
Guideline (G9.1b) - Package specifications should only contain the types, items and subprograms that must be visible to users of the package.
Also, to reduce the need for re-compiling when code is changed, place as few items as possible in a package specification. Changes to a package body do not require Oracle to re-compile dependent procedures. However, changes to a package specification require Oracle to re-compile every stored subprogram that references the package.
9.2 Procedures and Functions
The following points should be considered when designing a procedure/function.
Guideline (G9.2a) - Whenever possible encapsulate and name business rules and formulas behind functions.
Code is much easier to understand and reuse when it has been modularised in this fashion.
 
Example
function f_formatted_surname (p_surname in customers.surname%type) 
return varchar2;
 
function f_grant_entitlement (p_sap_id in applications.id%type) 
return number;
 
function f_fyfc_eligible (p_sap_id in assessments.sap_id%type,
p_ash_seq in assessments.sas_seq%type)
return varchar2;
 
Guideline (G9.2b) - Avoid side-effects in procedures and functions.
Each procedure/function should be designed in such a way that it has a single, clearly defined purpose. Avoid the temptation to include extraneous functionality inside a program. Such functionality makes maintenance more difficult.
Guideline (G9.2c) - Similarly avoid large functions and procedures - modularise code to split up larger subprograms.

Guideline (G9.2d) - Limit a function to having a single output, i.e. the return value.
This means that the function would only have in parameters. This avoids obscuring the usage of the function. There may be exceptions to the above, e.g. returning an error code in addition to the function output.
Standard (S9.2a) - Whenever possible ensure that there is a single return statement within a function,
i.e. avoid multiple function exit points. In the majority of circumstances this can be effectively coded using local variables. There are situations where a delay to return from a function would significantly restructure the code that follows. These exceptions would potentially require multiple return statements.
Standard (S9.2b) - Modularised code will identify library functions and procedures
- ensure that library functions are used where appropriate, i.e. do not re-develop common routines.
Standard (S9.2c) - where flexibility is anticipated around threshold and other constant values, these should where possible not be hardcoded.
If some degree of hardcoding cannot be avoided then it should be coded in such a way as to minimise change if and when the change is required to be implemented.
Guideline (G9.2e) - Where a function will be called either directly or indirectly from a SQL statement establish the purity of the function.
The purity of a function refers to the side effects of that function on database tables or package variables. Prior to Oracle8i, Oracle leveraged the PL/SQL compiler to enforce restrictions during the compilation of a stored function or SQL statement. A user-written function can now be called from a SQL statement without any compile-time checking of its purity: pragma restrict_references is no longer required on functions called from SQL statements. However, pragma restrict_references remains available as a means of asking the PL/SQL compiler to verify that a function has only the side effects that you expect. SQL statements, package variable accesses, or calls to functions that violate the declared restrictions will continue to raise PL/SQL compilation errors to help you isolate the code that has unintended effects.
9.3 Functionality
It is imperative that the code which is developed provides the desired functionality.
Standard (S9.3a) - the developed code should implement the functionality specified in the functional specification and design layout documentation.
=========================================================================================================
10 Child Pages
      Appendix
      Application Design
      Commenting
      Cursors and Transaction Management
      Defining Variables and Data Structures
      Exceptions
      Layout
      Naming Conventions
      PL/SQL Control Structures
      SQL Statements
=========================================================================================================
Appendix
Appendix A - Design Strategies

This section provides more detail of several application design strategies referred to within the document which have an impact on PL/SQL code being developed.
A.1 Optimistic Locking
Optimistic locking does not lock records when they are read. It proceeds on the assumption that the data being updated has not changed since the read. Since no locks are taken out during the read, it does not matter if the user goes to lunch after starting a transaction.
However, to ensure concurrency control - i.e. ensure that data being written back to the database is consistent with what was read from the database in the first place - an update key is read during the initial data get and checked during the data set. This consistency key is only updated upon a successful set operation. Failed set operations require a subsequent get to refresh the data including the consistency key.

Example One - Single Table Update

In this example the application function requires to make an update to a single table.
Data Access Layer
Get Method - select all relevant data (including the VERSION_NO) from the table.
Set Method - attempt to update the table with the changed data - passing in a value for VERSION_NO which is the value retrieved from the Get method plus one. Where a set fails with a 'Concurrent Update Failure' the data will have to be refreshed and the update re-issued via a subsequent Set Method call. Complete the transaction with a commit.
Database
Each table which can be updated online has the following:
Table Audit Column – a mandatory VERSION_NO audit column.
Table Before Insert Trigger – to initialise the VERSION_NO to 1.
Table Before Update Trigger – to only allow the update if the value passed in for VERSION_NO is equal to the current value plus one. All other updates should fail with a ‘Concurrent Update Failure’.

Example Two – Multiple Table Update

In this example the application function requires to make an update to more than one table and the integrity across the tables must be assured. In this situation there is generally a master table with which the tables being updated are all related either directly or indirectly.

Data Access Layer
Get Method - select all relevant data (including the VERSION_NOs) from all the relevant tables
Set Method - attempt to update the master table with the changed data - passing in a value for VERSION_NO which is the value retrieved from the Get method plus one. Where a set fails with a 'Concurrent Update Failure' the data will have to be refreshed and the update re-issued via a subsequent Set Method call. If update is successful then continue within the same transaction to perform the updates of the other tables in the same fashion with the incremented VERSION_NO. If all updates succeed then complete the transaction with a commit.

Database

Each table which can be updated online has the following:
Table Audit Column - a mandatory VERSION_NO audit column.
Table Before Insert Trigger - to initialise the VERSION_NO to 1.
Table Before Update Trigger - to only allow the update if the value passed in for VERSION_NO is equal to the current value plus one. All other updates should fail with a 'Concurrent Update Failure'.
It is important to note that the update does not perform a nowait operation. The database will lock the affected rows automatically for the period of the transaction, i.e. until the commit. This means that concurrent Set requests will wait until the update is released (i.e. committed) before ultimately failing with a 'Concurrent Update Failure'. On the plus side with this implementation the concurrent update checking is invisible with the exception of incrementing the VERSION_NO.
 	
Appendix B - Analysing SQL
 
B.1 - Using sql_trace

Tracing SQL and PL/SQL
To trace SQL and PL/SQL from your current SQL session:

- Identify the eventual destination of the trace .trc file:

SQL> select value from v$parameter where name = 'user_dump_dest';

- Enable SQL Trace for the session:

SQL> alter session set sql_trace = true;

- Execute the SQL or PL/SQL to be traced.

- Disable SQL Trace for the session:

SQL> alter session set sql_trace = false;

- To format the trace file for viewing:

tkprof [trace filename] [tkprof filename]
- To format the trace file for viewing:

tkprof [trace filename] [tkprof filename] explain=[user/password]

- To include the plans for the included queries within the tkprof output – add the following clause to the above tkprof statement:

explain=[user/password]
Where the user account will be used to execute the explain plan command.

To trace SQL and PL/SQL of another SQL session:

- Enable SQL Trace for the session:

SQL> execute dbms_system.set_ev([P1],[P2],10046,[P3],’’);
Where 
P1 = Session Identifier (sid from v$session)
P2 = Serial Number (serial# from v$session)
P3 = Trace Level (4=SQL, 8= (and) Wait Events, 12= (and) Binds)

- Execute the SQL or PL/SQL to be traced.

- Disable SQL Trace for the session:

SQL> execute dbms_system.set_ev([P1],[P2],10046,0,’’);

- Thereafter the tkprof can be used as above to format the trace output.

Interpreting TKPROF output
TKPROF lists the statistics for a SQL statement returned by the SQL trace facility in rows and columns. Each row corresponds to one of three steps of SQL statement processing:
- PARSE – translation of the SQL statement into an execution plan, including security and dependency checking.
- EXECUTE – actual execution of the statement: for insert, update and delete statements this step modifies the data; for select statements this step identifies the selected rows.
- FETCH – retrieves rows returned by a query, i.e. for select statements only.
Each column corresponds to one of the following statistics in the context of the above SQL statement processing steps:
- COUNT – number of times the SQL statement was parsed, executed, and fetched.
- CPU – total CPU time in seconds
- ELAPSED – total elapsed time in seconds
- DISK – total number of data blocks physically read from the datafiles on disk
- QUERY – total number of blocks retrieved in consistent mode. That could possibly entail reading rollback segment to reconstruct the data.
- CURRENT – total number of blocks read as they are (either in the datafile or still in the buffer cache). Current gets might entail waiting for some data which is being modified by another user (usually for update).
- ROWS – total number of rows processed by the SQL statement. For select statements, the number of rows returned appears in the FETCH step. For update, delete, and insert statements, the number of rows processed appears for the EXECUTE step.
An example of the above for a select statement would be:
 
Example
call    count  cpu       elapsed   disk       query      current    rows
------- ------ -------- ---------- ---------- ---------- ---------- ----------
Parse   1      19.52    19.54      0          0          0          0
Execute 1      9.76     9.76       0          0          0          0
Fetch   43442  7251.68  6894.36    475        43921      0          43442
------- ------ -------- ---------- ---------- ---------- ---------- ----------
total   43444  7280.96  6923.66    475        43921      0          43442
 
During the execution of a SQL statement issued by a user, Oracle must issue additional statements to, for example, allocate space for inserts, or retrieve data dictionary information not available in cache. The statements are known as recursive SQL statements and the associated statistics are clearly marked within the tkprof output.
B.2 - Using Explain Plan
Creating a Plan Table
Should already exist on the database, and it is generally deployed by the DBA. However, the DDL for PLAN_TABLE for the current version of the database is found in the file:
$ORACLE_HOME/rdbms/admin/utlxplan.sql
Populating the Plan Table
To populate the plan table for a particular SQL statement the following syntax is used:
explain plan 
set statement_id = '[Query Id]';
for [Query];
Where [Query] is the user SQL statement and [Query Id] is a unique user-defined identifier for that statement - this isolates the query within a shared plan table. Where the same statement is being executed multiple times - to identify and resolve performance issues - it is important that the previous rows identified by that [Query Id] are deleted from the plan table:
delete from plan_table where statement_id = '[Query Id]';
Displaying the Execution Plan
There are two Oracle supplied scripts to extract formatted explain plans from the plan table. One is form serial plans and the other is for parallel plans.
Serial Plans
To obtain a formatted execution plan for serial plans:
select lpad(' ',2*(level-1))||operation||' '||options
    ||' '||object_name
   ||' '||decode(id, 0, 'cost = '||position) "query plan"
from plan_table
start with id = 0 and statement_id = '&statement_id'
connect by prior id = parent_id and prior statement_id = statement_id;
 	
Appendix C - Coding Suggestions
 
This section presents various suggestions for consideration when coding PL/SQL and SQL modules. These points do not need to be considered during a code review and have been collated for information only.
It is hoped that this section can grow as developers share tips and workarounds for developing within PL/SQL and SQL.
C.1 - SQL Statements

When developing a SQL statement consider the following.
Tip - Adopting the format guidelines (i.e. layout and case) and the bind variable guidelines across the PL/SQL code base for SQL statements may identify identical SQL and therefore directly promote the sharing of SQL in the shared pool area in memory.
Tip - Ensure that date columns are truncated to remove the time component where it is not relevant during a comparison.
Tip - To improve SQL efficiency, use equi-joins whenever possible, i.e. using AND and = to compose a condition. Statements that perform equi-joins on untransformed column values are the easiest to tune.
Tip - Remember that the function != cannot use an index – the index can tell you what is in a table but not what is not. This also includes functions not, and <>.
Tip - Avoid transformed columns in the WHERE clause whenever possible. Any expression using a column, such as a function having the column as its argument, causes the optimiser to ignore the possibility of using an index on that column, unless there is a function-based index defined that can be used. When you need to use SQL functions on filters or join predicates, do not use them on the columns on which you want to have an index; rather, use them on the opposite side of the predicate.
Tip - Use separate SQL statements for different tasks whenever possible instead of creating a complex query to satisfy multiple requirements, e.g. a statement which includes an expensive or construct. If a single SQL statement is required, then consider the use of union all.
Tip - Avoid expensive sorts when they are not explicitly required. For example, a union all in comparison to a union avoids the expensive sort to get rid of duplicates. This is appropriate where the separate queries are mutually exclusive.
Tip - Consider using indexes to avoid the need to perform sorts. Indexes are stored in ascending order by default. If the columns in your order by clause are in the same sequence as the columns in an index, forcing the statement to use that index will cause the data to be returned in the desired order.
Tip - In certain circumstances, it is better to use in rather than exists. In general, if the selective predicate is in the subquery, then use in. If the selective predicate is in the parent query, then use exists.
 
Example _ Using an in
select csr.id,
  csr.surname
from customers csr
where csr.id in (select sap.csr_id
                 from support_applications sap
                  where sap.id = :p_sap_id);
 
 
Example _ Using an exists
select csr.id,
  csr.surname
from customers csr
where csr.art_id = :p_art_id
and exists (select sap.csr_id
            from support_applications sap
            where sap.id = :p_sap_id);
 
Tip - Consider the use of the case statement to combine multiple scans of a table to compute a set of aggregates, i.e. move the specific where conditions into the case statement. Note - the case statement can also make a decode statement more readable. The case statement is more efficient than its decode and multi-statement alternatives.
Tip - It is important that the execution path of the query is understood . Where CBO's chosen access path is not in line with the desired path, based on a knowledge of the application, the developer should consider controlling the path with hints.
Tip - Avoid full-table scans if it is more efficient to get the required rows through an index - ensuring that the index chosen is the most selective. Note - full-table scans are not necessarily a bad thing - in certain situations where all the data has to be accessed anyway or the table is relatively small a full-table scan may be more appropriate.
Tip - Choose the join order so as to join fewer rows to tables in the join order. The goal is to drive from the table that has the most selective filter. This means that there are fewer rows passed to the next step - where this is a join then fewer rows are joined.
Tip - when considering the update of a large number of rows – consider the appropriateness of a single SQL statement to perform the update before bulk collect and row-by-row processing options. More complicated transformations within the update may be performed using case statements. A rownum where condition could also be added to control the commit processing.
 
Example
loop
  update support_applications sap
  set sap.status = 
    case
      when sap.src_type = 1 then 8
      when sap.src_type = 2 and src_date = trunc(sysdate) then 9
      when sap.src_type = 2 and src_date < trunc(sysdate) then 7
    else 8 end,
   sap.last_updated_by = p_user,
   sap.last_updated_date_time = sysdate
  where sap.acy_id = 2004
    and sap.status is null
    and rownum < 10001;
  if l_commit_count > 100 then
    exit;
  end if;
  l_commit_count := l_commit_count + 1;
end loop;
 
Tip - The most effective way of optimizing distributed queries is to access the remote databases as little as possible and to retrieve only the required data, i.e. to filter as much data remotely before joining to local tables.
C.2 - NULL Processing
When coding with the possibility of NULLs it is important to note the following.
Note - A null is never equal to anything else.
 
Example
l_my_string := ' ';
if l_my_string = null then ... -- can never be true.
 
l_max_salary := 0;
if l_max_salary = null then ... -- can never be true.
if null = null then ... -- can never be true.
 
Note - A null is never NOT equal to anything else.
 
Example
l_my_string := 'Test';
l_your_string := null;
if l_my_string != l_your_string then ... -- can never be true.
 
l_max_salary := 1234;
if l_max_salary != null then ... -- can never be true.
if null != null then ... -- can never be true.
 
Note - When you apply a function to null value, your generally receive a null value as a result (with some exceptions).
 
Example
l_my_string := null;
if length(l_my_string) = 0 then ... -- will not work.
 
l_new_value := power(null,10); -- l_new_value is set to null.
 
C.3 - Cursor Processing
When coding cursor statements consider the following.
Tip - when using the current of clause within an update or delete statement, you must use the for update clause to acquire exclusive row locks for the cursor data.
 
Example
declare
  cursor c_sap is
  select sap.id,
    sap.acy_id,
    sap.lea_id
  from support_applications sap
  for update nowait;
begin
  for r_sap in c_sap loop
  ...
    update support_applications
    set lea_code = l_new_lea
    where current of c_sap;
  end loop;
  ...
end;
 
Note - if commit processing was required in between updates then the above example would result in a PL/SQL exception. An alternative - which would NOT lock the rows - would be to use rowid.
 
Example
declare
  cursor c_sap is
    select sap.id,
      sap.acy_id,
      sap.lea_id,
      sap.rowid
  from support_applications sap;
begin
  for r_sap in c_sap loop
    ...
    update support_applications
    set lea_code = l_new_lea
    where rowid = r_sap.rowid;
  end loop;
  ...
end;
 

Tip - to answer the question "is there at least one row matching certain criteria?" the %found attribute of the cursor should be checked.
Tip - Where there is a requirement to modify (insert, delete, or update) large volumes of rows with a non-trivial change (i.e. differences at a row level) then the use of the forall statement should be considered. This statement can dramatically improve DML performance by reducing the number of 'context switches' between the PL/SQL statement executor and the SQL engine.
 
Example
forall l_index in t_users.first .. t_users.last
  update borrowings brw
  set brw.borrow_date = sysdate,
      brw.borrow_id = t_users(l_index)
  where brw.isbn = t_isbns(l_index);
 
  if sql%bulk_rowcount(3) = 0 then ...
 
Note - the bulk_rowcount attribute is used to check whether the third update statement actually updated any rows.
Tip - When coding a dynamic cursor using the open-for construct with bind variables, only unique placeholders in a dynamic statement are associated with bind arguments in the using clause by position. So if the same placeholder appears two or more times in a PL/SQL block, all appearances correspond to one bind argument in the using clause.
C.4 - Collections and Records

A collection is an ordered group of elements, all of the same type. It is a general concept that encompasses lists, arrays, and other familiar datatypes. Each element has a unique subscript that determines its position in the collection.
Although collections can have only one dimension, you can model multi-dimensional arrays by creating collections whose elements are also collections.
To use collections in an application, you define one or more PL/SQL types, then define variables of those types. You can define collection types in a procedure, function, or package and you can pass collection variables as parameters.
Collection Types
Nested Tables
A nested table is an unbounded array with standard integer subscripts starting at one. Elements can be deleted from a nested table using the built-in procedure delete. This would result in gaps in the index, but the built-in function next allows you to iterate over any series of subscripts.
Nested tables can be stored in a database column.
A nested table is defined using the syntax:

type type_name is table 
of element_type [not null];

where type_name is the type specifier used later to declare collections of that type, and element_type is any PL/SQL datatype except ref cursor.

Varrays
A varray is an array which has its dimension bound at declaration. It has standard integer subscripts starting at one. Individual elements cannot be deleted from a varray.
All elements of a varray must be updated or retrieved at the same time.
A varray is defined using the syntax:

type type_name is varray (size_limit)
of element_type [not null];

where type_name and element_type are as per nested table type, and size_limit is a positive integer literal representing the maximum number of elements in the array.

Associative Arrays (or Index-by Tables
Associative arrays are sets of key-value pairs, where each key is unique and is used to locate a corresponding value in the array. The key can be an integer or a string.
Associative Arrays cannot be stored in a database column.
An associative array is defined using the syntax:

type type_name is table
of element_type [not null]
index by key_type;

where type_name and element_type are as per nested table type, and key_type is standard or user-defined type.

Constructors
To initialise a nested table or varray, you use a constructor – a system defined function with the same name as the collection type. This function constructs collections from the elements passed to it.
 
Example
declare
  type x_t_type is table
    of varchar2(10);
  t_x1 x_t_type;
  t_x2 x_t_type := x_t_type();
begin
  t_x1 := x_t_type('ONE','TWO');
end;
 
Note - t_x2 is an empty but not-null collection.

Referencing Collections
To reference an element of a collection you specify its subscript using the syntax
collection_name (subscript)
Entries within a nested table can be looped through using a for construct as follows:
 
Example
for index_name in collection_name.first .. 
    collection_name.last loop
  if collection_name (index_name) = value then
    expression;
  end if;
end loop;
 
Equally the reverse construct can be used to traverse the table in reverse subscript order as follows:
 
Example
for variable_name in reverse collection_name.first .. 
    collection_name.last loop
 

Assigning Collections
To assign the value of an expression to a specific element use the syntax:
collection_name (subscript) := expression;
Collection Methods
The following collection methods are available. These methods are called using dot notation, i.e. collection_name.method_name[(parameters)].
- exists - checks whether an element exists within a collection.
 If courses.exists(l_index) then
courses(l_index) := new_course;
end if;
- count - returns the number of elements that a collection currently contains.
l_course_count := courses.count;
- limit - for varrays this method returns the maximum number of elements that a varray can contain.
l_course_max := courses.limit;
- first and last - returns the lowest and highest index numbers in a collection. For example, the following identifies a collection with only one element.
if courses.first = courses.last then
- prior and next - returns the preceding and succeeding index in a collection. For example, the following assigns element l_index to itself.
projects(l_index) := projects.prior(projects.next(l_index));
- extend - to increase the size of a varray.
courses.extend; -- appends 1 null element
courses.extend(2); -- appends 2 null elements
courses.extend(5,1); -- appends 5 copies of element 1
- trim - to remove an element from a collection.
courses.trim; -- removes 1 element from end of collection
courses.trim(2); -- removes 2 elements from end
- delete - to remove an element from a collection - cannot delete an element from a varray.
courses.delete; -- deletes all elements from a collection
courses.delete(2); -- deletes element 2
courses.delete(3,6); -- delete elements 3 through 6
Collection Exceptions
The following collection exceptions are predefined.
- collection_is_null - attempt to operate on a collection which is null. 
- no_data_found - a subscript designates an element that was deleted or non-existent
- subscript_beyond_count - a subscript exceeds the number of elements in a collection
- subscript_outside_limit - a subscripts is outside the allowed range 
- value_error - a subscript is null or not convertible to the key type.
 	
Appendix D - Development Tool
 
This section presents guidelines and tips around the configuration and use of applications to support PL/SQL and SQL development.
D1 - TOAD
Using TOAD, developers can build, test, and debug PL/SQL packages, procedures, triggers, and functions.
It is hoped that this section can grow as developers share tips and workarounds for developing using TOAD.
Code Layout
It is important that when using any editor that any imposed layout setting comply with the standards and guidelines where appropriate. This section identifies those layout options which are configurable within TOAD. Setting these will allow the associated editors to comply with the standards by default and thus minimise any code rewrites subject to code review.
From the TOAD Options menu item - within the View menu - select Formatting Options (button at the foot of the pop-up window). From this interface set the following Formatting options as indicated:
- Tabs in place of spaces - ensure that tabs are NOT enforced.
- Exclusively lowercase - ensure keyword etc are lowercase.
- Package Templates - within the Procedure Editor Options section add PACKAGE and PACKAGE BODY Proc Templates to include the template text within the previous templates section. Noting that:
• %YourObjectName% can be substituted for [module name]
• %USERNAME% can be substituted for [module author]
In addition, templates may also be specified for functions and procedures in the same fashion.
Explain Plan
Within the TOAD interface there is the ability view the execution plan for a query. In order to enable this processing the following configuration options should be set up.
1. From the TOAD Options menu item - within the View menu - select Oracle under the Monitors section. The Explain Plan Table name should be set to PLAN_TABLE and the User name for Explain Plan should be set to the Users NT login (this allows the plan results to be distinguished from other users).
 	
Appendix E - Related Documents
 
This section presents documents referred to within this document.
Event Handling Standards
This document lays down standards for the use of the Oracle PL/SQL packages helpk002 and helpk003.
Location: P:\projects\Modernising Goverment\Build & Implement\Technical Stream Files\02 Documents\11 - High level designs\CLASS interfaces work\Event Logging
Oracle PL/SQL Best Practices (ISBN 0-596-00121-5)
This book is a summary of the best practices in the program development process as proposed by Steven Feuerstein. Several of the suggestions and guidelines were sourced from this text.
Location: External Textbook.
=========================================================================================================
DDL Standards
DDL Standards

This section details the set of design standards and guidelines to be checked during the design review process.
Adherence to the identified set of standards will determine whether any design work is allowed to progress through the review stage to the next stage in the development lifecycle.
The following list identifies categories of standards and guidelines against which the review item may be checked.

Logical Data Modelling
Entities
Attributes
Attribute Domains and Reference Data
Entity Relationships
Unique Identifiers
Physical Data Modelling
Physical modelling tasks
Tables and Columns
Primary and Unique Keys
Foreign Keys
Indexes
Triggers
Sequences
Views
Script templates and file extensions
 
Each category above has been presented as a sub-section within this section. Each will detail the set of applicable standards and guidelines:

Standard - where this appears, adherence is mandatory and non-compliance should require rework before the code can progress through this stage in the development lifecycle.
Guideline - where this appears, adherence is optional. A guideline should be viewed as a best practice suggestion from the TDL's. These guidelines are generally to do with a particular aspect of coding style. Non-compliance would not necessarily result in a failed code review unless the chosen style either compromised readability, maintainability, or efficiency.
In addition to the above categorisation, each standard and guideline will have an associated unique reference. This reference will be used to flag non-compliance with that particular standard or guideline when completing a Design Review template. For example, G1.1c identifies the third guideline in category 1 subsection 1. Likewise, S3.2a identifies the first standard in category 3 subsection 2.


Category 5 - Physical Model Implementation
The 'Server Model' tab of the Design Editor allows the final touches to be added to the database object to be created in terms of final physical implementation details. Once complete, generated scripts can then be used to form the basis of a an implementation plan, with as minimal as possible changes made to the scripts after generation. 
5.1 Oracle Databases 
A database must be created to hold the objects to be generated. The information stored within Designer will never be used to generate the actual physical database but will be used as a placeholder within Designer to generate the database objects. The following table details the information required to create a database. Mandatory items are underlined in bold 
Database Property Value

Name The name of the database. Normally the name of the database which the application will be developed on e.g. FSFOP
Standard (S5.1a) - Ensure all applications have a database created within the DB Admin area of the Design Editor. 
All other properties of the database should be left at their default values. 
5.2 Database Users 
Within the created database a number of users have to be created, which will hold details of the objects to be generated. As a minimum the following users must be created
• A Data Warehouse user, known as WAREHOUSE 
• An application owner user, e.g. XXEM for EMA, XXSL for SFD 
For each user created the following table details the information required to create a new database user. 
Standard (S5.2a) - Ensure the minimum number of users are created within the application and all mandatory properties are populated. 
Property Value

Name The name of the database user
Initial Password Populate with a value
All other properties of the database should be left at their default values. 
5.3 Tablespaces 
Within the created database the following tablespaces should be available. These should be referenced from the Common Development application container. 
• &TS_DATA_LARGE 
• &TS_DATA_MEDIUM 
• &TS_DATA_SMALL 
• &TS_INDEX_LARGE 
• &TS_INDEX_MEDIUM 
• &TS_INDEX_SMALL 
The use of the '&' character allows the correct physical tablespace name to be entered by the DBA team when the generated script is run.
Standard (S5.3a) - Ensure that an application has the minimum set of tablespaces set up. 
5.4 Object Grants 
As a minimum all database Tables must have 'SELECT' granted to the 'WAREHOUSE' user. This ensures that all database objects implemented can be accessed by the data warehouse uploads 
Standard (S5.4a) - Ensure the Warehouse user has been granted SELECT on all tables. 

Adding Sizing information to Database Objects 
5.5 Tables
Associated Tablespace 
The tablespace, which was identified during the table sizing exercise ( see section 4.2 ), should be associated with the table. 
Standard (S5.5a) - Ensure the table has the tablespace identified within the sizing exercise associated with it. 
Future Growth 
Where the percentage growth of the row is greater than 10% (the default) this growth should be identified by setting the PCTFREE property of the table implementation. Consultation with the TDA / DBA may be required. 
Standard (S5.5b) - Ensure the defined table row growth is reflected in the PCTFREE property of the table implementation. 
Concurrent Updates 
In order to simplify the setting of the INITRANS parameter for a table, it should always be set to 9 regardless of whether the table will be concurrently updated or not. 
Standard (S5.5c) - Ensure the INITRANS property for a table is set to 9.
5.6 Indexes
Associated Tablespace 
The tablespace, which was identified during the index sizing exercise ( see section 4.6 ), should be associated with the table. 
Standard (S5.6a) - Ensure the index has the tablespace identified within the sizing exercise associated with it. 
Future Growth 
Where the percentage growth of the row is greater than 10% (the default) this growth should be identified by setting the PCTFREE property of the index implementation. Consultation with the TDA / DBA may be required. 
Standard (S5.6b) - Ensure the defined index growth is reflected in the PCTFREE property of the table implementation. 
Concurrent Updates 
In order to simplify the setting of the INITRANS parameter for an index, it should always be set to 9 regardless of whether the underlying table will be concurrently updated or not. 
Standard (S5.6c) - Ensure the INITRANS property for an index is set to 9.
5.7 Sequences 
The following table details the lower level information required to implement a Sequence. Mandatory items are underlined in bold 
Standard (S5.7a) - Ensure all mandatory properties of a sequence implementation are populated. 
Sequence Attribute Value

Start Value 1, unless there is a specific reason not to start the sequence at 1
Increment 1, unless there is a specific reason not to increment the sequence by 1
Cache Value Where order is NOT required, this should be set to the highest anticipated allocation per day. 
Note - it is important to specify the cache value in this manner to alleviate performance issues. 
Always discuss the setting of the cache size with the TDA / DBA 
Cycle No, unless there is a specific reason to cycle the sequence
Order No
Minimum 1, unless there is a specific reason to have a different minimum value
Maximum This should match the maximum value which can be held in the column that the sequence is populating e.g. if the populated column is NUMBER(6) then the maximum value of the sequence should be 999999.














Appendix A - Designer Scripts in PVCS
This appendix details the types of files which must be stored in PCVS to support a physical data model, and their relationship with the files generated from Oracle Designer. 
File Headers 
All database scripts stored in PVCS must have a header, with all details completed, as highlighted in the following example 
--############################################################################ 
--# 
--# name : XXEM_INCOME_TYPES_3_TAB.sql 
--# 
--# author : Peter Bruning 
--# 
--# description : Initial table create. 
--# 
--# PVCS : $Revision: $ 
--# $Modtime: $ 
--# $Author: $ 
--# 
--########################################################################### 
--# Modification History 
--# 
--# $Log: $ 
--# 
--############################################################################
The PVCS items bound within '$' are populated automatically by PVCS when the script is added. 
Tables, Indexes and Constraints 
Designer generates Tables, Indexes and Constraints into separate files as follows 
• .tab - Table definition 
• .ind - Index definition 
• .con - Constraint definition 
These files must be combined into one file for creation in PVCS. If any DDL command requires the name of a tablespace, which has been generated as part of the script from Designer, to be qualified then a SQL ACCEPT command should be inserted prior to the execution of the DDL command as shown in the example below 
accept ts_data_small prompt "Enter small data tablespace name >"

PROMPT Creating Table 'XXEM_APPLICATIONS'
CREATE TABLE XXEM_APPLICATIONS
(ID NUMBER(11) NOT NULL ,
RECEIVED_DATE DATE NOT NULL ,
CSR_ID NUMBER(11) NOT NULL ,
ACY_ID NUMBER(4) NOT NULL ,
SCH_ID NUMBER(3) NOT NULL ,
CURRENT_WORK_STAGE_TYPE NUMBER(3) NOT NULL ,
CREATED_BY VARCHAR2(30) NOT NULL ,
CREATED_DATE_TIME DATE NOT NULL ,
LAST_UPDATED_BY VARCHAR2(30) ,
LAST_UPDATED_DATE_TIME DATE
)
INITRANS 9 TABLESPACE &ts_data_small
/
A table script should only contain the DDL commands to a single table. 
The first instance of the table script should be named as follows ( in upper case ) 
{Table Name}_1_TAB.SQL 
e.g. 
XXEM_APPLICATIONS_1_TAB.SQL 
Any further modifications to the table will result in a new script being created, incrementing the script number to 2 and so on. 
Sequences 
Designer generates sequences into a .sqs file. 
The first instance of a sequence script should be named as follows ( in upper case ) 
{Sequence Name ( minus the _SEQ )}_1_SEQ.SQL 
e.g. 
LEC_ID_1_SEQ.SQL 
Any further modifications to the sequence will result in a new script being created, incrementing the script number to 2 and so on. 
Synonyms 
Designer generates sequences into a .syn file. 
Designer will also write all synonyms within a generated implementation into the same file. These must be split into a separate file for each object generated. 
The first instance of a synonym script should be named as follows ( in upper case ) 
{Object Name}_1_SYN.SQL 
e.g. 
XXEM_APPLICATIONS_1_SYN.SQL 
LEC_ID_SEQ_1_SYN.SQL 
Any further modifications to the synonym will result in a new script being created, incrementing the script number to 2 and so on. 
Views 
Designer generates views into a .vw file. Designer will also write all views within a generated implementation into the same file. These must be split into a separate file for each view generated. 
The first instance of a view script should be named as follows ( in upper case ) 
{View Name}_1_V.SQL 
e.g. 
XXEM_IVR_STATISTICS_V_1_V.SQL 
Any further modifications to the view will result in a new script being created, incrementing the script number to 2 and so on. 
Materialised Views 
Designer generates materialised views into a .snp file. Designer will also write all views within a generated implementation into the same file. These must be split into a separate file for each view generated. 
The first instance of a view script should be named as follows ( in upper case ) 
{Materialised View Name}_1_MV.SQL 
e.g. 
XXSL_SUPPORT_ASSESSMENTS_MV_1_MV.SQL 
Any further modifications to the materialised view will result in a new script being created, incrementing the script number to 2 and so on. 
Triggers 
Designer generates triggers into a .trg file. Designer will also write all triggers within a generated implementation into the same file. These must be split into a separate file for each trigger generated. 
The first instance of a trigger script should be named as follows ( in upper case ) 
{Trigger Name}_1_TRG.SQL 
e.g.
COF_BIR_1_TRG.SQL 
Any further modifications to the trigger will result in a new script being created, incrementing the script number to 2 and so on. 
Domains 
Designer generates Domain values into a .avt file. Designer will also write all domains within a generated implementation into the same file. These must be split into a separate file for each domain generated. It will be necessary to change the table name in the generated script from {Application_system_name}_REF_CODES to the appropriate reference codes table e.g. XXFE_REF_CODES
The first instance of a domain script should be named as follows ( in upper case ) 
{Domain Name}_1_DAT.SQL 
e.g.
XXFE_PAYMENT_STATUS_TYPE_1_DAT.SQL 
Any further modifications to the domain will result in a new script being created, incrementing the script number to 2 and so on. 
Object Types 
Designer generates object types into a .typ file. Designer will also write all object types within a generated implementation into the same file. These must be split into a separate file for each object type generated. 
The first instance of a object type script should be named as follows ( in upper case ) 
{Object Name}_1_TYP.SQL 
e.g. 
XXCO_GROUP_MEMBERSHIP_O_TYPE_1_TYP.SQL 
Any further modifications to the object type will result in a new script being created, incrementing the script number to 2 and so on. 
Database Contexts 
Although Designer does not allow database contexts to be held within the repository they are used within SLC's applications. Therefore the following format should be used for any context objects created 
The first instance of a database context script should be named as follows ( in upper case )
{Context_Name}_1_CTX.SQL
e.g.
XXSL_CUSTOMER_SEARCH_CTX_1_CTX.SQL
Appendix B - Attribute Abbreviations 
The following tables details the acceptable abbreviations for entity attributes and table columns.
Abbreviation Meaning

NMTO Non Means Tested Only
NINO National Insurance Number
HE Higher Education
LEA Local Education Authority
COC Change of Circumstances
IVR Interactive Voice Recognition
ART Automated Response Technology
FYFC Final Year Fee Concession
PREV Previous
AMT Amount
CURR Current
ORSD Online Request for Security Details
 
No labels
3 Child Pages
Page: Logical Data Modelling
Page: Physical Data Modelling
Page: Script templates and file extensions
=========================================================================================================
Logical Data Modelling
1 - Logical Data Modelling

This section relates to creation of the data models in designer
Entities
2.1 Application Entities 
Entity Details
The following table details the information required to create a new entity. Mandatory items are underlined in bold
Standard (S2.1a) - Ensure all mandatory entity properties are populated appropriately.
Property 
Description 
Name	Name of the entity. See entity naming conventions below
Short Name	The short name of the entity. This must always be three letters long. This unique name will be used to name Primary and Foreign Key Constraints
Plural	
The plural of the entity name. This is used to generate the physical table name by the Database Design Transformer.
Therefore it is possible that the Name can be more than 30 characters long to be more descriptive within the logical level,
but the plural should be restricted to 30 characters to comply with Oracle Database standards.
If not the Database Design Transformer will use its own rules to determine the generated physical table name
Description	 A detailed description of the entity and its role within the entity model. This can contain as much information from any business documents to allow a complete picture to be built up within the repository
Entity Naming Conventions 
All entities must adhere to the following standards 
Standard (S2.1b) - Ensure Entity Name adheres to the entity naming rules 
Rule
Description
1	The entity name must be made only from the letters A to Z
2	The entity name must NOT contain underscores between words
3	Be aware that Designer will allow entity names of more than 30 characters but names should be restricted to 30 for the following reasons 
• Designer will generate the physical table name from the plural of the entity name, which is restricted to 30 characters. 
• By allowing more than 30 characters for the entity name a designer may be forced to compromise the plural name by including abbreviations in order to fit it into the 30 characters. 
4	The entity name must be singular and should be the name of a logical business object e.g. APPLICATION, PRODUCT
5	Attempts should be made to identify similar objects rather than creating different instances of a type of object unless the identified entity attributes are vastly different, e.g. STUDENT ADDRESS and PARENT ADDRESS should be created as a generic ADDRESS entity. 
Super Typing is allowed as long as the resulting physical model does not make the solution too generic and thereby masking the functionality. This should be resolved by a review of the logical data model before proceeding to the physical implementation. 
Guideline (G2.1b) - Ensure Entity Name adheres to the entity naming guidelines 
Guideline
Description
1	The entity name should consist of a maximum of three words
2	
An entity name should generally NOT contain abbreviations unless they are meaningful business abbreviations,
or an abbreviation has to be introduced to ensure that important descriptive elements of the entity name are maintained. See Appendix B for a list of acceptable abbreviations 
 
2.2 Entity Attributes 
Attribute Details 
The following table details the information required to create a new attribute for an entity. Mandatory items are underlined in bold. 
Standard (S2.2a) - Ensure all mandatory attribute properties are populated appropriately. 
Property
Description
Name	Name of the attribute. See attribute naming conventions below
Format	All numeric attributes should be of format NUMBER
Optional ?	 Indication if the attribute is mandatory or not
Maximum Length	 Must be populated if the format is one of the following 
• NUMBER 
• CHAR 
Do not populate if the format is 
• DATE 
Description	A detailed description of the attribute and its role within the entity. This can contain as much information from any business documents to allow a complete picture to be built up within the repository

Attribute Naming Conventions 
 An attribute must adhere to the following naming conventions. 
Standard (S2.2b) - Ensure Attribute Name adheres to the attribute naming rules 
Rule
 Description
1	Each attribute should be singular. Exceptions are NOTES and DETAILS as these attributes represent multi-line textual descriptions.
2	
Each attribute name should be based on a {Quailifier}{Data Class}structure where possible. See table below available Data Classes. 
{Qualifier} should be as concise as possible. It should include a reference to the entity name only for NUMBER and CODE unique key attributes e.g. EMPLOYEE NUMBER but not for example EMPLOYEE BIRTH DATE, in an EMPLOYEES entity. 
As a general rule the entity name should not be included as part of the attribute name. 

Guideline (G2.2b) - Attributes should not generally contain abbreviations
Guideline
Description
1	 Each attribute should generally NOT contain abbreviations unless they are meaningful business abbreviations, or an abbreviation has to be introduced to ensure that important descriptive elements of the attribute name are maintained. See Appendix B for a list of acceptable abbreviations 
Attribute Data Class
Type of Attribute
Data Type
AMOUNT	 An attribute which represents a monetary value. The associated qualifier should NOT identify the currency. For example: 
• APPLICANT INCOME AMOUNT 
• DISREGARD AMOUNT	
NUMBER
Generally 13 digits with 2 decimal places 
BY	 An attribute which represents a system username. Should always be qualified. For example: 
• LAST UPDATED BY 
• CREATED BY	
VARCHAR2
Generally 30 characters
CODE	 An attribute which represents a numeric key attribute for a reference data table, i.e. a primary key. In this instance there is no requirement to qualify the name of the attribute	NUMBER 
Generally 3 digits 
DATE	An attribute which represents a date only (i.e. does not contain a time component). For example: 
• PAYMENT DATE 
• RECEIVED DATE 
• COURSE START DATE 
Exceptions: 
• DATE OF BIRTH DATE

DATE
DATE TIME	An attribute which represents a date and time. 
For example: 
• STATUS DATE TIME 
• LAST UPDATED DATE TIME	DATE
DESCRIPTION	 An attribute which represents a textual description. Where this attribute is the description of an instance of a reference data entity the attribute name does NOT require to be qualified, unless there are multiple description	VARCHAR2 
Generally 255 characters 
DETAILS	 An attribute which represents a textual description. Should always be qualified. 
• PLACEMENT DETAILS 
• EEA WORK DETAILS	VARCHAR2 
Generally 255 characters 
ID	An attribute which identifies a numeric key attribute, i.e. a primary key. In this instance there is no requirement to qualify the name of the attribute. The ID data class is used for non-reference data primary keys (see section on Unique Identifiers for an Entity)	 NUMBER 
Generally 11 digits 
INDICATOR	An attribute which represents a Boolean value.
For example: 
• ELIGIBILITY INDICATOR 
• NMTO INDICATOR	CHAR(1) 
Single character 
NOTES	An attribute which represents a textual note. Should always be qualified: 
• ASSESSMENT NOTES 
• PENDED NOTES	VARCHAR2 
Generally 2000 characters 
REFERENCE	An attribute which represents an externally generated identifier. Should always be qualified. 
For example: 
• LEARNING CENTRE REFERENCE 
• UCAS REFENCE 
• NATIONAL INSURANCE REFERENCE	VARCHAR2 
Externally defined 
SEQUENCE	An attribute which represents a sequence number. Should always be qualified. 
For example: 
• ASSESSMENT SEQUENCE 
• PAYMENT BAND SEQUENCE	NUMBER
TYPE	An attribute which represents an item of reference data which has NOT been modelled as a lookup table. This should be a numeric code. Should always be qualified. 
For example: 
• EMPLOYMENT TYPE 
• LOAN STATUS TYPE	NUMBER 
Generally 3 digits 
Character based attributes should have the following datatype assigned
• If the size of the attribute is 1 then the datatype should be CHAR 
• If the size of the attribute is greater than 1 then the datatype should be VARCHAR2. 
There will be exceptions to the above. For example, where a status column from the CLASS application is being synchronized with an Operational application, and the status is character-based as opposed to the proposed numeric TYPE then the operational system would define a status TYPE column which was also character-based, e.g. NINO STATUS TYPE.
2.3 Attribute Domains & Reference Data 
Domains 
A domain defines a set of validation rules, format constraints and other properties that apply to a group of entity attributes and database columns. A domain consists of a code and a description and is often used to identify lookup data. 
Domain Naming Conventions 
All domains should follow the following naming conventions 
Standard (S2.3a) - Ensure Domain Name adheres to the domain naming rules 
Rule
Description
1	The name of the schema in which the table column referencing the domain resides in. This ensures that domain names are unique across application schemas e.g. XXSL, XXEM, XXAL
2	• Followed by _ ( underscore ) 
• Descriptive name ( with underscores bwteen words ) 
• Followed by _ ( underscore ) 
• Followed by TYPE 
e.g. XXEM_CONFIRMATION_STATUS_TYPE 
3	The domain name should restricted to 30 characters, although 40 are allowed. This is because the current implementation of domains within Oracle Applications restricts the name to 30 characters. 
The following table details the information required to create a new domain. Mandatory items are underlined in bold. 
Standard (S2.3b) - Ensure all mandatory Domain Name properties are populated appropriately. 
Property
Description
Name	 Name of the Domain. See Domain naming conventions above
Attributes in Domain	 Format NUMBER Maximum att Length 3 
Columns in Domain 	Format NUMBER Maximum att Length 3 
Description	 A detailed description of the domain and its role within the entity model. This can contain as much information from any business documents to allow a complete picture to be built up within the repository
Special Domains
Attributes which are named ....._INDICATOR may break the above rule on the type that a domained attribute takes ( i.e. NUMBER(3) ).
As the standard logical definition of these attributes is a CHAR(1) they may also be physically implemented as a CHAR(1), but they must also have a domain created and assigned to them.
As attributes of this type are usually used to define a boolean choice e.g. Yes / No or True / False, then valid domains for these attributes would be
Domain Name
Domain Type
Values 
Description
YES_NO	CHAR(1)	Y	Yes
 	 	N	No
TRUE_FALSE	CHAR(1)	T 	True
 	 	F	False
YES_NO_NA	CHAR(1) 	Y	Yes
 	 	N	No
 	 	X	Not Applicable **
** Although not strictly a boolean choice, this is seen as an acceptable domain value 
Standard (S2.3c) - Ensure INDICATOR attributes have an associated Domain created for them
Reference Data 
If a set of data is identified as reference or lookup data and contains more than just an identifying code and description then it should be implemented as a separate entity and follow similar standards to the creation of normal entity. 
Reference Data Entity Naming Conventions 
All reference data entities should follow the following naming conventions. 
Standard (S2.3d) - Ensure Reference Data Entity Name adheres to the Reference Data Entity Naming rules 
Rule
Description
1	
The name of the entity which implements reference data should be named as follows
• Descriptive name 
• Followed by TYPE 
e.g. CONFIRMATION STATUS TYPE 
2	All other naming conventions which apply to entities should be applied to reference data entities
Attributes within a Reference Data Entity 
As a minimum all reference data entities must implement the following attributes 
Standard (S2.3e) - Ensure Reference Data Entity implements minimum attribute set
Attribute Name
Meaning
CODE	This is the Unique Primary Identifier of the reference data entity. 
This must have the following attribute options set 
Format 
• NUMBER 
Optional ? 
• No 
Maximum Length 
• 3 
DESCRIPTION 	This is a description attribute for the reference data item. 
This must have the following attribute options set 
Format 
• CHAR 
Optional ? 
• No 
Maximum Length 
• 255 
All other additional attributes within the reference data entity must conform to the same rules and naming conventions defined for entity attributes.
2.4 Entity Relationships 
For ease all relationships between entities should be carried out with the Entity Relationship Diagrammer, although it is possible to create them within the Repository Object Navigator. 
The following table details the information required to create a new relationship between two entities. Mandatory items are underlined in bold 
Standard (S2.4a) - Ensure Entity relationship contains mandatory properties 
Property ( From ) 
Description
Entity	Name of the entity at the From end of the relationship
Relationship Name 	A meaningful description of the relationship between the two entities from the perspective of the Parent entity name.
Minimum Cardinality	The minimum number of entities possible at the other end of the relationship for the entity at this end.
Transferable	An indication that the relationship can be transferred to another entity instance. This equates to the cascading of the relationship to lower level entities. 
Description	A detailed description of this end of the relationship
Property ( To )
 Description
Entity	Name of the entity at To end of the relationship
Relationship Name 	A meaningful description of the relationship between the two entities from the perspective of the Child entity name.
Minimum Cardinality	The minimum number of entities possible at the other end of the relationship for the entity at this end
Transferable	An indication that the relationship can be transferred to another entity instance. This equates to the cascading of the relationship to lower lever entities.
Description 	A detailed description of this end of the relationship
2.5 Unique Identifiers for an Entity
 An entity may have a number of unique identifiers. 
Primary Identifier 
All entities must have a primary identifier, which will ensure that an individual occurrence of that entity can be uniquely identified. The name of the primary identifier must be made up from the three letter short name, followed by a space, followed by the letters PK, indicating the primary key of the entity e.g. #

CSR PK 

This name will be cascaded down to the physical model and complies with physical database naming conventions. 
A primary identifier must contain at least one entry and may include some or all of the following
Attributes held within the entity 
Relationships to other entities 
Standard (S2.5a) - Ensure Entity has a primary key, which is named appropriately, and contain at least one attribute.
Unique Identifier 
An entity may also have a number of unique identifiers, which also allow individual occurrences of the entity to uniquely identified. 
Unique identifiers must be made up from the three letter short name, followed by a space, followed by the letters UK, indicating a unique key of the entity e.g. 

CSR UK 
This name will be cascaded down to the physical model and complies with physical database naming conventions. 
A unique identifier must contain at least one entry and may include some or all of the following
Attributes held within the entity 
Relationships to other entities 
An entity may have a number of unique keys and these should be identified by adding a number qualifier at the end of the name e.g. CSR UK1, CSR UK2 etc 
Standard (S2.5b) - Ensure and Entity unique keys are named appropriately, and contain at least one attribute. 
=========================================================================================================
Physical Data Modelling
2 - Physical Data Modelling

Once the logical model is complete the physical database can be produced by scripts.
If Oracle Designer is available it can be be used to produce the physical database. This is achieved by use of the Database Design Transformer.
The physical model should be mapped to the logical model as shown in the following table
 
Logical Model
Element Physical Model Element
Entity Name	Pluralised to Table Name. Spaces between words are replaced by underscores.
Entity Short Name	Converted to Table Alias
Entity Description	Converted to Table Description
Attributes	Converted to Table Columns
Attribute Format 	Converted to Column Format
Attribute Optionality	Converted to Column Optionality
Attribute Description	Converted to Column Description
Entity Unique Identifiers	Converted to Table Primary and Unique Keys
Entity Relationships	Converted to Table Foreign Keys
 It should be seen from the above table that by putting the effort in at the logical model design stage it is possible to eliminate a large amount of effort to convert the logical model to a physical one.

2.1 Additional Physical Model Tasks
 
There are additional steps which must be carried out to ensure the physical model meets all standards and that the process of generating the physical model into scripts to implement on the target database is as smooth as possible. 
Table Synonyms
All tables must have a synonym created with the following details populated - Note in CLASS the DBAs create synonms when implementing the table DDL
Standard (S2.1a) - Ensure a public synonym is created for the table
Synonym Name 
Value
Name	Identical to the name of the table
Scope	Public
Audit Columns
There is a standard set of audit columns which should be added to ALL tables. These are detailed in the following table. 
Standard (S2.1b) - Ensure all audit columns are created for a table 
Column Name
Column Attributes
LAST_UPDATED_BY
DataType
VARCHAR2 
Maximum Length 
30 
Optional 
No 
Description 
Date and Time of last update 
LAST_UPDATED_DATE_TIME	
DataType
DATE
Optional
No
Description
Date and Time of last update
CREATED_BY 	
DataType 
VARCHAR2 
Maximum Length 
30 
Optional 
No 
Description 
Username of person responsible for creating the entry 
CREATED_DATE_TIME 	DataType 
DATE 
Optional 
No 
Description 
Date and Time of creation 
2.2 Tables
Table Sizing Template
To be completed for each new table created This will normally be stated in the notes section in the WR/CR to allow the DBAs to assign tablespace correctly
Standard (S2.2a) - Ensure WR/CR contains all sizing information 
 
Table Sizing Template
Icon
Summary of profile of usage: Description of what the table will be used for
a) Expected total no of rows (after 1 year). 
b) Expected growth rate per month.
c) Type of normal processing. ie Number and frequency of rows inserted per day/month/year as appropriate
Number and frequency of rows deleted per day/month/year as appropriate
Number and frequency of rows updated – particularly if this causes column lengths to grow. per day/month/year as appropriate
d) Whether the table will be updated/deleted/inserted by many concurrent processes 
e) Whether indexed columns are changed during updates.
f) The average row length *
This data will allow the DBAs to calculate the appropriate tablespace
*See appendix for calculating average row length
Any alterations to the table to add new columns should NOT revisit the initial sizing template. Instead a separate entry should be added to the appropriate section. 
Standard (S2.2b) - Ensure WR/CR contains sizing change information 
Change Template
Icon
a) New column name 
b) Nullable Yes/No 
c) Average length of column 
d) Percentage of rows populated
Below provides an example of the template completed for a new table. 
New Table Example
Icon
Summary of profile of usage: New table to store the customer confirmation of customer details form status 
a) Expected total no of rows (after 1 year): 3600000, initial load will be ~3000000
b) Expected growth rate per month: 50000 rows (peak processing in November ~130000)
c) Type of normal processing: New rows inserted, existing rows should have last_updated* and end_date columns updated
d) Whether the table will be updated/deleted/inserted by many concurrent processes - The table will be accesses for updates and inserts by batch modules and by on line forms, with online form processing may user maybe creating new records simultaneously
e) Whether indexed columns are changed during updates. - Indexed columns will not be updated
f) Average Row length 170

Below is an example of the template completed for a column addition.
Example of change in table
Icon

New column name - RESTRICT_SECONDARY_AUTH_IND 
Nullable Yes 
Average length of column 1 
Percentage of rows populated negligible (< 0.01%) 
Below is an example of the template completed for a column amendment.
Example of change in table
Icon
Amended column name ID 
Nullable No 
Column Change Num(6) to Num(13) 
Percentage of rows populated negligible (< 0.01%) 
Table Naming Conventions 
All tables must adhere to the following guidelines 
Standard (S2.2c) - Ensure new table name adheres to the table naming conventions. 
Rule
Description
1	The table should map to a corresponding Entity within the Logical Model, unless the table is being implemented purely at a physical level e.g. Work Tables, Temporary tables
Note: See additional rules below regarding Stakeholder Separation
2	The table name must be made only from the letters A to Z
3	The table name must be plural
4	The table name MUST contain underscores between words
5	Table names are restricted to 30 characters

Stakeholder Separation Table Naming Conventions

Additional table naming rules are required depending on the final database location of the table.

Currently all SLC's Front Office systems are dependent on a single database, which holds the Oracle Applications schema's. Due to support restrictions it is necessary to identify all Non-Apps objects within the database and this is currently done in two ways
Group all Non-Apps objects into a bespoke schema which can be easliy identified as Non-Apps. Oracle's preferred method to achieve this is to have all bespoke schemas start with 'XX'. There are currently two 'XX' schema's defined i.e. XXSL ( Student Finance Direct ) and XXEM ( Education Maintenance Allowance ).
 Within any bespoke schema all tables should are also prefixed with the name of the schema they reside in. e.g. XXSL_SUPPORT_APPLICATIONS or XXEM_APPLICATIONS.

The Stakeholder Separation project allows SLC to develop and deploy its bespoke applications on separate Non-APPS databases, which will all communicate with each other over a common Data Sharing Message Hub. Note that the table being created is for a system which will reside within its own bespoke database then the above two rules should be disregarded.
2.3 Table Columns 
Column Details 

The following table details the information required to create a table column. Mandatory items are underlined in bold 

Standard (S2.3a) - Ensure table column has all mandatory properties populated. 
Property 
Description
Name 	Name of the column. See column naming conventions below
Data Type Properties	DataType 
Must be populated e.g. DATE, VARCHAR2 etc 
Maximum Length
Leave blank if Data Type is DATE 
Decimal Places 
Populate if required 
Optional 	Indicate if the column is mandatory i.e. NOT NULL. If not stated then column will be nullable
Default	The value that the column should default to, if this is required.
Comment	Add a meaningful comment to explain the column usage

Column Naming Conventions 
All table columns must adhere to the following conventions
 
Standard (S2.3b) - Ensure table column adheres to the column naming rules. 
Rule
 Description
1	The column should map to a corresponding attribute within the Logical Model, unless the column has been added as physical implementation only e.g. audit columns.
2	The column name must be made only from the letters A to Z plus underscore
3	Column names are restricted to 30 characters
4	Only use abbreviations for pre-defined types - see below Do not use abbreviations if the full description can be accommodated within the 30 characters allowed 

Columns names should also adhere to the entity attribute naming standards with the following abbreviations adopted. 
INDICATOR is abbreviated to IND 
DESCRIPTION is abbreviated to DESC 
SEQUENCE is abbreviated to SEQ 
IDENTIFIER is abbreviated to ID 
2.4 Primary and Unique Keys 

Primary Keys 

All tables must have a primary key defined. All primary keys should adhere to the following rules 
If a primary key cannot be defined using at a maximum three columns derived from logical attributes then it must have an internally defined surrogate primary key column called ID created. This column must also be populated by a sequence. 
Do not base the primary key of a table based on an externally populated business attribute e.g. National Insurance Number, Health Service Number, Vehicle Registration Number, even if uniqueness is guaranteed. In this case adopt an internally generated primary key. 
All Primary Key constraints must be implemented with associated primary key index. 

The following table details the information required to create a Primary Key on a Table. 
Property
Description
Table	The name of the table on which the primary key is implemented.
Name	 Name of the primary key. See primary key naming conventions below
Source Attribute 	The name of the source unique identifier from the logical model that the primary key implements
Primary Key Naming Conventions 

All Primary Keys must adhere to the following naming conventions 

{TABLE ALIAS}_PK 

Where {TABLE_ALIAS} is the three letter alias defined for the table containing the Primary Key e.g.

CSR_PK 

All primary keys must contain at least one Column definition. 
Standard (S2.4a) - Ensure Primary Key adheres to naming conventions 
Primary Key Indexes 
All primary keys should be implemented with associated indexes. 
Unique Keys 
A table can also have a number of unique keys in addition to the primary key. Unique keys can be used to enforce business logic uniqueness to the data within a table. All unique keys should adhere to the following rules 
All Unique Key constraints must be implemented with associated Unique Key index. 
The following table details the information required to create a Unique Key on a Table. 
Property 
Description
Table	The name of the table on which the unique key is implemented.
Name	Name of the unique key. See unique key naming conventions below
Source Attribute 	Unique Identifier The name of the source unique identifier from the logical model that the unique key implements 

Unique Key Naming Conventions 

All Unique Keys must adhere to the following naming conventions 

{TABLE ALIAS}_UK 
Where {TABLE_ALIAS} is the three letter alias defined for the table containing the Primary Key e.g. 

CSR_UK 
All unique keys must contain at least one Column definition. 
If there are multiple unique keys within a table then an index value, starting at 2, is added to the end of the unique key name to enforce uniqueness e.g. 
CSR_UK 
CSR_UK2 
CSR_UK3 

Standard (S2.4b) - Ensure Unique Key name adheres to naming conventions 
Unique Key Indexes 
All unique keys should be implemented with associated indexes.  
2.5 Foreign Keys 

Relationships between entities are physically implemented by using Foreign Keys on the related tables. 
The following table details the information required to create a Foreign Key.  
Property 
Description
Table	The name of the table the Foreign Key resides in
Join Table	The name of the table the Foreign Key joins to
Name 	Name of the Foreign Key. See Foreign Key naming conventions below
Cascade Rules	Delete Rule
Restricted - Do not use
Update Rule
Restricted - Do not use
Foreign Key Naming Conventions 

All Foreign Keys must adhere to the following naming conventions. 

{Child Table Alias}_{Parent Table Alias}_FK 
e.g. table CUSTOMERS (CSR) has a child table SUPPORT_ASSESSMENTS (SAS ). The implemented Foreign Key on SUPPORT_ASSESSMENTS will be 

SAS_CSR_FK 
If more than one foreign key exists between the same tables then the name of the foreign key should have an index appended to the end of it, but only to the second and subsequent foreign keys e.g.

SAS_CSR_FK2, SAS_CSR_FK3 etc 
Standard (S2.5a) - Ensure Foreign Key name adheres to naming conventions 
Foreign Key Columns 

All Foreign keys must contain at least one Foreign Key column. The following table details the information required for each Foreign Key column 
Property
Description
Column	The name of the column in the child table which makes up the foreign key
Join Column	The name of the column in the parent table which makes up the foreign key

 Standard (S4.5b) - Ensure Foreign Key has at least one foreign key column defined
Foreign Key Indexes 
All Foreign Keys must have an associated Foreign Index created which supports the Foreign Key constraint. 
As a general rule an index should always be created for a foreign key, even if the foreign key column is included within another index on the table. Due to the different ways Oracle performs locks, under different versions of the database, when updating tables with foreign keys and also the minimal impact on performance and space in creating the index, this rule should always be adhered to. 
The following table details the information required to create a Foreign Key index. 

Standard (S2.5c) - Ensure a Foreign Key index is created for a foreign key.
Property
Description
Name	The name of the Foreign Key index. See Foreign Key Index naming conventions below
Index Type	Normally set to Not Unique for Foreign Key indexes
Foreign Key Index Columns 

All Foreign Key indexes must contain the same column entries as specified with the Foreign Key itself, and in the same sequence. 
Foreign Key Index Naming Conventions 

All Foreign Key indexes must adhere to the following naming conventions. 

{Name of the Foreign Key Supported}_I 

e.g. The foreign key CSR_SAS_FK which exists to support the relationship between the tables CUSTOMERS (CSR) and SUPPORT_ASSESSMENTS (SAS ) will have a foreign key index as follows. 
SAS_CSR_FK_I 

If more than one foreign key index exists between the same tables then the name of the foreign key index should have an index appended to the end of it, but only to the second and subsequent foreign key indexes e.g.
SAS_CSR_FK_I2, SAS_CSR_FK_I3 etc 

Standard (S2.5d) - Ensure a Foreign Key name adheres to the foreign key naming conventions 
2.6 Table Indexes 

A table may have other indexes, which do not support a Primary or Foreign Key and in most cases are used to improve performance when accessing a table. 
The following table details the information required to create an index.
Property
Description
Table	The name of the table the Index resides in
Name	Name of the Index. See Index naming conventions below
 
Index sizing information should be stated in the notes section in the WR/CR to allow the DBAs to assign tablespace correctly.
This should be populated with detailed sizing information using the template below.
 
Index Sizing Template
Icon
 Average Row Length ? 
Number of rows ? 


Below provides an example of the template completed for an index 
Sizing Example
Icon
Average Row Length 22 
Number of rows 1,300,000 
Tablespace calculation
Icon
To calculate tablespace:
When calculating the average row length - if it cannot be read from the table statistics within a development environment - use the following values: 
• Varchar2 Character = 1 
• Number Digit = 1 
• Date = 7 
If a Varchar2 column is greater than 100 characters e.g. varchar2(2000) then using this size will normally cause the size of the table to go beyond the 128Mb and always cause a Large tablespace to be used, even if the average size of the field is much smaller. Therefore if the size of the column is greater than 100 then estimate the average populated size when calculating the row size. If the size of the column is less than or equal to 100 then use the column size in the calculation.
Thereafter the tablespace is identified using the following rules:
• Average row length * number of rows < 4Mb - small 
• Average row length * number of rows between 4Mb and 128Mb - medium 
• Average row length * number of rows > 128Mb - large 
This would be re-visited every time the index changed, i.e. there is no need to maintain the original sizing information as the index would be re-built. 

Standard (S2.6a) - Ensure a Table Index has all sizing information recorded within the notes section. 
Index Naming Conventions 

All non Primary Key and Foreign Key indexes must adhere to the following naming conventions. 

{Table Alias}_I{Table Index Number} 

Where Table Alias is the three letter alias of the table and Table Index Number is a number ensuring the index name is unique within the table, starting at 1. 

e.g. table CUSTOMERS (CSR) has two new indexes. These would be named 
• CSR_I1 
• CSR_I2 

Standard (S2.6b) - Ensure a Table Index adheres to theIndex Naming Conventions. 
Index Columns 
All indexes must contain at least one column entry. 
Standard (S2.6c) - Ensure a Table Index contains at least one index column entry.
2.7 Table Triggers 

Table triggers allow predefined code to be executed whenever certain events occur on a table. 
When Triggers Fire
Triggers can fire at two particular time points. 
Before Triggering Statement 
The code within the trigger is executed before event which caused the trigger to fire. 
After Triggering Statement 
The code within the trigger is executed after the event which caused the trigger to fire. 

A third trigger time point exists - Instead of Triggering Statement - and only applies to database views. These triggers should be avoided as views should normally only be seen as read-only objects. Consult the TDA / DBA before implementing Instead of Triggers
Trigger Level 
There are two levels at which a trigger can fire. 
Row Level 
The trigger will fire for each row affected by the triggering event. This is the default and should be used in most cases. 
Statement Level 
The trigger fires once for the triggering event regardless of how many rows are affected by the triggering event. 
Statement Causing the Trigger to Fire 

Further control can be achieved with triggers by limiting the trigger to fire when certain types of statements affect the table the trigger resides on.
Insert 
The trigger fires when an insert statement occurs of the table 
Delete 
The trigger fires when a delete statement occurs on the table 
Update 
The trigger fires when an update statement occurs on the table 

If a trigger is to fire on a combination of the above events then separate triggers must be created. This reduces the impact analysis that is required when changes have to be made to the trigger code. 
Standard (S2.7a) - Ensure table trigger only fires on a single event. 

The following table details the information required to create a trigger. 
Property
Description
Table	The name of the table the trigger resides on
Name	Name of the Trigger. See Trigger naming conventions below
Trigger	
Time 
• Set to 'Before Triggering Statement' if the trigger is to fire before the triggering statement. Set to 'After Triggering Statement' if the trigger is to fire after the triggering statement. 
Level 
• Set to 'For each Row' if the trigger should fire for all rows affected by the triggering statement. This should be the default for most triggers Set to 'Statement' if the trigger should fire only once for all rows affected by the triggering statement. This type of trigger is not normally used 
Insert 
• Set to 'Before Insert' or 'After Insert' if the trigger should fire if the triggering statement is an Insert statement. 
Delete 
• Set to 'Before Delete' or 'After Delete' if the trigger should fire if the triggering statement is an Delete statement 
Update 
• Set to 'Before Update' or 'After update' if the trigger should fire if the triggering statement is an Update statement 
 
Trigger Naming Conventions 

All triggers should be have the following format

Schema Name _ Table Alias _ Trigger Type

Schema Name should be the name of the database schema which holds the table the trigger fires on e.g. XXSL, XXEM except for CLASS where this can be omitted

Table Alias should be the three letter alias of the table which the trigger fires on
Trigger Type is a three letter abbreviation based on the following
Letter Position
Value
1,2 & 3	The three letter alias of the table on which the trigger reside in.
4	
This is a single letter indicating when the trigger fires
'B' indicates Before Triggering Statement 
'A' indicates After Triggering Statement 
5	
This letter indicates what type of statement causes the trigger to fire 
'U' indicates that a trigger fires when an Update occurs 
'D' indicates that a trigger fires when a Delete occurs 
'I' indicates that the trigger fires when an Insert occurs 
6	This letter indicates the trigger level 
'R' indicates Row level trigger 
'S' indicates Statement level trigger 

Standard (S2.7b) - Ensure Trigger name adheres to trigger naming conventions. 
Trigger Examples 
A trigger exists on table XXSL_CUSTOMER ( Alias CSR ), held within the XXSL schema,and fires before every row is updated by the triggering statement. The trigger name is
XXSL_CSR_BUR 
A trigger exists on table XXEM_APPLICATIONS ( Alias APP ), held within the XXEM schema, and fires after every row has been inserted by the triggering statement. The trigger name is 
XXEM_APP_AIR
2.8 Sequences 
Sequence Naming Conventions 
All sequences should follow the adhere to the following naming conventions 

Schema Name(excl CLASS) _ Table Alias _ Column Name _ SEQ

For example the table XXSL_EXAMPLE_TABLE ( EXT ), which resides in the XXSL schema, has a column ID, which is populated by a sequence. The sequence name will be
XXSL_EXT_ID_SEQ 

Standard (S2.8a) - Ensure that a sequence conforms to the sequence naming conventions 
Sequence Synonym 
All sequences must have a synonym created with the following details populated 
Standard (S2.8b) - Ensure that a sequence has a public synonym created 
Synonym Attribute 
Value
Name	 Identical to the name of the sequence
Scope 	Public

Note: In CLASS the DBAs will create the synonym when applying the DDL.
 
The following table details the lower level information required to implement a Sequence.
Standard (S2.8c) - Ensure all mandatory properties of a sequence implementation are populated.
Sequence Attribute
 Value
START WITH	1, unless there is a specific reason not to start the sequence at 1
INCREMENT BY	1, unless there is a specific reason not to increment the sequence by 1
CACHE/
NO CACHE
Specify how many values of the sequence the database preallocates and keeps in memory for faster access. This integer value can have 28 or fewer digits. The minimum value for this parameter is 2. For sequences that cycle, this value must be less than the number of values in the cycle. You cannot cache more values than will fit in a given cycle of sequence numbers.
NOCACHE can be specified.
If netiher a CACHE value or NOCACHe is not specified then the deafult cache is 20
CYCLE/NOCYCLE	 should be NOCYCLE, unless there is a specific reason to cycle the sequence
Order	No
MINVALUE	1, unless there is a specific reason to have a different minimum value
MAXVALUE	This should match the maximum value which can be held in the column that the sequence is populating e.g. if the populated column is NUMBER(6) then the maximum value of the sequence should be 999999.

2.9 Views 

View Naming Conventions 

All views must adhere to the following guidelines. These guidelines are based on the same rules for table names

Standard (S2.9a) - Ensure new view name adheres to the table naming conventions. 
Rule 
Description
1	The view name must be made only from the letters A to Z and be a descriptive representation of what the view represents
2	The table name must be plural
3	The view name must have V_ prefixed to its name
4	The view name MUST contain underscores between words
5	View names are restricted to 30 characters
View Column Naming Conventions 

All view columns must adhere to the following guidelines. These guidelines are based on the same rules as for table columns.

Standard (S2.9b) - Ensure view column adheres to the column naming rules. 
Rule
Description
1	The column name must be made only from the letters A to Z plus underscore
2	Column names are restricted to 30 characters
3	Only use abbreviations for pre-defined types - see below Do not use abbreviations if the full description can be accommodated within the 30 characters allowed 

Columns names should also adhere to the entity attribute naming standards with the following abbreviations adopted. 
INDICATOR is abbreviated to IND 
DESCRIPTION is abbreviated to DESC 
SEQUENCE is abbreviated to SEQ 
IDENTIFIER is abbreviated to ID 

The following additional rules may also be applied in the case of columns based on lookup or domain entries:

If the view column is a retrieval of a descriptive meaning of a table column from a lookup table or domain then the view column should be based on the original column with _DESC appended
e.g.
If a table contains the column LEARNING_CENTRE_TYPE, which is a code based on a entry in a lookup domain then if the view is to contain the descriptive meaning it should be named LEARNING_CENTRE_TYPE_DESC.
If the new column name exceeds the allowable 30 characters then suitable abbreviations should be used.
View Synonym 

All views must have a synonym created with the following details populated. Note: In CLASS the DBAs will create the synonym when applying the DDL.
Standard (S2.9c) - Ensure that a view has a public synonym created 
Synonym Attribute 
Value
Name	 Identical to the name of the sequence
Scope 	Public

2.10 Object Types
Object Type Naming Conventions 

All Object Types must adhere to the following standards. 
Standard (S2.10a) - Ensure Object Type name adheres to the naming rules. 
 
Rule
Description
1	The object type name is made up from the following
The schema in which it will reside e.g. XXSL, followed by an underscore (CL for CLASS)
A descriptive name of the Object Type, followed by an underscore 
_O_TYPE to indicate that it is an object type 
2	Object names are restricted to 30 characters

e.g.
An object type is created which represents a Role Membership with the User Administration function. This object will be owned by the XXCO scheme. The name of the object will be
XXCO_ROLE_MEMBERSHIP_O_TYPE.
If the new column name exceeds the allowable 30 characters then suitable abbreviations should be used.
Object Type Attributes
The following table details the information required to create a object type. Mandatory items are underlined in bold 
All Object Type attributes should adhere to the same standards as Table Column names 
Standard (S2.10b) - Ensure object type attribute has all mandatory properties populated. 
Property 
Description
Name	Name of the attribute. See object attribute naming conventions below
Domain 	Name of the domain which defines the format of the attribute, if specified
Data Type Properties 	DataType 
• Must be populated e.g. DATE, VARCHAR2 etc 
Maximum Length
• Leave blank if Data Type is DATE 
Decimal Places 
• Populate if required 
Optional 	Indicate if the attribute is optional or mandatory. Will default to optional
Description	 A detailed description of the attribute and its role within the object type

Standard (S2.10c) - Ensure table object type attribute adheres to the attribute naming rules.
 
Rule 
Description
1	The object type attribute must be made only from the letters A to Z plus underscore
2	Object attribute names are restricted to 30 characters
3	Only use abbreviations for pre-defined types - see below Do not use abbreviations if the full description can be accommodated within the 30 characters allowed 
Object attribute names should also adhere to the entity attribute naming standards with the following abbreviations adopted. 
INDICATOR is abbreviated to IND 
DESCRIPTION is abbreviated to DESC 
SEQUENCE is abbreviated to SEQ 
IDENTIFIER is abbreviated to ID 
2.11 Collection Types

Collection Type Details 

The following table details the information required to create an Collection Type. Mandatory items are underlined in bold 

Standard (S2.11a) - Ensure all mandatory properties of an Collection Type are populated. 
 
Property
Description
Name	Name of the Collection Type. See Collection Type naming conventions below
Collection Type	Either NESTED TABLE or VARRAY
VARRAY Limit	If the Collection Type is VARRAY then enter the size of the VARRAY
Collection of	Either Object or Scaler
Scaler Collection	Indicate if the attribute is optional or mandatory
Scaler Data Type	The datatype of the scaler type e.g. NUMBER, DATE etc
Scaler Maximum Length 	The maximum length of the scaler type e.g. for NUMBER and VARCHAR2 types
Scaler Decimal Places	The number of decimal places e.g. for Number types
Object Collection 	The name of the source attribute from the logical model that the object type attribute implements
Object DataType 	The name of the Object Type that this is a collection of
Ref	Set to No
Description	 A detailed description of the attribute and its role within the object type
Notes 	Additional notes about the Collection Type


Standard (S2.11b) - Ensure Collection Type name adheres to the naming rules. 
Rule 
Description
1	The object type name is made up from the following
• The schema in which it will reside e.g. XXSL, followed by an underscore 
• A descriptive name of the Collection Type, followed by an underscore 
• _V_TYPE for VARRAY Collections or T_TYPE for NESTED TABLE Collections 
2	 If the collection type is a collection of objects then the descriptive name above should be the same as the descriptive name of the object type it collects
3	Collection Type names are restricted to 30 characters

2.12 Database Queues and Queue Tables

Queue Definitions

The following table details the information required to create a database Queue definition. Mandatory items are underlined in bold 

Standard (S2.12a) - Ensure all mandatory properties of an Queue definition are populated. 
 
Property 
Description
Name 	Name of the Queue. See Queue naming conventions below
Queue Table 	The name of the Queue Table used to store the queue
Queue Type	
Indicates the type of Queue
Normal, allowing queue and dequeue operations 
Exception, only dequeue operations are allowed 
Null, which indicates Normal 
Default to Normal
Auto Commit	Yes indicating that messages are automatically commited once queued or No indicating an additional Commit is required. Default to No
Max Retries	Default to 5. Not applicable for Exception Queues
Retry Delay	Default to null, indicating that a retry is attempted immediately
Retention Time	The number of seconds a message is retained in the associated queue table after being dequeued from the queue. Default to 0, indicating that messages are not retained once dequeued.
Unlimited Retention 	Yes or No.Default to No, indicating that messages are not indefinitely retained
Description	 A detailed description of the Queue
Notes 	Additional notes about the Queue

 Standard (S2.12b) - Ensure Queue name adheres to the naming rules. 
Rule
 Description
1	
 The Queue name is made up from the following
The schema in which it will reside e.g. XXSL, followed by an underscore 
A descriptive name of theQueue, followed by an underscore 
_Q 
2	Queue names are restricted to 30 characters

Queue Table Definitions

The following table details the information required to create a database Queue Table definition. Mandatory items are underlined in bold 

Standard (S2.12c) - Ensure all mandatory properties of an Queue Table definition are populated. 
Property
Description
Name 	Name of the Queue table. See Queue table naming conventions below
Payload type 	
Options are RAW or object type
Normally the object type should be chosen i.e
SYS.AQ$_JMS_TEXT_MESSAGE
Sort List 	
Options are priority, enq_time and commit_time.
Normally enq_time should be chosen
Multiple Consumers 	
FALSE means queues created in the table can only have one consumer for each message. This is the default.
TRUE means queues created in the table can have multiple consumers for each message.
Auto Commit	
TRUE causes the current transaction, if any, to commit before the CREATE_QUEUE_TABLE operation is carried out. The CREATE_QUEUE_TABLE operation becomes persistent when the call returns. This is the default. 
 FALSE means the operation is part of the current transaction and becomes persistent only when the caller enters a commit.
Primary Instance 	The default value for primary instance is 0, which means queue monitor scheduling and propagation will be done in any available instance.
Secondary Instance 	

The queue table fails over to the secondary instance if the primary instance is not available. The default value is 0, which means that the queue table will fail over to any available instance.
Compatible Database Instance 	
The lowest database version with which the queue is compatible. Currently the possible values are either 8.0, 8.1, or 10.0.
If the database is in 10.1-compatible mode, the default value is 10.0. If the database is in 8.1-compatible or 9.2-compatible mode, the default value is 8.1.
If the database is in 8.0 compatible mode, the default value is 8.0.
Set to 8.1
Comment	A detailed description of the Queue table

Standard (S2.12d) - Ensure Queue Table name adheres to the naming rules. 
Rule 
Description
1	
The Queue Table name is made up from the following
The schema in which it will reside e.g. XXSL, followed by an underscore 
A descriptive name of theQueue Table, followed by an underscore 
_QT 
2	Queue Table names are restricted to 24 characters
=========================================================================================================
Script templates and file extensions
Scripts in PVCS

This page details the types of files which must be stored in PCVS to support a physical data model
File Headers
All database scripts stored in PVCS must have a header, with all details completed, as highlighted in the following example
--############################################################################ 
--# 
--# name : XXEM_INCOME_TYPES_3_TAB.sql 
--# 
--# author : Peter Bruning 
--# 
--# description : Initial table create. 
--# 
--# PVCS : $Revision: $ 
--# $Modtime: $ 
--# $Author: $ 
--# 
--########################################################################### 
--# Modification History 
--# 
--# $Log: $ 
--# 
--############################################################################
The PVCS items bound within '$' are populated automatically by PVCS when the script is added.
Tables, Indexes and Constraints
Tables, Indexes and Constraints should be amalgamated into one files as follows
.tab - Table definition
A table script should only contain the DDL commands to a single table.
The first instance of the table script should be named as follows ( in upper case )
{Table Name}_1_TAB.SQL
e.g.
XXEM_APPLICATIONS_1_TAB.SQL
Any further modifications to the table will result in a new script being created, incrementing the script number to 2 and so on.
Sequences
Sequences should be saved as a .sql file.
The first instance of a sequence script should be named as follows ( in upper case )
{Sequence Name ( minus the _SEQ )}_1_SEQ.SQL
e.g.
LEC_ID_1_SEQ.SQL
Any further modifications to the sequence will result in a new script being created, incrementing the script number to 2 and so on.
Synonyms
Synonyms should be saved as a .sql file. There should be a seperate file for each synonym generated
The first instance of a synonym script should be named as follows ( in upper case )
{Object Name}_1_SYN.SQL
e.g.
XXEM_APPLICATIONS_1_SYN.SQL
LEC_ID_SEQ_1_SYN.SQL
Any further modifications to the synonym will result in a new script being created, incrementing the script number to 2 and so on.
Views
Views should be saved as a .sql file. There must be a separate file for each view generated.
The first instance of a view script should be named as follows ( in upper case )
V_{View Name}_1.SQL
e.g.
V_BUSINESS_TRANSACTIONS_1.SQL
Any further modifications to the view will result in a new script being created, incrementing the script number to 2 and so on.
Triggers
Triggers should be saved into a .trg file. There must be a separate file for each trigger generated.
The first instance of a trigger script should be named as follows ( in upper case )
{Trigger Name}.TRG
e.g.
COF_BIR.TRG
Any further modifications to the trigger should be done by incrementing the version in PVCS
Object Types
object types should be saved as a .sql file. There must be a separate file for each object type generated.
The first instance of a object type script should be named as follows ( in upper case )
{Object Name}_OBJ_TYPES.SQL
e.g.
VIEW_PAYMENTS_OBJ_TYPES.SQL
Any further modifications to the object type should be done by incrementing the version in PVCS
=========================================================================================================
Module Naming Conventions
Name Structure

Module names should conform to the following structure:
 
            Character Positions      Use
                        1                      Application Code, e.g. ‘C’ for CLASS
                        2-3                   Sub-Application Code, e.g. ‘AR’ for Archiving
                        4-5                   Module Type, e.g. ‘OF’ for Oracle Form
                        6-8                   Sequence Number within Module Type, e.g. 001
 
            i.e. CAROF001
 
Module names and extensions should ALWAYS be in uppercase.
Module Sub-Application Codes

The following Sub-Application Codes should be used in character positions 2-3 when specifying module names.
 
 
Application
Sub-Application Code Description
AI	Interfaces
BA	Batch
BG	Barcode Generation
BI	BACS Interface
CC	Common Code
CF	Core Finance
CL	Common Functions
CO	Collections
CS	Customer Services
DF	Deferments
DM	Data Migration
DS	Debt Sale
GR	General (standing data)
GV	General (validation routines)
HE	HEI Support
HU	HUNTER
IB	Inbound Correspondence
IC	Inter Connect
IR	ICR
JS	Job Scheduler
LA	Loans Administration
LI	Litigation
LO	Grant and Loan Overpayment
LS	LSS
MC	Manual Correspondence
NR	New RTL
PM	Printing and Mailing
PR	Product and Vendor details
RP	RAP
RT	Old RTL
SC	Common Screens
SD	Document Storage
 
Module Type Codes
The following Module Type Codes should be used in character positions 4-5 when specifying file names. 
 
 
Module Type Code
 Description
AW	AWK script
CT	Control file (Loader)
OF	Oracle Forms
PL	Oracle Forms Library
OM 	Oracle Menu
OR 	Oracle Reports
PC 	Oracle Pro*C file
QL	Oracle SQL/ PL/SQL file (.sql extension)
PK    	Oracle Package (.sql extension)
SH  	Unix Shell Script
=========================================================================================================
Strategic Data Warehouse Mirrorred Tables

The following tables are used in SDW CDC mirroring.
As such any changes to the structure of these tables will cause failures in SDW and so the team should be informed when the changes are being made (including a likely release date)
A reminder should also be sent when the code is about to go live
 
Table Names
Icon
ACAD_YRS
ACCOUNT_GROUPINGS
ADDRESSES
AWARD_AUTHORITIES
BUSINESS_TRANSACTIONS
CLASS_REF_CODES
COLLEGES
COURSES
COURSE_ATTENDANCE_HISTORIES
CUSTOMERS
CUSTOMER_CREDIT_BALANCES
DEBT_SALE_LOAN_PROPERTIES
DEBT_SALE_REF_CODES
DECEASED_NOTIFICATIONS
DISABLED_NOTIFICATIONS
EMPLOYMENT_TYPE_HISTORIES
HEI_LOCNS
HEI_TYPES
IR_NOTIFICATIONS
IR_REPAYMENT_NOTIFICATIONS
JOBS
JOB_SCHEDULES
JOURNALS
LOAN_ACCOUNTS
LOAN_ACCOUNT_BALANCES
LOAN_ACCOUNT_TRANSACTIONS
LOAN_ACCOUNT_TRANS_HISTORIES
LOAN_ENTITLEMENTS
LOAN_PACKS
MAINTAIN_DUPLICATE_CUSTOMERS
MANAGEMENT_ACCOUNTS
NINO_STATUS_HISTORIES
OVERSEAS_ASSESSMENTS
PAYMENT_INSTALMENTS
POSTAL_ADDRESS_BOOKS
PROCESS_RULES
PRODUCTS
REPURCHASE_CUSTOMERS
REPURCHASE_LOAN_ACCOUNTS
SELLABLE_CUSTOMERS
SUPPORT_NOTIFICATIONS
TUITION_FEE_ENTITLEMENTS
VENDORS
XXSL_CUSTOMERS
XXSL_REF_CODES
XXSL_SERVICE_DENIAL_PERIODS
=========================================================================================================




=========================================================================================================
=========================================================================================================
=========================================================================================================
=========================================================================================================
=========================================================================================================
=========================================================================================================
=========================================================================================================
=========================================================================================================
=========================================================================================================
=========================================================================================================
=========================================================================================================
=========================================================================================================
=========================================================================================================
=========================================================================================================
=========================================================================================================
=========================================================================================================
=========================================================================================================
=========================================================================================================
=========================================================================================================
=========================================================================================================
=========================================================================================================
=========================================================================================================
=========================================================================================================
=========================================================================================================
=========================================================================================================
=========================================================================================================
=========================================================================================================
=========================================================================================================
=========================================================================================================
=========================================================================================================
=========================================================================================================
=========================================================================================================
=========================================================================================================
=========================================================================================================
=========================================================================================================
=========================================================================================================
=========================================================================================================