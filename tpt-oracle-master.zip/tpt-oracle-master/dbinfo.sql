-- Copyright 2018 Tanel Poder. All rights reserved. More info at http://tanelpoder.com
-- Licensed under the Apache License, Version 2.0. See LICENSE.txt for terms & conditions.

select dbid, name, created, log_mode, checkpoint_change#, open_mode, force_logging from v$database;
