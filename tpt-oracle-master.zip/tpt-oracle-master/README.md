# Tanel Poder's Troubleshooting Scripts (TPT)

These sqlplus scripts are for Oracle Database performance optimization & troubleshooting.
Most of the scripts should be runnable directly from SQL Developer too.

### Getting Started & Videos

To get an idea of how I set up my client environment and use some of my main Oracle-related scripts, check out the videos here:

* [https://www.youtube.com/tanelpoder](https://www.youtube.com/tanelpoder)

Also you can follow me in Twitter as I'll post any noteworthy updates there:

* [https://twitter.com/tanelpoder](https://twitter.com/tanelpoder)

