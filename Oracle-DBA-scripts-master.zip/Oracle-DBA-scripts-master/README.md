    
    
    Download DBA scripts from
    
    https://oracle-base.com/dba/scripts
    
    